#!/bin/sh

DB_USER="azkaban"
DB_PAW='fe@2018'
DBNAME="azkaban" 
DBHOST="10.202.106.185"
DBPORT="3306"

TIME_PAR=$1
FLOW_ID=$2
JOB=$3
JOB_NAME=`echo $JOB|awk  -F '.'  '{print $(NF-1)}'`

echo $TIME_PAR
echo $FLOW_ID
echo $JOB_NAME
##############更新工程时间参数################################
SQL='UPDATE execution_flows
SET para_time='${TIME_PAR}'
WHERE exec_id='${FLOW_ID}';'
/usr/local/mysql/bin/mysql -h${DBHOST} -P${DBPORT} -u${DB_USER} -p${DB_PAW} -e " use ${DBNAME}; ${SQL}"

###############更新作业时间参数###############################
SQL='UPDATE execution_jobs
SET para_time='${TIME_PAR}'
WHERE exec_id='${FLOW_ID}'
    AND JOB_ID="'${JOB_NAME}'";'
/usr/local/mysql/bin/mysql -h${DBHOST} -P${DBPORT} -u${DB_USER} -p${DB_PAW} -e " use ${DBNAME}; ${SQL}"


