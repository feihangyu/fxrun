#!/bin/bash

#作用描述: 生成时间（YYYYMMDD）传入工程
#处理方式：每天运行一次
#创建人  ：陈日蕊
#创建日期：2017/09/01
#传入参数：无


#PROJECTS_NAME=$1
PARAM1="YYYYMMDD="`date -d "0 days" +"%Y%m%d"`
#PARAM2="YYYYMMDDHH="`date -d "0 hours" +"%Y%m%d%H"`
#PROJECTS_NAME="dm_rcmd_radio_feed_back"
#PROJECTS_ID=`echo "select id from azkaban.projects where name='${PROJECTS_NAME}' and active=1 " | go_mysql_hadoop183_3305 |tr '\n' ' ' |awk -F ' ' '{print $2}'`
PROJECTS_ID=$1

echo $PARAM
FILE_PATH=`ls /app/azkaban/executor/projects/${PROJECTS_ID}*/day_time.properties`
for FILE_TMP in $FILE_PATH
  do 
    echo $PARAM1 > $FILE_TMP
    echo $PARAM2 >> $FILE_TMP
  done
