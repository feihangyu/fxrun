
-- 实例1
SELECT task_name,SUBSTRING_INDEX(lists,'/',14) FROM (
SELECT k.task_name,GROUP_CONCAT(k.run_time ORDER BY k.start_time DESC  SEPARATOR '/') AS lists FROM
(
SELECT 
statedate,
task_name,
SUBSTRING_INDEX(loginfo,'%',-1) AS start_time,
createtime AS end_time,
ROUND((TIMESTAMPDIFF(SECOND,SUBSTRING_INDEX(loginfo,'%',-1),createtime))/60,1) AS run_time  
FROM feods.sf_dw_task_log WHERE LEFT(createtime,10)>='2020-03-26' AND loginfo NOT LIKE 'fjr%'
UNION ALL 
SELECT 
statedate,
task_name,
LEFT(RIGHT(loginfo,30),19) AS start_time,
createtime AS end_time,
ROUND((TIMESTAMPDIFF(SECOND,LEFT(RIGHT(loginfo,30),19),createtime))/60,1) AS run_time
FROM feods.sf_dw_task_log WHERE LEFT(createtime,10)>='2020-03-26' AND loginfo LIKE 'fjr%')k
WHERE k.task_name IN (
'sh_zs_goods_damaged',
'sp_op_shelf_user_month_stat',
'dwd_shelf_product_his',
'dwd_shelf_product_day_all',
'sh_shelf_product_flag',
'sp_op_fill_day_sale_qty',
'prc_d_ma_user_flag1',
'sh_member_research_crr_1',
'sh_member_research_crr_2',
'sh_member_research_crr_3',
'sh_member_research_crr_4',
'prc_d_ma_user_flag2',
'dwd_en_fx_consumption_rate_report_to_fhy',
'dm_mp_purchase_sell_stock_summary',
'dm_op_shelf_product_fill_update2',
'dm_op_shelf_product_start_fill_label',
'dwd_group_emp_user_day',
'dwd_order_item_refund_day_inc',
'dwd_shelf_product_day_all_update',
'dwd_staff_score_distribute_detail',
'dwd_update_dwd_table_info',
'prc_d_ma_shelf_sale_daily',
'shelf_product_stock_14days',
'sh_zs_shelf_grade',
'sp_abnormal_nsale_shelf_product',
'sp_op_false_stock_danger_level',
'sp_shelf_product_detail',
'dwd_shelf_product_day_all_update',
'sp_op_false_stock_danger_level',
'dm_op_shelf_product_start_fill_label',
'sp_shelf_product_detail',
'dwd_staff_score_distribute_detail',
'dwd_lsl_shelf_product_abnormal',
'sp_shelf_board',
'prc_d_ma_shelf_sale_daily',
'sp_shelf_board',
'dwd_lo_depot_refund_order',
'sp_op_false_stock_danger_level')
GROUP BY k.task_name
) q
;

-- 实例2
SELECT task_name,SUBSTRING_INDEX(lists,'/',14) FROM (
SELECT task_name,GROUP_CONCAT(run_time ORDER BY start_time DESC SEPARATOR '/') AS lists FROM 
fe_dwd.`dwd_sf_dw_task_log` 
WHERE task_name IN (
'prc_dm_ma_user_perfect_product',
'dm_op_su_shelfcross_stat_eight',
'dwd_shelf_product_day_south_his_four',
'dwd_shelf_product_sto_sal_day30',
'dm_op_product_area_sal_month_large_eight',
'dm_op_order_sku_relation',
'dm_op_offstock_integrate',
'dm_ma_user_life_cycle',
'dm_pub_user_research1',
'dm_pub_user_research2',
'dm_pub_user_research3',
'dm_pub_user_research4',
'dm_op_valid_danger_flag',
'dm_op_offstock2',
'dm_op_offstock_five',
'dm_op_package_config_two',
'dm_shelf_member_flag1',
'dm_shelf_member_flag2',
'dm_op_package_config_two',
'dm_op_su_shelfcross_stat_eight',
'prc_dm_ma_user_perfect_product',
'dm_op_area_high_stock_three',
'dwd_check_base_day_inc_to_dwd',
'dwd_order_item_refund_day_to_dwd',
'dm_ma_shelf_product_flag',
'jwq_sales_flag_weekly',
'dm_shelf_member_flag1',
'dm_shelf_member_flag2',
'dm_op_shelf_product_offstock_association',
'dwd_lo_prewarehouse_fill_order_item_month',
'dm_op_shelf_product_zerosale_monitor',
'dm_ma_autoshelf_kpi',
'dm_shelf_member_flag')
GROUP BY task_name
) q
;