SELECT 
db_name,
SUM(TRUNCATE((total_size+data_free)/1024/1024/1024, 2))  容量
 FROM fe_monitor.t_db_size_his
WHERE gather_date = '2021-03-21'  -- 日期选择最近的一个周日
GROUP BY db_name


-- 查具体的表增量明细
SELECT 
CONCAT(db_name,'.',table_name),
SUM(TRUNCATE((total_size+data_free)/1024/1024/1024, 2))  容量
 FROM fe_monitor.t_table_size_his
WHERE gather_date = '2021-03-21' AND  db_name='fe_dm' -- 日期选择最近的一个周日
GROUP BY CONCAT(db_name,'.',table_name)
 
SELECT 
CONCAT(db_name,'.',table_name),
SUM(TRUNCATE((total_size+data_free)/1024/1024/1024, 2))  容量
 FROM fe_monitor.t_table_size_his
WHERE gather_date = '2021-03-28' AND  db_name='fe_dm' -- 日期选择最近的一个周日
GROUP BY CONCAT(db_name,'.',table_name)


-- 查询某个表近段时间每天的变化
SELECT 
gather_date,
SUM(TRUNCATE((total_size+data_free)/1024/1024/1024, 2))  容量
 FROM fe_monitor.t_table_size_his
WHERE gather_date >= '2021-02-01' AND  db_name='fe_dm' AND table_name='dm_op_shelf_product_fill_update2_his' -- 日期选择最近的一个周日
GROUP BY gather_date


-- 下面的脚本供查询异常数据使用  
  
  
  SET @this_weekend = SUBDATE(CURDATE(),INTERVAL 1 DAY);  -- 一般查询上周日的做对比

   SET @last_weekend = SUBDATE(CURDATE(),INTERVAL 8 DAY);
   SET @last_weekend2 = SUBDATE(CURDATE(),INTERVAL 15 DAY); 
   
-- -- 查询表大小   
-- SELECT 
--  gather_date,
-- db_name,
-- SUM(TRUNCATE((total_size+data_free)/1024/1024/1024, 2))  容量
-- FROM fe_monitor.t_db_size_his
-- WHERE gather_date ='2020-12-06'
-- GROUP BY gather_date,db_name
-- ORDER BY db_name
-- 

-- 查询增长最大的表

DROP TEMPORARY TABLE IF EXISTS fe_dwd.dwd_lsl_tmp_1;
CREATE TEMPORARY TABLE fe_dwd.dwd_lsl_tmp_1 AS
SELECT a.db_name,a.table_name,a.size - b.size AS diff_size
FROM
(
SELECT 
 gather_date,
 db_name,
table_name,
SUM(TRUNCATE((total_size+data_free)/1024/1024/1024, 2))  size
FROM fe_monitor.t_table_size_his
WHERE gather_date =@this_weekend
AND db_name = 'fe_history'
GROUP BY gather_date,db_name,table_name
) a
JOIN 
(
SELECT 
 gather_date,
 db_name,
table_name,
SUM(TRUNCATE((total_size+data_free)/1024/1024/1024, 2))  size
FROM fe_monitor.t_table_size_his
WHERE gather_date =@last_weekend
AND db_name = 'fe_history'
GROUP BY gather_date,db_name,table_name
) b
ON a.db_name = b.db_name 
AND  a.table_name = b.table_name 
WHERE a.size - b.size > 0.1
;

-- 查询出这两周增量较大的表
SELECT * FROM fe_dwd.dwd_lsl_tmp_1 ORDER BY diff_size DESC 


sf_prewarehouse_stock_record_11  -- 6.24
user_member_wallet_log  -- 5.13
sf_shelf_product_weeksales_detail  -- 3.54

-- 查一下数据是否波动比较大

SELECT COUNT(*) FROM fe.sf_shelf_product_weeksales_detail 
WHERE add_time >=  SUBDATE(@this_weekend,INTERVAL -1 DAY)
AND add_time < SUBDATE(@this_weekend,INTERVAL -2 DAY)
UNION ALL
SELECT COUNT(*) FROM fe.sf_shelf_product_weeksales_detail 
WHERE add_time >= SUBDATE(@last_weekend,INTERVAL -1 DAY)
AND add_time < SUBDATE(@last_weekend,INTERVAL -2 DAY)
UNION ALL
SELECT COUNT(*) FROM fe.sf_shelf_product_weeksales_detail 
WHERE add_time >=SUBDATE(@last_weekend2,INTERVAL -1 DAY)
AND add_time < SUBDATE(@last_weekend2,INTERVAL -2 DAY)


-- 该表查出来的数据仅能做参考使用。实际以唐进查询数据库的磁盘使用空间为主。
-- 这个用来做监控使用。发现有异常及时查询一下。

