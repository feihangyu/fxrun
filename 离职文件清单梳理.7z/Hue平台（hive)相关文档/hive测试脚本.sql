set hive.compute.query.using.stats=false;
set hive.strict.checks.type.safety = false;

-- mysql  1min37sec
-- 每天全量更新结果表
TRUNCATE TABLE fezs.dwd_group_emp_user_day; 

drop TABLE if exists fezs.dwd_group_emp_user_1_1 ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_1_1  AS 
SELECT 
emp_user_id,
group_customer_id
FROM fezs.sf_group_emp a 
WHERE a.group_customer_id = 4726;

-- 正常的数据
drop TABLE if exists fezs.dwd_group_emp_user_1_2 ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_1_2  AS 
SELECT 
emp_user_id,
group_customer_id
FROM fezs.sf_group_emp a 
WHERE a.group_customer_id != 4726
AND  a.data_flag = 1;


-- 通过扫码支付的这部分，有些data_flag =2 的也能下单，需要补上这些用户。
drop TABLE if exists fezs.dwd_group_emp_user_1_3_tmp ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_1_3_tmp  AS
SELECT DISTINCT b.order_user_id
FROM fezs.sf_scan_order b 
UNION 
SELECT DISTINCT a.order_user_id
FROM fezs.sf_group_order a;

drop TABLE if exists fezs.dwd_group_emp_user_1_3 ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_1_3  AS  
SELECT 
a.emp_user_id,
a.group_customer_id
FROM fezs.dwd_group_emp_user_1_3_tmp aa
JOIN fezs.sf_group_emp a  -- 员工信息
ON aa.order_user_id = a.customer_user_id
WHERE a.data_flag =2;

drop TABLE if exists fezs.dwd_group_emp_user_1_5 ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_1_5 AS
SELECT * FROM fezs.dwd_group_emp_user_1_1
UNION 
SELECT * FROM fezs.dwd_group_emp_user_1_2
UNION  
SELECT * FROM fezs.dwd_group_emp_user_1_3
;

drop TABLE if exists fezs.dwd_group_emp_user_1 ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_1  AS  
SELECT 
 aa.emp_user_id
,a.customer_user_id  -- 丰声号ID
,aa.group_customer_id   -- 4726
,d.group_name 
,e.group_customer_id AS group_customer_id_sub  -- 企业id 
,e.group_name AS group_name_sub                -- 企业名称
,a.user_role
,a.bind_status
,a.manager_status
,a.emp_user_name
,a.sex
,a.mobile
,a.mobile_encrypt
,a.dept_id
,a.duties
,a.dept
-- ,a.dept_higher
,a.professional_level
,a.job_number
,LPAD(a.job_number, 8, '0') job_number_lpad
,a.ltrim_job_number
,a.group_email
,a.birthday
,a.joindate
,a.cancel_flag
,a.cancel_date
,a.add_time
,a.data_flag
,a.from_type
,a.bindtime
,a.remark
,a.nick
FROM fezs.dwd_group_emp_user_1_5 aa
LEFT JOIN fezs.sf_group_emp a  -- 员工信息
ON aa.emp_user_id = a.emp_user_id
LEFT JOIN fezs.sf_group_emp_extend b ON a.emp_user_id = b.emp_user_id --  AND b.data_flag = 1                         -- 员工信息扩展表 员工id关联 不发散
LEFT JOIN fezs.sf_group_auth c ON c.auth_id=b.auth_id -- AND c.data_flag=1                                           -- 人事权限 人事权限id关联 不发散
LEFT JOIN fezs.`sf_group_customer` d ON a.group_customer_id = d.group_customer_id -- AND d.data_flag=1               -- 企业信息表 企业ID关联 不发散
LEFT JOIN fezs.`sf_group_customer` e ON c.bind_group_customer_id = e.group_customer_id  -- AND e.data_flag=1         -- 企业信息表
;

drop TABLE if exists fezs.dwd_group_emp_user_2 ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_2  AS
SELECT DISTINCT a.emp_code job_number,     -- 工号
a.position_attr,                           -- 岗位属性
a.org_name,                                -- 组织全称
a.parent_org_name,                         -- 上级组织全称
a.division_code,                           -- 分部代码
a.division_name ,                        -- 分部名称
a.bukrs_txt
FROM fezs.dwd_group_emp_user_1 b  
JOIN fezs.`sap_pmp_hos_emp_base_info` a   -- SAP/PMP/HOS员工基础信息表
ON b.job_number_lpad= a.emp_code;


drop TABLE if exists fezs.dwd_group_emp_user_3 ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_3 AS 
SELECT DISTINCT a.user_id customer_user_id,a.mobile_phone,a.open_id,
a.OPEN_TYPE 
FROM 
  (SELECT user_id,max(mobile_phone) as mobile_phone,max(open_id) as open_id,concat_ws('/',collect_list(open_type)) AS OPEN_TYPE 
   FROM fezs.pub_user_open   -- 平台用户信息   
   WHERE data_flag = 1
   GROUP BY user_id
   ) a
JOIN fezs.dwd_group_emp_user_1 b
ON a.user_id = b.customer_user_id
;

drop TABLE if exists fezs.dwd_group_emp_user_4 ;
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_4  AS  
SELECT DISTINCT
a.emp_user_id
,a.customer_user_id  -- 丰声号ID
,a.group_customer_id
,a.group_name 
,a.group_customer_id_sub 
,a.group_name_sub 
,a.user_role
,a.bind_status
,a.manager_status
,a.emp_user_name
,a.sex
,a.mobile
,a.mobile_encrypt
,c.OPEN_TYPE
,c.open_id
,a.dept_id
,a.duties
,IF(a.dept is null,b.org_name,a.dept) dept  -- 员工表提取不到组织信息，取大网信息。但是dept_id两者不同，不能替换
,b.parent_org_name
,b.division_code
,b.division_name
,a.professional_level
,b.position_attr
,b.bukrs_txt
,a.job_number
,a.ltrim_job_number
,a.group_email
,a.birthday
,a.joindate
,a.cancel_flag
,a.cancel_date
,a.add_time
,a.data_flag
,a.from_type
,a.bindtime
,a.remark
,a.nick
FROM fezs.dwd_group_emp_user_1 a
LEFT JOIN fezs.dwd_group_emp_user_2 b      -- 获取员工岗位 组织及分部信息
ON a.job_number = b.job_number               
LEFT JOIN fezs.dwd_group_emp_user_3 c      -- 获取平台用户信息
ON a.customer_user_id = c.customer_user_id
;

DROP TABLE IF EXISTS fezs.`dwd_group_emp_user_5_0`; 
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_5_0 AS
SELECT DISTINCT e.emp_user_id
FROM  fezs.dwd_group_emp_user_1 e
WHERE e.group_customer_id=4726
;

DROP TABLE IF EXISTS fezs.`dwd_group_emp_user_5`; 
CREATE TEMPORARY TABLE fezs.dwd_group_emp_user_5 AS
SELECT DISTINCT d.customer_user_id
FROM fezs.sf_group_distribute_plan_detail d
JOIN fezs.sf_group_distribute_plan p 
ON p.distribute_plan_id = d.distribute_plan_id
AND p.data_flag=1
JOIN fezs.dwd_group_emp_user_5_0 e 
ON e.emp_user_id = d.emp_user_id
WHERE d.data_flag=1 
AND p.distribute_time >='2019-09-24'  -- 丰享开始派发的最初时间,必须添加上去，否则会把历史错误数据添加进去
AND d.customer_user_id IS NOT NULL 
;


INSERT INTO fezs.dwd_group_emp_user_day
SELECT 
 a.emp_user_id
,a.customer_user_id
,a.group_customer_id
,a.group_name
,IF(a.group_customer_id_sub is NULL,a.group_customer_id,a.group_customer_id_sub) group_customer_id_sub
,IF(a.group_name_sub is NULL,a.group_name,a.group_name_sub) group_name_sub
,a.user_role
,a.bind_status
,a.manager_status
,a.emp_user_name
,a.sex
,a.mobile
,a.OPEN_TYPE
,a.OPEN_ID
,a.dept_id
,a.duties
,a.dept
,a.parent_org_name
,a.division_code
,a.division_name
,a.professional_level
,a.position_attr
,a.bukrs_txt
,a.job_number
,a.ltrim_job_number
,a.group_email
,a.birthday
,a.joindate
,a.cancel_flag
,a.cancel_date
,a.add_time
,a.data_flag
,a.from_type
,a.bindtime
,a.remark
,a.nick
,IF(b.customer_user_id IS NULL,'0','1') is_fengxiang
,current_timestamp() as load_time
FROM fezs.dwd_group_emp_user_4 a 
LEFT JOIN fezs.dwd_group_emp_user_5 b
ON a.customer_user_id = b.customer_user_id
 ;

