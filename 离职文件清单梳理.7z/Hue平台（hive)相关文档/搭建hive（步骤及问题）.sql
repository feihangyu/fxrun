# chgrp  -R groupb filea      --改变filea所属群组 -R处理指定目录以及其子目录下的所有文件
chown -R myy fileb --修改fileb的拥有者为myy
chmod 755 file.txt  -- 修改文件权限


make apps 是安装app所需得依赖包
su Sf.fezs1234 -- 切换到root权限
su analyze  -- 切换到analyze用户


-- /etc/hosts
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
10.227.96.27 azkaban
10.227.96.23 hadoop-01
10.227.96.24 hadoop-02

ssh 10.227.96.27
ywzb@2020
 

scp -r /home/analyze/hadoop analyze@hadoop-01:/home/analyze
scp -r /home/analyze/hadoop analyze@hadoop-02:/home/analyze
scp -r /home/analyze/apache-tomcat-6.0.47.tar.gz analyze@10.227.96.27:/home/analyze/oozie/oozie-4.3.0/distro/downloads

scp /home/analyze/oozie-4.3.0.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp -r ext-2.2.zip   analyze@10.227.96.27:/home/analyze/oozie_4.3.0/oozie-4.3.0/libext
scp -r /home/analyze/scala analyze@hadoop-01:/home/analyze
scp -r /home/analyze/scala analyze@hadoop-02:/home/analyze

scp -r /home/analyze/spark analyze@hadoop-01:/home/analyze
scp -r /home/analyze/spark analyze@hadoop-02:/home/analyze

scp /home/analyze/hadoop/apache-zookeeper-3.5.8-bin.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/ixdba/etc.tar.gz root@192.168.60.168:/tmp
scp /home/analyze/hadoop/hadoop-2.8.5.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/hadoop/hbase-2.2.5-bin.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/hadoop/apache-hive-2.3.7-bin.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/hadoop/mysql-connector-java-5.1.47.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/hadoop/sqoop-1.4.7.bin__hadoop-2.6.0.tar analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/apache-hive-2.3.7-src.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/apache-hive-2.3.2-src.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/apache-ant-1.10.9-bin.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/scala-2.13.4.tgz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/spark-2.4.7-bin-hadoop2.7.tgz analyze@10.227.96.27:/home/analyze/softwares

scp /home/analyze/hive-1.1.0-cdh5.4.0-src.tar.gz analyze@10.227.96.27:/home/analyze/softwares
scp /home/analyze/apache-hive-2.1.1-src.tar.gz analyze@10.227.96.27:/home/analyze/softwares

scp /home/analyze/hue-4.2.0.tgz analyze@10.227.96.27:/home/analyze/softwares


scp /home/analyze/hadoop/hadoop-2.8.5.tar.gz analyze@10.227.96.23:/home/analyze/softwares
scp /home/analyze/hadoop/hadoop-2.8.5.tar.gz analyze@10.227.96.24:/home/analyze/softwares


scp /home/analyze/sqoop-1.99.5-bin-hadoop200.tar.gz analyze@10.227.96.27:/home/analyze/softwares


scp /home/analyze/hadoop/apache-hive-1.2.2-bin.tar.gz analyze@10.227.96.27:/home/analyze/softwares

mv apache-ant-1.10.9 /home/analyze/ant-1.10.9

export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export PATH=$PATH:$HADOOP_HOME/bin:$HADOOP_HOME/sbin

vim /home/analyze/hadoop/hadoop-2.8.5  hadoop-env.sh


/home/analyze/hadoop/hadoop-2.8.5/etc/hadoop




/home/analyze/hadoop/hadoop-2.8.5

cat ~/.bash_profile
source ~/.bash_profile
export JAVA_HOME=/app/jdk1.8.0_192
export PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/jre/lib/tools.jar
export PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH:$HOME/bin

source ~/.bash_profile


export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_HOME/lib/native
export PATH="$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH"
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop


 
mkdir  /home/analyze/hadoop/hadoop-2.8.5/tmp  
mkdir  /home/analyze/hadoop/hadoop-2.8.5/var  
mkdir  /home/analyze/hadoop/hadoop-2.8.5/dfs  
mkdir  /home/analyze/hadoop/hadoop-2.8.5/dfs/name  
mkdir  /home/analyze/hadoop/hadoop-2.8.5/dfs/data

-- 3.3.3修改 core-site.xml
-- master
<configuration>
<property>
        <name>hadoop.tmp.dir</name>
        <value>/home/analyze/hadoop/hadoop-2.8.5/tmp</value>
        <description>Abase for other temporary directories.</description>
   </property>
   <property>
        <name>fs.default.name</name>
        <value>hdfs://10.227.96.27:8100</value>   -- 9000 改为8100
   </property>
</configuration>


-- salve1
<configuration>
<property>
        <name>hadoop.tmp.dir</name>
        <value>/home/analyze/hadoop/hadoop-2.8.5/tmp</value>
        <description>Abase for other temporary directories.</description>
   </property>
   <property>
        <name>fs.default.name</name>
        <value>hdfs://10.227.96.23:8100</value>   -- 9000 改为8100
   </property>
</configuration>


-- salve2
<configuration>
<property>
        <name>hadoop.tmp.dir</name>
        <value>/home/analyze/hadoop/hadoop-2.8.5/tmp</value>
        <description>Abase for other temporary directories.</description>
   </property>
   <property>
        <name>fs.default.name</name>
        <value>hdfs://10.227.96.24:8100</value>   -- 9000 改为8100
   </property>
</configuration>

-- 3.3.4修改 hadoop-env.sh
export JAVA_HOME=/app/jdk1.8.0_192
-- 3.4.5修改 hdfs-site.xml

<property>
   <name>dfs.name.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/name</value>
   <description>Path on the local filesystem where theNameNode stores the namespace and transactions logs persistently.</description>
</property>
<property>
   <name>dfs.data.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/data</value>
   <description>Comma separated list of paths on the localfilesystem of a DataNode where it should store its blocks.</description>
</property>
<property>
   <name>dfs.replication</name>
   <value>1</value>
</property>
<property>
      <name>dfs.permissions</name>
      <value>false</value>
      <description>need not permissions</description>
</property>

说明：dfs.permissions 配置为false后，可以允许不要检查权限就生成dfs上的文件，方便倒是方便了，但是你需要防止误删除，请将它设置为true，或者直接将该property节点删除，因为默认就是true。
-- 3.4.6 修改mapred-site.xml


<property>
    <name>mapred.job.tracker</name>
    <value>10.227.96.27:8001</value>  -- 9001 改为8001
</property>
<property>
      <name>mapred.local.dir</name>
       <value>/home/analyze/hadoop/hadoop-2.8.5/var</value>
</property>
<property>
       <name>mapreduce.framework.name</name>
       <value>yarn</value>
</property>






-- 端口不在范围内需修改 hdfs-site.xml 这里修改hdfs相关的端口。

-- 端口选择 5000-5300
<property>
<name>dfs.namenode.secondary.http-address</name>
<value>10.227.96.27:5090</value>
</property>
<property>
<name>dfs.datanode.address</name>
<value>0.0.0.0:50010</value>
</property>
<property>
<name>dfs.datanode.http.address</name>
<value>0.0.0.0:50075</value>
</property>
<property>
<name>dfs.namenode.http-address</name>
<value>10.227.96.27:5070</value>
</property>
<property>
<name>dfs.datanode.ipc.address</name>
<value>0.0.0.0:50020</value>
</property>


#MYSQL_HOME
export MYSQL_HOME=/app/mysql
export PATH=$MYSQL_HOME/bin:$PATH

二、配置系统环境变量
修改/etc/profile文件 文件末尾加入  -- ~/.bash_profile
export HADOOP_HOME=/opt/modules/hadoop-2.8.2
export PATH=$PATH:$HADOOP_HOME/bin:$HADOOP_HOME/sbin

刷新profile，使配置生效  -- ~/.bash_profile
source /etc/profile

 三、配置hadoop环境变量

所有hadoop配置文件都在安目录的 etc/hadoop中
-- 修改hadoop-env.sh
-- 修改mapred-env.sh
-- 修改yarn-env.sh
加入java路径

-- 修改 core-site.xml 加入
-- fs.defaultFS/fs.default.name  HDFS默认访问路径
-- hadoop.temp.dir  Hadoop数据缓存路径
<configuration>
    <property>
        <name>fs.default.name</name>
        <value>hdfs://10.227.96.27:8100</value>  -- HDFS默认访问路径 hdfs://10.227.96.27:9000  改为 8100
    </property>
    <property>
        <name>hadoop.temp.dir</name>  -- 
        <value>file:/home/analyze/hadoop/hadoop-2.8.5/tmp</value>  -- Hadoop数据缓存路径
    </property>
</configuration>


8、打开hadoop/etc/hadoop/mapred-site.xml文件，编辑如下：
默认情况下，/usr/local/hadoop/etc/hadoop/文件夹下有mapred.xml.template文件，我们要复制该文件，并命名为mapred.xml，该文件用于指定MapReduce使用的框架。
cp mapred-site.xml.template mapred-site.xml  -- //复制并重命名

<configuration>    
  <property>     
     <name>mapred.job.tracker</name>    
     <value>localhost:9001</value>     
  </property>    
</configuration>
 

9.打开hadoop/etc/hadoop/hdfs-site.xml文件，编辑如下
<configuration>  
    <property>  
        <name>dfs.name.dir</name>  
        <value>/home/analyze/hadoop/hadoop-2.8.5/namenode</value>  
    </property>  
    <property>  
        <name>dfs.data.dir</name>  
        <value>/home/analyze/hadoop/hadoop-2.8.5/datanode</value>  
    </property>  
    <property>  
        <name>dfs.replication</name>  
        <value>1</value>  
    </property>  
</configuration> 


修改 hdfs-site.xml 加入
-- dfs.replication    文件在hdfs系统中的副本数
-- dfs.permissions.enabled  是否检查用户权限
-- dfs.namenode.name.dir  NameNode节点数据在本地文件系统存放位置
-- dfs.datanode.data.dir      DataNode节点数据在本地文件系统存放位置

<configuration>
    <property>
        <name>dfs.replication</name>
        <value>1</value>
    </property>
    <property>
        <name>dfs.permissions.enabled</name>
        <value>false</value>
    </property>
    <property>
        <name>dfs.namenode.name.dir</name>
        <value>file:/home/analyze/hadoop/hadoop-2.8.5/tmp/dfs/name</value>
    </property>
    <property>
       <name>dfs.datanode.data.dir</name>
        <value>file:/home/analyze/hadoop/hadoop-2.8.5/tmp/dfs/data</value>
    </property>
</configuration>


格式化hdfs文件系统
进入hadoop目录下，格式化hdfs文件系统，初次运行hadoop时一定要有该操作
bin/hadoop namenode -format

2、启动hdfs
cd /usr/local/hadoop 
./sbin/start-dfs.sh ﻿​    可以通过浏览器访问：http://127.0.0.1:5070/，选择“Browse the file system”：
停止hdfs
./sbin/stop-dfs.sh

ssh 10.227.96.27
ywzb@2020



、快捷启动配置
//配置hadoop环境变量
sudo gedit /etc/profile  

export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export PATH="$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH"
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop

-- 将文件上传到hdfs的根目录
 bin/hadoop fs -put words.txt /
 
-- 配置启动yarn (运行在hdfs上，mapreduce运行在yarn之上）
①配置etc/hadoop/mapred-site.xml：
<configuration>
    <!-- 通知框架MR使用YARN -->
    <property>
        <name>mapreduce.framework.name</name>
        <value>yarn</value>
    </property>
</configuration>
②配置etc/hadoop/yarn-site.xml:
<configuration>
    <!-- reducer取数据的方式是mapreduce_shuffle -->
    <property>
        <name>yarn.nodemanager.aux-services</name>  
        <value>mapreduce_shuffle</value>
    </property>
</configuration>

-- org.apache.hadoop.yarn.exceptions.InvalidAuxauxServiceException:auxServices:mapreduce_shuffle does not exists 解决方法
<property>
    <name>yarn.nodemanager.aux-services</name>
    <value>mapreduce_shuffle</value>
</property>
<property>
    <name>yarn.nodemanager.aux-services.mapreduce.shuffle.class</name>
    <value>org.apache.hadoop.mapred.ShuffleHandler</value>
</property>

*注意：在master和slave所有的主从机器上都需要修改这个文件，修改后重启即可，不用格式化（hadoop namenode -format）

③YARN的启动与停止
//启动  测试用浏览器访问： http://127.0.0.1:8088/cluster/
./sbin/start-yarn.sh
停止
./sbin/stop-yarn.sh


ssh 10.227.96.27
ywzb@2020
-- 运行一个简单的字符计数程序
 bin/hadoop fs -put words.txt /
 bin/hadoop   jar   /home/analyze/hadoop/hadoop-2.8.5/share/hadoop/mapreduce/hadoop-mapreduce-examples-2.8.5.jar  wordcount   hdfs://10.227.96.27:8100/words.txt   hdfs://10.227.96.27:8100/out
 
 

1、hdfs-site.xml 这里修改hdfs相关的端口。

-- 端口选择 5000-5300
<property>
<name>dfs.namenode.secondary.http-address</name>
<value>10.227.96.27:5090</value>
</property>
<property>
<name>dfs.datanode.address</name>
<value>10.227.96.27:5010</value>  -- 0.0.0.0 换成  10.227.96.27
</property>
<property>
<name>dfs.datanode.http.address</name>
<value>10.227.96.27:5075</value>  -- 0.0.0.0 换成  10.227.96.27
</property>
<property>
<name>dfs.namenode.http-address</name>
<value>10.227.96.27:5070</value>
</property>
<property>
<name>dfs.datanode.ipc.address</name>  -- 0.0.0.0 换成  10.227.96.27
<value>10.227.96.27:5020</value>
</property>

http://127.0.0.1:5075/webhdfs/v1/out/part-r-00000?op=OPEN&namenoderpcaddress=10.227.96.27:8100&offset=0


-- NameNode     50070   dfs.namenode.http-address   http服务的端口
<property>
<name>dfs.namenode.secondary.http-address</name>
<value>node01:5001</value>  -- 50090
</property>
<property>
<name>dfs.datanode.address</name>
<value>0.0.0.0:5002</value>  -- 50010  org.apache.hadoop.hdfs.server.datanode.DataNode: Opened streaming server at /0.0.0.0:50010
</property>
<property>
<name>dfs.datanode.http.address</name>
<value>0.0.0.0:5003</value>  -- 默认为 50075  org.apache.hadoop.hdfs.server.datanode.web.DatanodeHttpServer: Listening HTTP traffic on /0.0.0.0:50075
</property>
<property>
<name>dfs.namenode.http-address</name>
<value>node01:5004</value>  -- 50070
</property>
<property>
<name>dfs.datanode.ipc.address</name>  -- org.apache.hadoop.hdfs.server.datanode.DataNode: Opened IPC server at /0.0.0.0:50020
<value>0.0.0.0:5005</value>  -- 50020
</property>

用于访问和监控Hadoop系统运行状态

Daemon	缺省端口	配置参数
HDFS	Namenode	50070	dfs.http.address
Datanodes	50075	dfs.datanode.http.address   -- org.apache.hadoop.hdfs.server.datanode.web.DatanodeHttpServer: Listening HTTP traffic on /0.0.0.0:50075
Secondarynamenode	50090	dfs.secondary.http.address
Backup/Checkpoint node*	50105	dfs.backup.http.address
MR	Jobracker	50030	mapred.job.tracker.http.address
Tasktrackers	50060	mapred.task.tracker.http.address
HBase	HMaster	60010	hbase.master.info.port
HRegionServer	60030	hbase.regionserver.info.port


3.内部端口
Daemon	缺省端口	配置参数	协议	用于
Namenode	9000	fs.default.name	IPC: ClientProtocol	Filesystem metadata operations.
Datanode	50010	dfs.datanode.address	Custom Hadoop Xceiver: DataNodeand DFSClient	DFS data transfer  -- org.apache.hadoop.hdfs.server.datanode.DataNode: Opened streaming server at /0.0.0.0:50010
Datanode	50020	dfs.datanode.ipc.address	IPC:InterDatanodeProtocol,ClientDatanodeProtocol  -- org.apache.hadoop.hdfs.server.datanode.DataNode: Opened IPC server at /0.0.0.0:50020
ClientProtocol	Block metadata operations and recovery
Backupnode	50100	dfs.backup.address	同 namenode	HDFS Metadata Operations
Jobtracker	9001	mapred.job.tracker	IPC:JobSubmissionProtocol,InterTrackerProtocol	Job submission, task tracker heartbeats.
Tasktracker	127.0.0.1:0*	mapred.task.tracker.report.address	IPC:TaskUmbilicalProtocol	和 child job 通信
* 绑定到未用本地端口


-- yarn 8088页面报 Inspectable WebContents 查看yarn-log日志发现问题是 ： ERROR org.apache.hadoop.yarn.server.resourcemanager.ResourceManager: RECEIVED SIGNAL 15: SIGTERM

在8088端口查看不到任何Nodes的信息，提交任务到集群，任务一直卡在Accepted状态。

解决方法：在yarn-site.xml添加如下配置参数:

即：指定yarn.resourcemanager.hostname为Master节点的IP。


    <property>
        <name>yarn.resourcemanager.hostname</name>
        <value>10.227.96.27</value>
    </property>


2.原因
单个任务可申请的默认最大内存为1024M，任务执行实际需要1384M个，需要增加可申请的内存量，修改配置参数如下图。

3.解决方法
修改对应参数

#MR ApplicationMaster占用的内存量
yarn.app.mapreduce.am.resource.mb =4g
#单个节点上金额分配的物理内存总量
yarn.nodemanager.resource.memory-mb=8g
#单个任务可申请的最多物理内存量
yarn.scheduler.maximum-allocation-mb=4g

解决方法如下
在yarn-site.xml中添加：
<!-- 设置RM内存资源配置，两个参数 -->
<property>
    <description>The minimum allocation for every container request at the RM,
        in MBs. Memory requests lower than this won't take effect,
        and the specified value will get allocated at minimum.</description>
    <name>yarn.scheduler.minimum-allocation-mb</name>
    <value>1024</value>
</property>
<property>
    <description>The maximum allocation for every container request at the RM,
        in MBs. Memory requests higher than this won't take effect,
        and will get capped to this value.</description>
    <name>yarn.scheduler.maximum-allocation-mb</name>
    <value>4096</value>
</property>

<!-- 前者表示单个节点可用的最大内存，RM中的两个值都不应该超过该值。后者表示虚拟内存率，即占task所用内存的百分比，默认为2.1.-->
<property>
    <description>Amount of physical memory, in MB, that can be allocated
        for containers.</description>
    <name>yarn.nodemanager.resource.memory-mb</name>
    <value>8192</value>
</property>
<property>
    <description>Ratio between virtual memory to physical memory when
        setting memory limits for containers. Container allocations are
        expressed in terms of physical memory, and virtual memory usage
        is allowed to exceed this allocation by this ratio.
    </description>
    <name>yarn.nodemanager.vmem-pmem-ratio</name>
    <value>2.1</value>
</property>
<property>
    <description>Amount of physical memory, in MB, that can be allocated
        for containers.</description>
    <name>yarn.app.mapreduce.am.resource.mb</name>
    <value>4096</value>
</property>







-- 原有yarn-site.xml配置
<property>
    <name>yarn.nodemanager.aux-services</name>
    <value>mapreduce_shuffle</value>
</property>
<property>
    <name>yarn.nodemanager.aux-services.mapreduce.shuffle.class</name>
    <value>org.apache.hadoop.mapred.ShuffleHandler</value>
</property>
<property>
    <name>yarn.nodemanager.resource.memory-mb</name>
    <value>20480</value>
</property>
<property>
   <name>yarn.scheduler.minimum-allocation-mb</name>
   <value>2048</value>
</property>
<property>
     <name>yarn.nodemanager.vmem-pmem-ratio</name>
     <value>2.1</value>
 </property>



-- 集群
<property>
     <name>yarn.resourcemanager.hostname</name>
     <value>azkaban</value>
</property>
<property>
     <name>yarn.resourcemanager.address</name>
     <value>${yarn.resourcemanager.hostname}:8032</value>
</property>
<property>
     <description>The address of the scheduler interface.</description>
     <name>yarn.resourcemanager.scheduler.address</name>
     <value>${yarn.resourcemanager.hostname}:8030</value>
</property>
<property>
     <description>The http address of the RM web application.</description>
     <name>yarn.resourcemanager.webapp.address</name>
     <value>${yarn.resourcemanager.hostname}:8088</value>
</property>
<property>
     <description>The https adddress of the RM web application.</description>
     <name>yarn.resourcemanager.webapp.https.address</name>
     <value>${yarn.resourcemanager.hostname}:8090</value>   -- 可能会和hue 端口产生冲突
</property>
<property>
     <name>yarn.resourcemanager.resource-tracker.address</name>
     <value>${yarn.resourcemanager.hostname}:8031</value>
</property>
<property>
     <description>The address of the RM admin interface.</description>
     <name>yarn.resourcemanager.admin.address</name>
     <value>${yarn.resourcemanager.hostname}:8033</value>
</property>
<property>
     <name>yarn.nodemanager.aux-services</name>
     <value>mapreduce_shuffle</value>
</property>
<property>
 <name>yarn.nodemanager.aux-services.mapreduce.shuffle.class</name>
 <value>org.apache.hadoop.mapred.ShuffleHandler</value>
</property>
<property>
     <name>yarn.scheduler.maximum-allocation-mb</name>
     <value>8182</value>
     <discription>每个节点可用内存,单位MB,默认8182MB</discription>
</property>
<property>
     <name>yarn.nodemanager.vmem-pmem-ratio</name>
     <value>2.1</value>
</property>
<property>
     <name>yarn.nodemanager.resource.memory-mb</name>
     <value>2048</value>
</property>
<property>
     <name>yarn.nodemanager.vmem-check-enabled</name>
     <value>false</value>
</property>


-- 3.5.2.6 修改slaves
设置主从的配置。如果不设置这个，集群就无法得知主从了。如果是单机模式，就没必要配置了。
修改/opt/hadoop/hadoop2.8/etc/hadoop/slaves文件
更改为

hadoop-01 
hadoop-02

-- 问题：Hadoop：分布式集群搭建成功但livenode为0，从salver的datanode的log中可以看出一直在尝试连自己
在salver 的core-site.xml 中修改
   <property>
        <name>fs.default.name</name>
        <value>hdfs://10.227.96.27:8100</value>  -- 此处需要和master的保持一致
</property>

-- 问题：集群启动hdfs后 salver上没有看到datanode
解决办法：修改 vim hdfs-site.xml
对应的ip修改为本机器ip
<property>
<name>dfs.namenode.secondary.http-address</name>
<value>10.227.96.24:5090</value>
</property>
<property>
<name>dfs.datanode.address</name>
<value>10.227.96.24:5010</value>
</property>
<property>
<name>dfs.datanode.http.address</name>
<value>10.227.96.24:5075</value>
</property>
<property>
<name>dfs.namenode.http-address</name>
<value>10.227.96.24:5070</value>
</property>
<property>
<name>dfs.datanode.ipc.address</name>
<value>10.227.96.24:5020</value>
</property>
</configuration>


-- 问题：在5070页面出现权限不够的情况，执行以下命令
hdfs dfs -chmod -R 777 /tmp

-- 问题：on HDFS should be writable. Current permissions are: rwxr-xr-x 执行一下命令
hdfs dfs -chmod 777 /对应的路径

hdfs dfs -chmod -R 777 /home/analyze/hive/hive2.3/hive/tangjin1

-- 安装hbase
-- 环境配置 编辑 /etc/profile 文件
vim ~/.bash_profile
export HBASE_HOME=/home/analyze/hbase/hbase-2.2.5
export PATH=.:${JAVA_HOME}/bin:${HADOOP_HOME}/bin:${HBASE_HOME}/bin:$PATH


mkdir  /home/analyze/hbase/hbase-2.2.5 
mkdir  /home/analyze/hbase/hbase-2.2.5/tmp  
mkdir  /home/analyze/hbase/hbase-2.2.5/pids

-- 3.2.2.1 修改hbase-env.sh
export JAVA_HOME=/app/jdk1.8.0_192
export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HBASE_HOME=/home/analyze/hbase/hbase-2.2.5
export HBASE_CLASSPATH=/home/analyze/hadoop/hadoop-2.8.5/etc/hadoop
export HBASE_PID_DIR=/home/analyze/hbase/hbase-2.2.5/pids
export HBASE_MANAGES_ZK=false  #HBASE_MANAGES_ZK=false 是不启用HBase自带的Zookeeper集群。
-- 3.2.2.2 修改 hbase-site.xml 

<!-- 存储目录 -->
<property>  
 <name>hbase.rootdir</name>  
 <value>hdfs://10.227.96.27:8100/hbase</value>           -- 9000 改为8100
 <description>The directory shared byregion servers.</description>  
</property>  
<!-- hbase的端口 -->
<property>  
 <name>hbase.zookeeper.property.clientPort</name>  
 <value>2181</value>  
 <description>Property from ZooKeeper config zoo.cfg. The port at which the clients will connect.</description>  
</property>  
<!--  超时时间 -->
<property>  
 <name>zookeeper.session.timeout</name>  
 <value>120000</value>  
</property>  
<!--  zookeeper 集群配置。如果是集群，则添加其它的主机地址 -->
<property>  
 <name>hbase.zookeeper.quorum</name>  
 <value>10.227.96.27</value>  
</property>  
<property>  
 <name>hbase.tmp.dir</name>  
 <value>/home/analyze/hbase/hbase-2.2.5/tmp</value>  
</property>  
<!-- false是单机模式，true是分布式模式  -->
<property>  
 <name>hbase.cluster.distributed</name>  
 <value>false</value>  
</property>



-- 单机线上配置
  <property>
    <name>hbase.unsafe.stream.capability.enforce</name>
    <value>false</value>
  </property>

<!-- 存储目录 -->
<property>
 <name>hbase.rootdir</name>
 <value>hdfs://10.227.96.27:8100/hbase</value>
 <description>The directory shared byregion servers.</description>
</property>
<!-- hbase的端口 -->
<property>
 <name>hbase.zookeeper.property.clientPort</name>
 <value>8181</value>
 <description>Property from ZooKeepersconfig zoo.cfg. The port at which the clients will connect.</description>
</property>
<!--  超时时间 -->
<property>
 <name>zookeeper.session.timeout</name>
 <value>120000</value>
</property>
<!--  zookeeper 集群配置。如果是集群，则添加其它的主机地址 -->
<property>
 <name>hbase.zookeeper.quorum</name>
 <value>10.227.96.27</value>
</property>
<property>
 <name>hbase.tmp.dir</name>
 <value>/home/analyze/hbase/hbase-2.2.5/tmp</value>
</property>
<!-- false是单机模式，true是分布式模式  -->
<property>
 <name>hbase.cluster.distributed</name>
 <value>false</value>
</property>
<property>
    <name>hbase.master.info.port</name>
    <value>8010</value>
</property>



-- 集群
<property>
 <name>hbase.rootdir</name>
 <value>hdfs://azkaban:8100/hbase</value>
 <description>The directory shared byregion servers.</description>
</property>
 <!-- hbase端口 -->
<property>
 <name>hbase.zookeeper.property.clientPort</name>
 <value>2181</value>
</property>
<!-- 超时时间 -->
<property>
 <name>zookeeper.session.timeout</name>
 <value>120000</value>
</property>
<!--防止服务器时间不同步出错 -->
<property>
<name>hbase.master.maxclockskew</name>
<value>150000</value>
</property>
<!-- 集群主机配置 -->
<property>
 <name>hbase.zookeeper.quorum</name>
 <value>azkaban,hadoop-01,hadoop-02</value>
</property>
<!--   路径存放 -->
<property>
 <name>hbase.tmp.dir</name>
 <value>/home/analyze/hbase/hbase-2.2.5/tmp</value>
</property>
<!-- true表示分布式 -->
<property>
 <name>hbase.cluster.distributed</name>
 <value>true</value>
</property>
  <!-- 指定master -->
  <property>
    <name>hbase.master</name>
    <value>azkaban:60000</value>
  </property>
  <property>
    <name>hbase.master.info.port</name>
    <value>8010</value>
</property>


scp -r /home/analyze/hbase/hbase-2.2.5/conf root@slave1:/opt

说明:hbase.rootdir：这个目录是region server的共享目录，用来持久化Hbase 。hbase.cluster.distributed ：Hbase的运行模式。false是单机模式，true是分布式模式。若为false,Hbase和Zookeeper会运行在同一个JVM里面
 

以上说明:hbase.rootdir：这个目录是region server的共享目录，用来持久化Hbase 。hbase.cluster.distributed ：Hbase的运行模式。false是单机模式，true是分布式模式。若为false,Hbase和Zookeeper会运行在同一个JVM里面。

配置好HBase后，想从浏览器通过端口60010看下节点情况，但是提示无法访问

在服务器上netstat -natl|grep 60010 发现并没有60010端口

原来是因为HBase 1.0 之后的版本都需要在 hbase-site.xml中配置端口，如下

<property>
    <name>hbase.master.info.port</name>
    <value>8010</value>  -- 60010 改为 8010
</property>
重新启动HBase,在浏览器再次访问，就ok了。  http://127.0.0.1:8010/master-status

HBase shell 使用
HBase启动之后  start-hbase.sh stop-hbase.sh
输入:
hbase shell
进入hbase


新建一个用户表 t_user
添加两个列族 st1 和 st2

create 't_user','st1','st2'
1
给这张表添加数据
添加 主键 、列 和值

put 't_user','1001','st1:age','18'
1
put 't_user','1001','st2:name','zhangsan'
1
然后 查询该表数据

scan 't_user'
1
查看表结构

describe 't_user'
1
删除记录

delete't_user','1001','st1:age'
1
删除表
删除表首先要屏蔽该表

disable 't_user'
1
删除

drop 't_user'

-- hive搭建
mysql -u anamember -p'ana829test' -h 10.227.96.6 -P 3006 -D test
mysql -h10.227.96.6 -pywzb@2020 -P3006
ywzb@2020

-- 环境配置
vim ~/.bash_profile
export HIVE_HOME=/home/analyze/hive/hive2.3
export HIVE_CONF_DIR=${HIVE_HOME}/conf
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${HADOOP_HOME}/bin:${ZK_HOME}/bin:${HBASE_HOME}/bin:${HIVE_HOME}/bin:$PATH

-- hive1 版本
vim ~/.bash_profile
export HIVE_HOME=/home/analyze/hive1.1/hive1.2
export HIVE_CONF_DIR=${HIVE_HOME}/conf
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${HADOOP_HOME}/bin:${ZK_HOME}/bin:${HBASE_HOME}/bin:${HIVE_HOME}/bin:$PATH

$HADOOP_HOME/bin/hadoop fs -mkdir -p /home/analyze/hive/hive2.3/hive/

-- 3，配置更改
mkdir /home/analyze/hive/hive2.3/hive
mkdir /home/analyze/hive/hive2.3/hive/warehouse
-- 需要让hadoop新建/home/analyze/hive/hive2.3/hive 和 /home/analyze/hive/hive2.3/hive/warehouse 目录
$HADOOP_HOME/bin/hadoop fs -mkdir -p /home/analyze/hive/hive2.3/hive/
$HADOOP_HOME/bin/hadoop fs -mkdir -p /home/analyze/hive/hive2.3/hive/warehouse
-- 给刚才新建的目录赋予读写权限，执行命令
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/warehouse 
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/analyze 
-- 检查这两个目录是否成功创建
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive/hive2.3/
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive/hive2.3/hive/
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive/hive2.3/hive/warehouse
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive/hive2.3/hive/analyze


$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/warehouse 
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/analyze 

$HADOOP_HOME/bin/hadoop fs -chmod -R 755 /home/analyze/hive/hive2.3/hive/warehouse 
$HADOOP_HOME/bin/hadoop fs -chmod -R 755 /home/analyze/hive/hive2.3/hive/analyze
$HADOOP_HOME/bin/hadoop fs -chmod -R 755 /home/analyze/hive/hive2.3/hive/fhive.metastore.uris

-- hive1 版本
mkdir /home/analyze/hive1.1/hive1.2/hive
mkdir /home/analyze/hive1.1/hive1.2/hive/warehouse
-- 需要让hadoop新建/home/analyze/hive/hive2.3/hive 和 /home/analyze/hive/hive2.3/hive/warehouse 目录
$HADOOP_HOME/bin/hadoop fs -mkdir -p /home/analyze/hive1.1/hive1.2/hive/
$HADOOP_HOME/bin/hadoop fs -mkdir -p /home/analyze/hive1.1/hive1.2/hive/warehouse
-- 给刚才新建的目录赋予读写权限，执行命令
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive1.1/hive1.2/hive/
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive1.1/hive1.2/hive/warehouse 
-- 检查这两个目录是否成功创建
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive1.1/hive1.2/
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive1.1/hive1.2/hive/
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive1.1/hive1.2/hive/warehouse

$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive1.1/hive1.2/hive/analyze
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive1.1/hive1.2/hive/analyze 

-- 5.3.2 修改 hive-site.xml
-- 将hive-default.xml.template 拷贝一份，并重命名为hive-site.xml
cp hive-default.xml.template hive-site.xml
vim hive-site.xml

<!-- 指定HDFS中的hive仓库地址 -->  
  <property>  
    <name>hive.metastore.warehouse.dir</name>  
    <value>/home/analyze/hive/hive2.3/hive/warehouse</value>  
  </property>  

<property>
    <name>hive.exec.scratchdir</name>
    <value>/home/analyze/hive/hive2.3/hive</value>
  </property>

  <!-- 该属性为空表示嵌入模式或本地模式，否则为远程模式 -->  
  <property>  
    <name>hive.metastore.uris</name>  
    <value></value>  -- thrift://10.227.96.6:3006
  </property>  

<!-- 指定mysql的连接 -->
 <property>
        <name>javax.jdo.option.ConnectionURL</name>
        <value>jdbc:mysql://10.227.96.6:3006/hive?createDatabaseIfNotExist=true</value>
    </property>
<!-- 指定驱动类 -->
    <property>
        <name>javax.jdo.option.ConnectionDriverName</name>
        <value>com.mysql.jdbc.Driver</value>
    </property>
   <!-- 指定用户名 -->
    <property>
        <name>javax.jdo.option.ConnectionUserName</name>
        <value>anamember</value>
    </property>
    <!-- 指定密码 -->
    <property>
        <name>javax.jdo.option.ConnectionPassword</name>
        <value>ana829test</value>
    </property>
    <property>
   <name>hive.metastore.schema.verification</name>
   <value>false</value>
    <description>
    </description>
 </property>
 
 
<!-- 指定HDFS中的hive仓库地址 -->  
  <property>  
    <name>hive.metastore.warehouse.dir</name>  
    <value>/home/analyze/hive1.1/hive1.2/hive/warehouse</value>  
  </property>  

<property>
    <name>hive.exec.scratchdir</name>
    <value>/home/analyze/hive1.1/hive1.2/hive</value>
  </property>

  <!-- 该属性为空表示嵌入模式或本地模式，否则为远程模式 -->  
  <property>  
    <name>hive.metastore.uris</name>  
    <value></value>  -- thrift://10.227.96.6:3006
  </property>  

<!-- 指定mysql的连接 -->
 <property>
        <name>javax.jdo.option.ConnectionURL</name>
        <value>jdbc:mysql://10.227.96.6:3006/hive?createDatabaseIfNotExist=true</value>
    </property>
<!-- 指定驱动类 -->
    <property>
        <name>javax.jdo.option.ConnectionDriverName</name>
        <value>com.mysql.jdbc.Driver</value>
    </property>
   <!-- 指定用户名 -->
    <property>
        <name>javax.jdo.option.ConnectionUserName</name>
        <value>anamember</value>
    </property>
    <!-- 指定密码 -->
    <property>
        <name>javax.jdo.option.ConnectionPassword</name>
        <value>ana829test</value>
    </property>
    <property>
   <name>hive.metastore.schema.verification</name>
   <value>false</value>
    <description>
    </description>
 </property>
 
 然后将配置文件中所有的 ${system:java.io.tmpdir} 更改为 /home/analyze/hive/tmp (如果没有该文件则创建)，
并将此文件夹赋予读写权限，将 ${system:user.name} 更改为 anamember
/home/analyze/hive/tmp/anamember

-- 修改 hive-env.sh
-- 修改hive-env.sh 文件，没有就复制 hive-env.sh.template ，并重命名为hive-env.sh
export  HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export  HIVE_CONF_DIR=/home/analyze/hive/hive2.3/conf
export  HIVE_AUX_JARS_PATH=/home/analyze/hive/hive2.3/lib

-- hive1版本
export  HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export  HIVE_CONF_DIR=/home/analyze/hive1.1/hive1.2/conf
export  HIVE_AUX_JARS_PATH=/home/analyze/hive1.1/hive1.2/lib

 添加 数据驱动包
由于Hive 默认自带的数据库是使用mysql，所以这块就是用mysql
将mysql 的驱动包 上传到 /home/analyze/hive1.1/hive1.2/lib

-- 首先初始化数据库 初始化的时候注意要将mysql启动
schematool  -initSchema -dbType mysql

-- 切换到 cd /opt/hive/hive2.1/bin
create database db_hiveTest;
create  table  db_hiveTest.student(id int,name string)  row  format  delimited  fields   terminated  by  '\t';
说明: terminated by ‘\t’ 表示文本分隔符要使用Tab，行与行直接不能有空格。
-- 加载数据 因为hive 不支持写，所以添加数据使用load加载文本获取。
load data local inpath '/home/analyze/hive/hive2.3/student.txt'  into table db_hivetest.student;


ssh 10.227.96.27
start-dfs.sh
start-yarn.sh
start-hbase.sh 

hadoop dfsadmin -report


$HADOOP_HOME/sbin/mr-jobhistory-daemon.sh start historyserver  -- 对sqoop2 任务执行有影响，必须要先启动（详细问题见下方）

stop-hbase.sh
stop-yarn.sh
stop-dfs.sh

ywzb@2020

create external table t_student_info(id int,name string) stored by 'org.apache.hadoop.hive.hbase.HBaseStorageHandler' with serdeproperties("hbase.columns.mapping"=":key,st1:name") tblproperties("hbase.table.name"="t_student","hbase.mapred.output.outputtable" = "t_student");
-- 在hive中创建映射hbase的表
create external table fezs.t_student(id int,name string) stored by 'org.apache.hadoop.hive.hbase.HBaseStorageHandler' with serdeproperties("hbase.columns.mapping"=":key,st1:name") tblproperties("hbase.table.name"="t_student","hbase.mapred.output.outputtable" = "t_student");
说明：第一个t_student 是hive表中的名称，第二个t_student是定义在hbase的table名称 ，第三个t_student 是存储数据表的名称("hbase.mapred.output.outputtable" = "t_student"这个可以不要，表数据就存储在第二个表中了) 。
(id int,name string) 这个是hive表结构。如果要增加字段，就以这种格式增加。如果要增加字段的注释，那么在字段后面添加comment ‘你要描述的’。
例如:
create table t_student(id int comment ‘StudentId’,name string comment ‘StudentName’)
org.apache.hadoop.hive.hbase.HBaseStorageHandler 这个是指定的存储器。
hbase.columns.mapping 是定义在hbase的列族。
例如:st1就是列族，name就是列。在hive中创建表t_student，这个表包括两个字段（int型的id和string型的name）。 映射为hbase中的表t_student，key对应hbase的rowkey，value对应hbase的st1:name列。

put 't_student','1001','st1:name','zhangsan'  -- 对应insert into
put 't_student','1002','st1:name','lisi'
scan 't_student'  -- 对应describle
hive和hbase之间的数据成功同步！

-- 先在hbase中建一张t_student_info表，添加两个列族然后查看表结构
create 't_student','st1','st2'
describe 't_student'
-- hive中建外部表
create   table fezs.t_student(id int,age int,sex string) stored by 'org.apache.hadoop.hive.hbase.HBaseStorageHandler' with serdeproperties("hbase.columns.mapping"=":key,st1:age,st2:sex") tblproperties("hbase.table.name"="t_student");

-- 然后在t_student_info 中添加数据
put 't_student','1001','st2:sex','man'
put 't_student','1001','st1:age','20'
put 't_student','1002','st1:age','18'
put 't_student','1002','st2:sex','woman'

-- sqoop 
-- 1.配置环境变量
添加后的profile文件内容
export JAVA_HOME=/home/hadoop/jdk1.8.0_144
export HADOOP_HOME=/home/hadoop/hadoop-2.7.2
export HBASE_HOME=/home/hadoop/hbase-1.2.2
export HIVE_HOME=/home/hadoop/hive-2.1.0


#Sqoop1 Home
export SQOOP_HOME=/home/analyze/sqoop/sqoop-1.4.7
export CLASSPATH=.:$JAVA_HOME/lib:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$HBASE_HOME/bin:$HIVE_HOME/bin:$SQOOP_HOME/bin:$PATH



#Sqoop2 Home
export SQOOP_HOME=/home/analyze/sqoop2/sqoop1.99
export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$HBASE_HOME/bin:$HIVE_HOME/bin:$SQOOP_HOME/bin:$PATH
export CATALINA_BASE=/home/analyze/sqoop2/sqoop1.99/server
export LOGDIR=$SQOOP_HOME/logs/



common.loader=${catalina.base}/lib,${catalina.base}/lib/*.jar,${catalina.home}/lib,${catalina.home}/lib/*.jar,${catalina.home}/../lib/*.jar,/home/analyze/hadoop/hadoop-2.8.5/*.jar,/home/analyze/hadoop/hadoop-2.8.5/lib/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/hdfs/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/hdfs/lib/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/mapreduce/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/mapreduce/lib/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/yarn/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/yarn/lib/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/common/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/common/lib/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/tools/*.jar,/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/tools/lib/*.jar


将common.loader行后的/usr/lib/hadoop/lib/.jar改成自己的hadoop jar 包目录，我的为：
/home/hadoop/app/hadoop/share/hadoop/common/.jar,
/home/hadoop/app/hadoop/share/hadoop/common/lib/.jar,
/home/hadoop/app/hadoop/share/hadoop/hdfs/.jar,
/home/hadoop/app/hadoop/share/hadoop/hdfs/lib/.jar,
/home/hadoop/app/hadoop/share/hadoop/mapreduce/.jar,
/home/hadoop/app/hadoop/share/hadoop/mapreduce/lib/.jar,
/home/hadoop/app/hadoop/share/hadoop/tools/.jar,
/home/hadoop/app/hadoop/share/hadoop/tools/lib/.jar,
/home/hadoop/app/hadoop/share/hadoop/yarn/.jar,
/home/hadoop/app/hadoop/share/hadoop/yarn/lib/*.jar


/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/common/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/common/lib/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/hdfs/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/hdfs/lib/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/mapreduce/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/mapreduce/lib/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/tools/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/tools/lib/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/yarn/*.jar,
/home/analyze/hadoop/hadoop-2.8.5/share/hadoop/yarn/lib/*.jar

/home/analyze/hadoop/hadoop-2.8.5/share/hadoop


cp /home/analyze/hadoop/hadoop-2.8.5/share/hadoop/common/*.jar  $SQOOP_HOME/server/lib


$HADOOP_HOME/share/hadoop/common/*.jar,$HADOOP_HOME/share/hadoop/common/lib/*.jar,$HADOOP_HOME/share/hadoop/hdfs/*.jar,$HADOOP_HOME/share/hadoop/mapreduce/*.jar,$HADOOP_HOME/share/hadoop/yarn/*.jar



/home/analyze/hive1.1/hive1.2/lib/mysql-connector-java-5.1.47.jar
复制mysql-connector-java-5.1.21.jar到$SQOOP_HOME/server/lib/下
cp /home/analyze/hive1.1/hive1.2/lib/mysql-connector-java-5.1.47.jar  $SQOOP_HOME/server/lib/


Sqoop2全部配置好之后，按照如下的顺序来

1、启动Sqoop2的server（我这里做个最简单的，在bigdatamaster上）。启动sqoop服务
命令：$SQOOP_HOME/bin/sqoop.sh server start  ，通过jsp命令看到Bootstrap进程

验证sqoop2是否启动成功：
      
        方式一：jps查看进程: Bootstrap
        方式二：http://hadoop_IP:12000/sqoop/version
        方式三：wget -qO - hadoop_IP:12000/sqoop/version

/home/analyze/sqoop2/sqoop1.99/bin

启停sqoop-server:
$SQOOP_HOME/bin/sqoop.sh server start
$SQOOP_HOME/bin/sqoop.sh server stop
或者
$SQOOP_HOME/bin/sqoop2-server start
$SQOOP_HOME/bin/sqoop2-server stop

2、启动Sqoop2的client（我这里做个最简单的，在bigdatamaster上），进入客户端交互模式。进入sqoop控制台
命令： $SQOOP_HOME/bin/sqoop.sh client  



四、启停sqoop-server:

$SQOOP2_HOME/bin/sqoop.sh server start  
$SQOOP2_HOME/bin/sqoop.sh server stop  
或者  
$SQOOP2_HOME/bin/sqoop2-server start  
$SQOOP2_HOME/bin/sqoop2-server stop
五、验证sqoop2是否启动成功：

方式一：jps查看进程: Bootstrap  
方式二：http://hadoop_IP:12000/sqoop/version  
方式三：wget -qO - hadoop_IP:12000/sqoop/version
六、启动sqoop客户端：

$SQOOP2_HOME/bin/sqoop.sh client 
或者
$SQOOP2_HOME/bin/sqoop2-shell
七、为客户端配置服务器：

sqoop:000> set server --host hadoop000 --port 12000 --webapp sqoop
 八、查看服务器端信息：

sqoop:000> show server --all










3、在Sqoop2的client连接Sqoop2的server 。 连接服务器  
sqoop:000> set server --host bigdatamaster  --port 12000  --webapp sqoop
sqoop:000> set server --host localhost      --port 12000  --webapp sqoop
sqoop:000> show version --all   
sqoop:000> show connector --all   查看连接器

-- 问题：sqoop shell中输入：show connection --all 报错 The specified function "connection" is not recognized.
原因是版本不一样，SQOOP 1.99.4以后命令就变了: 具体看这
里：https://sqoop.apache.org/docs/1.99.4/CommandLineClient.html#create-link-function

sqoop:000> show link --all  查看连接 
sqoop:000> show link --xid 1  查看id为1的连接  
sqoop:000> create link --cid 1  创建id为1的连接 

sqoop:000> set server --host 10.227.96.27  --port 8100  --webapp sqoop
sqoop:000> set server --host localhost      --port 12000  --webapp sqoop
sqoop:000> show version --all   

show server --all  查看连接服务器
show connector --all or show connector
show driver
show link --all or show link  查看连接 
show job --all or show job  查看job
create link --cid 1 or create link -c 1  创建连接 链接器cid
update link --lid 1 更新连接
update job --jid 1 更新job
delete link --lid 1 删除连接
delete job --jid 1 删除job
clone link --lid 1 克隆连接
clone job --jid 1 克隆job
start job --jid 1 -s 开启job -s 可以显示执行状态 status
start job --jid 1 --synchronous
show job
stop job --jid 1 停止job
status job --jid 1 查看job状态时
create job --from 1 --to 2 or create job --f 1 --t 2 创建1到2的连接
start job --jid 1 启动
status job --jid 1
stop job --jid 1

4.sqoop2-tool verify 校验失败

-- 执行job时出错：
Caused by: org.apache.sqoop.common.SqoopException: MAPRED_EXEC_0018:Error occurs during loader run

-- 查看job时 Exception has occurred during processing command

set option --name verbose --value true   #打开报错详情输出
set option --name verbose --value true sqoop

-- 问题：当job 的 status 一直卡在一个地方时，在8088页面可以查看job执行日志发现具体的错误是：
 ERROR [OutputFormatLoader-consumer] org.apache.sqoop.job.mr.SqoopOutputFormatLoadExecutor: Error while loading data out of MR job



status job -n test

Exception: org.apache.sqoop.common.SqoopException Message: MAPREDUCE_0003:Can't get RunningJob instance -

Caused by: Exception: java.io.IOException Message: java.net.ConnectException: Call From hadoop1/192.168.122.10 to 0.0.0.0:10020 failed on connection exception: java.net.ConnectException: 拒绝连接; For more details see:  http://wiki.apache.org/hadoop/ConnectionRefused

解决方法：

表示： hadoop运行mapreduce作业无法连接0.0.0.0/0.0.0.0:10020

这个问题是由于没有启动historyserver引起的，解决办法：
在mapred-site.xml配置文件中添加：

<property>
    <name>mapreduce.jobhistory.address</name>
    <value>azkaban:10020</value>
</property>
在namenode上执行命令：mr-jobhistory-daemon.sh start historyserver 
这样在，namenode上会启动JobHistoryServer服务，可以在historyserver的日志中查看运行情况
mr-jobhistory-daemon.sh start historyserver


sqoop2 任务执行日志： /home/analyze/@LOGDIR@/sqoop.log

sqoop:000> start job --jid 1
Exception has occurred during processing command 
Exception: java.lang.RuntimeException Message: java.lang.ClassNotFoundException: org.apache.sqoop.driver.DriverError


sqoop:000> start job --jid 1                      
Exception has occurred during processing command 
Exception: java.lang.RuntimeException Message: java.lang.ClassNotFoundException: org.apache.sqoop.driver.DriverError

-- 问题： hue端 无法定义sqoop任务 ,不可以添加链接link 可以删除job

-- 2.sqoop配置文件修改
2.1 sqoop-env.sh 文件
进入 /home/hadoop/sqoop-1.4.7/conf 目录下，也就是执行：
cd /home/hadoop/sqoop-1.4.7/conf
将sqoop-env-template.sh复制一份，并取名为sqoop-env.sh，也就是执行命令：
cp sqoop-env-template.sh sqoop-env.sh

文件末尾加入一下配置：
#Set the path for where zookeper config dir is
#export ZOOCFGDIR=
export HADOOP_COMMON_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HADOOP_MAPRED_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HIVE_HOME=/home/analyze/hive/hive2.3
export HBASE_HOME=/home/analyze/hbase/hbase-2.2.5

export HIVE_HOME=/home/analyze/hive1.1/hive1.2
export HBASE_HOME=/home/analyze/hbase/hbase-2.2.5


-- 5.使用sqoop查看mysql中的数据表：
进入$SQOOP_HOME/bin目录下执行如下命令：连接mysql看有多少个表
 ./sqoop list-databases --connect jdbc:mysql://10.227.96.6:3006/hive?characterEncoding=UTF-8 --username anamember --password 'ana829test'  可以链接
 ./sqoop list-databases --connect jdbc:mysql://10.200.130.72:3306/fe_dwd?characterEncoding=UTF-8 --username shprocess --password 'JFH23idf83!#9m' 不可以链接
 ./sqoop list-databases --connect jdbc:mysql://10.200.130.4:3306/fe_dwd?characterEncoding=UTF-8 --username feprocess --password 'Tak()#Pause2019' 不可以链接

 
-- 6.把MySQL中的表导入hdfs中
前提：一定要启动hdfs和yarn,本人忘了启动yarn
sqoop import -m 1 --connect jdbc:mysql://10.227.96.6:3006/fe?characterEncoding=UTF-8 --username anamember --password 'ana829test' --table sf_product --target-dir /home/analyze/sqoop/sqoop-1.4.7/testdata
sqoop import --connect jdbc:mysql://10.227.96.6:3006/fe?characterEncoding=UTF-8 --username anamember --password 'ana829test' --table sf_product --target-dir /home/analyze/sqoop/sqoop-1.4.7/testdata
sqoop import --append --connect jdbc:mysql://10.227.96.6:3006/fe?characterEncoding=UTF-8 --username anamember --password 'ana829test' --table sf_shelf --target-dir /home/analyze/sqoop/sqoop-1.4.7/testdata

结果是java文件
-- 指定部分查询数据导入到集群众
sqoop-import --append --connect 'jdbc:mysql://10.227.96.6:3006/fe' --username 'anamember' --password 'ana829test' --query 'select * from fe.sf_shelf where shelf_id<100 and $CONDITIONS' -m 1 --target-dir '/home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sf_shelf' --fields-terminated-by '\t' --lines-terminated-by '\n'

-- 删除hive中mmzs数据库的testsqoop表的数据
hdfs dfs -rm -r /user/hive/warehouse/mmzs.db/testsqoop/part-m-00000
hdfs dfs -rm -r /home/analyze/hive/hive2.3/hive/warehouse/my.db/sqoop/

-- 指定一张表，整个表的数据一起导入到集群中
sqoop-import --append --connect 'jdbc:mysql://10.227.96.6:3006/fe' --username 'anamember' --password 'ana829test' --table sf_shelf -m 1 --target-dir '/home/analyze/hive/hive2.3/hive/warehouse/my.db/sqoop/' --fields-terminated-by '\t' --lines-terminated-by '\n'
 
 
----------------------- hive 表数据导入到mysql 以下为成功的例子

sqoop-export \
 --connect jdbc:mysql://10.227.96.6:3006/test \
 --username anamember \
 --password ana829test \
 --table sf_group_auth_tj \
 --input-null-string '\\N' \
 --input-null-non-string '\\N' \
 --export-dir /home/analyze/hive/hive2.3/hive/warehouse/fezs.db/sf_group_auth \
 --input-fields-terminated-by '\t' 
 
 
 sqoop import \
 --connect jdbc:mysql://10.227.96.6:3006/fe_group?tinyInt1isBit=false\
 --username anamember \
 --password ana829test \
 --table sf_group_auth \
 --target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth/ \
 --delete-target-dir \
 --num-mappers 1 \
 --fields-terminated-by '\t' \
 --hive-drop-import-delims \
 --null-string '\\N' \
 --null-non-string '\\N' \
 --lines-terminated-by '\n';

这个错误的原因是指定Hive中表字段之间使用的分隔符错误，供Sqoop读取解析不正确。如果是由hive执行mapreduce操作汇总的结果，默认的分隔符是 '\001'，否则如果是从HDFS文件导入的则分隔符则应该是'\t'。此处我是hive执行mapreduce分析汇总的结果，所以默认的分隔是'\001'。Sqoop命令修改如下，指定分隔符：



 
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/fezs.db/dwd_group_emp_user_day 
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db

$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/analyze 
-- 在hive数据库建表后上传到集群中表存放数据的路径下
hdfs dfs -put testsqoop /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.testsqoop

1.在hive数据库建表
create table if not exists db_hivetest.sqooptest(id int,name string,age int) row format delimited fields terminated by '\t';
2.然后上传到集群中表存放数据的路径下
hdfs dfs -put sqooptest /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sqooptest
3.查看是否导入成功
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sqooptest
4.hive中查看数据
select* from db_hivetest.sqooptest;
-- 将测试环境中的一个表数据同步到hive表中 
1.在hive数据库建表
create table if not exists db_hivetest.sf_product_activity_markup_price (
  `markup_price_id` string COMMENT '加价购id',
  `activity_id` string COMMENT '商品活动id',
  `full_price` string COMMENT '买满金额',
  `markup_price` string COMMENT '加价金额',
  `limit_num` string COMMENT '换购限制数量 1，换购1件 2，换购多件',
  `data_flag` string COMMENT '数据状态(1:正常、2:删除)',
  `add_time` string COMMENT '添加时间',
  `add_user_id` string COMMENT '添加人员id',
  `last_update_time` string COMMENT '最后修改时间',
  `last_update_user_id` string COMMENT '最后修改人员id'
) COMMENT '加价购商品活动表' row format delimited fields terminated by '\t';
2.然后上传到集群中表存放数据的路径下
sqoop-import --append --connect 'jdbc:mysql://10.227.96.6:3006/fe' --username 'anamember' --password 'ana829test' --table sf_product_activity_markup_price -m 1 --target-dir '/home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sf_product_activity_markup_price/' --fields-terminated-by '\t' --lines-terminated-by '\n'
3.查看是否导入成功
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db
hdfs dfs -rm -r /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sf_group_emp

4.hive中查看数据
select * from db_hivetest.sf_product_activity_markup_price;

或者用以下方法
1.首先在hive中建表（尽量与mysql字段对应）
2. 将mysql中的表导出 txt格式
3.通过hadoop 上传到HDFS上

命令 hadoop dfs -put /home/hadoop/dim_station_trans_com_info.txt  /user/hive/external/tables/dim/dim_station_trans_com_info

前面为 hadoop文件地址 ，后面为HDSF文件地址。

4.查看HDFS上是否成功
上传成功
4.将这个文件导入hive数据库
load data inpath '//user/hive/external/tables/dim/dim_station_trans_com_info/dim_station_trans_com_info.txt' into table dim_station_trans_com_info;

示例：
-- 建表
CREATE external TABLE db_hivetest.pub_user_open (
  `USER_OPEN_ID` string COMMENT '平台用户主键',
  `USER_ID` string COMMENT '用户ID',
  `OPEN_TYPE` string COMMENT '第三方平台标识',
  `OPEN_ID` string COMMENT '用户在第三方平台的标识',
  `mobile_phone` string COMMENT '手机号码',
  `open_entrance` string COMMENT '注册方式(1:扫码 2:微服务认证)',
  `ADD_TIME` string COMMENT '添加时间',
  `DATA_FLAG` string COMMENT '数据状态(1:正常、2:删除)',
  `last_update_time` string COMMENT '最后修改时间',
  `old_user_id` string COMMENT '合并前用户id',
  `old_open_id` string COMMENT '旧的openid'
) COMMENT '平台用户信息' 
row format delimited fields terminated by ','
LINES TERMINATED BY '\n'
NULL defined as ''
stored as textfile
location '/home/analyze/hive/hive2.3/hive/warehouse/pub_user_open';
-- 通过hadoop 上传到HDFS上
hadoop dfs -put /home/analyze/pub_user_open.txt  /home/analyze/hive/hive2.3/hive/warehouse/pub_user_open
-- 将这个文件导入hive数据库
load data inpath '/home/analyze/hive/hive2.3/hive/warehouse/pub_user_open/pub_user_open.txt' into table pub_user_open;


-- 特别说明：对于count(1)或count(*)没有执行MR Job直接返回0的结果，即设置参数 set hive.compute.query.using.stats=false;  即执行MR Job； 或者使用ANALYZE命令手动更新表统计信息：ANALYZE TABLE table_name COMPUTE STATISTICS;

hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.testsqoop
create table if not exists db_hivetest.testsqoop(id int,name string,age int) row format delimited fields terminated by '\t';

load data local inpath '/home/analyze/sqoop/sqoop-1.4.7/bin/testsqoop'  into table db_hivetest.testsqoop;-- 将数据直接加载到hive表中
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db
hdfs dfs -rm -r /home/analyze/hive/hive2.3/hive/warehouse/fezs.db/sf_group_emp

desc 表名；           -- hive 查看表的简单结构
desc formatted 表名； -- hive 查看表的详细内容

HIVE 问题：
1经常提示不存在数据库 SemanticException（Database does not exists)
-- 解决方法：复制hive/conf下的hive-site.xml到sqoop工作目录的conf下  未解决
实际上该database是在hive中存在的，由于sqoop下的配置文件太旧引起的，一般会出现在,换台机器执行sqoop
CDH 默认路径在： /etc/hive/conf/hive-site.xml  copy到 /etc/sqoop/conf/hive-site.xml
执行命令：cp /home/analyze/hive/hive2.3/conf/hive-site.xml /home/analyze/sqoop/sqoop-1.4.7/conf/hive-site.xml

2表注释乱码 -- 按照以下方法修改mysql元数据对应表的编码方式 已解决
#（1）修改表字段注解和表注解
ALTER TABLE hive.COLUMNS_V2 MODIFY COLUMN COMMENT VARCHAR(256) CHARACTER SET utf8;
ALTER TABLE hive.TABLE_PARAMS MODIFY COLUMN PARAM_VALUE VARCHAR(4000) CHARACTER SET utf8;
#（2）修改分区字段注解
ALTER TABLE hive.PARTITION_PARAMS MODIFY COLUMN PARAM_VALUE VARCHAR(4000) CHARACTER SET utf8 ;
ALTER TABLE hive.PARTITION_KEYS MODIFY COLUMN PKEY_COMMENT VARCHAR(4000) CHARACTER SET utf8;
#（3）修改索引注解
ALTER TABLE hive.INDEX_PARAMS MODIFY COLUMN PARAM_VALUE VARCHAR(4000) CHARACTER SET utf8;
3select count(1) 返回0
因为数据的存储问题，该表创建时指定的存储格式为parquet，所以count()无法统计
-- 解决办法：set hive.compute.query.using.stats=false;

4字段间分隔符不好把控 row format delimited fields terminated by '\t'; 有的字段中有\t导致数据列数错位


5.sqoop --direct报错 Cannot run program "mysqldump": error=2, No such file or directory
解决办法：
找到安装有Mysql的节点 在mysql/bin下找到mysqldump
传到sqoop节点下sqoop/bin
给mysqldump 加X（执行）权限
cp /app/mysql/bin/mysqldump  /home/analyze/sqoop/sqoop-1.4.7/bin
结论：这说明了sqoop导入的2种方式的底层实现不一致，direct的方式需要使用mysqldump命令实现，具体的实现带后续研究​


6采用SnappyCodec的方式压缩，在查询表数据明细的时候报错

set hive.strict.checks.type.safety = true   -- 严格类型安全
set hive.strict.checks.type.safety = false  -- 严格类型安全
set hive.strict.checks.cartesian.product = true  -- 该属性不允许笛卡尔积操作
set hive.mapred.mode = strict;  -- 需要进行设置严格模式，否则会引起笛卡尔积现象
set hive.strict.checks.large.query = true  -- 该设置会禁用：1. 不指定分页的orderby
　　　　　　                                              -- 2. 对分区表不指定分区进行查询 
　　　　　　                                              -- 3. 和数据量无关，只是一个查询模式

10mysql 表中的datetime字段对应hive表中timestamp格式，不然会多出一个0

8查询的时候没有字段名
set hive.cli.print.header=true;
set hive.resultset.use.unique.column.names=false;

7 mysql表字段类型在hive里面会自动转换，直接运行上面sqoop命令，查询，失败。。。。（类型自动转化） sqoop复制的Mysql表结构到HIVE，发现部分字段类型发生了变化；

tinyint(1) -> boolean  可通过 CONVERT(match_type,SIGNED) 进行类型转化
decimal -> double
datetime -> string 等


8hive表在插入数据的时候不能指定具体字段，默认全列插入
分析：hive插入数据时不能指定列名插入，默认是全列插入！！！目前高版本支持指定列插入，而低版本不支持指定列插入。


 hive  mysql 
 date_format('2020-12-03 08:00:00','HH:mm:ss')  time('2020-12-03 08:00:00')
 
 -- sqoop 将mysql数据导入到hive
 sqoop import \
 --connect jdbc:mysql://10.227.96.6:3006/fe_group\
 --username anamember \
 --password ana829test \
 --table sf_group_distribute_plan \
 --target-dir /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sf_group_distribute_plan/ \
 --delete-target-dir \
 --num-mappers 1 \
 --compress \
 --compression-codec org.apache.hadoop.io.compress.SnappyCodec \
 --fields-terminated-by '\t';
 
 
 hive 执行sql的几种方式：
 1.直接在终端中粘贴sql
 2.hive -e 'sql 语句'
 3.hive -f sql文件


hive -e 'SELECT 
emp_user_id,
group_customer_id
FROM db_hivetest.sf_group_emp a 
WHERE a.group_customer_id = '4726';'


hive临时表
hive可以在脚本的hql最前端，用如下语句

with  临时表名  as  （sql语句）

创建临时表，只在当前脚本使用的临时表。

with tmp_tj as ( 
SELECT 
emp_user_id,
group_customer_id
FROM db_hivetest.sf_group_emp
WHERE group_customer_id = '4726' );


cat ~/.bash_profile
source ~/.bash_profile

hive 获取当前时间：
 from_unixtime(unix_timestamp(), 'yyyy-MM-dd HH:mm:ss')
 date_format(current_timestamp(),'yyyy-MM-dd HH:mm:ss')
hive获取当日日期：
current_date()

/home/analyze/hive1.1/hive1.2/conf/hive-site.xml

  <property>
    <name>hive.hwi.listen.host</name>
    <value>0.0.0.0</value>
    <description>监听的地址</description>
  </property>
  <property>
    <name>hive.hwi.listen.port</name>
    <value>8098</value>   -- 9999
    <description>监听的端口号</description>
  </property>
  <property>
    <name>hive.hwi.war.file</name>
    <value>lib/hive-hwi-2.3.7.war</value>
    <description>war包所在的地址，注意这里不支持绝对路径，坑！</description>
  </property>
  
  <property>
    <name>hive.hwi.listen.host</name>
    <value>0.0.0.0</value>
    <description>监听的地址</description>
  </property>
  <property>
    <name>hive.hwi.listen.port</name>
    <value>8098</value>
    <description>监听的端口号</description>
  </property>
  <property>
    <name>hive.hwi.war.file</name>
    <value>lib/hive-hwi-2.3.7.war</value>
    <description>war包所在的地址，注意这里不支持绝对路径，坑！</description>
  </property>

export ANT_HOME=/home/analyze/ant-1.10.9/ant-1.10.9
export PATH=$PATH:$ANT_HOME/bin


需要把/usr/local/ant/lib下的ant-launcher.jar，ant.jar这两个jar包和jasper-compiler-5.5.23.jar，jasper-runtime-5.5.23.jar这两个jar包（这两个没放，暂时没影响）以及jdk的lib包下面的tools.jar包拷贝到${HIVE_HOME } /lib下，并且需要将相应的权限修改为777

cp ${JAVA_HOME}/lib/tools.jar ${HIVE_HOME}/lib
cp ant-launcher.jar ${HIVE_HOME}/lib
cp ant.jar ${HIVE_HOME}/lib

cp ${JAVA_HOME}/lib/jasper-compiler-5.5.23.jar ${HIVE_HOME}/lib
cp ${JAVA_HOME}/lib/jasper-runtime-5.5.23.jar ${HIVE_HOME}/lib

-- web页面出不来的时候 同上
拷贝jasper-compiler-5.5.23.jar
jasper-runtime-5.5.23.jar
commons-el-1.0.jar到hive的lib目录下

-- linux下查找文件
find ./ -name  "jasper-runtime*.jar"
find ./ -name "tangjin0001"
find ./ -name "maven"
find ./ -name "migration"

-- scala 搭建

export SCALA_HOME=/home/analyze/scala/scala2.13
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:$PATH

-- spark搭建

export  JAVA_HOME=/opt/java/jdk1.8.0_121
export  ZK_HOME=/opt/zookeeper/zookeeper-3.4.10
-- 编辑 ~/.bash_profile 修改环境配置
export  SCALA_HOME=/home/analyze/scala/scala2.13
export  SPARK_HOME=/home/analyze/spark/spark2.4
export  CLASS_PATH=.:${JAVA_HOME}/lib:$CLASS_PATH
export  PATH=.:${JAVA_HOME}/bin:${SPARK_HOME}/bin:${ZK_HOME}/bin:${SCALA_HOME}/bin:$PATH

source ~/.bash_profile

-- 在conf目录下，修改spark-env.sh文件
export SCALA_HOME=/home/analyze/scala/scala2.13   
export JAVA_HOME=/app/jdk1.8.0_192
export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5   
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop  
export SPARK_HOME=/home/analyze/spark/spark2.4
export SPARK_MASTER_IP=azkaban    
export SPARK_EXECUTOR_MEMORY=1G 
-- 注:上面的路径以自己的为准，SPARK_MASTER_IP为主机，SPARK_EXECUTOR_MEMORY为设置的运行内存

启动spark服务  -- 不依赖hadoop
sbin/start-all.sh  -- http://127.0.0.1:8083/
sbin/stop-all.sh
进入spark环境
spark-shell


-- 问题描述：在网页上无法下载hdfs文件数据
解决方案：是因为没有将Linux服务器上的 /etc/hosts文件中的集群信息，添加到本地hosts文件中，本地无法映射找不到。
打开C:\Windows\System32\drivers\etc\hosts对应自己的Linux上的集群配置，再去下载就可以了!
C:\Windows\System32\drivers\etc\hosts 中添加
127.0.0.1	azkaban


-- 调用Spark自带的计算圆周率的Demo，执行下面的命令
./bin/spark-submit  --class  org.apache.spark.examples.SparkPi  --master local   examples/jars/spark-examples_2.11-2.4.7.jar


ssh 10.227.96.27
ywzb@2020

TCP/1100-1140
TCP/3000-3040
TCP/5000-5300
TCP/5800-5900
TCP/8000-8200
TCP/10000-10100
TCP/21100-21120
TCP/59000-59010

netstat -anp  |grep 8090  -- 查看8080端口是否被占用
将/home/analyze/spark/spark2.4/sbin/start-master.sh 的8080端口改为可用的端口即可

-- spark web页面 worker_id 页面无法进入 http://10.227.96.27:8081/ 需要修改hosts文件 


启动spark-shell 方可通过以下方式查看 spark job（当应用在运行中的时候可以访问，一旦应用执行结束该端口关闭不可访问）

 验证访问http://master:4040/ -- 本机是 http://127.0.0.1:8140 此处端口在 spark-env.sh 文件中加一行 spark.ui.port	4040 即可


Spark部分：几个重要的端口汇总
50070：HDFSwebUI的端口号

8485:journalnode默认的端口号

9000：非高可用访问数rpc端口

8020：高可用访问数据rpc

8088：yarn的webUI的端口号

8080：master的webUI，Tomcat的端口号

7077：spark基于standalone的提交任务的端口号

8081：worker的webUI的端口号

18080：historyServer的webUI的端口号

4040：application的webUI的端口号

2181：zookeeper的rpc端口号

9083：hive的metastore的端口号  -- 9083 改为 8023

60010：Hbase的webUI的端口号

6379：Redis的端口号

8080：sparkwebUI的端口号

9092：kafka broker的端口


-- hive web 需要2.2以下版本的才支持

 

------------------------------ hadoop集群 三台机器
10.227.96.27 (master) -- azkaban     对应的用户是 analyze 
10.227.96.23 (slave1) -- hadoop-01   对应的用户是 appdeploy 
10.227.96.24 (slave2) -- hadoop-02   对应的用户是 appdeploy
appdeploy/shujuZU#.
ssh appdeploy@10.227.96.23
ssh appdeploy@10.227.96.24

10.227.96.27 azkaban
10.227.96.23 hadoop-01
10.227.96.24 hadoop-02

-- hive与hbase创建映射表 hive表中创建失败
FAILED: Execution Error, return code 1 from org.apache.hadoop.hive.ql.exec.DDLTask. org.apache.hadoop.hbase.client.HBaseAdmin.<init>(Lorg/apache/hadoop/conf/Configuration;)V  -- 切换hive的版本号


5)启动hwi服务

hive --service hwi
hive 不支持 update  delete操作

hive web页面 根据条件查询 中文显示异常
在对应的jsp文件开头加上以下信息：
<%@ page contentType="text/html;charset=UTF-8"%>
jar -cvf hive-hwi-1.1.0.war *
cp hive-hwi-1.1.0.war ${HIVE_HOME}/lib/

问题： 在hive_web界面建表，字段数少的时候可以正常建表，当字段数很多的时候无法建表，页面报：该网页无法正常运作  -- 还未解决
问题： show create table 表名 显示的表中文注释是乱码  desc 表名 显示正常 -- 还未解决 已有对应的方法




-- 安装hue / cloudera manager

-- 启动服务路径 supervisor  /  hue runserver 127.0.0.1:8090
/home/analyze/hue4.2/hue-4.2.0/build/env/bin
-- conf路径
/home/analyze/hue4.2/hue-4.2.0/desktop/conf

启动hue 这里runserver是本地启动（hue runserver 127.0.0.1:8090），如果部署在外网，启动方式是 supervisor
cd  /YourHuePath/build/env/bin/hue runserver 
输入你hue的路径就可以看到中文界面了。
http://127.0.0.1:8000/ 这是我的路径

-- 问题 ；Could not connect to 10.227.96.27:10000 (code THRIFTTRANSPORT): TTransportException('Could not connect to 10.227.96.27:10000',)
在安装的HIVE中启动 hiveserver2 &,因为端口号10000是hiveserver2服务的端口号，否则，Hue Web 控制无法执行HIVE 查询。


-- 问题：database is locked
-- 初始化hue元数据
bin/hue syncdb  -- 该步骤是创建表和插入部分数据。hue的初始化数据表命令由hue/bin/hue syncdb完成，创建期间，需要输入用户名和密码
bin/hue migrate -- 导入数据,主要包括oozie、pig、desktop所需要的表 



-- 问题：Could not start SASL: Error in sasl_client_start (-4) SASL(-4): no mechanism available: No worthy mechs found (code THRIFTTRANSPORT): TTransportException('Could not start SASL: Error in sasl_client_start (-4) SASL(-4): no mechanism available: No worthy mechs found',)
-- 报错信息如下： 从字面意思大致可以判断出是缺失依赖组件
缺少 cyrus-sasl  安装就OK了
yum install cyrus-sasl-plain cyrus-sasl-devel cyrus-sasl-gssapi  cyrus-sasl-md5 


-- 问题：Hue与MySQL集成之后查询表中的数据出现中文乱码  
解决方案
在 Hue的安装目录下的desktop/conf/hue.ini文件中添加
## options={}
options={ "init_command":"SET NAMES 'utf8'"}
问题解决


-- 问题：hue 删表 drop table if exists fezs.sf_group_auth;  没有 if exists 报错
-- 问题：hue 查看表结构 DESCRIBE formatted fezs.sf_group_auth; 没有formatted报错
-- 问题：创建数据库 create database if not exists test;

-- 问题：FAILED: Execution Error, return code 1 from org.apache.hadoop.hive.ql.exec.mr.MapRedTask
Hive是基于hadoop的封装,所有,hive在执行hive ql的时候回创建一个hadoop的Job（MapReduce），
所以需要操作到hadoop的HDFS文件系统，Eclipse 本地开发的时候使用的用户 对某些文件会没有权限,导致出现上述错误,所以只要对报读的路径变更权限就好了
hdfs dfs -chmod 777 文件路径
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive1.1/hive1.2/hive/

-- 查看某个任务的进程 
ps -ef |grep python2.7  -- 表示python2.7进程
kill -9 进程号


-- 问题：HUE与hive集成需要hive开启 HiveServer2 服务
相关配置如下：
属性：hive.server2.thrift.port
属性值：10000
属性：hive.server2.thrift.bind.host
属性值：azkaban
属性：hive.server2.long.polling.timeout
属性值：5000
属性：hive.metastore.uris
属性值：thrift://azkaban:8023  
-- 具体如下：
<property>
  <name>hive.server2.thrift.port</name>
  <value>10000</value>
</property>

<property>
  <name>hive.server2.thrift.bind.host</name>
  <value>azkaban</value>
</property>

<property>
  <name>hive.server2.long.polling.timeout</name>
  <value>5000</value>
</property>

<property>
  <name>hive.metastore.uris</name>
  <value>thrift://azkaban:8023</value>  -- 9083 改为 8023  该配置为空，则表示本地/有thrift 则表示远程
</property>
启动Hive相关服务 
cd /home/analyze/hive1.1/hive1.2/bin
$ bin/hive --service metastore &
$ bin/hive --service hiveserver2 &

cd /home/analyze/hue4.2/hue-4.2.0/build/env/bin
supervisor

如果设置了 uris，在今后使用Hive时，那么必须启动如上两个命令，否则Hive无法正常启动。

配置hue.ini
找到[beeswax]属性标签，涉及修改如下：
[beeswax]
hive_server_host=10.227.96.27      #hive的host可以是ip
hive_server_port=10000             #端口默认10000
hive_conf_dir=/home/analyze/hive1.1/hive1.2/conf    #hive的配置文件的主目录

重启HUE测试
$ build/env/bin/supervisor

-- hive1 版本
mkdir /home/analyze/hive1.1/hive1.2/hive
mkdir /home/analyze/hive1.1/hive1.2/hive/warehouse


-- 问题： Exception in thread "main" org.apache.thrift.transport.TTransportException: Could not create ServerSocket on address 0.0.0.0/0.0.0.0:9083.

metastore 重复启动，kill后重新启动即可解决


-- 问题：hue 配置 sqoop模块

[sqoop]
  # For autocompletion, fill out the librdbms section.

  # Sqoop server URL
  server_url=http://10.227.96.27:8120/sqoop

  # Path to configuration directory
  sqoop_conf_dir=/home/analyze/sqoop2/sqoop1.99/server/conf


ssh 10.227.96.27
start-dfs.sh
start-yarn.sh
start-hbase.sh 

stop-hbase.sh
stop-yarn.sh
stop-dfs.sh


cd /home/analyze/hive1.1/hive1.2/bin
$ bin/hive --service metastore &
$ bin/hive --service hiveserver2 &



-- zookeeper 安装
环境配置
export ZK_HOME=/home/analyze/zookeeper/zookeeper-3.5.8
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${ZK_HOME}/bin:$PATH


修改配置文件
在集群的服务器上都创建这些目录
mkdir   /home/analyze/zookeeper/zookeeper-3.5.8/data  
mkdir   /home/analyze/zookeeper/zookeeper-3.5.8/dataLog

并且在/opt/zookeeper/data目录下创建myid文件
输入:

touch  myid

创建成功之后，更改myid文件。
我这边为了方便，将master、slave1、slave2的myid文件内容改为1,2,3


5.3.2 新建zoo.cfg
切换到/opt/zookeeper/zookeeper3.4/conf 目录下
如果没有 zoo.cfg 该文件，就复制zoo_sample.cfg文件并重命名为zoo.cfg。
修改这个新建的zoo.cfg文件

dataDir=/home/analyze/zookeeper/zookeeper-3.5.8/data
dataLogDir=/home/analyze/zookeeper/zookeeper-3.5.8/dataLog
server.1=azkaban:1118:3018
server.2=hadoop-01:1118:3018
server.3=hadoop-02:1118:3018


TCP/1100-1140
TCP/3000-3040
TCP/5000-5300
TCP/5800-5900
TCP/8000-8200
TCP/10000-10100
TCP/21100-21120
TCP/59000-59010

netstat -anp  |grep 1118
netstat -anp  |grep 3018


说明：client port，顾名思义，就是客户端连接zookeeper服务的端口。这是一个TCP port。dataLogDir里是放到的顺序日志(WAL)。而dataDir里放的是内存数据结构的snapshot，便于快速恢复。为了达到性能最大化，一般建议把dataDir和dataLogDir分到不同的磁盘上，这样就可以充分利用磁盘顺序写的特性。dataDir和dataLogDir需要自己创建，目录可以自己制定，对应即可。server.1中的这个1需要和master这个机器上的dataDir目录中的myid文件中的数值对应。server.2中的这个2需要和slave1这个机器上的dataDir目录中的myid文件中的数值对应。server.3中的这个3需要和slave2这个机器上的dataDir目录中的myid文件中的数值对应。当然，数值你可以随便用，只要对应即可。2888和3888的端口号也可以随便用，因为在不同机器上，用成一样也无所谓。
1.tickTime：CS通信心跳数
Zookeeper 服务器之间或客户端与服务器之间维持心跳的时间间隔，也就是每个 tickTime 时间就会发送一个心跳。tickTime以毫秒为单位。
tickTime=2000
2.initLimit：LF初始通信时限
集群中的follower服务器(F)与leader服务器(L)之间初始连接时能容忍的最多心跳数（tickTime的数量）。
initLimit=10
3.syncLimit：LF同步通信时限
集群中的follower服务器与leader服务器之间请求和应答之间能容忍的最多心跳数（tickTime的数量）。
syncLimit=5



4，启动 zookeeper 
因为zookeeper是选举制，它的主从关系并不是像hadoop那样指定的，具体可以看官方的文档说明。
成功配置zookeeper之后，在每台机器上启动zookeeper。
切换到zookeeper目录下

cd /home/analyze/zookeeper/zookeeper-3.5.8/bin

输入：zkServer.sh start -Dzookeeper.admin.enableServer=false

成功启动之后
查看状态输入:
 zkServer.sh stop
 zkServer.sh status
 -- 问题：
 Client port found: 2181. Client address: localhost.
Error contacting service. It is probably not running.

原因是：8080端口被占用，解决方法如下：
通过查看zookeeper的官方文档，发现有3种解决途径：

（1）.删除jetty。

（2）修改端口。

修改方法的方法有两种，一种是在启动脚本中增加 -Dzookeeper.admin.serverPort=你的端口号.一种是在zoo.cfg中增加admin.serverPort=没有被占用的端口号。
（3）停用这个服务，在启动脚本中增加"-Dzookeeper.admin.enableServer=false"。
 
 停止
 zkServer.sh stop
 
 
 
 -- 问题：hue无法链接hive表，报错信息：Error: Failed to open new session: java.lang.RuntimeException: org.apache.hadoop.ipc.RemoteException  User: analyze is not allowed to impersonate hue
1.修改hadoop 配置文件 etc/hadoop/core-site.xml,加入如下配置项
<property>
    <name>hadoop.proxyuser.root.hosts</name>
    <value>*</value>
</property>
<property>
    <name>hadoop.proxyuser.root.groups</name>
    <value>*</value>
</property>
 

Hadoop.proxyuser.root.hosts配置项名称中root部分为报错User:* 中的用户名部分

例如User: zhaoshb is not allowed to impersonate anonymous则需要将xml变更为如下格式
	
解决方案：
首先需要开启rest接口，在hdfs-site.xml文件中加入：
<property>  
<name>dfs.webhdfs.enabled</name>  
<value>true</value>  
</property>

然后在core-site.xml文件中加入
<property>
    <name>hadoop.proxyuser.analyze.hosts</name>
    <value>*</value>
</property>
<property>
    <name>hadoop.proxyuser.analyze.groups</name>
    <value>*</value>
</property>


<property>
    <name>hadoop.proxyuser.hadoop.hosts</name>
    <value>*</value>
</property>
<property>
    <name>hadoop.proxyuser.hadoop.groups</name>
    <value>*</value>
</property>
<property>
    <name>hadoop.proxyuser.hue.hosts</name>
    <value>*</value>
</property>
<property>
    <name>hadoop.proxyuser.hue.groups</name>
    <value>*</value>
</property>
<property>
    <name>hadoop.proxyuser.hdfs.hosts</name>
    <value>*</value>
</property>
<property>
    <name>hadoop.proxyuser.hdfs.groups</name>
    <value>*</value>
</property> 

最后重启hadoop






-- 注意：启动zookeeper 需要在三台机器上都要启动，hadoop hive hbase spark 只需要在master上启动即可

start-dfs.sh
start-yarn.sh

cd /home/analyze/spark/spark2.4/sbin
start-all.sh

cd /home/analyze/zookeeper/zookeeper-3.5.8/bin
zkServer.sh start

start-hbase.sh (zookeeper集群搭建好后，需要先启动zk，不然hbase启动不起来）

hadoop dfsadmin -report

cd $HIVE_HOME/bin
hive --service metastore &

cd $HIVE_HOME/bin
hive --service hiveserver2 &

$HADOOP_HOME/sbin/mr-jobhistory-daemon.sh start historyserver

-- 启动服务路径 supervisor  /  hue runserver 127.0.0.1:8090
cd /home/analyze/hue4.2/hue-4.2.0/build/env/bin
supervisor

/home/analyze/livy/livy-0.5/bin
livy-server start     127.0.0.1:8199

stop-hbase.sh

cd /home/analyze/zookeeper/zookeeper-3.5.8/bin
zkServer.sh stop

cd /home/analyze/spark/spark2.4/sbin
stop-all.sh

stop-yarn.sh
stop-dfs.sh



--------------------------------------------------------------------------------- 搭建 oozie-4

cd /home/analyze/oozie/oozie-4.3.0/bin
-- 编译
mkdistro.sh  -DskipTests -Puber -Phadoop-2 \
-Dhadoop.version=2.7.2 \
-Dhadoop.auth.version=2.7.2 \
-Ddistcp.version=2.7.2 \
-Dsqoop.version=1.4.3 \
-Dhive.version=1.2.0 \
-Dhbase.version=0.94.27



-- 解决办法 
修改 /usr/local/maven/conf 路径下的 settings.xml，添加
<mirror>
    <id>Central</id>
    <mirrorOf>*</mirrorOf>
    <name>Central</name>
    <url>http://central.maven.org/maven2/</url>
</mirror>
<!-- 阿里云镜像 -->
<mirror>
    <id>nexus-aliyun</id>
    <mirrorOf>*</mirrorOf>
    <name>Nexus aliyun</name>
    <url>http://maven.aliyun.com/nexus/content/groups/public</url>
</mirror>

cd /home/analyze/oozie/oozie-4.3.0 修改 pom.xml
oozie的pom.xml中的地址是这样的：<id>central</id>的url是http://repo1.maven.org/maven2,然后电脑又不识别http,只认https!!!。

3.修改maven的仓库设置
#这里我们需要编译oozie，所以不用阿里云仓库(很多依赖不全)，改成使用maven的中央仓库。
[root@sht-sgmhadoopdn-04 app]# cd /root/learnproject/app/maven/conf 
[root@sht-sgmhadoopdn-04 conf]# vi settings.xml

复制代码
<mirror>
    <id>Central</id>
    <mirrorOf>*</mirrorOf>
    <name>Central</name>
    <url>http://central.maven.org/maven2/</url>
</mirror>
<!-- 阿里云镜像 -->
<mirror>
    <id>nexus-aliyun</id>
    <mirrorOf>*</mirrorOf>
    <name>Nexus aliyun</name>
    <url>http://maven.aliyun.com/nexus/content/groups/public</url>
</mirror>




Non-resolvable parent POM: Could not transfer artifact org.apache:apache:pom:17 from/to central (http://repo1.maven.org/maven2): Failed to transfer file: http://repo1.maven.org/maven2/org/apache/apache/17/apache-17.pom. Return code is: 501 , ReasonPhrase:HTTPS Required. and ‘parent.relativePath’ points at wrong local POM @ line 21, column 13 -> [Help 2]
困扰了我很久，网上说是改maven仓库的，我改了是肯定的啊，然后又是一大堆算起八糟的，困扰了我半天，睡一觉起来灵感来了，会不会是oozie里面自带的pom.xml文件写了错误的仓库地址，后来一查是的。

原因：oozie的pom.xml中的地址是这样的：<id>central</id>的url是http://repo1.maven.org/maven2,然后电脑又不识别http,只认https!!!。

解决办法：改成https。 /usr/local/maven/conf/settings.xml

-- 问题
[ERROR] Failed to execute goal org.apache.maven.plugins:maven-antrun-plugin:1.6:run (default) on project\
 oozie-distro: An Ant BuildException has occured: java.net.ConnectException: 连接超时 (Connection timed out) -> [Help]
 
-- 解决办法：
cd oozie-4.3.0/distro/downloads
wget http://archive.apache.org/dist/tomcat/tomcat-6/v6.0.47/bin/apache-tomcat-6.0.47.tar.gz
mv apache-tomcat-6.0.47.tar.gz tomcat-6.0.47.tar.gz


-- 编译完成后
在hdfs上创建/user/oozie目录，执行：
hdfs dfs -mkdir /user/oozie



-- 问题：./oozie-setup.sh:行317: zip: 未找到命令
切换到root 安装zip
yum install zip


设置环境变量 source ~/.bash_profile
export OOZIE_HOME=/home/analyze/oozie_4.3.0/oozie-4.3.0
export PATH=$OOZIE_HOME/bin:$PATH
export OOZIE_CONFIG=/home/analyze/oozie_4.3.0/oozie-4.3.0/conf

# 这里要注意地址后面要带/oozie，否则报404错误, 踩过的坑只有自己知道痛苦
export OOZIE_URL=http://10.227.96.27:11000/oozie


3.2 修改配置文件/usr/local/oozie/conf/oozie-site.xml
默认conf文件夹下的oozie-site.xml文件都是注释的，需要自己添加以下内容

<?xml version="1.0"?>
<configuration>

    <!--
        Refer to the oozie-default.xml file for the complete list of
        Oozie configuration properties and their default values.
    -->

    <!-- Proxyuser Configuration -->

    <property>
        <name>oozie.service.ProxyUserService.proxyuser.hadoop.hosts</name>
        <value>*</value>
        <description>
            List of hosts the '#USER#' user is allowed to perform 'doAs'
            operations.

            The '#USER#' must be replaced with the username o the user who is
            allowed to perform 'doAs' operations.

            The value can be the '*' wildcard or a list of hostnames.

            For multiple users copy this property and replace the user name
            in the property name.
        </description>
    </property>

    <property>
        <name>oozie.service.ProxyUserService.proxyuser.hadoop.groups</name>
        <value>*</value>
        <description>
            List of groups the '#USER#' user is allowed to impersonate users
            from to perform 'doAs' operations.

            The '#USER#' must be replaced with the username o the user who is
            allowed to perform 'doAs' operations.

            The value can be the '*' wildcard or a list of groups.

            For multiple users copy this property and replace the user name
            in the property name.
        </description>
    </property>

    <!-- 20180110 add -->
    <property>
        <name>oozie.service.JPAService.create.db.schema</name>
          <value>false</value>
        </property>
    <property>
        <name>oozie.service.JPAService.jdbc.driver</name>
        <value>com.mysql.jdbc.Driver</value>
    </property>
    <property>
        <name>oozie.service.JPAService.jdbc.url</name>
        <value>jdbc:mysql://10.227.96.6:3006/oozie?createDatabaseIfNotExist=true</value> 
    </property>
     
    <property>
        <name>oozie.service.JPAService.jdbc.username</name>
        <value>anamember</value>
    </property>
     
    <property>
        <name>oozie.service.JPAService.jdbc.password</name>
        <value>ana829test</value>
        <description>
                DB user password.
                IMPORTANT: if password is emtpy leave a 1 space string, the service trims the value,
                if empty Configuration assumes it is NULL.
        </description>
    </property>

    <property>
        <name>oozie.service.HadoopAccessorService.hadoop.configurations</name>
        <value>*=/home/analyze/hadoop/hadoop-2.8.5/etc/hadoop</value>
    </property>

      <property>
        <name>oozie.service.HadoopAccessorService.action.configurations</name>
        <value>*=/home/analyze/hadoop/hadoop-2.8.5/etc/hadoop</value>
    </property>

    <property>
         <name>oozie.service.SparkConfigurationService.spark.configurations</name>
         <value>*=/home/analyze/spark/spark2.4/conf</value>
    </property>

    <!-- 这里是保存在hdfs上的路径 -->
    <property>
         <name>oozie.service.WorkflowAppService.system.libpath</name>
         <value>/user/oozie/share/lib</value>
    </property>

    <property>
        <name>oozie.use.system.libpath</name>
        <value>true</value>
        <description>
                Default value of oozie.use.system.libpath. If user haven't specified =oozie.use.system.libpath=
                in the job.properties and this value is true and Oozie will include sharelib jars for workflow.
        </description>
    </property>

    <property>
        <name>oozie.subworkflow.classpath.inheritance</name>
        <value>true</value>
    </property>


    <property>
        <name>oozie.service.ProxyUserService.proxyuser.anamember.hosts</name>
        <value>*</value>
    </property>
	<property>
    <name>oozie.service.ProxyUserService.proxyuser.anamember.groups</name>
    <value>*</value>
    </property>

</configuration>


 3.3 创建元数据表

在/usr/local/oozie/bin目录下执行以下命令生成sql文件，并创建元数据表
bin/ooziedb.sh create -sqlfile oozie.sql -run

-- 问题：在创建元数据表的时候报： Specified key was too long; max key length is 767 bytes
修改oozie数据库的基集字符和排列规则 由utf8mb4改为utf8


ERROR ShareLibService:517 - SERVER[azkaban] There was an issue purging the sharelib java.io.FileNotFoundException
解决办法：

    <!-- 这里是保存在hdfs上的路径 -->
    <property>
         <name>oozie.service.WorkflowAppService.system.libpath</name>
         <value>/user/oozie/share/lib</value>  -- 修改为hdfs路径
    </property>
	
oozie-setup.sh sharelib create -fs hdfs://10.227.96.27:8100
oozied.sh start	
hdfs dfs -ls /user/oozie/share/lib

oozie admin -shareliblist -oozie http://azkaban:11000/oozie
oozie-setup.sh sharelib create -fs hdfs://azkaban:8100
oozie admin -shareliblist -oozie http://azkaban:11000/oozie
oozie admin -oozie http://azkaban:11000/oozie -shareliblist
cd /home/analyze/oozie_4.3.0/oozie-4.3.0/bin
oozied.sh start
oozie admin -shareliblist -oozie http://10.227.96.27:11000/oozie
oozie admin -shareliblist -oozie http://azkaban:11000/oozie

oozie-setup.sh sharelib create -fs hdfs://azkaban:11000 -locallib oozie-sharelib-4.1.0-cdh5.5.4-yarn.tar.gz
oozie-setup.sh sharelib create -fs hdfs://azkaban:11000 -locallib  share

查看web界面&查看状态 oozie admin -oozie http://azkaban:11000/oozie -status ##显示normal属于正常
oozie-setup.sh sharelib create -fs hdfs://azkaban:8100 

-- 问题：hue sqoop1 无法执行同步数据
Error submitting workflow Batch job for query-sqoop1: 500 Server Error: Internal Server Error for url: http://localhost:11000/oozie/v1/jobs?timezone=America%2FLos_Angeles&user.name=hue&doAs=analyze <html><head><title>Apache Tomcat/6.0.47 - Error report</title><style><!--H1 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:22px;} H2 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:16px;} H3 {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;font-size:14px;} BODY {font-family:Tahoma,Arial,sans-serif;color:black;background-color:white;} B {font-family:Tahoma,Arial,sans-serif;color:white;background-color:#525D76;} P {font-family:Tahoma,Arial,sans-serif;background:white;color:black;font-size:12px;}A {color : black;}A.name {color : black;}HR {color : #525D76;}--></style> </head><body><h1>HTTP Status 500 - Servlet execution threw an exception</h1><HR size="1" noshade="noshade"><p><b>type</b> Exception report</p><p><b>message</b> <u>Servlet execution threw an exception</u></p><p><b>description</b> <u>The server encountered an internal error that prevented it from fulfilling this request.</u></p><p><b>exception</b> <pre>javax.servlet.ServletException: Servlet execution threw an exception org.apache.oozie.servlet.AuthFilter$2.doFilter(AuthFilter.java:171) org.apache.hadoop.security.authentication.server.AuthenticationFilter.doFilter(AuthenticationFilter.java:595) org.apache.hadoop.security.authentication.server.AuthenticationFilter.doFilter(AuthenticationFilter.java:554) org.apache.oozie.servlet.AuthFilter.doFilter(AuthFilter.java:176) org.apache.oozie.servlet.HostnameFilter.doFilter(HostnameFilter.java:86) </pre></p><p><b>root cause</b> <pre>java.lang.NoSuchMethodError: org.apache.hadoop.security.authentication.util.KerberosUtil.hasKerberosTicket(Ljavax/security/auth/Subject;)Z org.apache.hadoop.security.UserGroupInformation.&lt;init&gt;(UserGroupInformation.java:657) org.apache.hadoop.security.UserGroupInformation.loginUserFromSubject(UserGroupInformation.java:848) org.apache.hadoop.security.UserGroupInformation.getLoginUser(UserGroupInformation.java:807) org.apache.oozie.service.UserGroupInformationService.getProxyUser(UserGroupInformationService.java:55) org.apache.oozie.service.HadoopAccessorService.getUGI(HadoopAccessorService.java:335) org.apache.oozie.service.HadoopAccessorService.createFileSystem(HadoopAccessorService.java:562) org.apache.oozie.service.AuthorizationService.authorizeForApp(AuthorizationService.java:374) org.apache.oozie.servlet.BaseJobServlet.checkAuthorizationForApp(BaseJobServlet.java:260) org.apache.oozie.servlet.BaseJobsServlet.doPost(BaseJobsServlet.java:99) javax.servlet.http.HttpServlet.service(HttpServlet.java:643) org.apache.oozie.servlet.JsonRestServlet.service(JsonRestServlet.java:304) javax.servlet.http.HttpServlet.service(HttpServlet.java:723) org.apache.oozie.servlet.AuthFilter$2.doFilter(AuthFilter.java:171) org.apache.hadoop.security.authentication.server.AuthenticationFilter.doFilter(AuthenticationFilter.java:595) org.apache.hadoop.security.authentication.server.AuthenticationFilter.doFilter(AuthenticationFilter.java:554) org.apache.oozie.servlet.AuthFilter.doFilter(AuthFilter.java:176) org.apache.oozie.servlet.HostnameFilter.doFilter(HostnameFilter.java:86) </pre></p><p><b>note</b> <u>The full stack trace of the root cause is available in the Apache Tomcat/6.0.47 logs.</u></p><HR size="1" noshade="noshade"><h3>Apache Tomcat/6.0.47</h3></body></html> (error 500)



2021-03-26 14:18:51,425  WARN AuthorizationService:523 - SERVER[azkaban] Oozie running with authorization disabled
2021-03-26 14:18:53,819 ERROR ShareLibService:517 - SERVER[azkaban] org.apache.oozie.service.ServiceException: E0104: Could not fully initialize service [org.apache.oozie.service.ShareLibService], Not able to cache sharelib. An Admin needs to install the sharelib with oozie-setup.sh and issue the 'oozie admin' CLI command to update the sharelib
org.apache.oozie.service.ServiceException: E0104: Could not fully initialize service [org.apache.oozie.service.ShareLibService], Not able to cache sharelib. An Admin needs to install the sharelib with oozie-setup.sh and issue the 'oozie admin' CLI command to update the sharelib

Caused by: java.lang.NoSuchMethodError: org.apache.hadoop.security.authentication.util.KerberosUtil.hasKerberosTicket(Ljavax/security/auth/Subject;)Z




Hadoop之HDFS上测试创建目录、上传、下载文件

1、HDFS上创建目录
${HADOOP_HOME}/bin/hdfs dfs -mkdir /demo1

2、上传本地文件到HDFS上
${HADOOP_HOME}/bin/hdfs dfs -put ${HADOOP_HOME}/etc/hadoop/core-site.xml /demo1

3、上传本地文件到HDFS上
${HADOOP_HOME}/bin/hdfs dfs -cat /demo1/core-site.xml

4、从HDFS上下载文件到本地
${HADOOP_HOME}/bin/hdfs dfs -get /demo1/core-site.xml


SERVER[azkaban] org.apache.oozie.service.ServiceException: E0104: Could not fully initialize service [org.apache.oozie.service.ShareLibService], Not able to cache sharelib. An Admin needs to install the sharelib with oozie-setup.sh and issue the 'oozie admin' CLI command to update the sharelib
org.apache.oozie.service.ServiceException: E0104: Could not fully initialize service [org.apache.oozie.service.ShareLibService], Not able to cache sharelib. An Admin needs to install the sharelib with oozie-setup.sh and issue the 'oozie admin' CLI command to update the sharelib


-- 问题：Caused by: java.io.IOException: Cannot initialize Cluster. Please check your configuration for mapreduce.framework.name and the correspond server addresses.

3. JA009: Cannot initialize Cluster. Please check your configuration for mapreduce.framework.name 

原因： 引起这种错误大部分都是配置问题，看了网上的各种错误配置导致的。我这里是因为配置oozie-site.xml中

oozie.service.ProxyUserService.proxyuser.XXXXX.hosts和oozie.service.ProxyUserService.proxyuser.XXXXX.groups

错误导致的。这里的XXXXX应该是执行任务的用户，由于我的ooziejob所有的都是在hadoop账号下调度，所有应该是hadoop。

    <property>
        <name>oozie.service.ProxyUserService.proxyuser.hadoop.hosts</name>
        <value>*</value>
    </property>
    <property>
        <name>oozie.service.ProxyUserService.proxyuser.hadoop.groups</name>
        <value>*</value>
    </property>


Hadoop在执行job任务时，有时容易出现这个错误，但是我们在编译的时间并没有发生到什么异常和错误，但是在执行的过程中可能会出现这个初始化异常，一看这个错误，好像是自己配置的地址不对，但是出现这类异常大部分是因为缺少像这样的jar包 ：hadoop-mapreduce-client-common

还有一种可能就是你的jar包引入的版本不正确导致的。或者缺少jar包，仔细根据异常去排查，最终都会解决这类错误。


bin/oozie-setup.sh sharelib create -fs hdfs://azkaban:8100
bin/oozie-setup.sh sharelib create -fs hdfs://azkaban:8100 -locallib oozie-sharelib-4.1.0-cdh5.5.4-yarn.tar.gz

/home/analyze/oozie_4.3.0/oozie-4.3.0/oozie-server/webapps/oozie/WEB-INF/lib

mv hadoop-mapreduce-client-app-2.7.2.jar hadoop-mapreduce-client-common-2.7.2.jar hadoop-mapreduce-client-core-2.7.2.jar hadoop-mapreduce-client-jobclient-2.7.2.jar  hadoop-mapreduce-client-shuffle-2.7.2.jar /home/analyze/lib_tmp




<!-- 配置 MapReduce JobHistory Server 地址 ，默认端口10020 -->
<property>
        <name>mapreduce.jobhistory.address</name>
        <value>azkaban:10020</value>
</property>

<!-- 配置 MapReduce JobHistory Server web ui 地址， 默认端口19888 -->
<property>
        <name>mapreduce.jobhistory.webapp.address</name>
        <value>azkaban:19888</value>
</property>



<property> 
    <name>yarn.log.server.url</name> 
    <value>http://azkaban:19888/jobhistory/logs/</value> 
</property> 

 

-- 问题：java.io.EOFException: End of File Exception between local host is: "azkaban/10.227.96.27"; destination host is: "azkaban":11000; : java.io.EOFException; For more details see:  http://wiki.apache.org/hadoop/EOFException

解决方法：进入：hadoop-2.8.5/etc/hadoop/  修改 core.site.xml 将
   <property>
        <name>fs.default.name</name>
        <value>hdfs://10.227.96.27:8100</value>
   </property>
改为
   <property>
        <name>fs.default.name</name>
        <value>hdfs://azkaban:8100</value>
   </property>



-- 问题：spark向hive中写入数据时，提示找不到已经创建完成的数据库，

org.apache.spark.sql.catalyst.analysis.NoSuchDatabaseException: Database 'traffic' not found;
我的问题出现原因：

没有为spark设置hive的路径
解决方案：
将hive客户端的hive-site.xml放入到spark的conf目录下，spark会自己找到该配置文件，找到hive的所在位置

-- 问题：
ERROR hdfs.KeyProviderCache: Could not find uri with key [dfs.encryption.key.provider.uri] to create a keyProvider !!

res2: org.apache.spark.sql.DataFrame = []
解决方案：暂无


-- spark-shell 和 spark-sql的区别
【spark-shell On Yarn】
需要配置Yarn的配置文件目录，export HADOOP_CONF_DIR=/etc/hadoop/conf   这个可以配置在spark-env.sh中。

需要允许命令：
cd $SPARK_HOME/bin/spark-shell --master yarn-client --executor-memory 1G --num-executors 10


注意，这里的–master必须使用yarn-client模式，如果指定yarn-cluster，则会报错：

Error: Cluster deploy mode is not applicable to Spark shells.

因为spark-shell作为一个与用户交互的命令行，必须将Driver运行在本地，而不是yarn上。

其中的参数与提交Spark应用程序到yarn上用法一样。

启动之后，在命令行看上去和standalone模式下的无异：


【spark-sql On Yarn】

cd $SPARK_HOME/bin/spark-sql --master yarn-client --executor-memory 1G --num-executors 10


spark-sql命令行运行在yarn上，原理和spark-shell on yarn一样。只不过需要将Hive使用的相关包都加到Spark环境变量。

1. 将hive-site.xml拷贝到$SPARK_HOME/conf

2.export HIVE_HOME=/usr/local/apache-hive-0.13.1-bin 添加到spark-env.sh

3.将以下jar包添加到Spark环境变量：

datanucleus-api-jdo-3.2.6.jar、datanucleus-core-3.2.10.jar、datanucleus-rdbms-3.2.9.jar、mysql-connector-java-5.1.15-bin.jar

可以在spark-env.sh中直接添加到SPARK_CLASSPATH变量中。



-- hue 问题：HTTPConnectionPool(host='localhost', port=8998): Max retries exceeded with url: /sessions (Caused by NewConnectionError(': Failed to establish a new connection: [Errno 97] Address family not supported by protocol',))

解决方法：安装Livy服务器

export LIVY_HOME=/home/analyze/livy/livy-0.5
export JAVA_HOME=/app/jdk1.8.0_192
export HADOOP_CONF_DIR=/home/analyze/hadoop/hadoop-2.8.5/etc/hadoop
export SPARK_HOME=/home/analyze/spark/spark2.4
export SPARK_CONF_DIR=/home/analyze/spark/spark2.4/conf
export SCALA_HOME=/home/analyze/scala/scala2.13
export LIVY_LOG_DIR=/home/analyze/livy/livy-0.5/logs
export LIVY_PID_DIR=/home/analyze/livy/livy-0.5/run

#PYSPARK_ALLOW_INSECURE_GATEWAY很重要关系到pyspark在hue的启动运行，
#在livy-env.sh、 /etc/profile 、和spark-env.sh都要配置

export PYSPARK_ALLOW_INSECURE_GATEWAY=1





-- 问题：notebook scala允许不了 资源不足

21/03/25 18:03:13 INFO yarn.Client: Verifying our application has not requested more than the maximum memory capability of the cluster (2048 MB per container)
21/03/25 18:03:13 ERROR spark.SparkContext: Error initializing SparkContext.
java.lang.IllegalArgumentException: Required executor memory (2048), overhead (384 MB), and PySpark memory (0 MB) is above the max threshold (2048 MB) of this cluster! Please check the values of 'yarn.scheduler.maximum-allocation-mb' and/or 'yarn.nodemanager.resource.memory-mb'.

The Spark session could not be created in the cluster: 21/03/19 19:19:48 INFO yarn.Client: Application report for application_1615272783417_0012 (state: ACCEPTED) 21/03/19 19:19:49 INFO yarn.Client: Application report for application_1615272783417_0012 (state: ACCEPTED) 21/03/19 19:19:50 INFO yarn.Client: Application report for application_1615272783417_0012 (state: ACCEPTED) 21/03/19 19:19:51 INFO yarn.Client: Application report for application_1615272783417_0012 (state: ACCEPTED) 21/03/19 19:19:52 INFO yarn.Client: Application report for application_1615272783417_0012 (state: ACCEPTED) 21/03/19 19:19:53 INFO yarn.Client: Application report for application_1615272783417_0012 (state: ACCEPTED) 21/03/19 19:19:54 INFO yarn.Client: Application report for application_1615272783417_0012 (state: ACCEPTED) 21/03/19 19:19:55 INFO yarn.Client: Application report for application_1615272783417_0012 (state: ACCEPTED) YARN Diagnostics: [星期五 三月 19 19:18:07 +0800 2021] Application is added to the scheduler and is not yet activated. Queue's AM resource limit exceeded. Details : AM Partition = ; AM Resource Request = ; Queue Resource Limit for AM = ; User AM Resource Limit of the queue = ; Queue AM Resource Usage = ;

2.原因
单个任务可申请的默认最大内存为1024M，任务执行实际需要1384M个，需要增加可申请的内存量，修改配置参数如下图。

3.解决方法
修改对应参数

#MR ApplicationMaster占用的内存量
yarn.app.mapreduce.am.resource.mb =4g
#单个节点上金额分配的物理内存总量
yarn.nodemanager.resource.memory-mb=8g
#单个任务可申请的最多物理内存量
yarn.scheduler.maximum-allocation-mb=4g

解决方法如下
在yarn-site.xml中添加：
<!-- 设置RM内存资源配置，两个参数 -->
<property>
    <description>The minimum allocation for every container request at the RM,
        in MBs. Memory requests lower than this won't take effect,
        and the specified value will get allocated at minimum.</description>
    <name>yarn.scheduler.minimum-allocation-mb</name>
    <value>1024</value>
</property>
<property>
    <description>The maximum allocation for every container request at the RM,
        in MBs. Memory requests higher than this won't take effect,
        and will get capped to this value.</description>
    <name>yarn.scheduler.maximum-allocation-mb</name>
    <value>4096</value>
</property>

<!-- 前者表示单个节点可用的最大内存，RM中的两个值都不应该超过该值。后者表示虚拟内存率，即占task所用内存的百分比，默认为2.1.-->
<property>
    <description>Amount of physical memory, in MB, that can be allocated
        for containers.</description>
    <name>yarn.nodemanager.resource.memory-mb</name>
    <value>8192</value>
</property>
<property>
    <description>Ratio between virtual memory to physical memory when
        setting memory limits for containers. Container allocations are
        expressed in terms of physical memory, and virtual memory usage
        is allowed to exceed this allocation by this ratio.
    </description>
    <name>yarn.nodemanager.vmem-pmem-ratio</name>
    <value>2.1</value>
</property>
<property>
    <description>Amount of physical memory, in MB, that can be allocated
        for containers.</description>
    <name>yarn.app.mapreduce.am.resource.mb</name>
    <value>4096</value>
</property>





-- 问题：yarn框架ha状态下8088端口故障处理

lepton126 2017-05-12 16:11:03  2251  收藏
分类专栏： 分布式系统 运维 文章标签： yarn ha
版权
ERROR org.apache.hadoop.yarn.server.resourcemanager.ResourceManager: RECEIVED SIGNAL 15: SIGTERM
ERROR org.apache.hadoop.security.token.delegation.AbstractDelegationTokenSecretManager: ExpiredTokenRemover received java.lang.Interr
uptedException: sleep interrupted
INFO org.mortbay.log: Stopped HttpServer2$SelectChannelConnectorWithSafeStartup@hostname:8088
yarn ha 8088 端口故障
./yarn rmadmin -transitionToActive --forcemanual rm1
./yarn rmadmin -transitionToStandby --forcemanual rm2

bin/hadoop namenode -format
sbin/hadoop-daemon.sh start namenode
sbin/hadoop-daemon.sh start datanode(多个datanode， 使用hadoop-daemons.sh)
sbin/yarn-daemon.sh start resourcemanager
sbin/yarn-daemon.sh start nodemanager(多个datanode， 使用yarn-daemons.sh)
或者一次启动过：sbin/start-yarn.sh


stop-all.sh
start-all.sh

参阅http://blog.chinaunix.net/uid-25691489-id-5595925.html
 
 
-- 大问题：
yarn资源管理器 无法可视化 8088
hue oozie框架
hive不稳定，是不是提示数据库不存在
hue spark notebook
hue sqoop 



-- 问题 HBase 创建表报错
org.apache.hadoop.hbase.PleaseHoldException: Master is initializing

这个情况是因为以前安装的HBASE有残留，只需要在Zookeeper Client端删除即可
输入以下命令：
（下面是CDH的命令。如果没有配置系统变量，你应该去zookeeper/bin下找到zookeeper-client.sh 启动客户端）
进入Zookeeper Client  /  zkCli.sh

[root@cdh03 ~]# zookeeper-client 
1
查看文件夹

[zk: localhost:2181(CONNECTED) 0] ls /
1
显示结果

删除hbase文件夹

[zk: localhost:2181(CONNECTED) 2] rmr /hbase
1
然后重启HBASE就好了




----------------------------------------------------------- hive on spark
<configuration>
<property> 
<name>hive.metastore.schema.verification</name> 
<value>false</value> 
</property>
<property>
<name>javax.jdo.option.ConnectionURL</name>
<value>jdbc:mysql://192.168.66.66:3306/hive?createDatabaseIfNotExist=true</value>
</property>
<property>
<name>javax.jdo.option.ConnectionDriverName</name>
<value>com.mysql.jdbc.Driver</value>
</property>
<property>
<name>javax.jdo.option.ConnectionUserName</name>
<value>hive</value>
</property>
<property>
<name>javax.jdo.option.ConnectionPassword</name>
<value>1</value>
</property>
<!--<property>
<name>hive.hwi.listen.host</name>
<value>192.168.66.66</value>
</property>
<property>
<name>hive.hwi.listen.port</name>
<value>9999</value>
</property>
<property>
<name>hive.hwi.war.file</name>
<value>lib/hive-hwi-2.1.1.war</value>
</property>-->
<property>
<name>hive.metastore.warehouse.dir</name>
<value>/user/hive/warehouse</value>
</property>
<property>
<name>hive.exec.scratchdir</name>
<value>/user/hive/tmp</value>
</property>
<property>
<name>hive.querylog.location</name>
<value>/user/hive/log</value>
</property>


<property> 
<name>hive.server2.thrift.port</name> 
<value>10000</value>
</property>
<property> 
<name>hive.server2.thrift.bind.host</name> 
<value>192.168.66.66</value>
</property>
<property>
<name>hive.server2.webui.host</name>
<value>192.168.66.66</value>
</property>


<property>
<name>hive.server2.webui.host</name>
<value>azkaban</value>
</property>
<property>
<name>hive.server2.webui.port</name>
<value>10002</value>
</property>

<property> 
<name>hive.server2.long.polling.timeout</name> 
<value>5000</value>                               
</property>
<property>
<name>hive.server2.enable.doAs</name>
<value>true</value>
</property>
<property>
<name>datanucleus.autoCreateSchema </name>
<value>false</value>
</property>
<property>
<name>datanucleus.fixedDatastore </name>
<value>true</value>
</property>



<!-- hive on mr-->
<!--
<property> 
<name>mapred.job.tracker</name> 
<value>azkaban:8001</value> 
</property>


<property> 
<name>mapreduce.framework.name</name> 
<value>yarn</value> 
</property>
-->


<!--hive on spark or spark on yarn -->
<property>
<name>hive.execution.engine</name>
<value>spark</value>
</property>
<property>
<name>spark.home</name>
<value>/home/analyze/spark/spark2.4</value>
</property>
<property>
<name>spark.master</name>
<value>spark://azkaban:7077</value>  
<description>或者yarn-cluster/yarn-client</description>
</property>
<property> 
<name>spark.submit.deployMode</name> 
<value>client</value> 
</property>
<property>
<name>spark.eventLog.enabled</name>
<value>true</value>
</property>
<property>
<name>spark.eventLog.dir</name>
<value>hdfs://zakaban:9000/spark-log</value>
</property>
<property>
<name>spark.serializer</name>
<value>org.apache.spark.serializer.KryoSerializer</value>
</property>
<property>
<name>spark.executor.memeory</name>
<value>512m</value>
</property>
<property>
<name>spark.driver.memeory</name>
<value>512m</value>
</property>
<property>
<name>spark.executor.extraJavaOptions</name>
<value>-XX:+PrintGCDetails -Dkey=value -Dnumbers="one two three"</value>
</property>
</configuration>
