

-- 开启
#开启hdfs
start-dfs.sh
#开启yarn
start-yarn.sh
#开启spark 集群
cd /home/analyze/spark/spark2.4/sbin
start-all.sh

#开启zookeeper集群
cd /home/analyze/zookeeper/zookeeper-3.5.8/bin
zkServer.sh start

#开启hbase集群
start-hbase.sh (zookeeper集群搭建好后，需要先启动zk，不然hbase启动不起来）

#启动hive服务
cd $HIVE_HOME/bin
hive --service metastore &

cd $HIVE_HOME/bin
hive --service hiveserver2 &

#启动 historyserver 服务
$HADOOP_HOME/sbin/mr-jobhistory-daemon.sh start historyserver

-- 启动服务路径 supervisor  /  hue runserver 127.0.0.1:8090 用于hue可视化访问
cd /home/analyze/hue4.2/hue-4.2.0/build/env/bin
supervisor

#启动Livy服务 用于spark任务
/home/analyze/livy/livy-0.5/bin
livy-server start     127.0.0.1:8199


-- 停止

/home/analyze/livy/livy-0.5/bin
livy-server stop  

stop-hbase.sh

cd /home/analyze/zookeeper/zookeeper-3.5.8/bin
zkServer.sh stop

cd /home/analyze/spark/spark2.4/sbin
stop-all.sh

stop-yarn.sh
stop-dfs.sh
