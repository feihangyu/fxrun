大数据平台搭建流程梳理

前期安装包及所在位置
1) JDK:1.8
analyze@jumpserver000
2) /home/analyze/hadoop/hadoop-2.8.5.tar.gz  (hadoop)  
3) /home/analyze/hadoop/hbase-2.2.5-bin.tar.gz  (hbase) 
4) /home/analyze/hadoop/apache-hive-2.3.7-bin.tar.gz (hive) 
5) /home/analyze/scala-2.13.4.tgz  (scala) 
6) /home/analyze/spark-2.4.7-bin-hadoop2.7.tgz  (spark)
7) /home/analyze/hadoop/sqoop-1.4.7.bin__hadoop-2.6.0.tar.gz  (sqoop)
8) /home/analyze/apache-zookeeper-3.5.8-bin.tar.gz  (zookeeper)

【大数据学习系列之一 ----- Hadoop环境搭建(单机)  【对应链接地址：https://blog.csdn.net/qazwsxpcm/article/details/78637874】】

【说明：在配置Hadoop之前，应该先做以下配置】
首先更改主机名，目的是为了方便管理
vim /etc/hosts
添加 主机IP 和对应的主机名称，做映射

127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
10.227.96.27 azkaban  （此处改为对应的机器，主机名建议改为 master）

【以下是测试环境的操作命令】
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
10.227.96.27 azkaban
10.227.96.23 hadoop-01   （集群salver）
10.227.96.24 hadoop-02   （集群salver）
注:在配置文件中使用主机名的话，这个映射必须做，这个以便后面方便集群配置


一、Hadoop环境安装
【压缩包路径： /home/analyze/hadoop/hadoop-2.8.5.tar.gz  (hadoop) 】
1、解压文件,先建hadoop文件夹
输入: 
tar -xvf hadoop-2.8.2.tar.gz
解压hadoop 并移动文件到hadoop文件下，并将文件夹重命名hadoop2.8

2、JDK环境配置和Hadoop 环境配置

编辑 /etc/profile 文件   （测试环境：vim ~/.bash_profile）
输入:vim /etc/profile
【以下是测试环境的操作命令】
#JAVA_HOME
export JAVA_HOME=/app/jdk1.8.0_192
export PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/jre/lib/tools.jar
export PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH:$HOME/bin
#MYSQL_HOME
export MYSQL_HOME=/app/mysql
export PATH=$MYSQL_HOME/bin:$PATH
#HADOOP_HOME
export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_HOME/lib/native
export HADOOP_OPTS="-Djava.library.path=$HADOOP_HOME/lib"
export PATH="$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH"
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop

输入：source /etc/profile，使配置生效
输入 java -version 查看版本信息

2.1、Hadoop 环境配置之新建文件夹
在修改配置文件之前，现在root目录下建立一些文件夹。
输入:
mkdir  /root/hadoop  
mkdir  /root/hadoop/tmp  
mkdir  /root/hadoop/var  
mkdir  /root/hadoop/dfs  
mkdir  /root/hadoop/dfs/name  
mkdir  /root/hadoop/dfs/data
注:在root目录下新建文件夹是防止被莫名的删除。

【以下是测试环境的操作命令】
mkdir  /home/analyze/hadoop/hadoop-2.8.5/tmp  
mkdir  /home/analyze/hadoop/hadoop-2.8.5/var  
mkdir  /home/analyze/hadoop/hadoop-2.8.5/dfs  
mkdir  /home/analyze/hadoop/hadoop-2.8.5/dfs/name  
mkdir  /home/analyze/hadoop/hadoop-2.8.5/dfs/data

2.2、Hadoop 环境配置之修改 core-site.xml
首先切换到 /home/hadoop/hadoop2.8/etc/hadoop/ 目录下
输入：vim core-site.xml
在<configuration>添加:

   <property>
        <name>hadoop.tmp.dir</name>
        <value>/root/hadoop/tmp</value>
        <description>Abase for other temporary directories.</description>
   </property>
   <property>
        <name>fs.default.name</name>
        <value>hdfs://test1:9000</value>
   </property>

【以下是测试环境的操作命令】
<property>
        <name>hadoop.tmp.dir</name>
        <value>/home/analyze/hadoop/hadoop-2.8.5/tmp</value>
        <description>Abase for other temporary directories.</description>
   </property>
   <property>
        <name>fs.default.name</name>
        <value>hdfs://azkaban:8100</value>   -- 因端口9000不在以下的范围内，测试环境为8100，azkaban为上述事先修改的主机名，此处 azkaban 可以替换为主机的ip 比如（10.227.96.27）
   </property>
<property>

TCP/1100-1140
TCP/3000-3040
TCP/5000-5300
TCP/5800-5900
TCP/8000-8200
TCP/10000-10100
TCP/21100-21120
TCP/59000-59010


2.3、Hadoop 环境配置之修改 hadoop-env.sh
首先切换到 /home/hadoop/hadoop2.8/etc/hadoop/ 目录下
输入：vim hadoop-env.sh
将${JAVA_HOME} 修改为自己的JDK路径 
即：export JAVA_HOME=${JAVA_HOME} 改为  
    export JAVA_HOME=/home/java/jdk1.8

【以下是测试环境的操作命令】
#export JAVA_HOME=${JAVA_HOME}
export JAVA_HOME=/app/jdk1.8.0_192


2.4、Hadoop 环境配置之修改 hdfs-site.xml
首先切换到 /home/hadoop/hadoop2.8/etc/hadoop/ 目录下
输入：vim hdfs-site.xml
在<configuration>添加:

<property>
   <name>dfs.name.dir</name>
   <value>/root/hadoop/dfs/name</value>
   <description>Path on the local filesystem where theNameNode stores the namespace and transactions logs persistently.</description>
</property>
<property>
   <name>dfs.data.dir</name>
   <value>/root/hadoop/dfs/data</value>
   <description>Comma separated list of paths on the localfilesystem of a DataNode where it should store its blocks.</description>
</property>
<property>
   <name>dfs.replication</name>
   <value>2</value>
</property>
<property>
      <name>dfs.permissions</name>
      <value>false</value>
      <description>need not permissions</description>
</property>
说明：dfs.permissions配置为false后，可以允许不要检查权限就生成dfs上的文件，方便倒是方便了，但是你需要防止误删除，请将它设置为true，或者直接将该property节点删除，因为默认就是true。
【以下是测试环境的操作命令】
<property>
   <name>dfs.name.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/name</value>
   <description>Path on the local filesystem where theNameNode stores the namespace and transactions logs persistently.</description>
</property>
<property>
   <name>dfs.data.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/data</value>
   <description>Comma separated list of paths on the localfilesystem of a DataNode where it should store its blocks.</description>
</property>
<property>
   <name>dfs.replication</name>
   <value>2</value>
</property>
<property>
      <name>dfs.permissions</name>
      <value>false</value>
      <description>need not permissions</description>
</property>

2.5、Hadoop 环境配置之修改mapred-site.xml
首先切换到 /home/hadoop/hadoop2.8/etc/hadoop/ 目录下
如果没有 mapred-site.xml 该文件，就复制mapred-site.xml.template文件并重命名为mapred-site.xml
输入：vim mapred-site.xml
修改这个新建的mapred-site.xml文件，在<configuration>节点内加入配置:

<property>
    <name>mapred.job.tracker</name>
    <value>test1:9001</value>
</property>
<property>
      <name>mapred.local.dir</name>
       <value>/root/hadoop/var</value>
</property>
<property>
       <name>mapreduce.framework.name</name>
       <value>yarn</value>
</property>

【以下是测试环境的操作命令】
<property>
    <name>mapred.job.tracker</name>
    <value>azkaban:8001</value>
</property>
<property>
      <name>mapred.local.dir</name>
       <value>/home/analyze/hadoop/hadoop-2.8.5/var</value>
</property>
<property>
       <name>mapreduce.framework.name</name>
       <value>yarn</value>
</property>


到此 Hadoop 的单机模式的配置就完成了

3、Hadoop启动

第一次启动Hadoop需要初始化，切换到 /home/hadoop/hadoop2.8/bin目录下输入
./hadoop  namenode  -format
初始化成功后，可以在/root/hadoop/dfs/name 目录下(该路径在hdfs-site.xml文件中进行了相应配置，并新建了该文件夹)新增了一个current 目录以及一些文件。

启动Hadoop 主要是启动HDFS和YARN
切换到/home/hadoop/hadoop2.8/sbin目录
启动HDFS，输入： start-dfs.sh
登录会询问是否连接，输入yes ，然后输入密码就可以了
启动YARN，输入： start-yarn.sh
可以输入 jps 查看是否成功启动
在浏览器输入:
http://39.108.77.250:8088/cluster  （测试环境：http://127.0.0.1:8088/cluster）
在浏览器输入: 
http://39.108.77.250:50070  （测试环境：http://127.0.0.1:5070）

到此，Hadoop的单机配置就结束了。



【大数据学习系列之二 ----- HBase环境搭建(单机)  【对应链接地址：https://blog.csdn.net/qazwsxpcm/article/details/78760055】】
【压缩包路径：/home/analyze/hadoop/hbase-2.2.5-bin.tar.gz  (hbase) 】 
将下载下来的HBase的配置文件进行解压，并移动到hbase文件夹中

二、hbase环境安装
1、编辑 /etc/profile 文件
输入:
export HBASE_HOME=/home/hbase/hbase-1.2.6
export PATH=.:${JAVA_HOME}/bin:${HADOOP_HOME}/bin:${HBASE_HOME}/bin:$PATH
【以下是测试环境的操作命令】
#Hbase HOME
export HBASE_HOME=/home/analyze/hbase/hbase-2.2.5
export PATH=.:${JAVA_HOME}/bin:${HADOOP_HOME}/bin:${HBASE_HOME}/bin:$PATH

输入： source  /etc/profile ，使配置生效，输入： hbase version  检查是否成功

2.1、HBase环境配置之新建配置文件
在 root目录下新建文件夹
mkdir  /root/hbase  
mkdir  /root/hbase/tmp  
mkdir  /root/hbase/pids
【以下是测试环境的操作命令】
mkdir  /home/analyze/hbase/hbase-2.2.5 
mkdir  /home/analyze/hbase/hbase-2.2.5/tmp  
mkdir  /home/analyze/hbase/hbase-2.2.5/pids


2.2、HBase环境配置之修改hbase-env.sh
首先切换到 /home/hbase/hbase-1.2.6/conf 目录下

编辑 hbase-env.sh 文件，添加以下配置

export JAVA_HOME=/home/java/jdk1.8
export HADOOP_HOME=/home/hadoop/hadoop2.8
export HBASE_HOME=/home/hbase/hbase-1.2.6
export HBASE_CLASSPATH=/home/hadoop/hadoop2.8/etc/hadoop
export HBASE_PID_DIR=/root/hbase/pids
export HBASE_MANAGES_ZK=false
【说明:配置的路径以自己的为准。HBASE_MANAGES_ZK=false 是不启用HBase自带的Zookeeper集群。】
【以下是测试环境的操作命令】
export JAVA_HOME=/app/jdk1.8.0_192
export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HBASE_HOME=/home/analyze/hbase/hbase-2.2.5
export HBASE_CLASSPATH=/home/analyze/hadoop/hadoop-2.8.5/etc/hadoop
export HBASE_PID_DIR=/home/analyze/hbase/hbase-2.2.5/pids
export HBASE_MANAGES_ZK=false  #HBASE_MANAGES_ZK=false 是不启用HBase自带的Zookeeper集群。

2.3、HBase环境配置之修改 hbase-site.xml
首先切换到 /home/hbase/hbase-1.2.6/conf 目录下
编辑hbase-site.xml 文件，在添加如下配置
<!-- 存储目录 -->
<property>  
 <name>hbase.rootdir</name>  
 <value>hdfs://test1:9000/hbase</value>  
 <description>The directory shared byregion servers.</description>  
</property>  
<!-- hbase的端口 -->
<property>  
 <name>hbase.zookeeper.property.clientPort</name>  
 <value>2181</value>  
 <description>Property from ZooKeeper'sconfig zoo.cfg. The port at which the clients will connect'.  
 </description>  
</property>  
<!--  超时时间 -->
<property>  
 <name>zookeeper.session.timeout</name>  
 <value>120000</value>  
</property>  
<!--  zookeeper 集群配置。如果是集群，则添加其它的主机地址 -->
<property>  
 <name>hbase.zookeeper.quorum</name>  
 <value>test1</value>  
</property>  
<property>  
 <name>hbase.tmp.dir</name>  
 <value>/root/hbase/tmp</value>  
</property>  
<!-- false是单机模式，true是分布式模式  -->
<property>  
 <name>hbase.cluster.distributed</name>  
 <value>false</value>  
</property>
【说明:hbase.rootdir：这个目录是region server的共享目录，用来持久化Hbase 。hbase.cluster.distributed ：Hbase的运行模式。false是单机模式，true是分布式模式。若为false,Hbase和Zookeeper会运行在同一个JVM里面。】

【以下是测试环境的操作命令】

  <property>
    <name>hbase.unsafe.stream.capability.enforce</name>
    <value>false</value>
  </property>

<!-- 存储目录 -->
<property>
 <name>hbase.rootdir</name>
 <value>hdfs://azkaban:8100/hbase</value>
 <description>The directory shared byregion servers.</description>
</property>
 <!-- hbase端口 -->
<property>
 <name>hbase.zookeeper.property.clientPort</name>
 <value>2181</value>
</property>
<!-- 超时时间 -->
<property>
 <name>zookeeper.session.timeout</name>
 <value>120000</value>
</property>
<!--防止服务器时间不同步出错 -->
<property>
<name>hbase.master.maxclockskew</name>
<value>150000</value>
</property>
<!-- 集群主机配置 -->
<property>
 <name>hbase.zookeeper.quorum</name>
 <value>azkaban</value>      待集群建好后，此处需要改为集群的三台机器：azkaban,hadoop-01,hadoop-02
</property>
<!--   路径存放 -->
<property>
 <name>hbase.tmp.dir</name>
 <value>/home/analyze/hbase/hbase-2.2.5/tmp</value>
</property>
<!-- true表示分布式 -->
<property>
 <name>hbase.cluster.distributed</name>
 <value>false</value>         待集群建好后，此处为 true
</property>
  <!-- 指定master -->
  <property>
    <name>hbase.master</name>
    <value>azkaban:60000</value>
  </property>
  <property>
    <name>hbase.master.info.port</name>
    <value>8010</value>
</property>

2.4、HBase启动
在成功启动Hadoop之后切换到HBase目录下，cd /home/hbase/hbase-1.2.6/bin
输入:
./start-hbase.sh
在浏览器输入：
http://39.108.208.105:16010/ ，显示这个界面则成功！  （测试环境：http://127.0.0.1:8010/）

【HBase shell 使用】

HBase启动之后
输入:
hbase shell
进入hbase
然后输入 list 查询有哪些表
因为HBase是列式存储结构，所以在建表方面和传统的关系型数据库不一样
新建一个用户表 t_user
添加两个列族 st1 和 st2
create 't_user','st1','st2'

给这张表添加数据
添加 主键 、列 和值
put 't_user','1001','st1:age','18'
put 't_user','1001','st2:name','zhangsan'

然后 查询该表数据：scan 't_user'

查看表结构：describe 't_user'

删除记录：delete't_user','1001','st1:age'

删除表
删除表首先要屏蔽该表：disable 't_user'

删除表：drop 't_user'



【大数据学习系列之四 ----- Hadoop+Hive环境搭建图文详解(单机) 【对应链接地址：https://blog.csdn.net/qazwsxpcm/article/details/78818185】】

1、Mysql安装  （此处忽略步骤）

2、Hive环境安装和配置
【压缩包路径： /home/analyze/hadoop/apache-hive-2.3.7-bin.tar.gz (hive) 】
新建一个文件夹hive，并将压缩包解压到该文件夹下，并命名hive2.3

3、环境配置
编辑 /etc/profile 文件
输入:
export HIVE_HOME=/opt/hive/hive2.1
export HIVE_CONF_DIR=${HIVE_HOME}/conf
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${HADOOP_HOME}/bin:${ZK_HOME}/bin:${HBASE_HOME}/bin:${HIVE_HOME}/bin:$PATH
注:实际配置以自己的为准
【以下是测试环境的操作命令】
#HIVE HOME
export HIVE_HOME=/home/analyze/hive/hive2.3
export HIVE_CONF_DIR=${HIVE_HOME}/conf
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${HADOOP_HOME}/bin:${ZK_HOME}/bin:${HBASE_HOME}/bin:${HIVE_HOME}/bin:$PATH

source  /etc/profile 使配置生效

4.1、hive配置之新建文件夹

在修改配置文件之前，需要先在root目录下建立一些文件夹。

mkdir /root/hive
mkdir /root/hive/warehouse
新建完该文件之后，需要让hadoop新建/root/hive/warehouse 和 /root/hive/ 目录。
执行命令：

$HADOOP_HOME/bin/hadoop fs -mkdir -p /root/hive/
$HADOOP_HOME/bin/hadoop fs -mkdir -p /root/hive/warehouse

给刚才新建的目录赋予读写权限，执行命令：
$HADOOP_HOME/bin/hadoop fs -chmod 777 /root/hive/
$HADOOP_HOME/bin/hadoop fs -chmod 777 /root/hive/warehouse 

检查这两个目录是否成功创建
输入:
$HADOOP_HOME/bin/hadoop fs -ls /root/
$HADOOP_HOME/bin/hadoop fs -ls /root/hive/

【以下是测试环境的操作命令】
mkdir /home/analyze/hive/hive2.3/hive
mkdir /home/analyze/hive/hive2.3/hive/warehouse
-- 需要让hadoop新建/home/analyze/hive/hive2.3/hive 和 /home/analyze/hive/hive2.3/hive/warehouse 目录
$HADOOP_HOME/bin/hadoop fs -mkdir -p /home/analyze/hive/hive2.3/hive/
$HADOOP_HOME/bin/hadoop fs -mkdir -p /home/analyze/hive/hive2.3/hive/warehouse

-- 给刚才新建的目录赋予读写权限，执行命令
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/
$HADOOP_HOME/bin/hadoop fs -chmod 777 /home/analyze/hive/hive2.3/hive/warehouse 

-- 检查这两个目录是否成功创建
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive/hive2.3/hive/
$HADOOP_HOME/bin/hadoop fs -ls /home/analyze/hive/hive2.3/hive/warehouse


4.2、hive配置之修改hive-site.xml

切换到 /opt/hive/hive2.1/conf 目录下
将hive-default.xml.template 拷贝一份，并重命名为hive-site.xml
然后编辑hive-site.xml文件,中添加:

<!-- 指定HDFS中的hive仓库地址 -->  
  <property>  
    <name>hive.metastore.warehouse.dir</name>  
    <value>/root/hive/warehouse</value>  
  </property>  

<property>
    <name>hive.exec.scratchdir</name>
    <value>/root/hive</value>
  </property>

  <!-- 该属性为空表示嵌入模式或本地模式，否则为远程模式 -->  
  <property>  
    <name>hive.metastore.uris</name>  
    <value></value>  
  </property>  

<!-- 指定mysql的连接 -->
 <property>
        <name>javax.jdo.option.ConnectionURL</name>
        <value>jdbc:mysql://master:3306/hive?createDatabaseIfNotExist=true</value>  修改为对应的线上正式环境的mysql数据库，用于储存hive的源数据
    </property>
<!-- 指定驱动类 -->
    <property>
        <name>javax.jdo.option.ConnectionDriverName</name>
        <value>com.mysql.jdbc.Driver</value>
    </property>
   <!-- 指定用户名 -->
    <property>
        <name>javax.jdo.option.ConnectionUserName</name>
        <value>root</value>
    </property>
    <!-- 指定密码 -->
    <property>
        <name>javax.jdo.option.ConnectionPassword</name>
        <value>123456</value>
    </property>
    <property>
   <name>hive.metastore.schema.verification</name>
   <value>false</value>
    <description>
    </description>
 </property>

然后将配置文件中所有的 ${system:java.io.tmpdir} 更改为 /opt/hive/tmp (如果没有该文件则创建)，并将此文件夹赋予读写权限，将 ${system:user.name} 更改为 root
【注: 由于hive-site.xml 文件中的配置过多，可以通过FTP将它下载下来进行编辑。也可以直接配置自己所需的，其他的可以删除。 MySQL的连接地址中的master是主机的别名，可以换成ip。】
【以下是测试环境的操作命令】
  <property>
    <name>hive.metastore.warehouse.dir</name>
    <value>/home/analyze/hive/hive2.3/hive/warehouse</value>
    <description>location of default database for the warehouse</description>
  </property>
  <property>
    <name>hive.exec.scratchdir</name>
    <value>/home/analyze/hive/hive2.3/hive</value>
    <description>HDFS root scratch dir for Hive jobs which gets created with write all (733) permission. For each connecting user, an HDFS scratch dir: ${hive.exec.scratchdir}/&lt;username&gt; is created, with ${hive.scratch.dir.permission}.
    </description>
  </property>
  <!-- 该属性为空表示嵌入模式或本地模式，否则为远程模式 -->
  <property>
    <name>hive.metastore.uris</name>
    <value></value>
    <description>Thrift URI for the remote metastore. Used by metastore client to connect to remote metastore.</description>
  </property>
  <!-- 指定mysql的连接 -->
  <property>
    <name>javax.jdo.option.ConnectionURL</name>
    <value>jdbc:mysql://10.227.96.6:3006/hive?createDatabaseIfNotExist=true</value>
    <description>
      JDBC connect string for a JDBC metastore.
      To use SSL to encrypt/authenticate the connection, provide database-specific SSL flag in the connection URL.
      For example, jdbc:postgresql://myhost/db?ssl=true for postgres database.
    </description>
  </property>
  <!-- 指定驱动类 -->
  <property>
    <name>javax.jdo.option.ConnectionDriverName</name>
    <value>com.mysql.jdbc.Driver</value>
    <description>Driver class name for a JDBC metastore</description>
  </property>
  <!-- 指定用户名 -->
  <property>
    <name>javax.jdo.option.ConnectionUserName</name>
    <value>anamember</value>
    <description>Username to use against metastore database</description>
  </property>
  <!-- 指定密码 -->
  <property>
    <name>javax.jdo.option.ConnectionPassword</name>
    <value>ana829test</value>
    <description>password to use against metastore database</description>
  </property>
  <property>
    <name>hive.metastore.schema.verification</name>
    <value>false</value>
  </property>

4.3、hive配置之修改 hive-env.sh
修改hive-env.sh 文件，没有就复制 hive-env.sh.template ，并重命名为hive-env.sh

在这个配置文件中添加

export  HADOOP_HOME=/opt/hadoop/hadoop2.8
export  HIVE_CONF_DIR=/opt/hive/hive2.1/conf
export  HIVE_AUX_JARS_PATH=/opt/hive/hive2.1/lib
【以下是测试环境的操作命令】
# export HIVE_AUX_JARS_PATH=
export  HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export  HIVE_CONF_DIR=/home/analyze/hive/hive2.3/conf
export  HIVE_AUX_JARS_PATH=/home/analyze/hive/hive2.3/lib

4.4、hive配置之添加 数据驱动包
由于Hive 默认自带的数据库是使用mysql，所以这块就是用mysql,将mysql 的驱动包 上传到 /opt/hive/hive2.1/lib
mysql-connector-java-5.1.47.jar
【以下是测试环境的操作命令】
cp /home/analyze/hive1.1/hive1.2/lib/mysql-connector-java-5.1.47.jar /home/analyze/hive/hive2.3/lib

5、Hive Shell 测试
在成功启动Hadoop之后切换到Hive目录下
cd /opt/hive/hive2.1/bin  
【以下是测试环境的操作命令】
cd /home/analyze/hive/hive2.3/bin
首先初始化数据库，初始化的时候注意要将mysql启动
输入： schematool  -initSchema -dbType mysql 
执行成功之后，可以看到hive数据库和一堆表已经创建成功了

切换到 cd /opt/hive/hive2.1/bin
进入hive (确保hadoop以及成功启动)
输入: hive

hive测试：
创建数据库： create database db_hiveTest;
创建表： create  table  db_hiveTest.student(id int,name string)  row  format  delimited  fields   terminated  by  '\t';  【说明: terminated by ‘\t’ 表示文本分隔符要使用Tab，行与行直接不能有空格。】

加载数据
新打开一个窗口
因为hive 不支持写，所以添加数据使用load加载文本获取。
新建一个文本
touch  /opt/hive/student.txt
输入 vim /opt/hive/student.txt

1001    zhangsan
1002    lisi
1003    wangwu
说明: 中间的空格符使用Tab建，文本可以在Windows上面新建，然后通过ftp上传到linux中，需要注意文本的格式为unix 格式。
在hive环境下，输入： load data local inpath '/opt/hive/student.txt'  into table db_hivetest.student;
然后执行查询： select * from db_hiveTest.student;
能够查询到上述结果，表示完成hive的创建。


【大数据学习系列之五 ----- Hive整合HBase图文详解  【对应链接地址：https://blog.csdn.net/zdy0_2004/article/details/78837221】】
Hive整合HBase的环境配置以及测试
1、环境配置
因为Hive与HBase整合的实现是利用两者本身对外的API接口互相通信来完成的，其具体工作交由Hive的lib目录中的hive-hbase-handler-.jar工具类来实现。所以只需要将hive的 hive-hbase-handler-.jar 复制到hbase/lib中就可以了。
切换到hive/lib目录下
cp hive-hbase-handler-*.jar /opt/hbase/hbase1.2/lib
注: 如果在hive整合hbase中，出现版本之类的问题，那么以hbase的版本为主，将hbase中的jar包覆盖hive的jar包。
【以下是测试环境的操作命令】
cp ./hive/hive2.3/lib/hive-hbase-handler-2.3.7.jar /home/analyze/hbase/hbase-2.2.5/lib

2、hive和hbase测试
在进行测试的时候，确保hadoop、hbase、hive环境已经成功搭建好，并且都成功启动了。
打开xshell的两个命令窗口
一个进入hive，一个进入hbase
2.1在hive中创建映射hbase的表
在hive中创建一个映射hbase的表，为了方便，设置两边的表名都为t_student，存储的表也是这个。
现在hbase中创建好 t_student
create 't_student','st1'

在hive中输入:
create external table t_student(id int,name string) stored by 'org.apache.hadoop.hive.hbase.HBaseStorageHandler' with serdeproperties("hbase.columns.mapping"=":key,st1:name") tblproperties("hbase.table.name"="t_student","hbase.mapred.output.outputtable" = "t_student");
说明：第一个t_student 是hive表中的名称，第二个t_student是定义在hbase的table名称 ，第三个t_student 是存储数据表的名称("hbase.mapred.output.outputtable" = "t_student"这个可以不要，表数据就存储在第二个表中了) 。
(id int,name string) 这个是hive表结构。如果要增加字段，就以这种格式增加。如果要增加字段的注释，那么在字段后面添加comment ‘你要描述的’。
例如:
create table t_student(id int comment ‘StudentId’,name string comment ‘StudentName’)
org.apache.hadoop.hive.hbase.HBaseStorageHandler 这个是指定的存储器。
hbase.columns.mapping 是定义在hbase的列族。
例如:st1就是列族，name就是列。在hive中创建表t_student，这个表包括两个字段（int型的id和string型的name）。 映射为hbase中的表t_student，key对应hbase的rowkey，value对应hbase的st1:name列。

表成功创建之后
在hive、hbase分别中查看表和表结构
hive中输入：
show tables；
describe t_student;
hbase输入:
list
describe 't_student'


2.2数据同步测试
进入hbase之后
在t_student中添加两条数据 然后查询该表

put 't_student','1001','st1:name','zhangsan'
put 't_student','1002','st1:name','lisi'
scan 't_student'

2.3关联查询测试
hive外部表测试
先在hbase中建一张t_student_info表，添加两个列族
然后查看表结构
输入:

create 't_student_info','st1','st2'
describe 't_student_info'


create external table t_student_info(id int,age int,sex string) stored by 'org.apache.hadoop.hive.hbase.HBaseStorageHandler' with serdeproperties("hbase.columns.mapping"=":key,st1:age,st2:sex") tblproperties("hbase.table.name"="t_student_info");

put 't_student_info','1001','st2:sex','man'
put 't_student_info','1001','st1:age','20'
put 't_student_info','1002','st1:age','18'
put 't_student_info','1002','st2:sex','woman'

查询到数据之后，然后将t_student 和t_student_info进行关联查询。
输入:

select * from t_student t join t_student ti where t.id=ti.id ;

说明:通过关联查询，可以得出表之间是可以关联查询的。但是明显看到hive 使用默认的mapreduce 作为引擎是多么的慢。。。




【大数据学习系列之六 ----- Hadoop+Spark环境搭建 对应链接地址：https://blog.csdn.net/qazwsxpcm/article/details/78846107?utm_medium=distribute.pc_aggpage_search_result.none-task-blog-2~all~top_click~default-1-78846107.nonecase&utm_term=%E5%A4%A7%E6%95%B0%E6%8D%AE%E5%AD%A6%E4%B9%A0%E7%B3%BB%E5%88%97%E4%B9%8B%E4%B8%89&spm=1000.2123.3001.4430】】

1、Scala环境配置
因为Spark的配置依赖与Scala，所以先要配置Scala。
【压缩包路径： /home/analyze/scala-2.13.4.tgz  (scala) 】
解压文件到文件夹 scala，并命名为scala2.13

1.1、环境配置

编辑 /etc/profile 文件
输入:
export SCALA_HOME=/opt/scala/scala2.1
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:$PATH
【以下是测试环境的操作命令】
#Scala Home
export SCALA_HOME=/home/analyze/scala/scala2.13
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:$PATH

输入： source  /etc/profile ，使配置生效，输入 scala -version 查看是否安装成功

2、Spark的环境配置
【压缩包路径： /home/analyze/spark-2.4.7-bin-hadoop2.7.tgz  (spark)】
解压文件到spark文件夹，并命名为spark2.4
2.1、环境配置
编辑 /etc/profile 文件
输入：
export  SPARK_HOME=/opt/spark/spark1.6-hadoop2.4-hive 
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:$PATH
【以下是测试环境的操作命令】
#Spark Home
export  SPARK_HOME=/home/analyze/spark/spark2.4
export  PATH=.:${JAVA_HOME}/bin:${SPARK_HOME}/bin:${SCALA_HOME}/bin:$PATH

输入： source  /etc/profile ，使配置生效

2.2、更改配置文件之 修改 spark-env.sh
切换到 cd /opt/spark/spark1.6-hadoop2.4-hive/conf 目录下
在conf目录下，修改 spark-env.sh文件，如果没有 spark-env.sh 该文件，就复制spark-env.sh.template文件并重命名为spark-env.sh。
修改这个新建的spark-env.sh文件，加入配置:
export SCALA_HOME=/opt/scala/scala2.1    
export JAVA_HOME=/opt/java/jdk1.8
export HADOOP_HOME=/opt/hadoop/hadoop2.8    
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop  
export SPARK_HOME=/opt/spark/spark1.6-hadoop2.4-hive
export SPARK_MASTER_IP=master    
export SPARK_EXECUTOR_MEMORY=1G 
注:上面的路径以自己的为准，SPARK_MASTER_IP为主机，SPARK_EXECUTOR_MEMORY为设置的运行内存
【以下是测试环境的操作命令】
export SCALA_HOME=/home/analyze/scala/scala2.13
export JAVA_HOME=/app/jdk1.8.0_192
export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export SPARK_HOME=/home/analyze/spark/spark2.4
export SPARK_MASTER_IP=azkaban
export SPARK_EXECUTOR_MEMORY=1G

3、Spark启动
启动spark要确保hadoop已经成功启动
首先使用jps命令查看启动的程序
在成功启动spark之后，再使用jps命令查看
切换到Spark目录下
输入:
cd /opt/spark/spark1.6-hadoop2.4-hive/sbin
然后启动Spark
输入:
start-all.sh
然后在浏览器输入
http://192.168.219.128:8080/ 【 测试环境： http://127.0.0.1:8083/】  
若端口冲突，将/home/analyze/spark/spark2.4/sbin/start-master.sh 的8080端口改为可用的端口即可
SPARK_MASTER_WEBUI_PORT=8083  # 因8080被占用，改为8083
注:如果spark成功启动，但是无法访问界面，首先检查防火墙是否关闭，然后在使用jps查看进程，如果都没问题的，一般就可以访问界面。如果还是不行，那么检查hadoop、scala、spark的配置。

启动spark服务  -- 不依赖hadoop
sbin/start-all.sh  -- http://127.0.0.1:8083/
sbin/stop-all.sh
进入spark环境
spark-shell



【Sqoop安装和简单使用 对应链接地址：https://www.jianshu.com/p/a088713ba26b】
【压缩包路径：/home/analyze/hadoop/sqoop-1.4.7.bin__hadoop-2.6.0.tar.gz  (sqoop)】
解压压缩包到sqoop文件夹，并命名sqoop-1.4.7
1、配置环境变量,编辑/etc/profile文件，添加SQOOP_HOME变量，并且将$SQOOP_HOME/bin添加到PATH变量中

export SQOOP_HOME=/home/hadoop/sqoop-1.4.7
export CLASSPATH=.:$JAVA_HOME/lib:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$HBASE_HOME/bin:$HIVE_HOME/bin:$SQOOP_HOME/bin:$PATH
编辑完成后，执行命令： source /etc/profile
【以下是测试环境的操作命令】
#Sqoop Home
export SQOOP_HOME=/home/analyze/sqoop/sqoop-1.4.7
export CLASSPATH=.:$JAVA_HOME/lib:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$HBASE_HOME/bin:$HIVE_HOME/bin:$SQOOP_HOME/bin:$PATH

2、sqoop配置文件修改
2.1 sqoop-env.sh 文件
切换到 /home/hadoop/sqoop-1.4.7/conf 目录下
将sqoop-env-template.sh复制一份，并取名为sqoop-env.sh，也就是执行命令：
cp sqoop-env-template.sh sqoop-env.sh
文件末尾加入一下配置：
export HADOOP_COMMON_HOME=/home/hadoop/hadoop-2.7.2
export HADOOP_MAPRED_HOME=/home/hadoop/hadoop-2.7.2
export HIVE_HOME=/home/hadoop/hive-2.1.0
export HBASE_HOME=/home/hadoop/hbase-1.2.2
注：上面的路径要改为自己的路径
【以下是测试环境的操作命令】
export HADOOP_COMMON_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HADOOP_MAPRED_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HIVE_HOME=/home/analyze/hive/hive2.3
export HBASE_HOME=/home/analyze/hbase/hbase-2.2.5

2.2 把MySQL的驱动包上传到sqoop的lib下

【以下是测试环境的操作命令】
cp /home/analyze/hive1.1/hive1.2/lib/mysql-connector-java-5.1.47.jar /home/analyze/sqoop/sqoop-1.4.7/lib

2.3 使用sqoop
安装后，如果命令不涉及hive和hdfs的，可以不启动，例如sqoop help命令：
此命令帮助查看sqoop有哪些命令
1)使用sqoop查看mysql中的数据表
进入$SQOOP_HOME/bin目录下执行如下命令：连接mysql看有多少个表
 ./sqoop list-databases --connect jdbc:mysql://192.168.1.34:3306/test?characterEncoding=UTF-8 --username root --password '123'
 
【以下是测试环境的操作命令】
 ./sqoop list-databases --connect jdbc:mysql://10.227.96.6:3006/hive?characterEncoding=UTF-8 --username anamember --password 'ana829test'  

2)把MySQL中的表导入hdfs中
前提：一定要启动hdfs和yarn

【以下是测试环境的操作命令】
 sqoop import \
 --connect jdbc:mysql://10.227.96.6:3006/fe?tinyInt1isBit=false\
 --username anamember \
 --password ana829test \
 --table sf_shelf_tag_item \
 --target-dir /home/analyze/hive/hive2.3/hive/warehouse/fezs.db/sf_shelf_tag_item/ \
 --delete-target-dir \
 --num-mappers 1 \
 --fields-terminated-by '\t' \
 --hive-drop-import-delims \
 --null-string '\\N' \
 --null-non-string '\\N' \
 --lines-terminated-by '\n';

3)把hdfs中的表导入mysql中
【以下是测试环境的操作命令】
 sqoop-export \
 --connect jdbc:mysql://10.227.96.6:3006/test \
 --username anamember \
 --password ana829test \
 --table sf_group_auth_tj \
 --input-null-string '\\N' \
 --input-null-non-string '\\N' \
 --export-dir /home/analyze/hive/hive2.3/hive/warehouse/fezs.db/sf_group_customer \
 --input-fields-terminated-by '\t' ;




【大数据学习系列之七 ----- Hadoop+Spark+Zookeeper+HBase+Hive集群搭建 图文详解  对应链接地址：https://blog.csdn.net/qazwsxpcm/article/details/78937820】 

需要在slaver1 和 slaver2 机器上安装好 jdk,hadoop,hbase,zookeeper (scala,spark 根据需要安装）
需要在master上安装好 jdk hadoop hbase hive mysql (scala,spark 根据需要安装）
只有mysql 和 hive 在slaver上不用安装！！！

【说明：在配置Hadoop之前，应该先做以下配置】
1.首先更改主机名，目的是为了方便管理
vim /etc/hosts
添加 主机IP 和对应的主机名称，做映射

127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
10.227.96.27 azkaban  （此处改为对应的机器，主机名建议改为 master）

【以下是测试环境的操作命令】
127.0.0.1   localhost localhost.localdomain localhost4 localhost4.localdomain4
::1         localhost localhost.localdomain localhost6 localhost6.localdomain6
10.227.96.27 azkaban     （对应集群master）
10.227.96.23 hadoop-01   （对应集群salver1）
10.227.96.24 hadoop-02   （对应集群salver2）
注:在配置文件中使用主机名的话，这个映射必须做，这个以便后面方便集群配置
【说明:可以在一台机器添加了之后可以使用scp 命令或使用ftp将这个文件copy到 其他机器中。】
scp命令示例:
scp -r /etc/hosts root@192.169.0.24:/etc
【以下是测试环境的操作命令】
scp /etc/hosts analyze@10.227.96.23:/etc/hosts
scp /etc/hosts analyze@10.227.96.24:/etc/hosts

2.ssh免登录

设置ssh免密码登录是为了操作方便
生成秘钥文件
在每台机器上都执行一遍
输入：
ssh-keygen -t rsa -P ''
生成秘钥之后，然后将每台机器/root/.ssh 都存入内容相同的文件，文件名称叫 authorized_keys，文件内容是我们刚才为3台机器生成的公钥。可以在一台机器上生成，然后复制到其它的机器上。
新建authorized_keys文件

touch  /root/.ssh/authorized_keys
编辑 authorized_keys 并将其他机器上的秘钥拷贝过来
cat /root/.ssh/id_rsa.pub
vim /root/.ssh/authorized_keys

将其它机器上的 id_rsa.pub 的内容拷贝到 authorized_keys这个文件中。
将这个最终的authorized_keys文件copy到其他机器的 /root/.ssh 目录下。使用scp或者ftp都可以。
scp命令示例:
scp -r /root/.ssh/authorized_keys root@192.169.0.24:/root/.ssh
【以下是测试环境的操作命令】
scp -r /root/.ssh/authorized_keys analyze@10.227.96.23:/root/.ssh/authorized_keys 
scp -r /root/.ssh/authorized_keys analyze@10.227.96.24:/root/.ssh/authorized_keys 

测试免密码登录
输入:
ssh slave1
ssh slave2

3.整体环境变量设置
在 /etc/profile 这个配置文件要添加很多的环境配置，这里就先将整体的环境配置列举出来，各位在配置环境变量的以自己的为准！！！ 可以先配置好环境变量之后，在传输到其他机器上去。

#Java Config
export JAVA_HOME=/opt/java/jdk1.8
export JRE_HOME=/opt/java/jdk1.8/jre
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar:$JRE_HOME/lib
# Scala Config
export SCALA_HOME=/opt/scala/scala2.12
# Spark Config
export  SPARK_HOME=/opt/spark/spark1.6-hadoop2.4-hive
# Zookeeper Config
export ZK_HOME=/opt/zookeeper/zookeeper3.4
# HBase Config
export HBASE_HOME=/opt/hbase/hbase1.2
# Hadoop Config 
export HADOOP_HOME=/opt/hadoop/hadoop2.8
export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_HOME/lib/native
export HADOOP_OPTS="-Djava.library.path=$HADOOP_HOME/lib"
# Hive Config
export HIVE_HOME=/opt/hive/hive2.1
export HIVE_CONF_DIR=${HIVE_HOME}/conf
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${HADOOP_HOME}/bin:${HADOOP_HOME}/sbin:${ZK_HOME}/bin:${HBASE_HOME}/bin:${HIVE_HOME}/bin:$PATH

【以下是测试环境的操作命令】
#JAVA_HOME
export JAVA_HOME=/app/jdk1.8.0_192
export PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH
export CLASSPATH=.:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/jre/lib/tools.jar
export PATH=$JAVA_HOME/bin:$JAVA_HOME/jre/bin:$PATH:$HOME/bin
#MYSQL_HOME
export MYSQL_HOME=/app/mysql
export PATH=$MYSQL_HOME/bin:$PATH
#HADOOP_HOME
export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HADOOP_COMMON_LIB_NATIVE_DIR=$HADOOP_HOME/lib/native
export HADOOP_OPTS="-Djava.library.path=$HADOOP_HOME/lib"
export PATH="$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$PATH"
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
#Hbase HOME
export HBASE_HOME=/home/analyze/hbase/hbase-2.2.5
export PATH=.:${JAVA_HOME}/bin:${HADOOP_HOME}/bin:${HBASE_HOME}/bin:$PATH
#HIVE HOME
export HIVE_HOME=/home/analyze/hive/hive2.3
#export HIVE_HOME=/home/analyze/hive1.1/hive1.2
export HIVE_CONF_DIR=${HIVE_HOME}/conf
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${HADOOP_HOME}/bin:${ZK_HOME}/bin:${HBASE_HOME}/bin:${HIVE_HOME}/bin:$PATH
#Sqoop Home
export SQOOP_HOME=/home/analyze/sqoop/sqoop-1.4.7
export CLASSPATH=.:$JAVA_HOME/lib:$JAVA_HOME/lib/dt.jar:$JAVA_HOME/lib/tools.jar
export PATH=$JAVA_HOME/bin:$HADOOP_HOME/bin:$HADOOP_HOME/sbin:$HBASE_HOME/bin:$HIVE_HOME/bin:$SQOOP_HOME/bin:$PATH
#Scala Home
export SCALA_HOME=/home/analyze/scala/scala2.13
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:$PATH
#Spark Home
export  SPARK_HOME=/home/analyze/spark/spark2.4
export  PATH=.:${JAVA_HOME}/bin:${SPARK_HOME}/bin:${SCALA_HOME}/bin:$PATH
#Zookeeper Home 搭建集群只需要添加上这个
export ZK_HOME=/home/analyze/zookeeper/zookeeper-3.5.8
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${ZK_HOME}/bin:$PATH

4.在slaver机器上安装好 jdk,hadoop,hbase，安装流程同master。【建议：可采取将master的hadoop,hbase等 scp复制到slaver上，然后再做配置上细微的调整。】
4.1 安装jdk
注意：jdk的各自的路径是否正确

4.2 安装hadoop
修改 core-site.xml、hadoop-env.sh、hdfs-site.xml、mapred-site.xml 等这些配置文件
切换到 cd /opt/hadoop/hadoop2.8/etc/hadoop路径下
4.2.1 修改 core-site.xml 【注意：slaver机器需要同master上保持一致】
在<configuration>节点内加入配置:

<property>
    <name>hadoop.temp.dir</name>
    <value>file:/root/hadoop/tmp</value>
  </property>
  <property>
    <name>fs.defaultFS</name>
    <value>hdfs://master:9000</value>
  </property>
<!-- eclipse连接hive 的配置-->
<property>
  <name>hadoop.proxyuser.root.hosts</name>
  <value>*</value>
 </property>
 <property>
  <name>hadoop.proxyuser.root.groups</name>
  <value>*</value>
</property>
【说明: fs.defaultFS 是缺省文件的名称， 最早使用的是 fs.default.name，后来在最新官方文档中查到该方法已经弃用了。于是边改成这个了。ps：感觉也没啥区别。】

【以下是测试环境的操作命令，master slaver均一致】
<property>
        <name>hadoop.tmp.dir</name>
        <value>/home/analyze/hadoop/hadoop-2.8.5/tmp</value>
        <description>Abase for other temporary directories.</description>
   </property>
   <property>
        <name>fs.default.name</name>
        <value>hdfs://azkaban:8100</value>
   </property>
<property>
    <name>hadoop.proxyuser.analyze.hosts</name>
    <value>*</value>
</property>
<property>
    <name>hadoop.proxyuser.analyze.groups</name>
    <value>*</value>
</property>
    <property>
        <name>hadoop.proxyuser.hadoop.hosts</name>
        <value>*</value>
    </property>
    <property>
        <name>hadoop.proxyuser.hadoop.groups</name>
        <value>*</value>
    </property>
    <property>
        <name>hadoop.proxyuser.hue.hosts</name>
        <value>*</value>
    </property>
    <property>
        <name>hadoop.proxyuser.hue.groups</name>
        <value>*</value>
    </property>
    <property>
        <name>hadoop.proxyuser.hdfs.hosts</name>
        <value>*</value>
    </property>
    <property>
        <name>hadoop.proxyuser.hdfs.groups</name>
        <value>*</value>
     </property>
    <property>
        <name>hadoop.proxyuser.anamember.hosts</name>
        <value>*</value>
    </property>
    <property>
        <name>hadoop.proxyuser.anamember.groups</name>
        <value>*</value>
     </property>
    <property>
        <name>hadoop.proxyuser.azkaban.hosts</name>
        <value>*</value>
    </property>
    <property>
        <name>hadoop.proxyuser.azkaban.groups</name>
        <value>*</value>
     </property>
【说明：根据需要 可以设置多个代理用户群，我这里设置了 analyze hadoop hue hdfs anamember azkaban】

4.2.2 修改 hadoop-env.sh 【注意：slaver机器上如果jdk路径一致，可以直接scp过去，如果不一致，scp过去后需要修改该文件的该参数】
将 export  JAVA_HOME=${JAVA_HOME} 修改为： export   JAVA_HOME=/opt/java/jdk1.8
注:修改为自己JDK的路径

【以下是测试环境的操作命令，测试环境jdk路径不一致】
export JAVA_HOME=/app/jdk1.8.0_192     （master即azkaban）
export JAVA_HOME=/app/jdk/jdk1.8.0_192 （slaver即hadoop-0x）

4.2.3 修改 hdfs-site.xml
下面的hdfs的存放路径，可以根据自己机器更改。
在<configuration>节点内加入配置:

  <property>
    <name>dfs:replication</name>
    <value>2</value>
  </property>
  <property>
    <name>dfs.namenode.name.dir</name>
    <value>file:/root/hadoop/name</value>
  </property>
  <property>
    <name>dfs.datanode.data.dir</name>
    <value>file:/root/hadoop/data</value>
  </property>    
  <property>
  <name>dfs.namenode.secondary.http-address</name>
  <value>对应的ip修改为本机器ip:5090</value> 
  </property>
  <property>
  <name>dfs.datanode.address</name>
  <value>对应的ip修改为本机器ip:5010</value>
  </property>
  <property>
  <name>dfs.datanode.http.address</name>
  <value>对应的ip修改为本机器ip:5075</value>
  </property>
  <property>
  <name>dfs.namenode.http-address</name>
  <value>对应的ip修改为本机器ip:5070</value>
  </property>
  <property>
  <name>dfs.datanode.ipc.address</name>
  <value>对应的ip修改为本机器ip:5020</value>
  </property>
  <property>
  <name>dfs.webhdfs.enabled</name>
  <value>true</value>
  </property>

【以下是测试环境的操作命令：master即azkaban】
<configuration>
<property>
   <name>dfs.name.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/name</value>
   <description>Path on the local filesystem where theNameNode stores the namespace and transactions logs persistently.</description>
</property>
<property>
   <name>dfs.data.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/data</value>
   <description>Comma separated list of paths on the localfilesystem of a DataNode where it should store its blocks.</description>
</property>
<property>
   <name>dfs.replication</name>
   <value>2</value>
</property>

<property>
<name>dfs.namenode.secondary.http-address</name>
<value>10.227.96.27:5090</value>    【说明：对应的ip修改为本机器ip】
</property>
<property>
<name>dfs.datanode.address</name>
<value>10.227.96.27:5010</value>    【说明：对应的ip修改为本机器ip】
</property>
<property>
<name>dfs.datanode.http.address</name>
<value>10.227.96.27:5075</value>    【说明：对应的ip修改为本机器ip】
</property>
<property>
<name>dfs.namenode.http-address</name>
<value>10.227.96.27:5070</value>    【说明：对应的ip修改为本机器ip】
</property>
<property>
<name>dfs.datanode.ipc.address</name>
<value>10.227.96.27:5020</value>    【说明：对应的ip修改为本机器ip】
</property>
<property>
<name>dfs.webhdfs.enabled</name>
<value>true</value>
</property>
</configuration>

【以下是测试环境的操作命令：slaver1即hadoop-01】
<configuration>
<property>
   <name>dfs.name.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/name</value>
   <description>Path on the local filesystem where theNameNode stores the namespace and transactions logs persistently.</description>
</property>
<property>
   <name>dfs.data.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/data</value>
   <description>Comma separated list of paths on the localfilesystem of a DataNode where it should store its blocks.</description>
</property>
<property>
   <name>dfs.replication</name>
   <value>2</value>
</property>
<property>
<name>dfs.namenode.secondary.http-address</name>
<value>10.227.96.23:5090</value>
</property>
<property>
<name>dfs.datanode.address</name>
<value>10.227.96.23:5010</value>
</property>
<property>
<name>dfs.datanode.http.address</name>
<value>10.227.96.23:5075</value>
</property>
<property>
<name>dfs.namenode.http-address</name>
<value>10.227.96.23:5070</value>
</property>
<property>
<name>dfs.datanode.ipc.address</name>
<value>10.227.96.23:5020</value>
</property>
<property>
<name>dfs.webhdfs.enabled</name>
<value>true</value>
</property>
</configuration>

【以下是测试环境的操作命令：slaver2即hadoop-02】
<configuration>
<property>
   <name>dfs.name.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/name</value>
   <description>Path on the local filesystem where theNameNode stores the namespace and transactions logs persistently.</description>
</property>
<property>
   <name>dfs.data.dir</name>
   <value>/home/analyze/hadoop/hadoop-2.8.5/dfs/data</value>
   <description>Comma separated list of paths on the localfilesystem of a DataNode where it should store its blocks.</description>
</property>
<property>
   <name>dfs.replication</name>
   <value>2</value>
</property>
<property>
<name>dfs.namenode.secondary.http-address</name>
<value>10.227.96.24:5090</value>
</property>
<property>
<name>dfs.datanode.address</name>
<value>10.227.96.24:5010</value>
</property>
<property>
<name>dfs.datanode.http.address</name>
<value>10.227.96.24:5075</value>
</property>
<property>
<name>dfs.namenode.http-address</name>
<value>10.227.96.24:5070</value>
</property>
<property>
<name>dfs.datanode.ipc.address</name>
<value>10.227.96.24:5020</value>
</property>
<property>
<name>dfs.webhdfs.enabled</name>
<value>true</value>
</property>
</configuration>


4.2.4 修改mapred-site.xml
执行mapreduce的运行框架配置
如果没有 mapred-site.xml 该文件，就复制mapred-site.xml.template文件并重命名为mapred-site.xml。
修改这个新建的mapred-site.xml文件，在<configuration>节点内加入配置:

<property>
       <name>mapreduce.framework.name</name>
       <value>yarn</value>
</property>

【以下是测试环境的操作命令：master slaver均一致】
<configuration>
<property>
    <name>mapred.job.tracker</name>
    <value>azkaban:8001</value>
</property>
<property>
      <name>mapred.local.dir</name>
       <value>/home/analyze/hadoop/hadoop-2.8.5/var</value>
</property>
<property>
       <name>mapreduce.framework.name</name>
       <value>yarn</value>
</property>
<property>
    <name>mapreduce.jobhistory.address</name>
    <value>azkaban:10020</value>
</property>
<property>
        <name>mapreduce.jobhistory.webapp.address</name>
        <value>azkaban:19888</value>
</property>
</configuration>


4.2.5  修改yarn-site.xml文件
yarn 资源调度的配置，集群的话这个配置是必须的。
修改/opt/hadoop/hadoop2.8/etc/hadoop/yarn-site.xml文件，
在<configuration>节点内加入配置

<property>
        <name>yarn.resourcemanager.hostname</name>
        <value>master</value>
   </property>
   <property>
        <name>yarn.resourcemanager.address</name>
        <value>${yarn.resourcemanager.hostname}:8032</value>
   </property>
   <property>
        <description>The address of the scheduler interface.</description>
        <name>yarn.resourcemanager.scheduler.address</name>
        <value>${yarn.resourcemanager.hostname}:8030</value>
   </property>
   <property>
        <description>The http address of the RM web application.</description>
        <name>yarn.resourcemanager.webapp.address</name>
        <value>${yarn.resourcemanager.hostname}:8088</value>
   </property>
   <property>
        <description>The https adddress of the RM web application.</description>
        <name>yarn.resourcemanager.webapp.https.address</name>
        <value>${yarn.resourcemanager.hostname}:8090</value>
   </property>
   <property>
        <name>yarn.resourcemanager.resource-tracker.address</name>
        <value>${yarn.resourcemanager.hostname}:8031</value>
   </property>
   <property>
        <description>The address of the RM admin interface.</description>
        <name>yarn.resourcemanager.admin.address</name>
        <value>${yarn.resourcemanager.hostname}:8033</value>
   </property>
   <property>
        <name>yarn.nodemanager.aux-services</name>
        <value>mapreduce_shuffle</value>
   </property>
   <property>
        <name>yarn.scheduler.maximum-allocation-mb</name>
        <value>8182</value>
        <discription>每个节点可用内存,单位MB,默认8182MB</discription>
   </property>
   <property>
        <name>yarn.nodemanager.vmem-pmem-ratio</name>
        <value>2.1</value>
   </property>
   <property>
        <name>yarn.nodemanager.resource.memory-mb</name>
        <value>2048</value>
</property>
   <property>
        <name>yarn.nodemanager.vmem-check-enabled</name>
        <value>false</value>
</property>
【说明：yarn.nodemanager.vmem-check-enabled 这个的意思是忽略虚拟内存的检查，如果你是安装在虚拟机上，这个配置很有用，配上去之后后续操作不容易出问题。如果是实体机上，并且内存够多，可以将这个配置去掉】

【以下是测试环境的操作命令：master slaver均一致】
<configuration>

<!-- Site specific YARN configuration properties -->

<property>
     <name>yarn.resourcemanager.hostname</name>
     <value>azkaban</value>
</property>
<property>
     <name>yarn.resourcemanager.address</name>
     <value>${yarn.resourcemanager.hostname}:8032</value>
</property>
<property>
     <description>The address of the scheduler interface.</description>
     <name>yarn.resourcemanager.scheduler.address</name>
     <value>${yarn.resourcemanager.hostname}:8030</value>
</property>
<property>
     <description>The http address of the RM web application.</description>
     <name>yarn.resourcemanager.webapp.address</name>
     <value>${yarn.resourcemanager.hostname}:8088</value>
</property>
<property>
     <description>The https adddress of the RM web application.</description>
     <name>yarn.resourcemanager.webapp.https.address</name>
     <value>${yarn.resourcemanager.hostname}:8090</value>
</property>
<property>
     <name>yarn.resourcemanager.resource-tracker.address</name>
     <value>${yarn.resourcemanager.hostname}:8031</value>
</property>
<property>
     <description>The address of the RM admin interface.</description>
     <name>yarn.resourcemanager.admin.address</name>
     <value>${yarn.resourcemanager.hostname}:8033</value>
</property>
<property>
     <name>yarn.nodemanager.aux-services</name>
     <value>mapreduce_shuffle</value>
</property>
<property>
 <name>yarn.nodemanager.aux-services.mapreduce.shuffle.class</name>
 <value>org.apache.hadoop.mapred.ShuffleHandler</value>
</property>
<property>
     <name>yarn.scheduler.maximum-allocation-mb</name>
     <value>8182</value>
     <discription>每个节点可用内存,单位MB,默认8182MB</discription>
</property>
<property>
     <name>yarn.nodemanager.vmem-pmem-ratio</name>
     <value>2.1</value>
</property>
<property>
     <name>yarn.nodemanager.resource.memory-mb</name>
     <value>2048</value>
</property>
<property>
     <name>yarn.nodemanager.vmem-check-enabled</name>
     <value>false</value>
</property>
<property>
    <name>yarn.log.server.url</name>
    <value>http://azkaban:19888/jobhistory/logs/</value>
</property>
</configuration>



4.2.6 修改slaves
设置主从的配置。如果不设置这个，集群就无法得知主从了。如果是单机模式，就没必要配置了。
修改/opt/hadoop/hadoop2.8/etc/hadoop/slaves文件
更改为：
slave1 
slave2


【以下是测试环境的操作命令】
vim /home/analyze/hadoop/hadoop-2.8.5/etc/hadoop/slaves
hadoop-01 
hadoop-01 


在一台机器上(最好是master)做完这些配置之后，我们使用scp命令将这些配置传输到其他机器上。
输入:
jdk环境传输

scp -r /opt/java root@slave1:/opt
scp -r /opt/java root@slave2:/opt

hadoop环境传输

scp -r /opt/hadoop root@slave1:/opt
scp -r /opt/hadoop root@slave2:/opt

传输之后，便在主节点启动集群。
在启动hadoop之前，需要初始化，这个只需要在master上初始化就可以了。


【说明：上述配置完后，需要进行检查确认是否配置正确。
在master机器上启动hdfs 和yarn
start-dfs.sh
start-yarn.sh
然后可以在浏览器输入: ip+50070 和8088端口查看，可参看对应的文章链接中图】



5.Spark的环境配置
根据单机的安装方法，在slaver机器上安装好 scala

6.Spark配置
根据单机的安装方法，在slaver机器上安装好 spark，注意 /etc/profile和 spark-env.sh 文件中路径配置

【以下是测试环境的操作命令 master即azkaban】
export SCALA_HOME=/home/analyze/scala/scala2.13
export JAVA_HOME=/app/jdk/jdk1.8.0_192
export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export SPARK_HOME=/home/analyze/spark/spark2.4
export SPARK_MASTER_IP=azkaban
export SPARK_EXECUTOR_MEMORY=1G
【以下是测试环境的操作命令 slaverx即hadoop-0x】
export SCALA_HOME=/home/analyze/scala/scala2.13
export JAVA_HOME=/app/jdk/jdk1.8.0_192  (此处不一样)
export HADOOP_HOME=/home/analyze/hadoop/hadoop-2.8.5
export HADOOP_CONF_DIR=$HADOOP_HOME/etc/hadoop
export SPARK_HOME=/home/analyze/spark/spark2.4
export SPARK_MASTER_IP=azkaban
export SPARK_EXECUTOR_MEMORY=1G

6.1修改slaves
slaves 分布式文件
在conf目录下，修改slaves文件，如果没有 slaves 该文件，就复制slaves .template文件并重命名为slaves 。
修改这个新建的slaves 文件，加入配置:

slave1 
slave2

【以下是测试环境的操作命令】
hadoop-01
hadoop-02

6.2spark启动
说明:要先启动Hadoop
切换到Spark目录下，然后启动Spark，输入:start-all.sh

启动成功之后，可以使用jps命令在各个机器上查看是否成功。可以在浏览器输入: ip+8080 端口查看
【测试环境：http://127.0.0.1:8083/ ，查看worker id是否有两台slaver机器】


7.Zookeeper的环境配置
【压缩包路径： /home/analyze/apache-zookeeper-3.5.8-bin.tar.gz  (zookeeper) 】 
因为HBase做集群，所以就需要zookeeper了。zookeeper 在很多环境搭建上，都会有他的身影，如kafka、storm等，这里就不多说了。
将下载下来的Zookeeper 的配置文件进行解压
在linux上输入:
tar  -xvf   zookeeper-3.4.10.tar.gz
然后移动到/opt/zookeeper里面，没有就新建，然后将文件夹重命名为zookeeper3.4

7.1环境配置

编辑 /etc/profile 文件
输入:
export  ZK_HOME=/opt/zookeeper/zookeeper3.4 
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${ZK_HOME}/bin:$PATH

输入:source  /etc/profile，使配置生效

【以下是测试环境的操作命令】
#Zookeeper Home
export ZK_HOME=/home/analyze/zookeeper/zookeeper-3.5.8
export PATH=.:${JAVA_HOME}/bin:${SCALA_HOME}/bin:${SPARK_HOME}/bin:${ZK_HOME}/bin:$PATH


7.2修改配置文件
7.2.1 创建文件和目录
在集群的服务器上都创建这些目录

mkdir   /opt/zookeeper/data  
mkdir   /opt/zookeeper/dataLog

并且在/opt/zookeeper/data目录下创建myid文件
输入:
touch  myid
创建成功之后，更改myid文件。我这边为了方便，将master、slave1、slave2的myid文件内容改为1,2,3


7.2.2 新建zoo.cfg
切换到/opt/zookeeper/zookeeper3.4/conf 目录下
如果没有 zoo.cfg 该文件，就复制zoo_sample.cfg文件并重命名为zoo.cfg。
修改这个新建的zoo.cfg文件

dataDir=/opt/zookeeper/data
dataLogDir=/opt/zookeeper/dataLog
server.1=master:2888:3888
server.2=slave1:2888:3888
server.3=slave2:2888:3888


说明：client port，顾名思义，就是客户端连接zookeeper服务的端口。这是一个TCP port。dataLogDir里是放到的顺序日志(WAL)。而dataDir里放的是内存数据结构的snapshot，便于快速恢复。为了达到性能最大化，一般建议把dataDir和dataLogDir分到不同的磁盘上，这样就可以充分利用磁盘顺序写的特性。dataDir和dataLogDir需要自己创建，目录可以自己制定，对应即可。server.1中的这个1需要和master这个机器上的dataDir目录中的myid文件中的数值对应。server.2中的这个2需要和slave1这个机器上的dataDir目录中的myid文件中的数值对应。server.3中的这个3需要和slave2这个机器上的dataDir目录中的myid文件中的数值对应。当然，数值你可以随便用，只要对应即可。2888和3888的端口号也可以随便用，因为在不同机器上，用成一样也无所谓。
1.tickTime：CS通信心跳数
Zookeeper 服务器之间或客户端与服务器之间维持心跳的时间间隔，也就是每个 tickTime 时间就会发送一个心跳。tickTime以毫秒为单位。
tickTime=2000
2.initLimit：LF初始通信时限
集群中的follower服务器(F)与leader服务器(L)之间初始连接时能容忍的最多心跳数（tickTime的数量）。
initLimit=10
3.syncLimit：LF同步通信时限
集群中的follower服务器与leader服务器之间请求和应答之间能容忍的最多心跳数（tickTime的数量）。
syncLimit=5

依旧将zookeeper传输到其他的机器上，记得更改 /opt/zookeeper/data 下的myid，这个不能一致。
输入:

scp -r /opt/zookeeper root@slave1:/opt
scp -r /opt/zookeeper root@slave2:/opt



【以下是测试环境的操作命令】
admin.serverPort=5808  (此处是因为端口8088与tomcat冲突，修改为5808)
dataDir=/home/analyze/zookeeper/zookeeper-3.5.8/data
dataLogDir=/home/analyze/zookeeper/zookeeper-3.5.8/dataLog
server.1=azkaban:2888:3888
server.2=hadoop-01:2888:3888
server.3=hadoop-02:2888:3888


7.2.3 启动zookeeper  （需要在slaver上启动）
因为zookeeper是选举制，它的主从关系并不是像hadoop那样指定的，具体可以看官方的文档说明。
成功配置zookeeper之后，在每台机器上启动zookeeper。
切换到zookeeper目录下

cd /opt/zookeeper/zookeeper3.4/bin

输入:
zkServer.sh start

成功启动之后查看状态输入:
zkServer.sh status
可以查看各个机器上zookeeper的leader和follower


8.在slaver上安装hbase
安装流程同master。【建议：可采取将master的hbase scp到slaver上，在做参数上的修改】

8.1修改 hbase-site.xml
编辑hbase-site.xml 文件，在<configuration>添加如下配置

<property>
 <name>hbase.rootdir</name>
 <value>hdfs://master:9000/hbase</value>
 <description>The directory shared byregion servers.</description>
</property>
 <!-- hbase端口 -->
<property>
 <name>hbase.zookeeper.property.clientPort</name>
 <value>2181</value>
</property>
<!-- 超时时间 -->
<property>
 <name>zookeeper.session.timeout</name>
 <value>120000</value>
</property>
<!--防止服务器时间不同步出错 -->
<property>
<name>hbase.master.maxclockskew</name>
<value>150000</value>
</property>
<!-- 集群主机配置 -->
<property>
 <name>hbase.zookeeper.quorum</name>
 <value>master,slave1,slave2</value>
</property>
<!--   路径存放 -->
<property>
 <name>hbase.tmp.dir</name>
 <value>/root/hbase/tmp</value>
</property>
<!-- true表示分布式 -->
<property>
 <name>hbase.cluster.distributed</name>
 <value>true</value>
</property>
  <!-- 指定master -->
  <property>
    <name>hbase.master</name>
    <value>master:60000</value>
  </property>

【说明:hbase.rootdir：这个目录是region server的共享目录，用来持久化Hbase 。hbase.cluster.distributed ：Hbase的运行模式。false是单机模式，true是分布式模式。若为false,Hbase和Zookeeper会运行在同一个JVM里面。】

【以下是测试环境的操作命令，master和slaver一致】
  <property>
    <name>hbase.unsafe.stream.capability.enforce</name>
    <value>false</value>
  </property>

<!-- 存储目录 -->
<property>
 <name>hbase.rootdir</name>
 <value>hdfs://azkaban:8100/hbase</value>
 <description>The directory shared byregion servers.</description>
</property>
 <!-- hbase端口 -->
<property>
 <name>hbase.zookeeper.property.clientPort</name>
 <value>2181</value>
</property>
<!-- 超时时间 -->
<property>
 <name>zookeeper.session.timeout</name>
 <value>120000</value>
</property>
<!--防止服务器时间不同步出错 -->
<property>
<name>hbase.master.maxclockskew</name>
<value>150000</value>
</property>
<!-- 集群主机配置 -->
<property>
 <name>hbase.zookeeper.quorum</name>
 <value>azkaban,hadoop-01,hadoop-02</value>
</property>
<!--   路径存放 -->
<property>
 <name>hbase.tmp.dir</name>
 <value>/home/analyze/hbase/hbase-2.2.5/tmp</value>
</property>
<!-- true表示分布式 -->
<property>
 <name>hbase.cluster.distributed</name>
 <value>true</value>
</property>
  <!-- 指定master -->
  <property>
    <name>hbase.master</name>
    <value>azkaban:60000</value>
  </property>
  <property>
    <name>hbase.master.info.port</name>
    <value>8010</value>
</property>


8.2修改regionservers
指定hbase的主从，和hadoop的slaves文件配置一样
将文件修改为

slave1 
slave2


注:上面的为集群的主机名称

在一台机器上(最好是master)做完这些配置之后，我们使用scp命令将这些配置传输到其他机器上。
输入:
hbase环境传输

scp -r /opt/hbaseroot@slave1:/opt
scp -r /opt/hbase root@slave2:/opt

传输之后，便在主节点启动集群。


8.3启动hbase
在成功启动Hadoop、zookeeper之后
切换到HBase目录下

cd /opt/hbase/hbase1.2/bin

输入:start-hbase.sh

启动成功之后，可以使用jps命令在各个机器上查看是否成功
可以在浏览器输入: ip+16010 端口查看 ServerName是否有slaver机器

【以下是测试环境的操作命令】
http://127.0.0.1:8010/master-status




【相关的组件启动/停止命令】

【启动hdfs：start-dfs.sh】
【启动yarn：start-yarn.sh】
【启动spark：cd /home/analyze/spark/spark2.4/sbin start-all.sh】
【启动zookeeper：cd /home/analyze/zookeeper/zookeeper-3.5.8/bin zkServer.sh start】
【启动hbase：start-hbase.sh 】
【查看集群各机器的状态：hadoop dfsadmin -report】
【启动hue :cd $HIVE_HOME/bin hive --service metastore &】
【启动hue :cd $HIVE_HOME/bin hive --service hiveserver2 &】
【启动hue :cd /home/analyze/hue4.2/hue-4.2.0/build/env/bin supervisor】

cd /home/analyze/zookeeper/zookeeper-3.5.8/bin zkServer.sh stop
cd /home/analyze/spark/spark2.4/sbin stop-all.sh
stop-hbase.sh
stop-yarn.sh
stop-dfs.sh
