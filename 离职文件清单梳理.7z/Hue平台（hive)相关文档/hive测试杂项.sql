-- fe_group.sf_group_emp  524362
-- fe_goods.sf_scan_order  752
-- fe_goods.sf_group_order 38452
-- fe_group.sf_group_distribute_plan_detail 4857521
-- fe_group.sf_group_distribute_plan  7221
-- fe_group.sf_group_customer 1143
-- fe_group.sf_group_emp_extend  756181
-- fe_group.sf_group_auth  240
-- feods.sap_pmp_hos_emp_base_info 0
-- fe.pub_user_open 2366
-- fe.sf_shelf
-- fe.sf_shelf_tag
-- fe.sf_shelf_tag_item 


-- 全量同步（hdfs到mysql ok 指定字段，用于mysql表有自增主键id字段)
sqoop-export \
 --connect jdbc:mysql://10.227.96.6:3006/test \
 --username anamember \
 --password ana829test \
 --table dwd_group_emp_user_day \
 --columns "emp_user_id,customer_user_id,group_customer_id,group_name,group_customer_id_sub,group_name_sub,user_role,bind_status,manager_status,emp_user_name,sex,mobile,OPEN_TYPE,OPEN_ID,dept_id,duties,dept,parent_org_name,division_code,division_name,professional_level,position_attr,bukrs_txt,job_number,ltrim_job_number,group_email,birthday,joindate,cancel_flag,cancel_date,add_time,data_flag,from_type,bindtime,remark,nick,is_fengxiang,load_time" \
 --input-null-string '\\N' \
 --input-null-non-string '\\N' \
 --export-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/dwd_group_emp_user_day \
 --input-fields-terminated-by '\t' 

 
 
-- 全量同步（hdfs到mysql ok)
sqoop-export \
 --connect jdbc:mysql://10.227.96.6:3006/test \
 --username anamember \
 --password ana829test \
 --table sf_group_auth_tj \
 --input-null-string '\\N' \
 --input-null-non-string '\\N' \
 --export-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth \
 --input-fields-terminated-by '\t' 
 
 
-- 全量同步 （hdfs到mysql ok  指定字段)
sqoop-export \
 --connect jdbc:mysql://10.227.96.6:3006/test \
 --username anamember \
 --password ana829test \
 --table sf_group_auth_tj \
 --columns "auth_id,group_customer_id,bind_group_customer_id,third_group_id,auth_name,data_flag,add_time,add_user_id,last_update_time,last_update_user_id" \
 --input-null-string '\\N' \
 --input-null-non-string '\\N' \
 --export-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth \
 --input-fields-terminated-by '\t' 
 
 
 -- 全量同步 （mysql到hdfs ok)
 sqoop import \
 --connect jdbc:mysql://10.227.96.6:3006/fe?tinyInt1isBit=false\
 --username anamember \
 --password ana829test \
 --table sf_shelf_tag \
 --target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_shelf_tag/ \
 --delete-target-dir \
 --num-mappers 1 \
 --fields-terminated-by '\t' \
 --hive-drop-import-delims \
 --null-string '\\N' \
 --null-non-string '\\N' \
 --lines-terminated-by '\n';
 
 
 -- 全量同步 （mysql到hdfs ok 指定字段)
 sqoop import \
 --connect jdbc:mysql://10.227.96.6:3006/fe?tinyInt1isBit=false\
 --username anamember \
 --password ana829test \
 --table pub_role \
 --columns "ROLE_ID,SHOP_ID,ROLE_NAME,DESCRIPTION" \
 --target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/pub_role/ \
 --delete-target-dir \
 --num-mappers 1 \
 --fields-terminated-by '\t' \
 --hive-drop-import-delims \
 --null-string '\\N' \
 --null-non-string '\\N' \
 --lines-terminated-by '\n';
 
 
-- 按照时间字段增量同步（mysql到hdfs ok ，创建job，创建好后，执行：sqoop job -exec mysql2hive_job)
sqoop job --create mysql2hive_job -- import \
--connect jdbc:mysql://10.227.96.6:3006/fe_group \
--username anamember \
--password ana829test \
--table sf_group_distribute_plan_detail \
--target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_distribute_plan_detail/ \
--check-column last_update_time \
--incremental lastmodified \
--last-value "2021-04-14 15:12:57.0" \
--fields-terminated-by '\t' \
--hive-drop-import-delims \
--input-null-non-string '\\N' \
--null-string '\\N' \
--null-non-string '\\N' \
--lines-terminated-by '\n' \
--merge-key detail_id;

-- 按照时间字段增量同步（mysql到hdfs ok )
sqoop import \
--connect jdbc:mysql://10.227.96.6:3006/fe_group \
--username anamember \
--password ana829test \
--table sf_group_distribute_plan_detail \
--target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_distribute_plan_detail/ \
--check-column last_update_time \
--incremental lastmodified \
--last-value "2021-04-14 15:12:57.0" \
--fields-terminated-by '\t' \
--hive-drop-import-delims \
--input-null-non-string '\\N' \
--null-string '\\N' \
--null-non-string '\\N' \
--lines-terminated-by '\n' \
--merge-key detail_id;
 

/home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth/

sqoop:000> create link --cid 1
Creating link for connector with id 1
Please fill following values to create new link object
Name: mysql2hive

Link configuration

JDBC Driver Class: com.mysql.jdbc.Driver        
JDBC Connection String: jdbc:mysql://10.227.96.6:3006/fe_group?tinyInt1isBit=false
Username: anamember
Password: **********
JDBC Connection Properties: 
There are currently 0 values in the map:
entry# 

注意 在创建JDBCjob时
Schema name: Table name: 配对使用，如果输入了schema 和 table name ,Table SQL statement: 就不需要输入，如果输入了 sql语句就不填 schema 和 table name

sqoop:000> create link -c 2
Creating link for connector with id 2
Please fill following values to create new link object
Name: hdfs_link

Link Configuration

HDFS host and port: 10.227.96.27:8100
New link was successfully created with validation status OK and persistent id 2

http://10.227.96.27:5070/explorer.html#/home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth

hdfs://10.227.96.27:5070/home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth/
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/fezs.db/sf_group_auth 
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db
hdfs dfs -rm -r /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth
hdfs dfs -ls /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth  
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/fezs.db/sf_scan_order
hdfs dfs -rm -r /user/oozie
dataset:file:/home/analyze/test

Job with id 1 and name mysql2hive (Enabled: true, Created by analyze at 21-1-22 下午9:50, Updated by analyze at 21-1-28 上午11:45)
Using link id 1 and Connector id 1
  From database configuration
    Schema name: fe_group
    Table name: sf_group_auth
    Table SQL statement: 
    Table column names: 
    Partition column name: 
    Null value allowed for the partition column: false
    Boundary query: 
  Throttling resources
    Extractors: 1
    Loaders: 2
  To Kite Dataset Configuration
    Dataset URI: dataset:file:/home/analyze/test/test
    File format: PARQUET




以下是各个属性

Name：一个标示符，自己指定即可。

Schema Name：指定Database或Schema的名字，在MySQL中，Schema同Database类似，具体什么区别没有深究过，但官网描述在创建时差不多。这里指定数据库名字为db_ez即可，本例的数据库。

Table Name：本例使用的数据库表为tb_forhadoop，自己指定导出的表。多表的情况请自行查看官方文档。

SQL Statement：填了schema name和table name就不可以填sql statement。sql语句中必须包含${CONDITIONS}字样，一般是where 1=1 and ${CONDITIONS}

Partition column: 在填写了sql statement的情况下，必须填写，用以对数据分区,一般为可唯一标识记录的数字型字段。

Partition column nullable:

Boundary query:

Last value:

后面需要配置数据目的地各项值：

Null alue：大概说的是如果有空值用什么覆盖

File format：指定在HDFS中的数据文件是什么文件格式，这里使用TEXT_FILE，即最简单的文本文件。

Compression codec：用于指定使用什么压缩算法进行导出数据文件压缩，我指定NONE，这个也可以使用自定义的压缩算法CUSTOM，用Java实现相应的接口。

Custom codec：这个就是指定的custom压缩算法，本例选择NONE，所以直接回车过去。

Output directory：指定存储在HDFS文件系统中的路径，这里必须指定一个存在的路径，或者存在但路劲下是空的，貌似这样才能成功。

Append mode：用于指定是否是在已存在导出文件的情况下将新数据追加到数据文件中。

Extractors：map数量

Loaders：reduce数量




将关系型数据的表结构复制到hive中 

sqoop create-hive-table \
 --connect jdbc:mysql://10.227.96.6:3006/fe \
 --table sf_supplier \
 --username anamember \
 --password ana829test \
 --target-dir /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sf_supplier/ \
 --delete-target-dir \
 --hive-table sf_supplier \
 --fields-terminated-by '\t' \
 --lines-terminated-by '\n';


sqoop create-hive-table --connect jdbc:mysql://10.227.96.6:3006/fe --table sf_supplier --username 'anamember' --password 'ana829test'  --fields-terminated-by "\t"  --lines-terminated-by "\n";
sqoop create-hive-table --connect jdbc:mysql://10.227.96.6:3006/fe --username anamember --password ana829test --table sf_supplier


 
参数说明： 

--fields-terminated-by "\0001"  是设置每列之间的分隔符，"\0001"是ASCII码中的1，它也是hive的默认行内分隔符， 而sqoop的默认行内分隔符为"，" 

--lines-terminated-by "\n"  设置的是每行之间的分隔符，此处为换行符，也是默认的分隔符； 

注意：只是复制表的结构，表中的内容没有复制 



2.然后上传到集群中表存放数据的路径下
sqoop-import --append --connect 'jdbc:mysql://10.227.96.6:3006/fe_group' --username 'anamember' --password 'ana829test' --table sf_group_emp -m 1 --target-dir '/home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sf_group_emp/' --fields-terminated-by '\001' --lines-terminated-by '\n'
-- 加了 direct 属性在导出mysql数据库表中的数据会快一点 执行的是mysq自带的导出功能


sqoop export –connect jdbc:mysql://10.10.20.11/test –username root  –password admin –table test 
–export-dir /user/hive/warehouse/actmp –input-fields-terminated-by ‘\001′ –input-null-string ‘\\N’ –input-null-non-string ‘\\N’

<%@ page contentType="text/html;charset=UTF-8"%>
sqoop import \
 --connect jdbc:mysql://10.227.96.6:3006/fe?tinyInt1isBit=false\
 --username anamember \
 --password ana829test \
 --table sf_group_auth \
 --target-dir /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sf_group_auth/ \
 --delete-target-dir \
 --num-mappers 1 \
 --fields-terminated-by '\t' \
 --hive-drop-import-delims \
 --null-string '\\N' \
 --null-non-string '\\N' \
 --lines-terminated-by '\n';
hive-drop-import-delims \   #来把导入数据中包含的hive默认的分隔符去掉
sqoop从mysql导入数据到hive里面，时间是datetime的后面会多加个.0， 最好的解决办法就是将mysql表对应的datetime字段替换成hive中timestamp字段类型,以下这个方法不能解决办法 --map-column-hive "gmt_create=timestamp,gmt_modify=timestamp" \  (–-map-column-hive ${列名}=STRING)
–null-string <null-string>	如果指定列为字符串类型，使用指定字符串替换值为null的该类列的值
–null-non-string <null-string>	如果指定列为非字符串类型，使用指定字符串替换值为null的该类列的值

注：经测试，–null-string 后添加 '\\N' 或者 'NULL' 都可以！
即都可以在hive表中通过is null或者is NULL 的方式查出NULL值，
但不同的是--null-string '\\N'实际在HDFS中是以\N的存储NULL，而--null-string 'NULL'实际在HDFS中是以NULL的存储NULL


cp /app/mysql/bin/mysqldump  /home/analyze/sqoop/sqoop-1.4.7/bin
cp /app/mysql/bin/mysqldump  /home/analyze/hadoop/hadoop-2.8.5/bin
cp /app/mysql/bin/mysqldump  /home/analyze/sqoop/sqoop-1.4.7/bin

3.查看是否导入成功
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/test_huimin.db/sf_group_auth
hdfs dfs -ls /home/analyze/hive/hive2.3/hive/warehouse/db_hivetest.db/sf_activity_user_join_item
hdfs dfs -rm -r /home/analyze/hive/hive2.3/hive/warehouse/fezs.db/sf_group_auth

select count(1) from db_hivetest.sf_group_auth;
4.hive中查看数据
select * from db_hivetest.sf_group_emp_extend;
select count(item_id) from db_hivetest.sf_activity_user_join_item;
select item_id,activity_user_join_id from db_hivetest.sf_activity_user_join_item limit 100;


drop table if exists fezs.pub_role;
CREATE TABLE fezs.pub_role (
  `ROLE_ID` string COMMENT '编号',
  `SHOP_ID` string COMMENT '店铺ID',
  `ROLE_NAME` string COMMENT '角色名称',
  `DESCRIPTION` string COMMENT '说明'
) COMMENT '角色表，平台和商家的角色目前都放在这个表' 
row format delimited fields terminated by '\t'
LINES TERMINATED BY '\n'
stored as textfile
;


CREATE TABLE `pub_role` (
  `ROLE_ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '编号',
  `SHOP_ID` bigint(20) DEFAULT NULL COMMENT '店铺ID',
  `ROLE_NAME` varchar(100) DEFAULT NULL COMMENT '角色名称',
  `DESCRIPTION` varchar(1000) DEFAULT NULL COMMENT '说明',
  PRIMARY KEY (`ROLE_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8 COMMENT='角色表，平台和商家的角色目前都放在这个表'




