

--- mysql测试环境
IP:10.227.96.6
端口:3006
用户:  anamember
密码: ana829test


hive 功能测试
本测试基于 hive on mapreduce，hive测试环境，以及 mysql测试环境
【1.通过Sqoop将mysql数据导入到hdfs 详细的请参照：https://mp.weixin.qq.com/s/Kp6LLZ-tGZQIHvdAt6eYqA 进行学习】

以下为四个例子，分别为全量同步和增量同步
 -- 全量同步 （mysql到hdfs 成功，将 fe.sf_shelf_tag 同步到hdfs)
 sqoop import \
 --connect jdbc:mysql://10.227.96.6:3006/fe?tinyInt1isBit=false\
 --username anamember \
 --password ana829test \
 --table sf_shelf_tag \
 --target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_shelf_tag/ \
 --delete-target-dir \
 --num-mappers 1 \
 --fields-terminated-by '\t' \
 --hive-drop-import-delims \
 --null-string '\\N' \
 --null-non-string '\\N' \
 --lines-terminated-by '\n';
 
具体参数请网上先了解清楚
 
 -- 全量同步 （mysql到hdfs 成功 指定字段，将 fe.pub_role 同步到hdfs)
 sqoop import \
 --connect jdbc:mysql://10.227.96.6:3006/fe?tinyInt1isBit=false\
 --username anamember \
 --password ana829test \
 --table pub_role \
 --columns "ROLE_ID,SHOP_ID,ROLE_NAME,DESCRIPTION" \
 --target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/pub_role/ \
 --delete-target-dir \
 --num-mappers 1 \
 --fields-terminated-by '\t' \
 --hive-drop-import-delims \
 --null-string '\\N' \
 --null-non-string '\\N' \
 --lines-terminated-by '\n';
 
 
-- 按照时间字段增量同步（mysql到hdfs 成功 ，将 fe_group.sf_group_distribute_plan_detail 同步到hdfs，创建job，创建好后，执行：sqoop job -exec mysql2hive_job)
sqoop job --create mysql2hive_job -- import \
--connect jdbc:mysql://10.227.96.6:3006/fe_group \
--username anamember \
--password ana829test \
--table sf_group_distribute_plan_detail \
--target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_distribute_plan_detail/ \
--check-column last_update_time \
--incremental lastmodified \
--last-value "2021-04-14 15:12:57.0" \
--fields-terminated-by '\t' \
--hive-drop-import-delims \
--input-null-non-string '\\N' \
--null-string '\\N' \
--null-non-string '\\N' \
--lines-terminated-by '\n' \
--merge-key detail_id;

-- 按照时间字段增量同步（mysql到hdfs 成功 ,将 fe_group.sf_group_distribute_plan_detail 同步到hdfs)
sqoop import \
--connect jdbc:mysql://10.227.96.6:3006/fe_group \
--username anamember \
--password ana829test \
--table sf_group_distribute_plan_detail \
--target-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_distribute_plan_detail/ \
--check-column last_update_time \
--incremental lastmodified \
--last-value "2021-04-14 15:12:57.0" \
--fields-terminated-by '\t' \
--hive-drop-import-delims \
--input-null-non-string '\\N' \
--null-string '\\N' \
--null-non-string '\\N' \
--lines-terminated-by '\n' \
--merge-key detail_id;
 
 
 
 
 
【2.通过Sqoop将hdfs数据导入到mysql 详细的请参照：https://mp.weixin.qq.com/s/Kp6LLZ-tGZQIHvdAt6eYqA 进行学习】

 
-- 全量同步（hdfs到mysql 成功，fezs.dwd_group_emp_user_day 同步到mysql test.dwd_group_emp_user_day， 指定字段，用于mysql表有自增主键id字段)
sqoop-export \
 --connect jdbc:mysql://10.227.96.6:3006/test \
 --username anamember \
 --password ana829test \
 --table dwd_group_emp_user_day \
 --columns "emp_user_id,customer_user_id,group_customer_id,group_name,group_customer_id_sub,group_name_sub,user_role,bind_status,manager_status,emp_user_name,sex,mobile,OPEN_TYPE,OPEN_ID,dept_id,duties,dept,parent_org_name,division_code,division_name,professional_level,position_attr,bukrs_txt,job_number,ltrim_job_number,group_email,birthday,joindate,cancel_flag,cancel_date,add_time,data_flag,from_type,bindtime,remark,nick,is_fengxiang,load_time" \
 --input-null-string '\\N' \
 --input-null-non-string '\\N' \
 --export-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/dwd_group_emp_user_day \
 --input-fields-terminated-by '\t' 

 
 
-- 全量同步（hdfs到mysql ok)
sqoop-export \
 --connect jdbc:mysql://10.227.96.6:3006/test \
 --username anamember \
 --password ana829test \
 --table sf_group_auth_tj \
 --input-null-string '\\N' \
 --input-null-non-string '\\N' \
 --export-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth \
 --input-fields-terminated-by '\t' 
 
 
-- 全量同步 （hdfs到mysql ok  指定字段)
sqoop-export \
 --connect jdbc:mysql://10.227.96.6:3006/test \
 --username anamember \
 --password ana829test \
 --table sf_group_auth_tj \
 --columns "auth_id,group_customer_id,bind_group_customer_id,third_group_id,auth_name,data_flag,add_time,add_user_id,last_update_time,last_update_user_id" \
 --input-null-string '\\N' \
 --input-null-non-string '\\N' \
 --export-dir /home/analyze/hive1.1/hive1.2/hive/warehouse/fezs.db/sf_group_auth \
 --input-fields-terminated-by '\t' 
 
 
【3.DDL DML操作】
1) 建表：

-- 以下为创建hive表，注意：将mysql datetime对应hive表中 timestamp,其他的字段都改为string ,如下例子
drop table if exists fezs.sf_group_auth;
CREATE TABLE fezs.sf_group_auth (
  `auth_id` string COMMENT '人事权限id',
  `group_customer_id` string COMMENT '父级企业id',
  `bind_group_customer_id` string COMMENT '绑定资金账户的企业id',
  `third_group_id` string COMMENT '第三方企业id',
  `auth_name` string COMMENT '人事权限名称',
  `data_flag` string COMMENT '数据状态(1:正常、2:删除)',
  `add_time` timestamp COMMENT '添加时间',
  `add_user_id` string COMMENT '添加人员id',
  `last_update_time` timestamp COMMENT '最后修改时间',
  `last_update_user_id` string COMMENT '最后修改人员id'
) COMMENT '人事权限' 
row format delimited fields terminated by '\t'
LINES TERMINATED BY '\n'
stored as textfile
;

-- 以下为mysql表，
CREATE TABLE fe_group.`sf_group_auth` (
  `auth_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '人事权限id',
  `group_customer_id` bigint(20) DEFAULT NULL COMMENT '父级企业id',
  `bind_group_customer_id` bigint(20) DEFAULT NULL COMMENT '绑定资金账户的企业id',
  `third_group_id` varchar(40) DEFAULT NULL COMMENT '第三方企业id',
  `auth_name` varchar(100) DEFAULT NULL COMMENT '人事权限名称',
  `data_flag` tinyint(2) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`auth_id`),
  KEY `idx_bind_group_customer_id` (`bind_group_customer_id`),
  KEY `idx_group_customer_id` (`group_customer_id`),
  KEY `idx_third_group_id` (`third_group_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10001671 DEFAULT CHARSET=utf8mb4 COMMENT='人事权限'

2) 执行脚本

可以拿这个脚本进行测试，git上路径：fe_data_analysis_group\唐进\离职文件清单梳理\Hue平台（hive)相关文档\hive测试脚本


3)附上慧敏整理的hive的详细的使用文档：
https://shimo.im/docs/GCDGVGQVqyqXxPQG/ 《HIVE笔记》，可复制链接后用石墨文档 App 或小程序打开


