DELIMITER $$

USE `sh_process`$$

DROP PROCEDURE IF EXISTS `dm_op_cal_fill_reasonable_month_two`$$

CREATE DEFINER=`shprocess`@`%` PROCEDURE `dm_op_cal_fill_reasonable_month_two`()
BEGIN
SET @run_date := CURRENT_DATE(),@user := CURRENT_USER(),@stime := CURRENT_TIMESTAMP();




-- 执行记录日志
CALL sh_process.`sp_sf_dw_task_log` (
'dm_op_cal_fill_reasonable_month_two',
DATE_FORMAT(@run_date, '%Y-%m-%d'),
CONCAT('宋英南@', @user),
@stime);
 
COMMIT;
	END$$

DELIMITER ;


@Spover feods.`d_sc_preware_daily_report` --  fe_dm.`dm_sc_preware_daily_report`   这个表需要同步到实例2上。目前先补全一个月的数据吧。

-- dm_op_area_high_stock_three ok  sp_op_shelf_product_high_stock
三个结果表 均为增量更新
需要datax 同步结果表历史数据
fe_dm.dm_op_shelf_product_high_stock -- fe_dm.dm_op_shelf_product_high_stock
fe_dm.dm_op_shelf_high_stock  -- fe_dm.dm_op_shelf_high_stock
fe_dm.dm_op_area_high_stock   -- fe_dm.dm_op_area_high_stock



-- dm_op_area_stock_change_two  ok  sp_op_area_stock_change
两个结果表 均为增量更新
fe_dm.dm_op_area_stock_change_detail -- fe_dm.dm_op_area_stock_change_detail
fe_dm.dm_op_area_stock_change  -- fe_dm.dm_op_area_stock_change

-- dm_op_manual_fill_monitor ok  sp_op_manual_fill_monitor
一个结果表 dm_op_manual_fill_monitor 为增量更新
需要同步结果表历史数据 dm_op_manual_fill_monitor
fe_dm.dm_op_manual_fill_monitor   -- fe_dm.dm_op_manual_fill_monitor

-- dm_op_shelf_product_trans_out_monitor  ok  sp_op_shelf_product_trans_out_monitor
一个结果表 增量更新 
需要同步历史数据
fe_dm.dm_op_shelf_product_trans_out_monitor  -- fe_dm.dm_op_shelf_product_trans_out_monitor

-- dm_op_valid_danger_flag      ok  sp_op_valid_danger_flag   暂时不部署
fe_dm.dm_op_valid_danger_flag  -- fe_dm.dm_op_valid_danger_flag
一个结果表 全量更新 无需同步历史数据


-- dm_op_shelf_product_trans_out_his_two ok sp_op_shelf_product_trans_out_list
fe_dm.dm_op_shelf_product_trans_out_list  -- fe_dm.dm_op_shelf_product_trans_out_list
fe_dm.dm_op_shelf_product_trans_out_his  -- fe_dm.dm_op_shelf_product_trans_out_his

结果表 fe_dm.`dm_op_shelf_product_trans_out_his` 增量 需要同步历史数据 
fe_dm.dm_op_shelf_product_trans_out_list 全量更新


sp_op_package_shelf
两个结果表 
feods.d_op_package_shelf   -- fe_dm.dm_op_package_shelf  增量 需要同步历史数据  1004360  datax同步
feods.d_op_package_config  -- fe_dm.dm_op_package_config  全量 dm_op_package_config

还需要同步源表 fe_dm.dm_op_offstock_s7 T-1天的数据  -- feods.d_op_offstock_s7  3000条  datatx同步

d_mp_weixin_payment
d_mp_ssf_payment
D_MP_CMBC_payment
D_MP_epay_shelf_detail

select 'a' as table_name,count(1) from feods.d_mp_weixin_payment    union all #dwd_mp_weixin_payment  datax同步  08:22

select 'a' as table_name,count(1) from feods.d_mp_ssf_payment       union all #dwd_mp_ssf_payment  datax同步   00:15
select 'a' as table_name,count(1) from feods.D_MP_CMBC_payment      union all #dwd_mp_cmbc_payment  datax同步
select 'a' as table_name,count(1) from feods.D_MP_epay_shelf_detail ; #dwd_mp_epay_shelf_detail  datax同步

"table_name"	"count(1)"
"a"	"30021956"
"a"	"2453228"
"a"	"79195"
"a"	"163571"

truncate table fe_dwd.dwd_mp_weixin_payment    ;
truncate table fe_dwd.dwd_mp_ssf_payment       ;
truncate table fe_dwd.dwd_mp_cmbc_payment      ;
truncate table fe_dwd.dwd_mp_epay_shelf_detail ;


sp_op_package_shelf  08:13 每日
两个结果表 
feods.d_op_package_shelf   -- fe_dm.dm_op_package_shelf  增量 需要同步历史数据  1004360  datax同步
feods.d_op_package_config  -- fe_dm.dm_op_package_config  全量 dm_op_package_config

还需要同步源表 fe_dm.dm_op_offstock_s7 T-1天的数据  -- feods.d_op_offstock_s7  3000条  datatx同步

dm_subtype_price_stat_three  周一05:00
select 'a1' as table_name,count(1) from feods.fjr_subtype_price_salqty       union all #dm_op_subtype_price_salqty  datax同步   00:15
select 'a2' as table_name,count(1) from feods.fjr_product_price_salqty      union all #dm_op_product_price_salqty  datax同步
select 'a3' as table_name,count(1) from feods.fjr_subtype_price_stat ; #dm_subtype_price_stat  datax同步





    #目标表: test.dm_ma_HighProfit_list_monthly 每月一号运行一次
call sh_process.prc_dm_ma_HighProfit_list_monthly(curdate());  部署再07：30之后

	      #目标表: test.dm_ma_sectype_kpi_monthly  每天运行一次
call sh_process.prc_dm_ma_sectype_kpi_monthly(subdate(curdate(),1));



ALTER TABLE fe_dwd.`dwd_group_order_refound_address_day`
ADD COLUMN `pay_type`  INT(1) NULL DEFAULT NULL COMMENT '支付类型 1微信二维码支付，2手工线下支付,4E币支付' AFTER `sale_channel`;


 ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `CLOSE_TYPE`  INT(2) NULL DEFAULT NULL COMMENT '货架关闭原因类型' AFTER `CLOSE_TIME`; 

 ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `CLOSE_REMARK`  VARCHAR(100) NULL DEFAULT NULL COMMENT '货架关闭备注' AFTER `CLOSE_TYPE`; 
      
	  
	  
ALTER TABLE fe_dm.`dm_lo_fill_for_month_label`
ADD COLUMN `MANAGER_ID`  BIGINT(20) NULL DEFAULT NULL COMMENT '维护人员编号' AFTER `shelf_id`; 
	  



dm_ma_sectype_kpi_monthly  prc_dm_ma_HighProfit_list_monthly 之后
prc_dm_ma_HighProfit_list_monthly  07:30后
dm_ma_sectype_kpi_daily  prc_dm_ma_HighProfit_list_monthly 之后 06:44 
dwd_pub_emp_leave  05:00




ALTER TABLE fe_temp.dwd_group_order_refound_address_day CHANGE pay_type pay_type_desc VARCHAR(15) comment '支付类型描述';
ALTER TABLE fe_temp.`dwd_group_order_refound_address_day`
ADD COLUMN `pay_type`  INT(1) NULL DEFAULT NULL COMMENT '支付类型 1微信二维码支付，2手工线下支付,4E币支付' AFTER `sale_channel`;




#每半小时运行一次,第一次在当天的8:10运行 (目标表test.dm_ma_shelf_sale_daily)
	call test.dm_ma_shelf_sale_daily(curdate(),0);
	
	
	    #每半小时运行一次,第一次8:11运行 (目标表test.dm_ma_shelf_paytype_sale_daily)
	call test.dm_ma_shelf_paytype_sale_daily(curdate(),0);
	
		
	    #每半小时运行一次,第一次8:12运行 (目标表test.dm_ma_area_sale_hourly)
	call test.dm_ma_area_sale_hourly(curdate(),0);@李世龙 @唐进
	

	
	-- 2020-03-30
	    #每天运行一次 (目标表test.dm_ma_shelf_sale_weekly)
	call test.dm_ma_shelf_sale_weekly(subdate(curdate(),1));
	
	    #新增存储过程: 每天运行一次 (目标表test.dm_ma_shelf_sale_monthly)
	call test.dm_ma_shelf_sale_monthly(subdate(curdate(),1));
	

帮忙替换  dwd_order_item_refund_day.json文件，并帮忙触发临时同步任务  实例2的存储过程更改，并执行；
dm_lo_fill_for_month_label.json


ALTER TABLE fe_dwd.`dwd_order_item_refund_day`
ADD COLUMN `o_discount_amount`  DECIMAL(18,2)  NULL DEFAULT '0.00' COMMENT '订单优惠金额' AFTER `purchase_price`;
@唐进，那个任务云峰手动跑了。删除了 manager_id 字段。你的json文件也得麻烦鑫森改一下


    #修改存储过程:(修改表结构: test.dm_ma_shelf_sale_weekly)
    call test.dm_ma_shelf_sale_weekly(subdate(curdate(),1));

@唐进，那个任务云峰手动跑了。删除了manager_id字段。你的json文件也得麻烦鑫森改一下
唐进，你说的5个任务数据不一致的问题我核对了一下，主要是货架商品表历史结存的数据不是全量的问题
@Spover 我今天直接改了发给你部署吧，这个和经纬度清洗的分开





----------------------------  2020-04-07

alter table fe_dwd.`dwd_shelf_day_his`
add column `skus`  int(11) null default '0' comment 'sku数' after `sal_qty_act`;

alter table fe_dwd.`dwd_shelf_day_his`
add column `o_product_total_amount` decimal(18,2) null default '0.00' comment '商品总金额_折算后的' after `gmv`;


alter table fe_dwd.`dwd_shelf_day_his`
add column `o_discount_amount` decimal(18,2) null default '0.00' comment '订单优惠金额_折算后的' after `o_product_total_amount`;


alter table fe_dwd.`dwd_shelf_day_his`
add column `o_coupon_amount` decimal(18,2) null default '0.00' comment '优惠券优惠金额_折算后的' after `o_discount_amount`;

alter table fe_dwd.`dwd_shelf_day_his`
add column `o_third_discount_amount` decimal(18,2) null default '0.00' comment '第三方优惠金额_折算后的' after `o_coupon_amount`;

-- 修改以上 dwd_shelf_day_his.json 文件 近to_dwd存储过

-- 英南的任务   sp_unstock_detail_week -- dwd_op_unstock_area_product_week_two   每周一 04：58执行一次
@李世龙 世龙，帮我在实例2建两个表 fjr_unstock_detail_week ， fjr_unstock_area_product_week

fe_dwd.dwd_op_unstock_area_product_week   feods.fjr_unstock_area_product_week  -- 404875
fe_dwd.dwd_op_unstock_detail_week         feods.fjr_unstock_detail_week   -- 9935825

-- 李世龙的任务  dwd_shelf_product_sto_sal_30_days  每日执行一次


-- 英南的任务  每日04：51执行一次  dm_op_pwh_reqsto_two -- sp_op_dc_reqsto

fe_dm.dm_op_dc_reqsto  -- feods.d_op_dc_reqsto    579308
fe_dm.dm_op_pwh_reqsto -- feods.d_op_pwh_reqsto   5946858


-- 蔡松林的任务  dwd_lo_prewarehouse_fill_order_item_month  -- sp_d_lo_prewarehouse_fill_order_item_month 每日 00:17
结果表 dwd_lo_prewarehouse_fill_order_item_month --  feods.d_lo_prewarehouse_fill_order_item_month  12686327

-- 蔡松林的任务  dm_manager_shelf_performance_label  -- sp_zs_manager_shelf_performance_label 每日 04：54  (暂不部署）
 结果表 dm_manager_shelf_performance_label  -- feods.zs_manager_shelf_performance_label  3017234
 
 -- 蔡松林的任务   dm_product_fill_number_sorting -- sp_zs_product_fill_number_sorting 每月1号 04：14
  dm_product_fill_number_sorting -- feods.zs_product_fill_number_sorting  405877
  
 
fe_dwd.dwd_op_unstock_area_product_week   feods.fjr_unstock_area_product_week  -- 404875
fe_dwd.dwd_op_unstock_detail_week         feods.fjr_unstock_detail_week   -- 9935825

fe_dm.dm_op_dc_reqsto  -- feods.d_op_dc_reqsto    579308
fe_dm.dm_op_pwh_reqsto -- feods.d_op_pwh_reqsto   5946858

结果表 dwd_lo_prewarehouse_fill_order_item_month --  feods.d_lo_prewarehouse_fill_order_item_month  12686327
-- 结果表 dm_manager_shelf_performance_label  -- feods.zs_manager_shelf_performance_label  3017234
结果表 dm_product_fill_number_sorting -- feods.zs_product_fill_number_sorting  405877



------------------------------ 2020-04-08
-- 李世龙
ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `grade_cur_month`  VARCHAR(32) NULL DEFAULT NULL COMMENT '当月货架等级(即星华当月算出来的等级)' AFTER `grade`;

ALTER TABLE fe_dwd.dwd_fill_day_inc_recent_two_month
ADD COLUMN `LAST_UPDATE_TIME`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
 COMMENT '最后修改时间(取消订单的时间)' AFTER `CANCEL_REMARK`;

ALTER TABLE fe_dwd.dwd_fill_day_inc
ADD COLUMN `LAST_UPDATE_TIME`  DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
 COMMENT '最后修改时间(取消订单的时间)' AFTER `CANCEL_REMARK`;

datax同步
--feods.zs_shelf_flag                      fe_dm.dm_shelf_flag  已同步 全量 数据量少于10万         计划同步时间 00：30
--feods.zs_shelf_flag_his                  fe_dm.dm_shelf_flag_his  即将同步 增量 数据量少于10万   计划同步时间 00：30
--feods.zs_shelf_product_flag              fe_dm.dm_shelf_product_flag  即将同步 全量 数据量500万  计划同步时间 00：30
--feods.d_ma_shelf_product_seckill_remove  fe_dm.dm_ma_shelf_product_seckill_remove  暂不同步
--feods.dm_ma_shelf_kpi_detail_monthly     fe_dm.dm_ma_shelf_kpi_detail_monthly  暂不同步

SELECT COUNT(1) FROM feods.zs_shelf_flag ;-- 33130               zs_shelf_flag  23：45 耗时 5分钟
SELECT COUNT(1) FROM feods.zs_shelf_flag_his ;-- 5202357         zs_shelf_flag  23：45 耗时 5分钟
SELECT COUNT(1) FROM feods.zs_shelf_product_flag ;-- 5798481     zs_shelf_product_flag  23：00 耗时27分钟
SELECT COUNT(1) FROM feods.d_ma_shelf_product_seckill_remove ;-- 0   zs_shelf_product_flag 23：00 耗时27分钟
SELECT COUNT(1) FROM feods.dm_ma_shelf_kpi_detail_monthly ;-- 141778  prc_dm_ma_shelf_kpi_detail_monthly  03：24 每月1号 耗时 1分钟

sp_op_sf_fillorder_requirement_his 实例1上任务时间由现在的 05：35 调整到每日 07：43

英南需求（已完成）

-- 纪伟铨
#实例2新增表: (test.dm_op_kpi2_monitor,test.dm_op_kpi2_monitor_area )
d_op_kpi2_monitor
#实例2 修改存储过程:  test.dm_ma_shelf_sale_weekly ;


鑫森好！
请帮忙今晚处理以下以下几个需求：
1 帮忙修改azkaban调度任务的执行时间（实例1）
sp_op_sf_fillorder_requirement_his 由现在的 每日05：35执行一次 调整到每日 07：43 执行一次；（宋英南）
修改原因：fe库源表数据在7点多有更新一批数据。

2 帮忙替换datax同步任务的json文件（见“要替换的三个json文件”压缩包）
datax_dwd_wide_table_erp 任务的一个json文件：dwd_shelf_base_day_all.json，原因：新增一个grade_cur_month字段；（李世龙）
datax_dwd_wide_table_erp 任务的一个json文件：dwd_fill_day_inc.json，原因：新增一个LAST_UPDATE_TIME字段；（李世龙）
datax_dwd_fill_order_item_month_erp 任务的json文件：dwd_fill_day_inc_recent_two_month.json，原因：新增一个LAST_UPDATE_TIME字段；（李世龙）

3 帮忙执行一下临时同步任务：zs_shelf_flag_his_erp_temp（需要在部署以下datax同步任务之前执行）
说明：只执行一次，不用部署，目的是追平部署的datax同步任务实例2的结果表与实例1上的数据，在同一个shell文件中逐一执行）
只含一个表，数据量500万；

4 帮忙更新dataxt同步任务：zs_shelf_flag_erp
请做如下操作：
a.更改该同步任务的同步时间：由现在的每日00：57改为00：30;
b.压缩包内含1个shell文件：zs_shelf_flag_erp.sh，请直接替换现有的同名文件；
c.内含3个json文件，zs_shelf_flag.json  ，zs_shelf_flag_his.json（新增） ，zs_shelf_product_flag.json（新增），此次新增两个表的同步，只需要在对应的目录下新增后两个json文件即可；
同步说明：
1）zs_shelf_flag_his.json 是用于 同步实例1上的货架标签历史结存数据到实例，每日增量同步，数据量小于10万；
2）zs_shelf_product_flag.json 是用于 同步实例1上的货架商品标签到实例2，每日全量同步 ，数据量500万，目前暂无法增量同步，因为该表的数据是全量更新的；

5 帮忙部署azkaban调度任务（实例2，无需触发）：dwd_fill_day_inc_recent_two_month_update，用于更新实例2补货订单宽表及结存两个月宽表的数据 ，因为实例1上fe库源表会出现data_flag由之前的1变为2的情况，实例1上宽表该部分数据是删除了，但是实例2上是无法识别到，该存储过程是用于删除实例2上该部分的数据。执行时间：每日02：04执行一次；

6 帮忙修改azkaban调度任务（实例2）：dm_op_shelf_product_fill_last_time2 的执行时间，由现在的每日 01：44 改为每日 02：14；调整原因：新增了一个存储过程，对补货订单宽表及两个月结存的宽表做数据更新处理。



--- 待完成任务
presto 自助取数
1.自助取数
2.尼和任务迁移
3.datax同步shell脚本记录日志 实例2存储过程内部加记录数据量的统计
4.1400万优化测试
5.实例2azkaban库访问权限
6.实例2盘点表问题处理
7.家荣任务归属处理
8.梳理存储过程信息

唐进，帮我看下家荣的任务 sp_unstock_detail_week ，这个我看最新更新的数据是2019-12-11的，之后没有更新，是更新失败还是他有通知停止更新 -- 英南
任务失败监控优化，解决超时logout问题


d_op_shelf_type_product_sale  这个存储过程里用到家荣的表。都替换成我的宽表吧。你明天修改一下
d_op_shelf_active_week 这个表也是
d_op2_shelf_day_avg_gmv ， dm_op_autoshelf_stock_and_sale  
-- 梳理已经停掉的任务
停掉的，做个备份，就删了。不要保留
sh_buhuo_sale_flag  停掉了 
删掉结果表 pj_buhuo_sale_flag_frozen
           pj_buhuo_sale_flag


SELECT * FROM fe_dwd.dwd_fill_day_inc WHERE CANCEL_REMARK IS NOT NULL  -239  实例2补货订单宽表数据修复
SELECT COUNT(1) FROM fe_dwd.dwd_fill_day_inc WHERE CANCEL_REMARK IS NOT NULL  -- 1486
SELECT COUNT(1) FROM fe_dwd.dwd_fill_day_inc_recent_two_month WHERE CANCEL_REMARK IS NOT NULL  -- 1486

-- 纪伟铨  dm_ma_group_product_flag 实例1 
    #实例1新增存储过程: 每天运行一次 (test.dm_ma_group_product_flag)
	call sh_process.dm_ma_group_product_flag();
	
-- 宋英南 dm_op_cancel_fill_order 实例2


--------------------------------------- 2020-04-10
更换世龙宽表
梳理停止的调度任务 补货宽表数据修复

feods.d_op_shelf_grade 同步到实例2  fe_dm.`dm_pub_shelf_grade`   @唐进  这个表还是需要同步一下数据。表名如前所示
约翰通的表同步
fe_pay.sf_pay_requirement 这个表需要同步一下  dwd_sf_pay_requirement

dm_op_area_product_mgmv_six
dm_op_area_product_dfill_two
dm_shelf_mgmv_two
dm_op_kpi2_shelf_level_stat(subdate(curdate(),1));

dwd_shelf_base_day_all.json



英南的 sp_op_offstock  05:41 执行 耗时 13分钟  -- dm_op_offstock_five

feods.d_op_offstock          -- dm_op_offstock
feods.d_op_p_offstock        -- dm_op_p_offstock
feods.d_op_sp_offstock       -- dm_op_sp_offstock       全量无需同步历史数据
feods.d_op_sp_offstock_his   -- dm_op_sp_offstock_his
feods.d_op_s_offstock        -- dm_op_s_offstock

truncate table fe_dm.dm_op_offstock          ;
truncate table fe_dm.dm_op_p_offstock        ;
truncate table fe_dm.dm_op_sp_offstock       ;
truncate table fe_dm.dm_op_sp_offstock_his   ;
truncate table fe_dm.dm_op_s_offstock        ;


select 'a' as t,count(1) as nums from feods.d_op_offstock         union all    -- "a"	"11026157"  1100万 拆成每个400万左右数据
select 'b' as t,count(1) as nums from feods.d_op_p_offstock       union all    -- "b"	"105297159" 1亿  拆成55个子同步，每个200万左右
select 'c' as t,count(1) as nums from feods.d_op_sp_offstock      union all    -- "c"	"5297573"   500万
select 'd' as t,count(1) as nums from feods.d_op_sp_offstock_his  union all    -- "d"	"37021441"  3700万
select 'e' as t,count(1) as nums from feods.d_op_s_offstock      ;             -- "e"	"128384633" 1.2亿

"a"	"2848887"
"b"	"16453802"
"c"	"5464494"
"d"	"8488872"
"e"	"25922386"

feods.d_op_offstock  （数据量： 280万）
feods.d_op_p_offstock   （数据量：1600万，拆成4个子同步，每个数据量400万）
feods.d_op_sp_offstock_his  （数据量：850万，拆成7个子同步，每个数据量100多万）
feods.d_op_s_offstock      （数据量： 2600万，拆成6个子同步，每个数据量300多万）

sp_op_offstock_slot  -- dm_op_offstock_area7_six 
feods.d_op_offstock_area7       -- dm_op_offstock_area7
feods.d_op_offstock_m7          -- dm_op_offstock_m7
feods.d_op_offstock_s7          -- dm_op_offstock_s7   d_op_offstock_s7_erp 同步任务可以停掉
feods.d_op_offstock_s7p         -- dm_op_offstock_s7p
feods.d_op_offstock_s7_key      -- dm_op_offstock_s7_key
feods.d_op_offstock_slot        -- dm_op_offstock_slot


truncate table fe_dm.dm_op_offstock_area7  ;
truncate table fe_dm.dm_op_offstock_m7  ;
truncate table fe_dm.dm_op_offstock_s7  ;
truncate table fe_dm.dm_op_offstock_s7p  ;
truncate table fe_dm.dm_op_offstock_s7_key  ;
truncate table fe_dm.dm_op_offstock_slot  ;

select 'a' as t,count(1) as nums from feods.d_op_offstock_area7   union all    -- "a"	"3897"   
select 'b' as t,count(1) as nums from feods.d_op_offstock_m7      union all    -- "b"	"136455"
select 'c' as t,count(1) as nums from feods.d_op_offstock_s7      union all    -- "c"	"377018"
select 'd' as t,count(1) as nums from feods.d_op_offstock_s7p     union all    -- "d"	"16532548"  1600万
select 'e' as t,count(1) as nums from feods.d_op_offstock_s7_key  union all    -- "e"	"179939"
select 'f' as t,count(1) as nums from feods.d_op_offstock_slot  ;              -- "f"	"18703353"  1800万

feods.d_op_offstock_area7  	(数据量： 4317    )
feods.d_op_offstock_m7     	(数据量： 8.5万   )
feods.d_op_offstock_s7     	(数据量： 42万    )
feods.d_op_offstock_s7p    	(数据量： 1100万，拆成3个子同步，每个数据量300多万  )
feods.d_op_offstock_s7_key 	(数据量： 14万    )
feods.d_op_offstock_slot   	(数据量： 2100万，拆成5个子同步，每个数据量400多万  )

/app/datax/datax/job/tmp/XXX.json


星华的需求处理  实例1部署两个存储过程 dm_op_newshelf_firstfill_and_sale ； dm_op_out_product_sale_rate_and_clear_efficiency

蔡松林 sserp.T_BAS_BILLTYPE表数据为空 （处理ok)
sserp.T_SAL_OUTSTOCKENTRY
sserp.T_SAL_OUTSTOCKENTRY_F
sserp.T_STK_INSTOCKENTRY_F
sserp.T_BAS_BILLTYPE

世龙的任务部署 实例2
sp_area_product_dgmv -- 

--feods.d_op_product_area_shelftype_dgmv      dm_op_product_area_shelftype_dgmv  
--feods.fjr_area_product_dgmv                 dm_area_product_dgmv
--feods.d_op_product_area_shelftype_dfill     dm_op_product_area_shelftype_dfill 
--feods.fjr_area_product_dfill                dm_op_area_product_dfill


select 'a' as t,count(1) as nums from feods.d_op_product_area_shelftype_dgmv   union all  -- "a"	"4589673"  460万
select 'b' as t,count(1) as nums from feods.fjr_area_product_dgmv              union all  -- "b"	"2037919"  200万
select 'c' as t,count(1) as nums from feods.d_op_product_area_shelftype_dfill  union all  -- "c"	"9285314"  900万
select 'd' as t,count(1) as nums from feods.fjr_area_product_dfill  ;                     -- "d"	"1505510"  150万

"a"	"4596893"
"b"	"2040541"
"c"	"9303085"
"d"	"1507714"

select 'a' as t,count(1) as nums from fe_dm.dm_op_product_area_shelftype_dgmv  union all  
select 'b' as t,count(1) as nums from fe_dm.dm_area_product_dgmv union all  
select 'c' as t,count(1) as nums from fe_dm.dm_op_product_area_shelftype_dfill union all  
select 'd' as t,count(1) as nums from fe_dm.dm_op_area_product_dfill    ;        

"a"	"4596892"
"b"	"2040541"
"c"	"9303085"
"d"	"1507714"

sp_shelf_dgmv  -- 

--feods.d_op_product_area_shelftype_wgmv      dm_op_product_area_shelftype_wgmv
--feods.fjr_area_product_wgmv                 dm_op_area_product_wgmv
--feods.d_op_product_area_shelftype_mgmv      dm_op_product_area_shelftype_mgmv
--feods.fjr_area_product_mgmv                 dm_op_area_product_mgmv
--feods.fjr_shelf_wgmv                        dm_shelf_wgmv
--feods.fjr_shelf_mgmv                        dm_shelf_mgmv

fjr_shelf_dgmv
fjr_shelf_wgmv
fjr_shelf_mgmv
d_op_product_area_shelftype_mgmv
fjr_area_product_mgmv
d_op_product_area_shelftype_wgmv
fjr_area_product_wgmv

select 'a' as t,count(1) as nums from feods.d_op_product_area_shelftype_wgmv   union all    -- "a"	"859912"
select 'b' as t,count(1) as nums from feods.fjr_area_product_wgmv              union all    -- "b"	"342420"
select 'c' as t,count(1) as nums from feods.d_op_product_area_shelftype_mgmv   union all    -- "c"	"245906"
select 'd' as t,count(1) as nums from feods.fjr_area_product_mgmv              union all    -- "d"	"90579"
select 'e' as t,count(1) as nums from feods.fjr_shelf_wgmv                     union all    -- "e"	"3388216"   338万
select 'f' as t,count(1) as nums from feods.fjr_shelf_mgmv                   ;              -- "f"	"923297"

"a"	"860251"
"b"	"342481"
"c"	"246034"
"d"	"90596"
"e"	"3389152"
"f"	"923740"

select 'a' as t,count(1) as nums from fe_dm.dm_op_product_area_shelftype_wgmv  union all    
select 'b' as t,count(1) as nums from fe_dm.dm_op_area_product_wgmv  union all    
select 'c' as t,count(1) as nums from fe_dm.dm_op_product_area_shelftype_mgmv  union all    
select 'd' as t,count(1) as nums from fe_dm.dm_op_area_product_mgmv  union all    
select 'e' as t,count(1) as nums from fe_dm.dm_shelf_wgmv  union all    
select 'f' as t,count(1) as nums from fe_dm.dm_shelf_mgmv;              

"a"	"860480"
"b"	"342520"
"c"	"246135"
"d"	"90614"
"e"	"3389150"
"f"	"923739"


dm_op_area_product_mgmv_six
dm_op_area_product_dfill_two
dm_shelf_mgmv_two

--feods.d_op_product_area_shelftype_dgmv      truncate table fe_dm.dm_op_product_area_shelftype_dgmv      ;
--feods.fjr_area_product_dgmv                 truncate table fe_dm.dm_area_product_dgmv                   ;
--feods.d_op_product_area_shelftype_wgmv      truncate table fe_dm.dm_op_product_area_shelftype_wgmv      ;
--feods.fjr_area_product_wgmv                 truncate table fe_dm.dm_op_area_product_wgmv                ;
--feods.d_op_product_area_shelftype_mgmv      truncate table fe_dm.dm_op_product_area_shelftype_mgmv      ;
--feods.fjr_area_product_mgmv                 truncate table fe_dm.dm_op_area_product_mgmv                ;
--feods.d_op_product_area_shelftype_dfill     truncate table fe_dm.dm_op_product_area_shelftype_dfill     ;
--feods.fjr_area_product_dfill                truncate table fe_dm.dm_op_area_product_dfill               ;
--feods.fjr_shelf_wgmv                        truncate table fe_dm.dm_shelf_wgmv                          ;
--feods.fjr_shelf_mgmv                        truncate table fe_dm.dm_shelf_mgmv                          ;


ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `operation_time`  DATETIME NULL DEFAULT NULL COMMENT '前置仓运营时间' AFTER `CONTACT_MAIL`;


-- 纪伟铨 dm_op_kpi2_shelf_level_stat 实例2部署
    #实例2新增表: (test.dm_op_kpi2_shelf_level_stat)
    call test.dm_op_kpi2_shelf_level_stat(subdate(curdate(),1));

总结：
1 松林需求表数据为空处理；
2 世龙任务部署3个（10个表）
3 伟铨任务部署（1个）
4 同步 货架等级，约翰通，支付需求单表 共3个表
	
	
--------------------------------------------------------------- 待完成任务
英南的三个迁移任务（待盘点表处理好之后）
星华的需求处理
presto 自助取数
1.自助取数
2.尼和任务迁移
3.datax同步shell脚本记录日志 实例2存储过程内部加记录数据量的统计 kettle执行任务监控
4.1400万优化测试  关联家荣结存的表统计更新的数据；实例1的商品货架宽表优化测试（0点仅结存库存数据，3点多再使用）
5.实例2azkaban库访问权限
6.实例2盘点表问题处理
7.家荣任务归属处理
8.梳理存储过程信息

唐进，帮我看下家荣的任务 sp_unstock_detail_week ，这个我看最新更新的数据是2019-12-11的，之后没有更新，是更新失败还是他有通知停止更新 -- 英南
任务失败监控优化，解决超时logout问题


sp_op_sf_fillorder_requirement_his  dwd_fillorder_requirement_information （实例1，两个任务一致）


d_op_shelf_type_product_sale  这个存储过程里用到家荣的表。都替换成我的宽表吧。你明天修改一下
d_op_shelf_active_week 这个表也是
d_op2_shelf_day_avg_gmv ， dm_op_autoshelf_stock_and_sale  
-- 梳理已经停掉的任务
停掉的，做个备份，就删了。不要保留
sh_buhuo_sale_flag  停掉了 
删掉结果表 pj_buhuo_sale_flag_frozen
           pj_buhuo_sale_flag


SELECT * FROM fe_dwd.dwd_fill_day_inc WHERE CANCEL_REMARK IS NOT NULL  -239  实例2补货订单宽表数据修复
SELECT COUNT(1) FROM fe_dwd.dwd_fill_day_inc WHERE CANCEL_REMARK IS NOT NULL  -- 1486
SELECT COUNT(1) FROM fe_dwd.dwd_fill_day_inc_recent_two_month WHERE CANCEL_REMARK IS NOT NULL  -- 1486

dw_history.`dwd_check_base_day_inc_2019` 这个表的数据我已经补完了。有空的时候同步一下。这个不急
dw_history.`dwd_check_base_day_inc_2019`




--------------------------------------------- 2020-04-13

T_BAS_BILLTYPE_L 同步 （松林）
sp_d_mp_finance_data_fetch_task 、 sp_finance_instock_sales_outstock
fe.sf_shelf_relation_record  这个表需要同步到实例2   -- 8930  fe_dwd.`dwd_sf_shelf_relation_record`
fe.pub_shelf_manager          -- dwd_pub_shelf_manager  这个需要同步一下  125676

@唐进 实例1 sp_f_d_mp_f_amount 这个存储过程帮忙删除下  停止 sp_f_d_mp_f_amount  （航宇）  ok



-- 明天处理
-- 三个表同步到实例2
-- select count(1) from feods.zs_shelf_product_flag          union all    -- zs_shelf_product_flag  每晚23：00 开始，耗时23分钟左右，同步时间：每日 00：14执行 全量同步 580万
select count(1) from feods.zs_shelf_member_flag           union all    -- prc_d_ma_user_flag1 prc_d_ma_user_flag2  每周一 07：00前数据可以更新完，同步 全量同步 780万
select count(1) from feods.zs_shelf_member_flag_history   ;            -- prc_d_ma_user_flag1 每周一 07：00前数据可以更新完，同步 增量同步 780万 
DELETE FROM feods.zs_shelf_member_flag_history WHERE   sdate>=ADDDATE(@sdate,-IF(DAYOFWEEK(@sdate)=1,7,DAYOFWEEK(@sdate)-1) +1)  OR  sdate< DATE_SUB(CURDATE(),INTERVAL 9 WEEK);

feods.zs_shelf_member_flag 	        fe_dm.dm_shelf_member_flag
feods.zs_shelf_member_flag_history 	fe_dm.dm_shelf_member_flag_history

"5809960"  580万
"7814745"  780万
"76164117" 7600万

1 请帮忙修改datax同步任务：dm_lo_fill_for_month_label_erp 的同步时间，由现在的每日09：00 执行一次改为 每日08：00执行一次，修改原因：源表数据每日07：00更新，同步时间提前；（李世龙）

2 请帮忙更新datax同步任务：sp_op_fill_day_sale_qty_erp，（更新文件见附件“sp_op_fill_day_sale_qty_erp”压缩包） （宋英南）
任务目前该同步三个表，现在只需要同步两个表，请做如下操作：
1）帮忙删掉 d_op_com_day_sale_qty.json文件，原因是：实例1的该表已删除，无需同步；
2）帮忙替换 d_op_fill_day_sale_qty.json 文件，因为融合了删除的那个表字段，表结构发生变化；
3）帮忙更新 sp_op_fill_day_sale_qty_erp.sh 文件，现在都换成带有监控的最新shell脚本；

3 请帮忙执行datax临时同步任务:datax_20200414_01_temp_erp，用于追平下面部署的azkaban调度任务结果表和实例1上数据 （宋英南）
该临时同步任务包含8个表的同步，如下：
feods.d_op_dim_product_area_normal       （数据量： 13万   ）
feods.d_op_product_area_sal_month_large  （数据量： 8千    ）
feods.d_op_product_area_stat_month       （数据量： 7万    ）
feods.d_op_product_shelf_dam_month       （数据量： 3300万 ，拆成4个子同步，每个数据量800万左右，字段数少）
feods.d_op_product_shelf_sal_month       （数据量： 2400万，拆成4个子同步，每个数据量600万左右，字段数少 ）
feods.d_op_product_shelf_sal_month_large （数据量： 1.2万  ）
feods.d_op_product_shelf_stat            （数据量： 1900万，拆成3个子同步，每个数据量600万左右 ）
feods.d_op_product_shelf_sto_month       （数据量： 3700万，拆成3个子同步，每个数据量1300万左右，字段数少）

4 请帮忙执行datax临时同步任务:datax_20200414_02_temp_erp ，用于追平下面部署的datax同步任务实例2和实例1上数据
该临时同步任务包含1个表的同步，如下：
feods.zs_shelf_member_flag_history (数据量：7600万，已拆成10个子同步，每个数据量700多万，字段数少)（李世龙，纪伟铨）
feods.zs_shelf_member_flag (数据量：760万，已拆成2个子同步，每个数据量400万左右)（李世龙，纪伟铨）

5 请帮忙部署datax同步任务（见附件名为“2个datax同步任务”压缩包）
1) d_op_shelf_firstfill_erp,用于每日全量同步实例1上首次补货日期表数据到实例2，数据量9万，同步时间：每日02：41执行一次； （李世龙）
2) zs_shelf_member_flag_erp,用于每周一同步货架用户标识数据表到实例2，包含2个表，一个全量，一个增量，全量700多万拆成2个子同步，一个增量700多万同步字段数比较少，同步时间：每周一 07：01执行一次；    （李世龙，纪伟铨）

6 请帮忙部署azkaban调度任务（实例2）（见附件名为“3个azkaban任务包”的压缩文件）
1) dm_op_product_area_sal_month_large_eight ，用于每日更新地区商品月销售_大单表等8个表的数据，执行时间：每日05：28执行一次；（宋英南）
2) dm_op_newshelf_firstfill_and_sale ，用于每日更新每月1日截存新装无人货架初始商品包补货及销售数据，执行时间：每日08：29执行一次：（朱星华）
3) dm_op_out_product_clear_efficiency_two ,用于每日更新淘汰品售罄率和淘汰品清货效率数据，执行时间：每日07：29执行一次；（朱星华）



dm_op_product_area_sal_month_large_eight -- sp_op_product_shelf_stat 每日 05：28执行一次

truncate table fe_dm.dm_op_dim_product_area_normal;              -- feods.d_op_dim_product_area_normal      
truncate table fe_dm.dm_op_product_area_sal_month_large;         -- feods.d_op_product_area_sal_month_large 
truncate table fe_dm.dm_op_product_area_stat_month;              -- feods.d_op_product_area_stat_month      
truncate table fe_dm.dm_op_product_shelf_dam_month;              -- feods.d_op_product_shelf_dam_month      
truncate table fe_dm.dm_op_product_shelf_sal_month;              -- feods.d_op_product_shelf_sal_month      
truncate table fe_dm.dm_op_product_shelf_sal_month_large;        -- feods.d_op_product_shelf_sal_month_large
truncate table fe_dm.dm_op_product_shelf_stat;                   -- feods.d_op_product_shelf_stat           
truncate table fe_dm.dm_op_product_shelf_sto_month;              -- feods.d_op_product_shelf_sto_month      

9975557025944(邮政）

select count(1) from feods.d_op_dim_product_area_normal       （数据量： 13万   ）
select count(1) from feods.d_op_product_area_sal_month_large  （数据量： 8千    ）
select count(1) from feods.d_op_product_area_stat_month       （数据量： 7万    ）
select count(1) from feods.d_op_product_shelf_dam_month       （数据量： 3300万 ）
select count(1) from feods.d_op_product_shelf_sal_month       （数据量： 2400万 ）
select count(1) from feods.d_op_product_shelf_sal_month_large （数据量： 1.2万  ）
select count(1) from feods.d_op_product_shelf_stat            （数据量： 1900万 ）
select count(1) from feods.d_op_product_shelf_sto_month       （数据量： 3700万 ）
 


-- 星华任务部署 需要同步该表 
SELECT COUNT(1) FROM feods.d_op_shelf_firstfill  -- 91814  fe_dm.dm_op_shelf_firstfill  每日02：33更新


--------------------------------------------------------- 2020-04-15

完成英南的三个迁移任务+一个新增 4个
dm_op_valid_danger_flag （之前遗留） 每日 05：16执行一次   -- sp_op_valid_danger_flag  实例1每日 03:58
结果表： fe_dm.dm_op_valid_danger_flag  全量跟新无需同步历史数据
call sh_process.dm_op_valid_danger_flag();

dm_op_offstock_five （暂时不部署）
dm_op_offstock_area7_six  （暂时不部署）

dm_op_stock_reach_ratio (新增）  执行时间：每日06：01执行一次  
结果表： fe_dm.dm_op_stock_reach_ratio  
call sh_process.dm_op_stock_reach_ratio();

dm_op_fill_shelf_stat_four  每日04：16执行一次
sp_day_stat -- dm_op_fill_shelf_stat_four  均需要同步历史数据  json文件已经编写
call sh_process.dm_op_fill_shelf_stat_four();

select count(1) from feods.fjr_fill_area_product_stat  union all     -- truncate table fe_dm.dm_op_fill_area_product_stat  ;
select count(1) from feods.fjr_fill_shelf_stat         union all     -- truncate table fe_dm.dm_op_fill_shelf_stat         ;
select count(1) from feods.fjr_st_fill_stat            union all     -- truncate table fe_dm.dm_shelftype_fill_stat        ;
select count(1) from feods.fjr_st_order_stat          ;              -- truncate table fe_dm.dm_shelftype_order_stat       ;

feods.fjr_fill_area_product_stat   （数据量：146万 )
feods.fjr_fill_shelf_stat          （数据量：233万 )
feods.fjr_st_fill_stat             （数据量：1.2万 )
feods.fjr_st_order_stat            （数据量：5千   )


------------------------------------------- 完成松林的迁移任务
dm_manager_shelf_performance_label (之前遗留）每日04：54 执行一次  -- sp_zs_manager_shelf_performance_label  实例1 04：54
结果表   fe_dm.dm_manager_shelf_performance_label   -- feods.zs_manager_shelf_performance_label  数据量 3312441  330万  json文件已经编写
call sh_process.dm_manager_shelf_performance_label();

sp_d_mp_finance_data_fetch_task                  -- dm_mp_finance_month_income_result  每月1号 03：43 执行一次 测试ok
结果表： feods.D_MP_finance_month_income_result  -- fe_dm.dm_mp_finance_month_income_result  需要同步历史数据 数据量 2628 json文件已经编写
call sh_process.dm_mp_finance_month_income_result(curdate());

sp_zs_shelf_manager_monitor_result      每日 02：47 耗时7分钟         -- dm_shelf_manager_monitor_result  每日 02：47   耗时1分钟
结果表： feods.zs_shelf_manager_monitor_result    -- fe_dm.dm_shelf_manager_monitor_result   需要同步历史数据 数据量 4163368  420万 json文件已经编写
call sh_process.dm_shelf_manager_monitor_result();




-- 完成纪委铨的需求
#实例2新增表: (test.dm_ma_paytype_dashboard_daily)
call test.dm_ma_paytype_dashboard_daily(curdate(),0); #每半小时更新一次,更新时间注意调整实时同步时间
执行时间：每日08：14开始，每隔30分钟执行一次，如 08：14，08：44，09：14……；


#实例2新增表: (test.dm_ma_shelf_paytype_sale_monthly)  每月1号 03：01执行一次；
call test.dm_ma_shelf_paytype_sale_monthly(subdate(curdate(),1)); #每月一号更新一次

#实例2新增表: (test.dm_ma_shelf_product_monitor)  每日 05：17执行一次；
call test.dm_ma_shelf_product_monitor(); #每天一次@李世龙 @唐进
	
call sh_process.dm_ma_user_stat_info(); #每周一运行@唐进 每周一 02：34执行一次
	
	

-- 黎尼和 sp_op_shelf_user_month_stat   每日 04：07 耗时8-10分钟   dm_op_su_shelfcross_stat_eight  每日 02：54执行一次 耗时1分钟  
select count(1) from feods.d_op_su_month_stat            union all   -- "23483991"  2300万                 truncate table fe_dm.dm_op_su_month_stat         ; 
select count(1) from feods.d_op_su_shelf_month_stat      union all   -- "923428"    92万                   truncate table fe_dm.dm_op_su_shelf_month_stat   ;
select count(1) from feods.d_op_su_user_month_stat       union all   -- "20259340"  2000万                 truncate table fe_dm.dm_op_su_user_month_stat    ;
select count(1) from feods.d_op_su_uptolm_stat           union all   -- "7836431"   780万   全量更新       truncate table fe_dm.dm_op_su_uptolm_stat        ;   数据量 0
select count(1) from feods.d_op_su_stat                  union all   -- "7936262"   790万   全量更新       truncate table fe_dm.dm_op_su_stat               ;   数据量51万
select count(1) from feods.d_op_su_u_stat                union all   -- "5595379"   560万   全量更新       truncate table fe_dm.dm_op_su_u_stat             ;   数据量 48万
select count(1) from feods.d_op_su_s_stat                union all   -- "89305"     9万     全量更新       truncate table fe_dm.dm_op_su_s_stat             ;   数据量 2万多
select count(1) from feods.d_op_su_shelfcross_stat       ;           -- "2910442"   290万   全量更新       truncate table fe_dm.dm_op_su_shelfcross_stat    ;   数据量 2万多

feods.d_op_su_stat
feods.d_op_su_s_stat
feods.d_op_su_u_stat


select count(1) from fe_dm.dm_op_su_month_stat            union all
select count(1) from fe_dm.dm_op_su_shelf_month_stat      union all
select count(1) from fe_dm.dm_op_su_user_month_stat       union all
select count(1) from fe_dm.dm_op_su_uptolm_stat           union all
select count(1) from fe_dm.dm_op_su_stat                  union all
select count(1) from fe_dm.dm_op_su_u_stat                union all
select count(1) from fe_dm.dm_op_su_s_stat                union all
select count(1) from fe_dm.dm_op_su_shelfcross_stat       ;        

feods.d_op_su_stat   -- fe_dm.dm_op_su_stat
feods.d_op_su_s_stat -- fe_dm.dm_op_su_s_stat
feods.d_op_su_u_stat  -- fe_dm.dm_op_su_u_stat


	

   `add_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_time_detail` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',	
  fe_dwd.`dwd_activity_invitation_information` 修改json文件
	
	请帮忙更新datax同步任务：dwd_to_dwd_12erp dwd_activity_invitation_information.json
	
	
实例2 修改存储过程:  test.dm_ma_shelf_paytype_sale_daily ; （已处理）
	
ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `stock_skus`  INT(11) NULL DEFAULT '0' COMMENT '库存sku数(取库存大于0的商品数)' AFTER `stock_quantity`;

1.请帮忙替换datax同步任务：datax_dwd_wide_table_erp 的一个json文件，dwd_shelf_day_his.json，替换原因：新增一个字段stock_skus（库存sku数）；（李世龙）

select * from feods.d_op_su_u_stat;
select * from feods.d_op_su_stat;
select * from feods.d_op_su_s_stat;


-------------------------------------- 2020-04-17

请帮忙执行临时同步任务：d_op_su_uptolm_stat_temp_erp

实例1
feods.mongo_shelf_manager_behavior_log    每日同步时间 02：46
实例2
fe_dwd.dwd_mongo_shelf_manager_behavior_log  
通过 logTimeDate 来限定每天同步的数据。
历史同步最近四个月数据。动态保留四个月的数据

    #实例2新增表: (test.dm_ma_user_daily)
    call test.dm_ma_user_daily( subdate(current_date,1)); #每天一次
    #实例2新增表: (test.dm_ma_user_weekly)
    call test.dm_ma_user_weekly( subdate(current_date,1)); #每天一次
    #实例2新增表: (test.dm_ma_user_monthly)
    call test.dm_ma_user_monthly( subdate(current_date,1)); #每天一次
	
	#实例2新增表: (test.dm_ma_shelf_sale_2week)
    call test.dm_ma_shelf_sale_2week(); #每周一一次
	
	#实例2迁移表: (test.dm_ma_shelf_user_stat, 实例1数据:feods.d_ma_shelf_user_stat)  数据量 9万
    call test.dm_ma_shelf_user_stat( subdate(current_date,1)); #每天一次
	
	#实例2新增表: (test.dm_ma_shelf_product_temp)
    call test.dm_ma_shelf_product_temp(); #每天一次
	
	
	test.dm_ma_shelf_paytype_sale_daily@唐进 更新存储过程 (已处理）
	
世龙、唐进：
    二位好，如业务需求1，现需要在实例2新增报表和任务，因此需要：
1、世龙在实例2fe_dm库建2张表，同test.`dm_op_fill_not_push_order_stat`和test.`dm_op_fill_not_push_order_stat_total`； 测试ok  dm_op_fill_not_push_order_stat 依赖每天 06：21同步的 fe_dm.dm_op_auto_push_fill_date_his 时间设置在每日 07：09
2、世龙建好表后，需要唐进将附件存储过程进行部署，更新频率：每天，更新时间：上午9点前；
以上，谢谢。
	
世龙、唐进：
    二位好，如业务需求2，现需要在实例2新增报表和任务，因此需要：
1、世龙在实例2fe_dm库建2张表，同test.`dm_op_manual_fill_stat`和test.`dm_op_manual_fill_stat_total`；测试ok   dm_op_manual_fill_stat 依赖每天 07：58执行的任务 dm_op_manual_fill_monitor，耗时1分钟左右，时间定在每日 08：27执行一次；
2、世龙建好表后，需要唐进将附件存储过程进行部署，更新频率：每天，更新时间：上午9点前；
以上，谢谢。


-------------------------------------------------------
fe.`sf_shelf_info_flag`   这个兔兔比较急用。你找鑫森今天搞定一下（完成）
fe.`sf_shelf_info_flag`  这个表每天全量同步到实例2吧 (李世龙） 只同步data_flag= 1的

fe_dwd.`dwd_en_combined_payment_order` @黎尼和  表已经建好了。稍后唐进会跟进部署一下（已完成）
CALL sh_process.dwd_en_combined_payment_order();
  
-- 航宇停掉两个任务
sp_D_MA_area_product_sales_data_daily (可删除）
该存储过程对应的调度工程可以删除，存储过程代码及对应中间表D_MA_area_product_sales_data_daily可以备份后删除，备份保留时间建议至少1个月
工程 pj_zs_shelf_grade 删除
存储过程 sh_zs_shelf_grade 代码备份后删除，备份1个月
中间表zs_shelf_grade数据备份后删除，备份1个月



---------------------------- 2020-04-21


-- 星华的任务
-- 淘汰及时率
CREATE TABLE fe_dm.dm_op_out_product_intime_rate
-- 原有品淘汰建议清单
CREATE TABLE fe_dm.dm_op_out_product_suggest

-- 无人货架价格敏感度
CREATE TABLE fe_dm.`dm_op_shelf_price_sensitivity`

-- 地区商品平均单价
CREATE TABLE fe_dm.dm_op_area_product_avg_price

1 英南遗留的迁移任务 
dm_op_offstock_five （暂时不部署）
dm_op_offstock_area7_six  （暂时不部署）

2 英南周末新增的4个迁移任务
dm_op_kpi_unsku  每日04：49执行一次   测试ok 同步历史数据-- sp_kpi_unsku   每日
   fe_dm.dm_op_kpi_unsku  -- feods.fjr_kpi_unsku  1156885 

dm_op_effective_stock_two  每日05：52执行一次    测试ok  -- sp_op_effective_stock  03:17每日
   fe_dm.dm_op_tot_stat       -- feods.d_op_tot_stat  8772038
   fe_dm.dm_op_effective_stock  -- feods.d_op_effective_stock 1698651  无需同步历史数据

3 松林新增的迁移任务6个
dwd_lo_node_monitor_data_after_cleanout  每日03：16执行一次  测试ok 同步历史数据 -- sp_D_LO_node_monitor_data_after_cleanout 每日02：43执行
   fe_dwd.dwd_lo_node_monitor_data_after_cleanout   -- feods.D_LO_node_monitor_data_after_cleanout  1507974
dm_lo_manager_performance_report_everyday_for_month  每日02：17执行一次 测试ok  同步历史数据   -- sp_D_LO_manager_performance_report_everyday_for_month 每日00：54
  fe_dm.dm_lo_manager_performance_report_everyday_for_month   -- feods.D_LO_manager_performance_report_everyday_for_month   3222
 

fe_dwd.dwd_pub_large_amount_order 这个是批量订单的。有70多条历史数据。需要同步到实例2上。实例1上数据已经加工出来了。同步完成告知我一下
sf_product_fill_order_extend.json文件修改
家荣gmv 和 尼和两个任务 共3个任务部署以及数据同步 
dwd_en_combined_payment_order 每日00：32执行一次
dwd_en_distribute_detail_fx  每日00：33执行一次
dm_shelf_add_mgmv  每日 00：57执行一次


feods.csl_finance_instock_sales_outstock_table  --fe_dm.dm_finance_instock_sales_outstock_table  8万
每月10号同步一次同步更新一次，增量更新。stat_date作为增量更新的字段。（ok)

请帮忙部署datax同步任务：csl_finance_instock_sales_outstock_table_erp，用于每月10号增量同步实例1上财务进销存汇总报表数据到实例2，同步时间：每月10号 00：29执行一次；


鑫森晚上好！
        请帮忙处理一下以下两个需求：
1 请帮忙部署azkaban调度任务（实例1），文件见“azkaban实例1任务包”
1）dwd_en_distribute_detail_fx，用于每日更新丰享积分派发明细宽表数据，执行时间：每日00：33执行一次；（黎尼和）
2）dm_shelf_add_mgmv ，用于每日更新货架每月gmv数据， 每日 00：57执行一次；（李世龙）
2 请帮更新datax同步任务：fe_to_dwd_erp 的一个表同步的json文件，sf_product_fill_order_extend.json（如附件），更新原因：对应的实例1表新增了两个字段；（李世龙）
3 请帮忙执行datax临时同步任务：datax_20200421_temp_erp，文件如附件，用的是新版shell脚本，路径已修改，只需执行一次，用于追平实例2上即将部署的datax同步和azkaban调度任务的表数据。该同步包含以下9个表：
feods.fjr_kpi_unsku  （数据量：110万）
feods.d_op_tot_stat  （数据量：870万，字段数少） 
feods.D_LO_node_monitor_data_after_cleanout  （数据量：150万） 
feods.D_LO_manager_performance_report_everyday_for_month   （数据量：3千）
fe_dwd.dwd_pub_large_amount_order （数据量：70多）
feods.csl_finance_instock_sales_outstock_table  （数据量：8万）
fe_dwd.dwd_en_combined_payment_order  (数据量：1.6万）
fe_dwd.dwd_en_distribute_detail_fx  （数据量：267万）
fe_dm.dm_shelf_add_mgmv  （数据量：4千）
4 请帮忙更新datax同步任务：datax_feods_d_op_fill_dwd_erp，目前是同步3个表，现新增1个表：feods.d_op_smart_shelf_fill_update_his，增量同步。请做如下操作：
更新 datax_feods_d_op_fill_dwd_erp.sh 文件，新增d_op_smart_shelf_fill_update_his.json文件 （见附件：datax_feods_d_op_fill_dwd_erp压缩包）（宋英南）

5 请帮忙更新datax同步任务：datax_dwd_wide_table_erp，目前是同步12个宽表，现新增3个宽表： dwd_en_combined_payment_order（增量同步），dwd_en_distribute_detail_fx（增量同步），dm_shelf_add_mgmv（全量同步）。请做如下操作：更新datax_dwd_wide_table_erp.sh文件，新增dwd_en_combined_payment_order.json ，dwd_en_distribute_detail_fx.json，dm_shelf_add_mgmv.json 共三个json文件。（见附件：datax_dwd_wide_table_erp压缩包）（李世龙，黎尼和）

6 请帮忙部署datax同步任务：csl_finance_instock_sales_outstock_table_erp，用于每月10号增量同步实例1上财务进销存汇总报表数据到实例2，同步时间：每月10号 00：29执行一次；（蔡松林，李世龙）

7.帮忙部署azkaban调度任务（实例2）：见附件”4个azkaban任务实例2“
1）dm_lo_manager_performance_report_everyday_for_month，用于每日更新 全职店主月度每日效能结果表数据，执行时间：每日02：17执行一次；（蔡松林）
2）dwd_lo_node_monitor_data_after_cleanout，用于每日更新清洗后的埋点明细结果表数据，执行时间：每日03：16执行一次；（蔡松林）
3）dm_op_kpi_unsku，用于每日更新sku不足货架表数据，执行时间：每日04：49执行一次；（宋英南）
4）dm_op_effective_stock_two，用于每日更新有效库存阈值等两个表的数据，执行时间：每日05：52执行一次；（宋英南）

--------------------------------------------------------------------------- 20200422
-- 航宇停掉两个任务
sp_D_MA_area_product_sales_data_daily (可删除）

-- 星华的任务
-- 淘汰及时率
 -- dm_op_out_product_intime_rate_and_suggest
CREATE TABLE fe_dm.dm_op_out_product_intime_rate
-- 原有品淘汰建议清单
CREATE TABLE fe_dm.dm_op_out_product_suggest
-- dm_op_shelf_price_sensitivity
-- 无人货架价格敏感度
CREATE TABLE fe_dm.`dm_op_shelf_price_sensitivity`
-- call dm_op_area_product_avg_price (in in_month_id char(7)) 参数需要确认
-- 地区商品平均单价
CREATE TABLE fe_dm.dm_op_area_product_avg_price

1 英南遗留的迁移任务 
dm_op_offstock_five （暂时不部署）
dm_op_offstock_area7_six  （暂时不部署）
2 英南周末新增的4个迁移任务,还有2个
3 松林新增的迁移任务 （1+6）

sp_D_LO_area_fulltime_reached_index_statistics  每日 06：06  -- dm_lo_area_fulltime_reached_index_statistics  测试ok  缺少 fe_dm.dm_op_s_offstock 源表  datax同步
结果表 feods.d_lo_area_fulltime_reached_index_statistics 数据量 1325    -- fe_dm.dm_lo_area_fulltime_reached_index_statistics

sp_D_LO_school_order_item  每日 00：21   -- dwd_lo_school_order_item   测试ok 每日02：06 
结果表 feods.D_LO_school_order_item   数据量：278492  -- fe_dwd.dwd_lo_school_order_item

sp_D_LO_shelf_fill_timeliness_detail  每日04：22   -- dm_lo_shelf_fill_timeliness_detail  测试ok 04：22 
结果表 feods.D_LO_shelf_fill_timeliness_detail  数据量 1329129  -- fe_dm.dm_lo_shelf_fill_timeliness_detail  1329441
select 1329441-1329129  312

sp_zs_fill_operation_kpi_for_management 每日 04：58   -- dm_fill_operation_kpi_for_management  datax同步
结果表 feods.zs_fill_operation_kpi_for_management 数据量 94  无需同步历史数据  -- fe_dm.dm_fill_operation_kpi_for_management

sp_zs_shelf_manager_behavior_with_check_ID  每日03：23  0.2分钟  -- dm_shelf_manager_check_monitor_point 测试ok 每日03：23 datax同步
结果表： feods.zs_shelf_manager_check_monitor_point  数据量 938579  -- fe_dm.dm_shelf_manager_check_monitor_point

zs_shelf_manager_suspect_problem_label  每日00：14 0.4min     -- dm_shelf_manager_suspect_problem_label  测试ok datax同步
结果表 feods.zs_shelf_manager_suspect_problem_label  44893    -- fe_dm.dm_shelf_manager_suspect_problem_label



-- 吴婷
CALL test.`sh_preware_outbound_fill`();
CALL test.`sh_preware_product_sale`(); # 
CALL test.`d_sc_preware_sku_satisfy`();
-- CALL test.`sp_prewarehouse_stock_detail`();
-- CALL test.`sh_preware_stock_weekly_monthly`();
CALL test.`sp_d_sc_preware_balance`('2020-04-20');
CALL test.`sh_prewarehouse_coverage_rate`();
CALL test.`sp_d_sc_preware_wave_cycle`('2020-04-20');
CALL test.`sp_d_sc_profit_monthly_shelf_product`(); # 
CALL test.`sp_d_sc_preware_daily_report`('2020-04-20');
CALL test.`sp_d_sc_warehouse_stock_out`();
CALL test.`sp_warehouse_product_presence`(); # 
CALL test.`d_sc_preware_kpi`();

dm_prewarehouse_stock_detail  每日 05：42执行一次 -- sp_prewarehouse_stock_detail
结果表： fe_dm.dm_prewarehouse_stock_detail  -- feods.pj_prewarehouse_stock_detail   51844534
dm_prewarehouse_stock_detail_weekly_monthly  每日 05：52执行一次 -- sh_preware_stock_weekly_monthly
结果表  fe_dm.dm_prewarehouse_stock_detail_weekly   -- feods.pj_prewarehouse_stock_detail_weekly  7739548
结果表  fe_dm.dm_prewarehouse_stock_detail_monthly  -- feods.pj_prewarehouse_stock_detail_monthly 1818615

同步这个表 dm_sc_current_dynamic_purchase_price 每日 05：17 同步时间 每日05：31


    #实例2新增表: (test.dm_ma_area_dashboard_daily)
    call test.dm_ma_area_dashboard_daily( 0 ); #每半小时更新一次, 注意依赖的fe_dm.dm_ma_shelf_sale_daily 时间
	执行时间：每日08：16开始，每隔30分钟执行一次，如 08：16，08：46，09：16……；
	
#实例2 迁移
truncate fe_dm.dm_ma_shelfRedPacket_shelf;
truncate fe_dm.dm_ma_shelfRedPacket_activity;
truncate fe_dm.dm_ma_shelfRedPacket_activity_compare3week;
call test.dm_ma_shelf_red_packet( subdate(current_date,if(dayofweek(current_date)=1,6,dayofweek(current_date)-2)+4)); # 每周一运行一次 
用到 dwd_sf_shelf_scope_detail 该表数据异常，暂时无法使用


select 'a' as table_name,count(1) from feods.dm_ma_shelfRedPacket_activity              union all
select 'b' as table_name,count(1) from feods.dm_ma_shelfRedPacket_activity_compare3week union all
select 'c' as table_name,count(1) from feods.dm_ma_shelfRedPacket_shelf;

"a"	"20"
"b"	"80"
"c"	"5729"

feods.fjr_shelf_nsys_list-- fe_dwd.`dwd_shelf_nsys_list_insert` 

sp_op_stock 每日05：58  -- dm_op_stock_three 测试ok  07：12执行

feods.d_op_stock_forecast -- dm_op_stock_forecast_insert  数据量 128

feods.d_op_stock_area      truncate table fe_dm.dm_op_stock_area     ; 
feods.d_op_stock_product   truncate table fe_dm.dm_op_stock_product  ;
feods.d_op_stock_shelf     truncate table fe_dm.dm_op_stock_shelf    ;    #每日增量同步
select 'a' as table_name,count(1) from feods.d_op_stock_area union all
select 'b' as table_name,count(1) from feods.d_op_stock_product union all
select 'c' as table_name,count(1) from feods.d_op_stock_shelf;

"a"	"271"
"b"	"33248"
"c"	"262160"

sp_flags_area_product_week   时间在05：00之后即可  -- call sh_process.dm_op_flags_res_area_two(SUBDATE(CURRENT_DATE,WEEKDAY(CURRENT_DATE)+1))  06:13 每周一     
call sh_process.sp_flags_area_product_week(subdate(current_date,weekday(current_date)+1))

feods.fjr_flags_area_product    fe_dm.dm_op_flags_area_product
feods.fjr_flags_res_area        fe_dm.dm_op_flags_res_area
select 'a' as table_name,count(1) from feods.fjr_flags_area_product union all
select 'b' as table_name,count(1) from feods.fjr_flags_res_area  ;
"a"	"7920143"
"b"	"199362"

dm_op_shelf_product_sales_flag_change  (新增)

sf_prize_record 修改json文件，并全量同步历史数据
sf_shelf_manager_score_detail 修改json文件，并全量同步历史数据

sf_coupon_use
user_member_wallet
user_member_wallet_log
sf_shelf_slot_stock_record
sf_prize_record
sf_shelf_scope_detail
sf_shelf_inspection_survey_answer
sf_shelf_manager_score_detail
sf_shelf_machine_online_status_record


    #实例2迁移表: 
    select * from test.dm_op_shelfs_area_areaversion;
    select * from test.dm_op_shelfs_dstat_areaversion;
    call test.dm_op_shelfs_dstat_areaversion( ); #每天一次
实例1 的源表是:
select 'a' as table_name,count(1)  from feods.d_op_shelfs_dstat_areaversion (12个字段）   fe_dm.dm_op_shelfs_dstat_areaversion  （12个字段）
select 'b' as table_name,count(1)  from feods.d_op_shelfs_area_areaversion;              fe_dm.dm_op_shelfs_area_areaversion

 sp_op_shelfs_dstat_areaversion  02:28 每日  -- dm_op_shelfs_area_areaversion_two
 

datax 同步任务
-- feods.d_en_org_address_info    62604                           fe_dwd.dwd_en_org_address_info            全量同步
-- feods.d_dv_emp_org             1817458                         fe_dwd.dwd_dv_emp_org                     增量同步  update_time
-- feods.fjr_abnormal_nsale_shelf_product 494349 直接同步         fe_dm.dm_op_abnormal_nsale_shelf_product  全量同步

-- sp_users_day_stat   每日 04：45 0.1分钟  -- dm_op_users_day_stat_nine(subdate(current_date,1))  测试ok
结果表：全部同步历史数据
feods.fjr_user_firstday_month_tran -- truncate table fe_dm.dm_op_firstday_month_tran        ;
feods.fjr_user_firstday_week_tran  -- truncate table fe_dm.dm_op_user_firstday_week_tran    ;
feods.fjr_user_firstday_tran       -- truncate table fe_dm.dm_op_user_firstday_tran         ;
feods.fjr_user_firstday_year_tran  -- truncate table fe_dm.dm_op_user_firstday_year_tran    ;
feods.fjr_users_dayct_month_tran   -- truncate table fe_dm.dm_op_users_dayct_month_tran     ;
feods.fjr_users_dayct_week_tran    -- truncate table fe_dm.dm_op_users_dayct_week_tran      ;
feods.fjr_users_dayct_tran         -- truncate table fe_dm.dm_op_users_dayct_tran           ;
feods.fjr_users_dayct_year_tran    -- truncate table fe_dm.dm_op_users_dayct_year_tran      ;
feods.fjr_users_day_stat           -- truncate table fe_dm.dm_op_users_day_stat             ;


select 'a0' as  t,count(1) from fe_dm.dm_op_firstday_month_tran         union all
select 'a1' as  t,count(1) from fe_dm.dm_op_user_firstday_week_tran     union all
select 'a2' as  t,count(1) from fe_dm.dm_op_user_firstday_tran          union all
select 'a3' as  t,count(1) from fe_dm.dm_op_user_firstday_year_tran     union all
select 'a4' as  t,count(1) from fe_dm.dm_op_users_dayct_month_tran      union all
select 'a5' as  t,count(1) from fe_dm.dm_op_users_dayct_week_tran       union all
select 'a6' as  t,count(1) from fe_dm.dm_op_users_dayct_tran            union all
select 'a7' as  t,count(1) from fe_dm.dm_op_users_dayct_year_tran       union all
select 'a8' as  t,count(1) from fe_dm.dm_op_users_day_stat      ;     

  feods.fjr_user_firstday_month_tran (数据量： 54万  )
  feods.fjr_user_firstday_week_tran  (数据量： 27万  )
  feods.fjr_user_firstday_tran       (数据量： 544万 )
  feods.fjr_user_firstday_year_tran  (数据量： 107万 )
  feods.fjr_users_dayct_month_tran   (数据量： 768     )
  feods.fjr_users_dayct_week_tran    (数据量： 160     )
  feods.fjr_users_dayct_tran         (数据量： 3万   )
  feods.fjr_users_dayct_year_tran    (数据量： 3680    )
  feods.fjr_users_day_stat           (数据量： 3.3万   )

-- sp_abnormal_order    每日 04：59 0.1分钟   -- dm_op_abnormal_order_user_four(subdate(current_date,1)) 测试ok
结果表： 全部同步历史数据
feods.fjr_abnormal_order_shelf_product         -- truncate table fe_dm.dm_op_abnormal_order_shelf_product   ;
feods.fjr_abnormal_order_user                  -- truncate table fe_dm.dm_op_abnormal_order_user            ;
feods.fjr_abnormal_order_over100               -- truncate table fe_dm.dm_op_abnormal_order_over100         ;
feods.fjr_abnormal_order_product_qty           -- truncate table fe_dm.dm_op_abnormal_order_product_qty     ;

dm_op_abnormal_order_shelf_product
dm_op_abnormal_order_user
dm_op_abnormal_order_over100
dm_op_abnormal_order_product_qty


select 'a0' as  t,count(1) from feods.fjr_abnormal_order_shelf_product  union all
select 'a1' as  t,count(1) from feods.fjr_abnormal_order_user  union all
select 'a2' as  t,count(1) from feods.fjr_abnormal_order_over100  union all
select 'a3' as  t,count(1) from feods.fjr_abnormal_order_product_qty  ;

feods.fjr_abnormal_order_shelf_product  (数据量: 461)
feods.fjr_abnormal_order_user           (数据量: 4.6万)
feods.fjr_abnormal_order_over100        (数据量: 3.7万)
feods.fjr_abnormal_order_product_qty    (数据量: 27万)

-- 英南遗留2个任务 已完成
-- 松林遗留1个任务
-- 伟铨遗留1个任务


-- 吴婷
CALL test.`sh_preware_outbound_fill`();
CALL test.`sh_preware_product_sale`(); # 
CALL test.`d_sc_preware_sku_satisfy`();
CALL test.`sp_prewarehouse_stock_detail`();
CALL test.`sh_preware_stock_weekly_monthly`();
CALL test.`sp_d_sc_preware_balance`('2020-04-20');
CALL test.`sh_prewarehouse_coverage_rate`();
CALL test.`sp_d_sc_preware_wave_cycle`('2020-04-20');
CALL test.`sp_d_sc_profit_monthly_shelf_product`(); # 
CALL test.`sp_d_sc_preware_daily_report`('2020-04-20');
CALL test.`sp_d_sc_warehouse_stock_out`();
CALL test.`sp_warehouse_product_presence`(); # 
CALL test.`d_sc_preware_kpi`();
call test.sp_d_sc_warehouse_balance('2020-04-26';) 
call test.sp_d_sc_warehouse_out_record(); 

d_sc_oms_stock_daily

"d_sc_preware_kpi"	"08:11"	"每周1"	"1.2"
"d_sc_preware_sku_satisfy"	"06:20"	"每日"	"0.0"
"sh_preware_outbound_fill"	"03:40"	"每日"	"1.4"
"sh_preware_product_sale"	"06:01"	"每日"	"1.7"
"sh_preware_stock_weekly_monthly"	"06:49"	"每日"	"1.7"
"sp_d_sc_preware_balance"	"06:10"	"每日"	"0.2"
"sp_d_sc_preware_daily_report"	"06:35"	"每日"	"1.1"
"sp_d_sc_preware_wave_cycle"	"06:31"	"每日"	"0.1"
"sp_d_sc_profit_monthly_shelf_product"	"06:57"	"每日"	"0.6"
"sp_d_sc_warehouse_stock_out"	"00:19"	"每日"	"0.0"
"sp_prewarehouse_stock_detail"	"00:03"	"每日"	"1.5"
"sp_warehouse_product_presence"	"07:28"	"每日"	"0.2"


-- sh_preware_outbound_fill   "03:40"	"每日"	"1.4"   dm_sc_preware_fill_seven_day_eight 测试ok  45s 每日 04：46执行一次
结果表   需要同步结果表历史数据
feods.d_sc_preware_fill_seven_day             -- truncate table fe_dm.dm_sc_preware_fill_seven_day         ;  feods.d_sc_preware_fill_seven_day     (数据量： 410万 )
feods.d_sc_preware_outbound_seven_day         -- truncate table fe_dm.dm_sc_preware_outbound_seven_day     ;  feods.d_sc_preware_outbound_seven_day (数据量： 672万 )
feods.d_sc_preware_outbound_three_day         -- truncate table fe_dm.dm_sc_preware_outbound_three_day     ;  feods.d_sc_preware_outbound_three_day (数据量： 394万 )
feods.preware_fill_daily                      -- truncate table fe_dwd.dwd_preware_fill_daily              ;  feods.preware_fill_daily              (数据量： 122万 )
feods.preware_outbound_daily                  -- truncate table fe_dwd.dwd_preware_outbound_daily          ;  feods.preware_outbound_daily          (数据量： 418万 )
feods.preware_outbound_forteen_day            -- truncate table fe_dwd.dwd_preware_outbound_forteen_day    ;  feods.preware_outbound_forteen_day    (数据量： 990万 )
feods.preware_outbound_monthly                -- truncate table fe_dwd.dwd_preware_outbound_monthly        ;  feods.preware_outbound_monthly        (数据量： 76万  )
feods.preware_outbound_weekly                 -- truncate table fe_dwd.dwd_preware_outbound_weekly         ;  feods.preware_outbound_weekly         (数据量： 178万 )


select 'a0' as table_name,count(1) from fe_dm.dm_sc_preware_fill_seven_day           union all
select 'a1' as table_name,count(1) from fe_dm.dm_sc_preware_outbound_seven_day       union all
select 'a2' as table_name,count(1) from fe_dm.dm_sc_preware_outbound_three_day       union all
select 'a3' as table_name,count(1) from fe_dwd.dwd_preware_fill_daily                union all
select 'a4' as table_name,count(1) from fe_dwd.dwd_preware_outbound_daily            union all
select 'a5' as table_name,count(1) from fe_dwd.dwd_preware_outbound_forteen_day      union all
select 'a6' as table_name,count(1) from fe_dwd.dwd_preware_outbound_monthly          union all
select 'a7' as table_name,count(1) from fe_dwd.dwd_preware_outbound_weekly            ;


-- sh_preware_product_sale   "06:01"	"每日"	"1.7"    dm_preware_shelf_sales_thirty_five 测试ok 1min2sec 每日 04：27执行一次；
结果表  需要同步结果表历史数据                                                                                                       
select count(1) from feods.d_sc_preware_sales_daily        union all   -- select count(1) from  fe_dm.dm_sc_preware_sales_daily       union all ;  feods.d_sc_preware_sales_daily       (数据量： 635万 ,拆成2个子同步，每个数据量约300多万)
select count(1) from feods.d_sc_preware_shelf_sales_daily  union all   -- select count(1) from  fe_dm.dm_sc_preware_shelf_sales_daily union all ;  feods.d_sc_preware_shelf_sales_daily (数据量： 1800万,拆成5个子同步，每个数据量约300多万)
select count(1) from feods.pj_preware_sales_fifteen        union all   -- select count(1) from  fe_dm.dm_preware_sales_fifteen        union all ;  feods.pj_preware_sales_fifteen       (数据量： 1000万,拆成3个子同步，每个数据量约300多万)
select count(1) from feods.pj_preware_sales_seven          union all   -- select count(1) from  fe_dm.dm_preware_sales_seven          union all ;  feods.pj_preware_sales_seven         (数据量： 944万, 拆成3个子同步，每个数据量约300多万 )
select count(1) from feods.pj_preware_shelf_sales_thirty   union all   -- select count(1) from  fe_dm.dm_preware_shelf_sales_thirty   union all ;  feods.pj_preware_shelf_sales_thirty  (数据量： 1100万,拆成3个子同步，每个数据量约300多万 )


select 'a0' as table_name,count(1) from fe_dm.dm_sc_preware_sales_daily           union all
select 'a1' as table_name,count(1) from fe_dm.dm_sc_preware_shelf_sales_daily     union all
select 'a2' as table_name,count(1) from fe_dm.dm_preware_sales_fifteen            union all
select 'a3' as table_name,count(1) from fe_dm.dm_preware_sales_seven              union all
select 'a4' as table_name,count(1) from fe_dm.dm_preware_shelf_sales_thirty       ;


-- d_sc_preware_sku_satisfy    "06:20"	"每日"	"0.0"    dm_sc_preware_sku_satisfy   测试ok  每日 06：20执行一次； 需要部署在 dm_preware_shelf_sales_thirty_five 之后  因为用到 dm_preware_shelf_sales_thirty，部署在 sp_prewarehouse_stock_detail 05：42后 ，部署在 dm_sc_preware_fill_seven_day_eight 每日 04：46 之后
结果表  需要同步结果表历史数据
feods.d_sc_preware_sku_satisfy   --  fe_dm.dm_sc_preware_sku_satisfy      数据量：  498万


-- sp_d_sc_preware_balance  "06:10"	"每日"	"0.2"  dm_sc_preware_balance 测试ok  每日 06：12执行一次； 部署在 dm_prewarehouse_stock_detail 05：42后
结果表  需要同步结果表历史数据     truncate table  fe_dm.dm_sc_preware_balance;
feods.d_sc_preware_balance    -- fe_dm.dm_sc_preware_balance   数据量： 4000万
call sh_process.dm_sc_preware_balance(subdate(current_date,1));

-- sh_prewarehouse_coverage_rate  03：46 每日 0.2    dm_prewarehouse_coverage_rate 测试ok  每日 03：46执行一次；
结果表  需要同步结果表历史数据             truncate table fe_dm.dm_prewarehouse_coverage_rate;
feods.pj_prewarehouse_coverage_rate   -- fe_dm.dm_prewarehouse_coverage_rate  数据量 ：1.7万




-- sp_d_sc_preware_wave_cycle  "06:31"	"每日"	"0.1"  dm_sc_preware_wave_cycle 测试ok 每日 06：31执行一次 需部署在 dm_sc_preware_balance 06：12之后
结果表  需要同步结果表历史数据      truncate table fe_dm.dm_sc_preware_wave_cycle ;
feods.d_sc_preware_wave_cycle    -- fe_dm.dm_sc_preware_wave_cycle   数据量： 2600万  先同步2020-03-01（含）之后的数据 约1000万
feods.d_sc_preware_fill_frequency      -- fe_dm.dm_sc_preware_fill_frequency
call sh_process.dm_sc_preware_wave_cycle(subdate(current_date,1));

需先同步 fe.sf_prewarehouse_info 数据 ，每天全量 数据量很小


-- sp_d_sc_profit_monthly_shelf_product "06:57"	"每日"	"0.6"  dm_sc_profit_monthly_shelf_product   测试ok  每日06：57执行一次
结果表：                              truncate table fe_dm.dm_sc_profit_monthly_shelf_product;
 feods.d_sc_profit_monthly_shelf_product   -- fe_dm.dm_sc_profit_monthly_shelf_product  数据量： 16万
 

-- sp_d_sc_preware_daily_report   "06:35"	"每日"	"1.1"  dm_sc_preware_daily_report  测试ok 每日 06：54执行一次；调度时间修改到06:38执行一次  特别说明：部署之后停止datax同步任务： d_sc_preware_daily_report_erp（每日06：40) 需要新增同步： dwd_sc_bdp_warehouse_stock_daily 每日 05：21执行一次，增量同步；依赖 sp_d_sc_preware_wave_cycle 06：31 
feods.d_sc_preware_daily_report   -- fe_dm.dm_sc_preware_daily_report  数据量： 3700万
call sh_process.dm_sc_preware_daily_report(subdate(current_date,1));


（数据量：1700万，先同步2020年的数据量，拆成6个子同步，每个数据量约200多万

-- sp_d_sc_warehouse_stock_out  "00:19"	"每日"	"0.0"  dm_sc_oms_stock_daily  测试ok 每日 02：44执行一次；
feods.d_sc_oms_stock_daily    -- fe_dm.dm_sc_oms_stock_daily   数据量: 132万


-- sp_warehouse_product_presence   "07:28"	"每日"	"0.2"  dm_warehouse_product_presence  测试ok 暂时不部署 缺 fe_dm.dm_sc_shelf_packages  datax同步
feods.pj_warehouse_product_presence   fe_dm.dm_warehouse_product_presence   数据量： 247万
 

-- sp_d_sc_warehouse_balance   dm_sc_warehouse_balance  测试ok 每日07：53  缺 fe_dm.dm_sc_warehouse_outbound_daily   需先部署 sp_d_sc_warehouse_out_record
fe_dm.dm_sc_warehouse_balance  6.3万

-- sp_dm_sc_preware_monthly_kpi   暂时不部署
CALL test.sp_dm_sc_preware_monthly_kpi('2020-05-08');

sp_warehouse_product_presence  -- dm_warehouse_product_presence 暂时不部署 暂时不部署 暂时不部署
sp_dm_sc_preware_monthly_kpi
sp_kpi2_sale_vs_stock_week
sp_d_sc_warehouse_preware_stock_outbound   -- dm_sc_warehouse_sku_shelf_cnt_two

-- sp_d_sc_warehouse_out_record  07:32 每日 0.1 dm_sc_warehouse_stock_monthly_five 每日07：32 测试ok  dwd_sc_bdp_warehouse_stock_daily_erp 中加入 需要同步 fe_dwd.dwd_sc_bdp_warehouse_shipment_detail 数据量 1310189
结果表：
select count(1) from feods.d_sc_warehouse_outbound_daily           union all
select count(1) from feods.d_sc_warehouse_outbound_forteen         union all
select count(1) from feods.d_sc_warehouse_outbound_forteen_total   union all
select count(1) from fe_dm.dm_sc_warehouse_outbound_monthly_total  union all
select count(1) from fe_dm.dm_sc_warehouse_stock_monthly           ;


feods.d_sc_warehouse_outbound_daily          (数据量：70万  )  truncate table fe_dm.dm_sc_warehouse_outbound_daily         ;
feods.d_sc_warehouse_outbound_forteen        (数据量：100万 )  truncate table fe_dm.dm_sc_warehouse_outbound_forteen       ;
feods.d_sc_warehouse_outbound_forteen_total  (数据量：22万  )  truncate table fe_dm.dm_sc_warehouse_outbound_forteen_total ;
fe_dm.dm_sc_warehouse_outbound_monthly_total (数据量：1万    ) truncate table fe_dm.dm_sc_warehouse_outbound_monthly_total ;
fe_dm.dm_sc_warehouse_stock_monthly          (数据量：1万   )  truncate table fe_dm.dm_sc_warehouse_stock_monthly          ;


select count(1) from fe_dm.dm_sc_warehouse_outbound_daily  union all
select count(1) from fe_dm.dm_sc_warehouse_outbound_forteen  union all
select count(1) from fe_dm.dm_sc_warehouse_outbound_forteen_total  union all
select count(1) from fe_dm.dm_sc_warehouse_outbound_monthly_total  union all
select count(1) from fe_dm.dm_sc_warehouse_stock_monthly  ;


-- 吴婷
-- CALL test.`sh_preware_outbound_fill`();
-- CALL test.`sh_preware_product_sale`(); # 
-- CALL test.`d_sc_preware_sku_satisfy`();
-- CALL test.`sp_prewarehouse_stock_detail`();
-- CALL test.`sh_preware_stock_weekly_monthly`();
-- CALL test.`sp_d_sc_preware_balance`('2020-04-20');
-- CALL test.`sh_prewarehouse_coverage_rate`();
CALL test.`sp_d_sc_preware_wave_cycle`('2020-04-20');
-- CALL test.`sp_d_sc_profit_monthly_shelf_product`(); # 
-- CALL test.`sp_d_sc_preware_daily_report`('2020-04-20');
-- CALL test.`sp_d_sc_warehouse_stock_out`();
CALL test.`sp_warehouse_product_presence`(); # 
CALL test.`d_sc_preware_kpi`();
call test.sp_d_sc_warehouse_balance('2020-04-26';)  
-----------------------------------------------------------

-- 新增同步（松林） 已完成
采购退料单财务信息   feng1.T_PUR_MRBFIN       FBILLAMOUNT(金额)
采购入库单 财务信息  feng1.t_STK_InStockFin   FBILLAMOUNT(金额)

航宇那边的红框里的存储过程可以停掉了。停掉之后，告知我一下，我删除表
伟铨这些绿色的，是直接同步结果表的。
fjr_shelf_profile                           (数据量：35137   )   -- dm_shelf_profile
user_research                               (数据量：7943066 )   -- dm_user_research
tmp_user_shelf(没有查到是属于哪个存储过程)  (数据量：5550283 )   -- 是否可删除？
zs_shelf_member_flag_history                (数据量：77022350)   -- dm_shelf_member_flag_history       已同步 77003634
zs_shelf_member_flag                        (数据量：7943038 )   -- 是否可删除？  dm_shelf_member_flag 已同步 7943038
user_research_day                           (数据量：4225    )   -- dm_user_research
zs_shelf_flag                               (数据量：33961   )   -- dwd_shelf_flag     已同步 实例2 表 dm_shelf_flag
zs_shelf_flag_his                           (数据量：5838015 )   -- dm_shelf_flag_his  已同步
zs_shelf_product_flag                       (数据量：6021985 )   -- dm_shelf_product_flag 已同步
d_ma_shelf_product_seckill_remove           (数据量：0       )   -- dm_ma_shelf_product_seckill_remove
dm_ma_shelf_kpi_detail_monthly              (数据量：141778  )   -- dm_ma_shelf_kpi_detail_monthly
dm_ma_coupon_bi_daily                       (数据量：65013   )   -- dm_ma_coupon_bi_daily
dm_ma_discount_activity_bi_daily            (数据量：38429   )   -- dm_ma_discount_activity_bi_daily



select 'a0' as table_name,count(1) as nums from feods.fjr_shelf_profile                    union all               
select 'a1' as table_name,count(1) as nums from feods.user_research                        union all       
select 'a2' as table_name,count(1) as nums from feods.tmp_user_shelf                       union all
select 'a3' as table_name,count(1) as nums from feods.zs_shelf_member_flag_history         union all       
select 'a4' as table_name,count(1) as nums from feods.zs_shelf_member_flag                 union all       
select 'a5' as table_name,count(1) as nums from feods.user_research_day                    union all       
select 'a6' as table_name,count(1) as nums from feods.zs_shelf_flag                        union all       
select 'a7' as table_name,count(1) as nums from feods.zs_shelf_flag_his                    union all       
select 'a8' as table_name,count(1) as nums from feods.zs_shelf_product_flag                union all       
select 'a9' as table_name,count(1) as nums from feods.d_ma_shelf_product_seckill_remove    union all       
select 'a10' as table_name,count(1) as nums from feods.dm_ma_shelf_kpi_detail_monthly       union all       
select 'a11' as table_name,count(1) as nums from feods.dm_ma_coupon_bi_daily                union all       
select 'a12' as table_name,count(1) as nums from feods.dm_ma_discount_activity_bi_daily     ;       

a0	35137
a1	7943066
a2	5550283
a3	77022350
a4	7943038
a5	4225
a6	33961
a7	5838015
a8	6021985
a9	0
a10	141778
a11	65013
a12	38429

feods.`d_op_sp_stock_detail`  同步到实例2 fe_dwd.`dwd_op_sp_stock_two_month`。只保留最近两个月的数据进去。  每日
同时 sp_op_sp_stock_detail 这个任务调至0点左右执行。同步到实例2的时间你来定  （已完成）
修改 dwd_shelf_base_day_all.json文件 （已完成）
dwd_city_business 这个需要每周一同步一下到实例2  （已完成）

T_STK_STKTRANSFERAPPENTRY_E （已完成）
fe.`sf_prewarehouse_delivery_date_config` 同步到实例2 (已完成）
sh_zs_goods_damaged 可以迁移到实例2
fe.sf_prewarehouse_info

prc_d_en_gross_margin_rate_order  -- 
feods.d_en_gross_margin_rate_user_month	-- truncate table fe_dm.dm_en_gross_margin_rate_user_month    ;
feods.d_en_gross_margin_rate_order_month	-- truncate table fe_dm.dm_en_gross_margin_rate_order_month   ;
feods.d_en_gross_margin_rate_user_week	-- truncate table fe_dm.dm_en_gross_margin_rate_user_week     ;
feods.d_en_gross_margin_rate_order_week	-- truncate table fe_dm.dm_en_gross_margin_rate_order_week    ;


select 'a' as table_name,count(1) as nums from feods.d_en_gross_margin_rate_user_month	 union all
select 'a' as table_name,count(1) as nums from feods.d_en_gross_margin_rate_order_month	 union all
select 'a' as table_name,count(1) as nums from feods.d_en_gross_margin_rate_user_week	 union all
select 'a' as table_name,count(1) as nums from feods.d_en_gross_margin_rate_order_week	;


d_op_s7p_detail  159172       -- dm_op_s7p_detail  （已同步）



-- dwd_pub_shelf_first_order_info 实例1 （李世龙）每日 00:58执行一次 （已完成）

    #实例1新增存储过程: 每周一运行一次,运行时间9点前  （纪伟铨）  （已完成）
	call sh_process.dm_ma_shelf_derived_data_weekly(current_date);@唐进

-- sp_kpi_shelf_nps   每日 04：28执行一次      dm_op_kpi_shelf_nps   （李世龙 实例2） （已完成）
结果表：feods.fjr_kpi_shelf_nps  （数据量： 300万）
call sh_process.dm_op_kpi_shelf_nps(subdate(current_date,interval 1 day));

-- dm_op_shelf_offstock （英南 实例2） 最好7点左右 （已完成）


-- sp_subtype_price_salqty_week 每周一 05：00  之前已部署 dm_subtype_price_stat_three
feods.fjr_product_price_salqty  fe_dm.dm_op_product_price_salqty
feods.fjr_subtype_price_salqty  fe_dm.dm_op_subtype_price_salqty
feods.fjr_subtype_price_stat    fe_dm.dm_subtype_price_stat

--  sp_kpi_np_gmv_month  每月1号 03：23 耗时 8分钟  dm_op_kpi_gmv_month_three  测试ok  每月1号 05：46执行一次
结果表： 
1）feods.fjr_kpi_np_gmv_month     （数据量： 1.2万）   truncate table fe_dm.dm_op_kpi_np_gmv_month     ;
2）feods.fjr_kpi_np_sal_sto_month （数据量： 1.2万）   truncate table fe_dm.dm_op_kpi_np_sal_sto_month ;
3）feods.fjr_kpi_gmv_month        （数据量： 773  ）   truncate table fe_dm.dm_op_kpi_gmv_month        ;

select count(1) from feods.fjr_kpi_np_gmv_month       union all 
select count(1) from feods.fjr_kpi_np_sal_sto_month   union all 
select count(1) from feods.fjr_kpi_gmv_month         ;
11668
12213
773

dm_op_price_sensitive_stat_nation
dm_op_price_sensitive_stat_two
dm_op_kpi_gmv_month_three
dm_subtype_price_stat_three

-- sp_price_sensitive_week  每周1 05:00  1.3  在 sp_price_sensitive_week_nation 前执行  dm_op_price_sensitive_stat_two  测试ok 有数据 每周一 05:01执行一次
call sh_process.sp_price_sensitive_week(subdate(current_date,weekday(current_date)+1));
需要同步历史数据
feods.fjr_user_miser_stat      （数据量：38645528 ）    truncate table fe_dm.dm_op_user_miser_stat      ;  先同步2019-07-01 （含）之后的数据 约1400万 24210711
feods.fjr_price_sensitive_stat （数据量：350727   ）    truncate table fe_dm.dm_op_price_sensitive_stat ;
这个存储过程涉及到两张表。需要将历史数据同步到实例2上。


-- sp_price_sensitive_week_nation 每周1 05:00  0  dm_op_price_sensitive_stat_nation  测试ok  每周一 05：37执行一次
需要同步历史数据 
fjr_price_sensitive_stat_nation  (数据量:74953)   truncate table fe_dm.dm_op_price_sensitive_stat_nation;


-- sp_kpi2_sale_vs_stock_week   每周1 05:00  7.1  暂时不部署
call sh_process.sp_kpi2_sale_vs_stock_week(subdate(current_date,weekday(current_date)+1));
fjr_kpi2_sale_vs_stock_week   dm_op_kpi2_sale_vs_stock_week
其中脚本里面的
fjr_kpi2_monitor_area         dm_op_kpi2_monitor_area   这个表对应实例2存储过程 dm_ma_shelf_sale_weekly（纪伟铨）
fjr_kpi2_monitor              dm_op_kpi2_monitor        这个表对应实例2存储过程 dm_ma_shelf_sale_weekly（纪伟铨）
这两个表需要注意一下，是否有其它的表对它进行更新

275449
41268
1161


-- 朱星华 
dm_op_shelf_week_month_sale   -- 周销售，每周一更新并截存上周数据；  月销售，每日更新，每月1日截存上月数据 部署实例2
dm_op_area_product_shelf_cover  -- 地区商品覆盖情况，需每日更新并截存，保留一个月的数据 部署实例2
dm_op_shelf_sku_situation    -- 需每日更新并截存 部署实例1


-- sf_prewarehouse_info datax同步已完成


fe.sf_material_transfer_order （数据量：8千）-- fe_dwd.`dwd_sf_material_transfer_order`  datax同步已完成

fe.sf_shelf_change_apply     （数据量：约5千）  -- fe_dwd.dwd_sf_shelf_change_apply datax同步已完成

#每4小时运行一次,11:02到16:02更新今天数据(2) 
call sh_process.dm_ma_discount_activity_shelf_daily(curdate(),0);  已完成
    #实例1新增存储过程: 11点前更新昨天数据, 11:02到16:02更新今天数据 (test.dm_ma_coupon_shelf_daily)
call sh_process.dm_ma_coupon_shelf_daily(curdate(),0);  已完成

-- 吴婷
CALL test.sp_fill_order_efficiency();  这个可以部署了
CALL test.`d_sc_preware_kpi`(); 这个应该也可以了
CALL test.sh_outstock_day();
call test.sp_d_sc_warehouse_preware_stock_outbound('2020-05-08')




-- sh_outstock_day  每日 04：25 耗时8 分钟  dwd_pj_outstock2_day 测试ok  部署后停掉 datax同步任务 pj_outstock2_day_erp（每日 04：39执行） 已完成
结果表
feods.PJ_OUTSTOCK2_DAY     3342416   fe_dwd.dwd_pj_outstock2_day   3342416 

-- sp_fill_order_efficiency   每日 06：51 耗时 0.3分钟    dm_fill_order_efficiency  测试ok   已完成
结果表
feods.pj_fill_order_efficiency  546577    dm_fill_order_efficiency

-- d_sc_preware_kpi "08:11"	"每周1"	"1.2"    dm_sc_preware_kpi 测试ok  需先部署 sp_fill_order_efficiency  已完成
feods.d_sc_preware_kpi  fe_dm.dm_sc_preware_kpi   数据量： 700





-- sp_d_sc_warehouse_preware_stock_outbound 每日 07:52  耗时0.4分钟  dm_sc_warehouse_sku_shelf_cnt_two 依赖 dm_warehouse_product_presence 暂时不部署
结果表：
feods.d_sc_warehouse_preware_stock_outbound  1178215         dm_sc_warehouse_preware_stock_outbound
feods.d_sc_warehouse_sku_shelf_cnt  8930                     dm_sc_warehouse_sku_shelf_cnt






dm_op_shelfs_area_areaversion_two 由现在的 每日07:22执行一次改为 每日 03：30执行一次； 已完成
prc_dm_ma_user_perfect_product 由现在的 每日00:52执行一次改为 每日02：23执行一次； 已完成



-- 纪伟铨 已完成
环境:实例1
要删除的表: 
	feods.d_ma_shelf_payment_type_simple_monthly;      prc_d_ma_shelf_payment_type_simple_monthly        无影响
	feods.d_ma_shelf_PAYMENT_TYPE_performance_monthly  prc_d_ma_shelf_PAYMENT_TYPE_performance_monthly   无影响
要删除的存储过程:
	prc_d_ma_shelf_payment_type_simple_monthly
	prc_d_ma_shelf_PAYMENT_TYPE_performance_monthly	;
请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.

-- 李世龙 已完成
环境:实例1
要删除的表: 
	feods.zs_order;
要删除的存储过程:
	sh_zs_order_users
请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.


-- 纪伟铨 已完成
环境:实例1
要删除的表: 
    feods.d_ma_marketing_data_hourly  prc_d_ma_marketing_data_hourly  无影响
要删除的存储过程:
   prc_d_ma_marketing_data_hourly
请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.


-- 李世龙 已完成
环境:实例1
#表
feods.fjr_order_and_item_last30;
feods.fjr_order_and_item_last_week;
#存储过程
sp_order_and_item_lastxx_week;  sp_order_and_item_lastxx_week 无影响

请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.



-- 纪伟铨 已完成
环境:实例1
#表
feods.d_ma_stock_satisfaction_monthly;   prc_d_ma_stock_satisfaction_monthly 无影响
feods.d_ma_paytype_performence_daily;    prc_d_ma_paytype_performence_daily  无影响
#存储过程
prc_d_ma_paytype_performence_daily;
prc_d_ma_stock_satisfaction_monthly;

请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.


-- 纪伟铨 已完成
环境:实例1
#要删除的表
feods.zs_users;                     sh_zs_users_yuki                sh_zs_order_users_by_tyq  无影响
feods.zs_shelf_curmonth_sale_yuki;  sh_shelf_curmonth_sale_yuki     已停止
feods.D_M_SHELF_SALE_KPI;           sp_D_M_SHELF_SALE_KPI           已停止
feods.tmp_user_shelf;   
#要删除的存储过程
sh_zs_users_yuki
sh_shelf_curmonth_sale_yuki
sp_D_M_SHELF_SALE_KPI

请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.


-- 李世龙  已完成
环境:实例1
#表
feods.zs_qzc_queh_shelf_lv;
#存储过程
sh_qzc_queh_shelf_lv;   zs_qzc_queh_shelf_lv 

请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.



    #实例2迁移表:
    select * from test.dm_ma_coupon_use_stat_daily;  
    call test.dm_ma_coupon_use_stat_daily( ); #每天一次
	
	prc_d_ma_coupon_use_stat_daily  每日 05：23  结果表数据 6481  feods.d_ma_coupon_use_stat_daily   -- dm_ma_coupon_use_stat_daily   因为用到fe_dwd.dwd_sf_coupon_use 表增量同步，数据可能存在异常 已处理
	
	select * from feods.d_ma_coupon_use_stat_daily; 实例1的表是这个 字段有点区别 @唐进
	
	
sp_op_product_area_disrate  每日 05:06 耗时 1min -- dm_op_product_area_disrate_two  测试ok  （李世龙） 已完成
无需同步结果表数据  

sp_product_list_manager_week  每周一 06:17 耗时5min -- dm_op_product_list_manager_week  测试ok （李世龙） 已完成
结果表 feods.fjr_product_list_manager_week 488738 需同步历史数据   truncate table fe_dm.dm_op_product_list_manager_week;


sp_abnormal_package   每日04:51 耗时1分钟      -- dm_op_abnormal_package_product_two  测试ok （李世龙） 已完成
feods.fjr_abnormal_package         121125    truncate table fe_dm.dm_op_abnormal_package;
feods.fjr_abnormal_package_product 10358165  truncate table fe_dm.dm_op_abnormal_package_product;


-- 修改json文件 已完成
fe_to_dwd_erp 同步任务的一个json文件：user_member_wallet_log.json ，替换原因： 没有写入数据库
fe_to_dwd_erp 同步任务的一个json文件：sf_shelf_goods_transfer.json，替换原因： 没有写入数据库
dwd_order_item_refund_real_time_erp同步任务的一个json文件：sf_after_payment.json ，替换原因： 没有写入数据库
fe_to_dwd_erp 同步任务的一个json文件：sf_prize_record.json ，替换原因： 模式设置为replace
fe_to_dwd_erp 同步任务的一个json文件：sf_shelf_manager_score_detail.json ，替换原因： 模式设置为replace
fe_to_dwd_erp 同步任务的一个json文件：sf_shelf_slot_stock_record.json，替换原因： 模式设置为replace
fe_to_dwd_erp 同步任务的一个json文件：sf_shelf_machine_online_status_record.json，替换原因： 模式设置为replace
fe_to_dwd_erp 同步任务的一个json文件：sf_shelf_scope_detail.json，替换原因： 模式设置为replace

-- 重新同步 已完成
fe_activity.sf_prize_record                         数据量：  300万
fe.sf_shelf_scope_detail                            数据量：  220万
fe.sf_shelf_manager_score_detail                    数据量：  150万
fe_ana_data.sf_shelf_machine_online_status_record   数据量：  280万



prc_dm_ma_shelf_RedPacket  -- dm_ma_shelf_red_packet  已完成
#实例2 迁移
truncate fe_dm.dm_ma_shelfRedPacket_shelf;
truncate fe_dm.dm_ma_shelfRedPacket_activity;
truncate fe_dm.dm_ma_shelfRedPacket_activity_compare3week;
call test.dm_ma_shelf_red_packet(subdate(current_date,if(dayofweek(current_date)=1,6,dayofweek(current_date)-2)+4)); # 每周一运行一次 


dm_ma_coupon_use_stat_daily 已完成

#实例2迁移表:
select * from test.dm_ma_coupon_use_stat_daily;  
call test.dm_ma_coupon_use_stat_daily( ); #每天一次

prc_d_ma_coupon_use_stat_daily  每日 05：23  结果表数据 6481  feods.d_ma_coupon_use_stat_daily  ---------------------------------------------- 此处以上未映射



sp_avgqty_fill_dayst  每日 04:43 耗时0.4分钟             -- dm_op_avgqty_fill_dayst_stat_two 测试ok  每日 04:53 李世龙 已完成
需要同步历史数据  
feods.fjr_avgqty_fill_dayst      44702471   sdate>='2020-01-01'  先同步2020年数据，数据量650多万   truncate table fe_dm.dm_op_avgqty_fill_dayst;
feods.fjr_avgqty_fill_dayst_stat 2043322       truncate table fe_dm.dm_op_avgqty_fill_dayst_stat;


sp_area_product_stock_rate  每日 04:48 耗时1.4分钟    -- dm_op_area_product_stock_rate  测试ok 李世龙 已完成
需要同步历史数据
feods.fjr_area_product_stock_rate   2674236         truncate table  fe_dm.dm_op_area_product_stock_rate;


sp_shelf_product_price_tag  每日 06:07 耗时1.3分钟   -- dwd_shelf_product_price_tag   李世龙 测试ok 已完成
不需要同步历史数据
feods.fjr_shelf_product_price_tag         truncate table  fe_dwd.dwd_shelf_product_price_tag;


sf_new_product_gmv(); 可以部署了   每日 04:51 耗时0.1分钟    -- 吴婷 dm_new_product_gmv 测试ok 已完成
feods.zs_new_product_gmv    520396   truncate table fe_dm.dm_new_product_gmv;


truncate table fe_dm.dm_new_product_gmv;
truncate table  fe_dm.dm_op_area_product_stock_rate;
truncate table fe_dm.dm_op_avgqty_fill_dayst;
truncate table fe_dm.dm_op_avgqty_fill_dayst_stat;



-- sp_area_product_month 每月1号 07：15 耗时10分钟    dm_op_area_product_stat_month  测试ok
结果表 feods.fjr_area_product_month  175970          truncate table  dm_op_area_product_stat_month;



-- sp_kpi2_area_product_satrate 每日05：10 耗时2分钟   dm_op_kpi2_area_product_satis_rate 测试ok
结果表
select count(1) from feods.fjr_kpi2_area_product_satrate    union all        fe_dm.dm_op_kpi2_area_product_satis_rate 
select count(1) from feods.fjr_kpi2_monitor                 union all        fe_dm.dm_op_kpi2_monitor
select count(1) from feods.fjr_kpi2_monitor_area  ;                          fe_dm.dm_op_kpi2_monitor_area


-- sp_kpi2_area_top10_uprate_month 每月13号 05：31 耗时0.4分钟   dm_op_kpi2_area_top10_uprate_month 测试ok
fjr_kpi2_area_top10_uprate_month 9990             dm_op_kpi2_area_top10_uprate_month
fjr_kpi2_monitor_area  41754
fjr_kpi2_monitor  1175


-- sp_kpi2_area_top10_uprate_week 每周一  05：00 耗时 2分钟      call sh_process.dm_op_kpi2_area_top10_uprate_week(SUBDATE(CURRENT_DATE,WEEKDAY(CURRENT_DATE)+1)); 测试ok

feods.fjr_kpi2_area_top10_uprate_week  48470   dm_op_kpi2_area_top10_uprate_week
feods.fjr_kpi2_monitor_area  41754
feods.fjr_kpi2_monitor  1175

-- sp_kpi2_new_out_storate  每日04：52 耗时0.8分钟    dm_op_kpi2_product_new_out_sto_rate   测试ok

fjr_kpi2_new_out_storate  4430925    dm_op_kpi2_product_new_out_sto_rate
fjr_kpi2_monitor_area  41754
fjr_kpi2_monitor  1175


-- sp_kpi2_np_success_rate_month  每月1号 05：30 耗时0.3分钟    dm_op_kpi2_np_success_rate_month 测试ok
fjr_kpi2_np_success_rate_month  4706    dm_op_kpi2_np_success_rate_month
fjr_kpi2_monitor_area  41754
fjr_kpi2_monitor  1175


-- sp_kpi2_outlet_rate   每日05：44 耗时0.3      dm_op_kpi2_outlet_rate 测试ok

fjr_kpi2_outlet_rate  2518454  dm_op_kpi2_outlet_rate
fjr_kpi2_monitor_area  41754
fjr_kpi2_monitor  1175

 
-- sp_kpi2_sale_vs_stock_month  每月1号 06：00 耗时4.4   dm_op_kpi2_sale_vs_stock_month  测试ok
fjr_kpi2_sale_vs_stock_month 98687   dm_op_kpi2_sale_vs_stock_month
fjr_kpi2_monitor_area  41754
fjr_kpi2_monitor  1175
sp_unstock_detail_week

truncate table fe_dm.dm_op_area_product_stat_month           ;
truncate table fe_dm.dm_op_kpi2_sale_vs_stock_month          ;
truncate table fe_dm.dm_op_kpi2_outlet_rate                  ;
truncate table fe_dm.dm_op_kpi2_np_success_rate_month        ;
truncate table fe_dm.dm_op_kpi2_product_new_out_sto_rate     ;
truncate table fe_dm.dm_op_kpi2_area_top10_uprate_week       ;
truncate table fe_dm.dm_op_kpi2_area_top10_uprate_month      ;
truncate table fe_dm.dm_op_kpi2_area_product_satis_rate      ;


#实例1目标表字段  纪伟铨 每周一
select * from test.dm_ma_users_all_weekly ;
#实例1存储过程
    #新增
call sh_process.dm_ma_users_all_weekly(current_date);

-- dm_op_fill_type_monitor 英南新增任务部署



dm_op_area_product_stat_month      
dm_op_kpi2_sale_vs_stock_month     
dm_op_kpi2_outlet_rate             
dm_op_kpi2_np_success_rate_month   
dm_op_kpi2_product_new_out_sto_rate
dm_op_kpi2_area_top10_uprate_week  
dm_op_kpi2_area_top10_uprate_month 
dm_op_kpi2_area_product_satis_rate 
dm_op_fill_type_monitor


#世龙执行操作
alter table feods.zs_shelf_member_flag_history rename test.zs_shelf_member_flag_history; #保留一周后删除
alter table test.user_flag_jwq rename feods.zs_shelf_member_flag_history ;

唐进把实例2 的同步任务以及 表结构相应更改 feods.zs_shelf_member_flag_history  @唐进


-- 李世龙
sp_op_ds7p_sal_fil    每日02：14           dm_op_ds7p_sal_fil   测试ok 每日 02：21 执行一次  已完成
需同步历史数据
feods.d_op_ds7p_sal_fil  2585439  -- fe_dm.dm_op_ds7p_sal_fil

-- 李世龙
sp_op_shelf7_area_product_sale   每日 05：19         dm_op_shelf7_area_product_sale_day_three  测试ok 已完成
需同步历史数据
select count(1) from feods.d_op_shelf7_area_product_sale_day   union all       fe_dm.dm_op_shelf7_area_product_sale_day
select count(1) from feods.d_op_shelf7_area_product_sale_week  union all       fe_dm.dm_op_shelf7_area_product_sale_week
select count(1) from feods.d_op_shelf7_area_product_sale_month     ;           fe_dm.dm_op_shelf7_area_product_sale_month

-- 宋英南 新增任务 测试ok
dm_op_fill_gmv_change_monitor 已完成

ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `is_test`  INT(2) NULL DEFAULT '0' COMMENT '是否测试白名单(1为测试的货架)' AFTER `type_name`; 已完成

ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `shelf_tag`  TINYINT(1) NULL DEFAULT '1'  COMMENT '货架标签 字典名:virtualShelfTag(1:自贩机未对接、2:智能柜未对接、3:采购促销货架、4:地区清理货架)' AFTER `is_test`; 已完成

ALTER TABLE fe_dwd.`dwd_shelf_machine_info`
ADD COLUMN `machine_id`  INT(11)  NOT NULL DEFAULT '0'  COMMENT '自增主键' AFTER `template_no`; 已完成
 
-- 蔡松林的任务
sp_finance_instock_sales_outstock    每月1号 00：00 耗时 0.3分钟       dm_finance_instock_sales_outstock_two  测试ok 已完成
结果表
feods.D_MP_Lead_warehouse_temp_table_main   101898   fe_dm.dm_mp_lead_warehouse_temp_table_main
feods.D_MP_finance_statement_log   14                fe_dm.dm_mp_finance_statement_log

sp_manager_shelf_statistic_result  每日01：32 耗时0.5分钟     dm_manager_shelf_statistic_result  测试ok  已完成
结果表
feods.pj_manager_shelf_statistic_result   3756709    fe_dm.dm_manager_shelf_statistic_result


-- 吴婷
@唐进 实例2上面 test.pj_poorderlist_day 可以部署了哈
 
pj_poorderlist_day    每日04：22 耗时7分钟      dm_sc_poorderlist_day  测试ok 已完成
结果表
feods.pj_poorderlist_day         68819          dm_sc_poorderlist_day
feods.d_sc_warehouse_onload 无需同步历史数据    dm_sc_warehouse_onload



需先同步 sf_shelf_logistics_task_change 2000 和 sf_shelf_logistics_task 66687 表，这周完成
dwd_sf_shelf_logistics_task  已完成
dwd_sf_shelf_logistics_task_change 已完成


-- sp_kpi2_sale_vs_stock_week   每周1 05:00  7.1   dm_op_kpi2_sale_vs_stock_week  测试ok 已完成
call sh_process.sp_kpi2_sale_vs_stock_week(subdate(current_date,weekday(current_date)+1));
fjr_kpi2_sale_vs_stock_week 282886  dm_op_kpi2_sale_vs_stock_week
其中脚本里面的
fjr_kpi2_monitor_area         dm_op_kpi2_monitor_area   
fjr_kpi2_monitor              dm_op_kpi2_monitor        
这两个表需要注意一下，是否有其它的表对它进行更新


sp_op_shelf7_area_product_stat  每日05：18 耗时1.2分钟  dm_op_shelf7_area_product_stat  测试ok 已完成
结果表
feods.d_op_shelf7_area_product_stat   无需同步历史数据       dm_op_shelf7_area_product_stat


sp_op_slot_his    每日04：16 耗时0.2分钟       dm_op_slot_his_three   测试ok 已完成
结果表
feods.d_op_s7p_detail  无需同步历史数据       fe_dm.dm_op_s7p_detail
feods.d_op_slot_his   29843294        sdate>='2020-04-01'  850万      fe_dm.dm_op_slot_his
feods.d_op_s7p_nslot  162202                  fe_dm.dm_op_s7p_nslot


    CALL test.sh_dynamic_weighted_purchase_price()；  
	
	唐进好：
   麻烦在实例2上部署一下存储过程，详见test库：
    CALL test.sh_dynamic_weighted_purchase_price()； sh_dynamic_weighted_purchase_price 每日05：17 执行一次 测试ok  dm_sc_current_dynamic_purchase_price_two 已完成
	
	同步 feods.wt_monthly_manual_purchase_price 121756

  涉及到结果表 fe_dm.`dm_sc_current_dynamic_purchase_price`，之前是直接同步实例1结果，需要调整一下同步计划。
  停止datax同步任务 dm_sc_current_dynamic_purchase_price_erp
  
------------------------------------------------------- 2020-05-20 
  sf_shelf_smart_log(3704943)  sf_operate_result (218356)   同步到实例2  已完成
  
  dm_op_offstock_not_push_order  英南新增 测试ok   已完成
  
  dm_op_area_out_product_purchase 朱星华新增 测试ok 已完成
  
--  sh_shelf_machine_slot  每日 02：22 耗时 13分钟        dwd_shelf_machine_slot_history  测试ok   已完成
 结果表需同步
 feods.zs_shelf_machine_slot_history    1316593     truncate table fe_dwd.dwd_shelf_machine_slot_history
 feods.zs_shelf_machine_sale_total  世龙反馈不同步 实例2无对应表
  
-- sp_kpi3_shelf7  每日05：37 耗时 10秒钟  dm_op_kpi3_shelf7_nine  测试ok  已完成
结果表
feods.fjr_kpi3_shelf7_fill_nday        (数据量： 133694 )     truncate table  fe_dm.dm_op_kpi3_shelf7_fill_nday        ;
feods.fjr_kpi3_shelf7_monitor          (数据量： 11448  )     truncate table  fe_dm.dm_op_kpi3_shelf7_monitor          ;
feods.fjr_kpi3_shelf7_shelf_sale_day   (数据量： 287673 )     truncate table  fe_dm.dm_op_kpi3_shelf7_shelf_sale_day   ;
feods.fjr_kpi3_shelf7_shelf_sale_month (数据量： 12887  )     truncate table  fe_dm.dm_op_kpi3_shelf7_shelf_sale_month ;
feods.fjr_kpi3_shelf7_shelf_sale_week  (数据量： 51546  )     truncate table  fe_dm.dm_op_kpi3_shelf7_shelf_sale_week  ;
feods.fjr_kpi3_shelf7_shelf_stat_day   (数据量： 582931 )     truncate table  fe_dm.dm_op_kpi3_shelf7_shelf_stat_day   ;
feods.fjr_kpi3_shelf7_shelf_stat_month (数据量： 19372  )     truncate table  fe_dm.dm_op_kpi3_shelf7_shelf_stat_month ;
feods.fjr_kpi3_shelf7_shelf_stat_week  (数据量： 84071  )     truncate table  fe_dm.dm_op_kpi3_shelf7_shelf_stat_week  ;
feods.fjr_kpi3_shelf7_shelf_stock_his  (数据量： 582775 )     truncate table  fe_dm.dm_op_kpi3_shelf7_shelf_stock_his; 

  
-- sp_kpi3_shelf7_current 每日05：37 耗时10秒钟   dm_op_kpi3_shelf7_current_four  测试ok 已完成
结果表
feods.fjr_kpi3_shelf7_monitor           (数据量： 11448   )          truncate table fe_dm.dm_op_kpi3_shelf7_monitor           ;
feods.fjr_kpi3_shelf7_shelf_stock_day   (数据量： 1607767 )          truncate table fe_dm.dm_op_kpi3_shelf7_shelf_stock_day     ;
feods.fjr_kpi3_shelf7_slot_sale_day     (数据量： 156256  )          truncate table fe_dm.dm_op_kpi3_shelf7_slot_sale_day     ;
feods.fjr_kpi3_shelf7_slot_stock_day    (数据量： 701563  )          truncate table fe_dm.dm_op_kpi3_shelf7_slot_stock_day   ;
  

-- sp_kpi3_shelf7_stosal  每日05：37 耗时10秒钟    dm_op_kpi3_shelf7_stosal_four 测试ok 已完成
结果表
feods.fjr_kpi3_shelf7_monitor                                   truncate table fe_dm.dm_op_kpi3_shelf7_monitor                   ;
feods.fjr_kpi3_shelf7_product_sale_stock_day     (数据量： 396069 )        truncate table fe_dm.dm_op_kpi3_shelf7_product_sale_stock_day    ;
feods.fjr_kpi3_shelf7_product_sale_stock_month   (数据量： 13389  )        truncate table fe_dm.dm_op_kpi3_shelf7_product_sale_stock_month  ;
feods.fjr_kpi3_shelf7_product_sale_stock_week    (数据量： 57666  )        truncate table fe_dm.dm_op_kpi3_shelf7_product_sale_stock_week   ;


-- sp_op_machine_online  每日01：39 耗时 8分钟         dm_op_machine_online_three 测试ok  耗时8分钟 已完成
结果表  不用同步历史数据
feods.d_op_machine_online_detail 2166690         truncate table fe_dm.dm_op_machine_online_detail  ;
feods.d_op_machine_online_shelf  4659            truncate table fe_dm.dm_op_machine_online_shelf   ;
feods.d_op_machine_online_stat   2951499         truncate table fe_dm.dm_op_machine_online_stat    ;


 
-- sp_slot_change_record  每日00：47开始执行 每隔一个小时执行一次 耗时2秒钟     dm_op_slot_change_record_two     测试ok 已完成
结果表
feods.d_op_shelf_machine_slot   无需同步      truncate table fe_dm.dm_op_shelf_machine_slot     ;
feods.d_op_slot_change_record    242407       truncate table fe_dm.dm_op_slot_change_record     ;


  
-- 已停止调度
'sh_fill_requirement_history',
'sh_inventory_filling_ratio',
'sh_loss_value_total',
'sh_new_shelf_risk_manage',
'sh_vending_machine_history'


-- 尼和的这个存储过程， prc_d_en_gross_margin_rate_order 每日00：36  直接同步结果表过去。我已经建好表了  无任务依赖 每日全量同步  已完成
select count(1) from feods.d_en_gross_margin_rate_user_month   union all 
select count(1) from feods.d_en_gross_margin_rate_order_month  union all
select count(1) from feods.d_en_gross_margin_rate_user_week    union all
select count(1) from feods.d_en_gross_margin_rate_order_week  ;

260
266
1143
1145


select count(1) from fe_dm.dm_en_gross_margin_rate_user_month  union all
select count(1) from fe_dm.dm_en_gross_margin_rate_order_month union all
select count(1) from fe_dm.dm_en_gross_margin_rate_user_week   union all
select count(1) from fe_dm.dm_en_gross_margin_rate_order_week  ;



-- prc_d_en_order_user 每日 00：02 这个也直接同步结果过去。我建好表了。尼和那边的，基本不好替换 已完成
select count(1) from feods.sf_third_user_balance_day union all   # 增量同步 同步sdate = T-1 6千的数据量
select count(1) from feods.d_en_new_user_balance     union all     
select count(1) from feods.d_en_user_channle_first   union all   d_en_user_channle_first  -- 每日全量更新数据，所以全量同步
select count(1) from feods.d_en_order_user           ;

2544155
77465
379320
341672

select count(1) from fe_dm.dm_pub_third_user_balance_day   union all 
select count(1) from fe_dm.dm_en_new_user_balance          union all
select count(1) from fe_dm.dm_en_user_channle_first        union all
select count(1) from fe_dm.dm_en_order_user                ;


-- sp_shelf_board 每日05：04  耗时 7分钟 同步结果表 已完成
select count(1) from feods.fjr_shelf_board        union all dm_pub_shelf_board   fjr_shelf_board  -- 每日全量更新数据，所以全量同步
select count(1) from feods.d_op_shelf_board_month union all dm_pub_shelf_board_month
select count(1) from feods.d_op_shelfs_dstat      union all dm_pub_shelfs_dstat
select count(1) from feods.d_op_shelfs_area       ;         dm_pub_shelfs_area  -- 数据量小 全量同步


49779
284625
88694
9373


-- prc_d_en_fx_new_user_daily_balance  每日 00：12 耗时1分钟 同步结果表 已完成
select count(1) from feods.d_en_fx_balance                  union all      #先同步add_time>='2020-05-01' -- pid=60129322 数据过去，数据量1000万
select count(1) from feods.d_en_fx_daily_num_user_balance   union all
select count(1) from feods.d_en_fx_new_user_daily_balance ;

64819880
213
200074

select count(1) from fe_dm.dm_en_fx_balance                  union all
select count(1) from fe_dm.dm_en_fx_daily_num_user_balance   union all
select count(1) from fe_dm.dm_en_fx_new_user_daily_balance   ;


-- prc_d_ma_tag_num  每日00：29  这个直接同步结果表。我已经建好表了 已完成
d_ma_tag_num	1602  dm_ma_tag_num 每日全量更新数据，所以全量同步


-- prc_d_en_org_area 每日 03：45 耗时6.5分钟 这个也直接同步结果表吧 已完成
d_en_org_area	122184 dm_en_org_area  每日全量更新数据，所以全量同步




-- d_op2_shelf_grade              每日04：12 耗时 10秒钟    朱星华     dm_pub_shelf_grade 测试ok  结果表无需同步，待该任务部署后，停止datax同步任务  d_op_shelf_grade_erp   
-- d_op_type_revoke_close_day     每日00：14 耗时3秒钟  需同步历史数据 dm_op_type_revoke_close_day 测试ok  李吹防
-- d_op_type_revoke_active_num    每日07：55  需同步历史数据  dm_op_type_revoke_active_num 测试ok  李吹防
-- d_op2_shelf_day_avg_gmv        每日03：06 耗时约1分钟 需同步历史数据 dm_shelf_day_avg_gmv  测试ok 朱星华
-- d_op_sp_avgsal7                每日09：45 耗时10秒钟   每天全量更新 无需同步历史数据  dm_op_sp_avgsal_recent_week   测试ok 朱星华  
-- op_shelf_week_product_stock_detail_tmp  每周一 03：22 无需同步历史数据    dm_op_shelf_week_product_stock_detail_tmp 测试ok 朱星华
-- d_op_shelf_type_product_sale 每周一09：40 耗时小于1分钟 需同步历史数据      dm_op_shelf_type_product_sale  测试ok  朱星华
-- d_op_shelf_active_week       每日03：27 耗时10秒 需同步历史数据   dm_op_shelf_active_week  测试ok  朱星华

-- d_op_shelf_type_flag         每日03：57 耗时1分钟   dm_op_shelf_type_flag  暂时不迁移 有问题

例2 dm_op_tot_stat 和 dm_op_effective_stock 这两个表数据清空后，再从实例1重新同步过去。

dm_op_effective_stock_two  每日05：52执行一次    测试ok  -- sp_op_effective_stock  03:17每日
   fe_dm.dm_op_tot_stat       -- feods.d_op_tot_stat  (数据量：11600996)
   d_op_effective_stock



实例1迁移
#删除表
select count(1) from feods.d_ma_coupon_use_stat_daily union all 
select count(1) from feods.d_op_shelfs_area_areaversion union all
select count(1) from feods.d_op_shelfs_dstat_areaversion union all
select count(1) from feods.d_ma_shelf_sale_2week union all
select count(1) from feods.dm_ma_shelfRedPacket_shelf union all
select count(1) from feods.dm_ma_shelfRedPacket_activity union all
select count(1) from feods.dm_ma_shelfRedPacket_activity_compare3week ;

#删除存储过程
'prc_d_ma_coupon_use_stat_daily',
'sp_op_shelfs_dstat_areaversion',
'prc_d_ma_shelf_sale_2week',
'prc_dm_ma_shelf_RedPacket'
;

请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例1上删除存储过程,再告知李世龙删除相应的表.



实例1迁移
#删除表
select count(1) from feods.d_ma_user_daily union all
select count(1) from feods.d_ma_user_weekly union all
select count(1) from feods.d_ma_user_monthly ;
#删除存储过程
# prc_d_ma_user_stat

请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例1上删除存储过程,再告知李世龙删除相应的表.




唐进好：

     实例1上有2个表，需要先同步到实例2上：

1、实例1上表： sp_d_sc_shelf_package  每日 04：55 耗时1分钟 已完成
feods.d_sc_shelf_packages          1768853  每日全量更新  全量同步 d_sc_shelf_packages   dm_sc_shelf_packages
feods.d_sc_shelf_packages_onsale   509401     dm_sc_shelf_packages_onsale
feods.d_op_sp_avgsal30     1655204   sp_op_sp_avgsal30  每日03：21 耗时1分钟  每日全量更新 所以全量同步  dm_op_sp_avgsal30 已完成
2、同步之后将实例2:  test.sp_d_sc_warehouse_preware_stock_outbound 部署，再将结果表从实例1同步到实例2。 已完成
3、可部署 sp_warehouse_product_presence  已完成

-- sp_d_sc_warehouse_preware_stock_outbound 每日 07:52  耗时0.4分钟  dm_sc_warehouse_sku_shelf_cnt_two 依赖 dm_warehouse_product_presence 已完成
结果表：
feods.d_sc_warehouse_preware_stock_outbound  1178215         dm_sc_warehouse_preware_stock_outbound
feods.d_sc_warehouse_sku_shelf_cnt  8930                     dm_sc_warehouse_sku_shelf_cnt


-- sp_warehouse_product_presence   "07:28"	"每日"	"0.2"  dm_warehouse_product_presence  测试ok  已完成
feods.pj_warehouse_product_presence   fe_dm.dm_warehouse_product_presence   数据量： 247万



feods.d_op_sp_stock_detail-->  fe_dwd.dwd_shelf_product_stock_detail,     未完成 每日00：31执行一次；         先同步2020-05 （含）之后的数据
feods.d_op_sp_stock_detail_after--> fe_dwd.dwd_shelf_product_stock_detail_after 未完成  每日02：41执行一次；  先同步2020-05 （含）之后的数据
这两个表同步一下。实例1的数据量较大。周一我们讨论一下

SELECT COUNT(1) FROM feods.d_op_sp_stock_detail         -- 43773068
SELECT COUNT(1) FROM feods.d_op_sp_stock_detail_after   -- 44035004

sh_zs_user_week_sale 和 pj_city_unsalable_his  这个存储过程有处理过吗？

sserp.T_STK_STKTRANSFERAPP          dwd_sserp_t_stk_stktransferapp 341 
sserp.T_STK_STKTRANSFERAPPENTRY     dwd_sserp_t_stk_stktransferappentry  3237 
sserp.T_STK_STKTRANSFERAPPENTRY_E   dwd_sserp_t_stk_stktransferappentry_e 3237
@李世龙 @唐进 erp还有2个表需要同步过来  已完成

fe.`sf_shelf_product_supply_info` 99556 --> fe_dwd.`dwd_sf_shelf_product_supply_info` 已完成

call test.dm_ma_user_weekly('2020-5-11');  (纪委铨） 已完成


数据表：  feng1.T_PUR_PRICELISTENTRY （价目表明细） 已完成
数据表：  feng1.T_PUR_PRICELIST  （价目表） 已完成


test.dm_ma_shelf_sale_weekly@唐进 更换实例2的存储过程
test.dm_ma_shelf_sale_daily 这个也要更新@唐进
test.dm_ma_shelf_sale_daily  我的锅 刚才没搞对 现在还得实例2再更新一次




@唐进 @李世龙   sserp.T_PUR_PRICELIST  和sserp.T_PUR_PRICELISTENTRY 也同步一下到实例2哈

sserp.T_PUR_PRICELIST  --> fe_dwd.dwd_sserp_t_pur_pricelist

sserp.T_PUR_PRICELISTENTRY  --> fe_dwd.dwd_sserp_t_pur_pricelistentry


ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `VALID_CHANCE`  int(2) NULL DEFAULT '1'  COMMENT '有效商机(1:有效、2:无效)' AFTER `REVOKE_TIME`;


test.sp_d_mp_shelf_monitor ，这个等世龙增加了我刚才说的字段之后，你就给我部署下这个哈

唐进，帮我更新一下实例2中的 test.sp_d_sc_preware_daily_report 已完成
test.sh_preware_outbound_fill 这个也修改一下哈 已完成

-- 蔡松林的任务
sp_D_LO_campus_manager_level  每日02：13    -- dm_lo_campus_manager_level 测试ok
需同步历史数据
feods.D_LO_campus_manager_level (数据量：2188)  -- fe_dm.dm_lo_campus_manager_level


-- 吴婷的任务
sp_d_mp_shelf_monitor  每日00：30      -- dm_mp_shelf_stat_monitor  测试ok
需同步历史数据
结果表 feods.d_mp_shelf_monitor  (数据量： 11840)      -- fe_dm.dm_mp_shelf_stat_monitor


-- 李世龙任务
sp_kpi_area_product_sat_rate_week  每周一 03：15 耗时4分钟    -- dm_op_kpi_area_product_sat_rate 测试ok
需同步历史数据
feods.fjr_kpi_area_product_sat_rate  (数据量： 92966)   -- fe_dm.dm_op_kpi_area_product_sat_rate

sp_kpi_np_flag5_sto    每日05：53 耗时2分钟       -- dm_op_kpi_np_flag5_sto  测试ok
需同步历史数据
feods.fjr_kpi_np_flag5_sto  (数据量： 823190) -- fe_dm.dm_op_kpi_np_flag5_sto


sp_kpi_np_gmv_week  每周一 01：20 耗时2分钟   -- dm_op_kpi_np_gmv_week_three  测试ok
需同步历史数据
feods.fjr_kpi_np_gmv_week        (数据量： 39257)  -- select count(1) from truncate table fe_dm.dm_op_kpi_np_gmv_week     ; union all
feods.fjr_kpi_np_sal_sto_week    (数据量： 41228)  -- select count(1) from truncate table fe_dm.dm_op_kpi_np_sal_sto_week ; union all
feods.fjr_kpi_gmv_week           (数据量： 3304)  -- select count(1) from truncate table fe_dm.dm_op_kpi_gmv_week        ;  ;


sp_kpi_np_out   每日02：28 耗时1分钟   -- dm_op_kpi_np_out_week  测试ok
需同步历史数据
feods.fjr_kpi_np_out_week    (数据量： 215024)   -- dm_op_kpi_np_out_week

sp_kpi_sto_val_rate  每日05：52            -- dm_op_kpi_sto_val_rate   测试ok
需同步历史数据
feods.fjr_kpi_sto_val_rate   (数据量： 2452432)     -- fe_dm.dm_op_kpi_sto_val_rate


sp_op_smart_log   每日01：37      -- dm_op_smart_log       测试ok
无需同步历史数据
feods.d_op_smart_log    -- fe_dm.dm_op_smart_log


sp_price_sensitive_stat_month  每月1号 06：50     -- dm_op_price_sensitive_stat_month  测试ok
需同步历史数据
feods.fjr_price_sensitive_stat_month   (数据量： 90071)  -- fe_dm.dm_op_price_sensitive_stat_month


sp_price_sensitive_stat_month_nation  每月1号 06：51    -- dm_op_price_sensitive_stat_month_nation  测试ok
需同步历史数据
feods.fjr_price_sensitive_stat_month_nation    (数据量： 19676)      -- fe_dm.dm_op_price_sensitive_stat_month_nation

sh_zs_user_week_sale  每周一 01：55          -- dm_user_week_sale  测试ok
需同步历史数据
feods.zs_user_week_sale     (数据量： 22003265,  sdate>='2019-12-01' 数据量 772万)    -- fe_dm.dm_user_week_sale


call test.dm_ma_shelf_paytype_sale_daily(curdate(),1);  已完成
call test.dm_ma_shelf_paytype_sale_monthly(subdate(curdate(),1));修改存储过程  已完成



fe_dm.dm_user_suspect  2286 -- fe_dm.dm_user_suspect 


dm_op_shelf_product_fill_suggest_label 表名





实例1迁移
#删除表
select * from feods.d_ma_shelf_user_stat;

#删除存储过程
# prc_d_ma_shelf_user_stat


实例1
#删除表
select * from feods.d_ma_paytype_dashboard_daily;
select * from feods.d_ma_shelf_product_monitor;

#删除存储过程
# prc_d_ma_shelf_product_monitor   -- d_ma_shelf_product_monitor
# prc_d_ma_paytype_dashboard_daily   -- d_ma_paytype_dashboard_daily


实例1迁移
#迁移实例1 feods.fjr_kpi2_shelf_level_stat 到 实例2fe_dm.dm_op_kpi2_shelf_level_stat   -- -- 已完成

#删除表
select * from feods.d_ma_shelf_paytype_sale_monthly;
select * from feods.d_ma_shelf_paytype_sale_daily;
select * from feods.fjr_kpi2_shelf_level_stat;
#删除存储过程
# prc_d_ma_shelf_paytype_sale_daily
# prc_d_ma_shelf_paytype_sale_monthly
# sp_kpi2_shelf_level_stat

请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例1上删除存储过程,再告知李世龙删除相应的表.


2.请帮忙部署datax任务：（需先执行上述临时同步任务）  鑫森未处理，需反馈
1）dm_user_suspect_erp，用于每日增量同步实例1上嫌疑人短信推送表数据到实例2，同步时间：每日08：20，12：20，16：20 三个时间点各同步一次；（费航宇）
2）dwd_process_aim_table_for_check_erp，用于每日全量同步实例1上表的相关字段统计信息到实例2，同步时间：每日14：00同步一次；

   麻烦在实例2中部署，
（1）test.`sp_d_mp_daily_shelf_stock_stag` 
（2）test.`sp_d_mp_week_kpi_monitor`


sp_d_mp_daily_shelf_stock_stag  每日04：17                      dm_mp_daily_shelf_stock_stag_two  测试ok  吴婷 -- 已完成
 
feods.d_mp_daily_shelf_stock_stag_detail  无需同步历史数据      fe_dm.dm_mp_daily_shelf_stock_stag_detail
feods.d_mp_daily_shelf_stock_stag   需要同步历史数据  212   fe_dm.dm_mp_daily_shelf_stock_stag

sp_d_mp_week_kpi_monitor  每周五04：32     dm_mp_week_kpi_monitor  测试ok 吴婷  缺这个表 fe_dwd.dwd_shelf_product_stock_detail 的同步 -- 已完成

CALL sp_d_mp_week_kpi_monitor(DATE_SUB(CURDATE(),INTERVAL 1 DAY));

feods.d_mp_week_kpi_monitor   需要同步历史数据  30 fe_dm.dm_mp_week_kpi_monitor

dm_pub_area_product_stat  测试ok 部署实例1 同步实例2  李世龙  每日跑 -- 已完成


-- 星华需求
所有的表有： fe_dwd.dwd_shelf_base_day_all
所有的表有： feods.d_op_shelf_firstfill
所有的表有： fe_dwd.dwd_pub_shelf_first_order_info    -- 需要同步到实例2 每日全量同步
所有的表有： feods.d_op_sp_avgsal7
所有的表有： feods.fjr_shelf_dgmv
所有的表有： fe_dwd.dwd_op_out_of_system_order_yht
所有的表有： feods.d_op_machine_online_stat
所有的表有： feods.d_op_slot_his
所有的表有： fe_dwd.dwd_pub_order_item_recent_one_month
所有的表有： select count(1) from fe.sf_order_yht                    union all  -- dwd_sf_order_yht
所有的表有： select count(1) from fe.sf_order_yht_item               union all  -- dwd_sf_order_yht_item
所有的表有： select count(1) from fe.sf_shelf_machine_slot           union all  -- dwd_sf_shelf_machine_slot
所有的表有： select count(1) from fe.sf_shelf_machine_command_log  ;            -- dwd_sf_shelf_machine_command_log

count(1)
fe.sf_order_yht                 1665637  根据 last_update_time 取 t-1 replace    -- 已同步
fe.sf_order_yht_item            1667112  根据 last_update_time 取 t-1 replace    -- 已同步
fe.sf_shelf_machine_slot        193477   根据 last_update_time 取 t-1 replace    -- 已同步
fe.sf_shelf_machine_command_log 4196909  根据 last_update_time 取 t-1 replace    -- 已同步


唐进：
    目前实例2 dm_op_effective_stock_two 运行时间较长，经跟业务志荣沟通，最近没在使用，可以停掉，后续如果需要我再取数给业务就好了。
所以，帮忙停止实例2 dm_op_effective_stock_two 的调度任务，存储过程和表暂保留，谢谢。  -- 已完成



dwd_en_fx_distribute_consume_area_month

datax同步任务 d_op_shelf_firstfill_erp 由现在的每日02:41 调整到 每日04:11同步一次；-- 已完成

test.sh_preware_product_sale 改一下这个哈



fe_dwd.dwd_shelf_product_stock_detail

feods.d_op_sp_stock_detail-->  fe_dwd.dwd_shelf_product_stock_detail,     未完成 每日00：31执行一次；          -- 已完成
feods.d_op_sp_stock_detail_after--> fe_dwd.dwd_shelf_product_stock_detail_after 未完成  每日02：41执行一次；   -- 已完成

call sh_process.sp_op_sp_stock_detail_after(DATE_FORMAT(SUBDATE(current_date,1),'%Y-%m'));

这两个表同步一下。实例1的数据量较大。周一我们讨论一下

sp_d_mp_week_kpi_monitor  每周五04：32     dm_mp_week_kpi_monitor  测试ok 吴婷  缺这个表 fe_dwd.dwd_shelf_product_stock_detail 的同步 -- 已完成
feods.d_mp_week_kpi_monitor   需要同步历史数据  30 fe_dm.dm_mp_week_kpi_monitor

实例1迁移
#迁移实例1 feods.fjr_kpi2_shelf_level_stat 到 实例2fe_dm.dm_op_kpi2_shelf_level_stat   -- 已完成
feods.fjr_kpi2_shelf_level_stat WHERE sdate<'2020-04-09' 1.6万

所有的表有： fe_dwd.dwd_pub_shelf_first_order_info    -- 需要同步到实例2 每日全量同步

dm_op_shelf7_slot_analysis 朱星华任务部署 -- 已完成

fe_dm.dm_db_machine_shelf_gmv  这个表需要同步到实例2上一下   -- 需要同步到实例2 每日全量同步

dm_pub_area_product_stat  临时同步

sp_op_fill_day_sale_qty_erp 停止同步 feods.d_op_valid_sto_sal_day30   -- 已完成




sp_D_LO_shelf_fill_timeliness_detail  每日04：22   -- dm_lo_shelf_fill_timeliness_detail  测试ok 04：22 
结果表 feods.D_LO_shelf_fill_timeliness_detail  数据量 1333920  -- fe_dm.dm_lo_shelf_fill_timeliness_detail  1333929
select 1329441-1329129  312  4月26号正式调度



-- 实例1
-- 删除的表
select * from feods.d_ma_city_dashboard_daily; shelfnum_valid  prc_d_ma_dashboard_daily  
select * from feods.d_ma_shelf_product_temp;
select * from feods.d_ma_activity_vist_statistics;

-- 删除的存储过程
prc_d_ma_dashboard_daily;
prc_d_ma_shelf_product_temp;
prc_sync_data_d_ma_activity_vist_statistics;
请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.

sp_finance_instock_sales_outstock 调整执行时间 

csl_finance_instock_sales_outstock_table_erp   调整同步时间



ALTER TABLE fe_dwd.`dwd_order_item_refund_day`
ADD COLUMN `pay_amount_product`  INT(4) NULL DEFAULT NULL COMMENT '支付金额_商品' AFTER `PAY_AMOUNT`;


  -- 每周一凌晨1点之前跑数
  
  SET @sdate := SUBDATE(CURRENT_DATE, 1), @add_user := CURRENT_USER, @timestamp := CURRENT_TIMESTAMP;
  SET @day2m := SUBDATE(@sdate, INTERVAL 2 MONTH);

insert into TABLE fe_dwd.dwd_sf_shelf_product_weeksales_detail 
  SELECT
    t.*
  FROM
    fe.sf_shelf_product_weeksales_detail t
  WHERE t.stat_date = ADDDATE(@day2m, 6- WEEKDAY(@day2m));
  
  
  insert into TABLE fe_dwd.dwd_sf_shelf_product_weeksales_detail 
  SELECT
    t.*
  FROM
    fe.sf_shelf_product_weeksales_detail t
  WHERE t.stat_date = ADDDATE(SUBDATE(SUBDATE(CURRENT_DATE, 1), INTERVAL 2 MONTH), 6- WEEKDAY(SUBDATE(SUBDATE(CURRENT_DATE, 1), INTERVAL 2 MONTH)));  -- 11945671



-- d_op_shelf_type_flag         每日03：57 耗时1分钟   dm_op_shelf_type_flag   

feods.d_op_shelf_type_flag  98万   fe_dm.dm_op_shelf_type_flag


-- d_op_area_shelf_open_close_times   
feods.d_op_area_shelf_open_close_times     11万                -- fe_dm.dm_op_area_shelf_open_close_times
 同步 feods.pj_area_sale_dashboard    滚动结存3个月的数据  900多万
 
 
 
 
 
 
-- feods.pj_zs_goods_damaged  同步到实例2  数据量200万，每天同步数据量10万   fe_dm.`dm_goods_damaged`
  DELETE
  FROM
    feods.pj_zs_goods_damaged
  WHERE smonth = DATE_FORMAT(DATE_SUB(CURDATE(), INTERVAL 1 DAY),'%Y%m');

-- 同步 fe.`sf_shelf_apply_log` 数据量60万 每天增量同步 2000千   fe_dwd.`dwd_sf_shelf_apply_log`
SELECT COUNT(1) FROM fe.`sf_shelf_apply_log` WHERE last_update_time>=CURRENT_DATE

-- 同步 fe.sf_machines_apply_record_extend 数据量 9千 每天全量同步  fe_dwd.dwd_sf_machines_apply_record_extend

-- 朱兴华任务 dm_op_area_quality_detective  dm_op_shelf_gmv_split 部署

fe.foundation_advertion  4430         --  fe_dwd.`dwd_foundation_advertion`   全量同步
fe.foundation_advertion_position  165 --  fe_dwd.`dwd_foundation_advertion_position` 全量同步


-- 纪伟铨 实例2
    select * from test.dm_ma_usertype_sale_daily;
    call sh_process.dm_ma_usertype_sale_daily( subdate(curdate(),1)); #每天一次
	
-- 郑志省

dwd_group_activity_order_day
dwd_group_order_coupon_day


fe.sf_shelf_area_info 621 -->  fe_dwd.`dwd_sf_shelf_area_info`

dm_op_zone_new_product_gmv  --朱星华
dm_op_shelf_label_month  --朱星华



    #实例2 新建表与存储过程
    select * from test.dm_ma_user_sale_weekly ; #取代fe_dm.dm_user_week_sale(停表及存储过程)
	
    call test.dm_ma_user_sale_weekly(subdate(curdate(),1));#每周一九点前  
    #修改存储过程
    call test.dm_ma_usertype_sale_daily(subdate(curdate(),1));
	
	
	test.sp_d_sc_warehouse_balance，test.sp_d_sc_warehouse_out_record  ，已测试，麻烦跟进一下。


@李世龙 fe_dwd.dwd_sf_shelf_area_info 实例2这个同步下哈  (吴婷)


-- 实例1
-- 删除的表
select * from feods.dm_ma_shelf_kpi_weekly;
select * from feods.dm_ma_zone_fill_kpi_daily; #可以删除
select * from feods.dm_ma_zone_fill_kpi_daily_1912; #可以删除
#
-- 删除的存储过程
prc_dm_ma_shelf_kpi_weekly;
prc_dm_ma_zone_fill_kpi_daily;
prc_dm_ma_zone_fill_kpi_daily_1912;

请唐进验证并执行停止存储过程,再告知李世龙删除相应的表.


世龙、唐进：
    之前实例1迁移实例2的任务 sh_buhuo_shelf_action，已经迁移到实例2，但是实例1有伟铨的任务关联，经跟伟铨沟通后可以解除关联，所以：
1、世龙帮忙删除实例1 的两个表`pj_buhuo_shelf_action_total_history`和`zs_buhuo_shelf_action_history`；
2、唐进帮忙删除存储过程 sh_buhuo_shelf_action 和对应的调度任务。
    以上，谢谢！
	


-- 修改json文件（李世龙）
ALTER TABLE fe_dwd.`dwd_product_base_day_all`
ADD COLUMN `ADD_TIME`  DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间(sf_product.add_time)' AFTER `fname`;


-- 李世龙 吴婷
补全 feods.`d_sc_preware_daily_report` 2020年前的数据   -- 19945604

pj_prewarehouse_stock_detail 帮我查一下，实例2上这个表	fe_dm.dm_prewarehouse_stock_detail  比实例1的数据还多。看下是否是直接同步结果数据？

	
--- 星华任务部署

dwd_op_shelf6_should_start_fill_item  每周一更新并结存

先datax同步表
SELECT COUNT(1) FROM fe.sf_shelf_smart_product_template  -- 116         fe_dwd.dwd_sf_shelf_smart_product_template
SELECT COUNT(1) FROM fe.sf_product_business_area  -- 116                fe_dwd.dwd_sf_product_business_area
SELECT COUNT(1) FROM fe.sf_shelf_smart_product_template_item  -- 2950   fe_dwd.dwd_sf_shelf_smart_product_template_item


feods.d_op_fill3_detail  2292583 -- >     fe_dm.dm_op_fill3_detail  每天增量更新
  DELETE 
  FROM
    feods.d_op_fill3_detail 
  WHERE fill_time >= @sub_day 
    AND fill_time < @sdate ;
	
feods.d_op_shelf_info    106610 -- >      fe_dm.dm_op_shelf_info  每天全量更新

feods.d_op_shelf_info_month 901307 同步一次历史数据   -- fe_dm.dm_op_shelf_info_month  dm_op_shelf_info_month任务部署（李世龙）

-- 补全2019年12月份1-10号数据 （已完成）
SELECT COUNT(1) FROM fe_dwd.dwd_shelf_product_day_east_his_2019_12  UNION ALL
SELECT COUNT(1) FROM fe_dwd.dwd_shelf_product_day_west_his_2019_12  UNION ALL
SELECT COUNT(1) FROM fe_dwd.dwd_shelf_product_day_north_his_2019_12  UNION ALL
SELECT COUNT(1) FROM fe_dwd.dwd_shelf_product_day_south_his_2019_12 ;

COUNT(1)
29232582
27267822
38080487
28283688

-- 星华任务部署
dm_op_out_product_sto_and_sale

修改货架等级任务时间 星华实例2任务时间 gitlab操作规范邮件发给大家

-- dm_op_shelf_offstock_loss 英南任务 每日 06:53执行
-- dm_lo_zone_daily_data 汤云峰任务

feods.d_op_sp_sal_sto_detail          46522482 -->fe_dm.dm_op_sp_sal_sto_detail                          每日03：25之后同步
fe_dwd.dwd_shelf_product_last_status  7802589 -->fe_dwd.dwd_shelf_product_last_status 只同步一次
feods.fjr_shelf_archives  -- 107803 -- >fe_dm.`dm_pub_shelf_archives` 这个表同步到实例2.每天全量更新的。 每日05：25之后同步
feods.fjr_newshelf_stat   -- 456215 -- >fe_dm.`dm_op_newshelf_stat` 增量更新近两天的数据                 每日04：50之后同步
feods.d_op_sp_sal_sto_detail


  DELETE
  FROM
    feods.fjr_newshelf_stat
  WHERE sdate = @sdate;

zs_shelf_machine_sale_total：自动贩卖机总销售概况；zs_shelf_machine_slot_history：贩卖机货道库存近7天截存

停止datax同步任务  d_op_shelf_grade_erp（每日04:28）    d_op_s7p_detail_erp（每日05:54）


sp_op_shelf_gmv_analysis                 -- dm_op_shelf_gmv_analysis
结果表： fe_dm.dm_op_shelf_gmv_analysis   `fe_dm`.`dm_op_shelf_gmv_analysis`

DELETE FROM  fe_dm.dm_op_shelf_gmv_analysis WHERE stat_date = @stat_date;
SET @stat_date := SUBDATE(CURDATE(),1);

1.请帮忙更新datax同步任务：dwd_op_out_of_system_order_yht_erp的json文件dwd_op_out_of_system_order_yht.json（如同名附件），更新原因：新增两个字段，增量同步的字段有修改

2.请帮忙执行datax临时同步任务：dwd_op_out_of_system_order_yht_temp_erp （如同名附件），该同步任务包含1个表的同步,用于全量修复约翰通未对接部分数据，说明如下：
1）fe_dwd.dwd_op_out_of_system_order_yht (数据量： 200万）

2.请帮忙部署azkaban调度任务（实例1）
1）sp_dm_lo_order_logistics_task_data （如同名附件），用于每日更新物流串点任务费用均摊表数据，执行时间：每日02：05执行一次；（汤云峰）

dm_op_false_stock_danger_level 同步到实例2 每月1号 -- 宋英南

唐进，因为商品清单的原因，麻烦将实例2的fe_dm.dm_op_area_product_shelf_cover 删除6月28日的数据，然后重call一下存储过程，dm_op_area_product_shelf_cover  -- 朱星华 已完成

fe_dwd.dwd_group_order_refound_address_day


fe_dwd.dwd_order_item_refund_day_2018 这个表同步到实例2的fe_dwd.dwd_order_item_refund_day_2018  已完成

fe.`sf_prewarehouse_product_detail` -- 165924 @李世龙 看看这个同步实例2咩？
@唐进 sf_prewarehouse_product_detail 这个表是单独的，数据量比较小，不适合做成宽表。帮忙同步到实例2上 已完成
@唐进 sserp.`T_ORG_ORGANIZATIONS_L`这个表需要同步到实例2中一下哈
sf_prewarehouse_product_detail  --> fe_dwd.`dwd_sf_prewarehouse_product_detail`  已经建好表。可进行下一步操作 已完成

ALTER TABLE fe_dwd.`dwd_shelf_base_day_all` ADD cover_num INT(11) DEFAULT '0'  COMMENT '覆盖人数' AFTER shelf_tag 已完成

dwd_pub_auto_shelf_undock_insert  同步到实例2  -- 141 已完成
select * from fe_dwd.`dwd_auto_shelf_undock_gmv_insert`; 同步到实例2  -- 3978  已完成


-- 吴婷 已完成脚本更新
CALL test.`sp_prewarehouse_stock_detail`(); -- 不要call，没法复现
CALL test.`sh_preware_outbound_fill`();      
CALL test.`sh_preware_product_sale`();      -- 不要call，没法复现
CALL test.`sp_d_sc_preware_balance`();
CALL test.`sh_prewarehouse_coverage_rate`();
CALL test.`sh_preware_stock_weekly_monthly`();
CALL test.`sp_d_sc_preware_wave_cycle`('2020-07-01');
CALL test.`sp_fill_order_efficiency`();
CALL test.`sp_d_sc_warehouse_out_record`('2020-07-01');
CALL test.`sp_warehouse_product_presence`();
CALL test.`sp_d_sc_warehouse_preware_stock_outbound`('2020-07-01');
CALL test.`sp_d_sc_warehouse_balance`('2020-07-01');


--  已完成
因业务需求，fe_dm.dm_op_shelf_product_start_fill_label、fe_dm.dm_op_shelf_product_fill_suggest_label需要增加字段，完成后开发同事会直接引用这个字段对货架商品进行开启补货或停止补货，脚本见附件。
涉及存储过程：sh_process.dm_op_shelf_product_start_fill_label、sh_process.dm_op_shelf_product_fill_suggest_label
期望完成时间：本周五前（2020年07月03日）


20200703tangjintxySF.ok


dwd_pub_order_item_recent_two_month_two 这个里面 temp 要加字段
ALTER TABLE fe_temp.dwd_pub_order_item_recent_one_month
ADD COLUMN `pay_amount_product`  INT(4) NULL DEFAULT NULL COMMENT '支付金额_商品' AFTER `PAY_AMOUNT`;
pay_amount_product
ALTER TABLE fe_temp.dwd_pub_order_item_recent_two_month
ADD COLUMN `pay_amount_product`  INT(4) NULL DEFAULT NULL COMMENT '支付金额_商品' AFTER `PAY_AMOUNT`;

`dm_op_machine_fill_update`,
`dm_op_smart_shelf_fill_update`,
`dm_op_shelf_product_fill_update`,
`dm_op_shelf_product_fill_update_his`,
`dm_op_smart_shelf_fill_update_his`

'fe_dm.dm_op_machine_fill_update',
'fe_dm.dm_op_smart_shelf_fill_update',
'fe_dm.dm_op_shelf_product_fill_update',
-- 'fe_dm.dm_op_shelf_product_fill_update_his',
'fe_dm.dm_op_smart_shelf_fill_update_his'

table_name_one	table_name_two
feods.d_op_machine_fill_update	fe_dm.dm_op_machine_fill_update
feods.d_op_shelf_product_fill_update	fe_dm.dm_op_shelf_product_fill_update
feods.d_op_smart_shelf_fill_update	fe_dm.dm_op_smart_shelf_fill_update
feods.d_op_smart_shelf_fill_update_his	fe_dm.dm_op_smart_shelf_fill_update_his

'd_op_shelf_firstfill_erp', 'datax_sp_shelf_board_erp','datax_feods_d_op_fill_dwd_erp' 




datax_project_name	table_name_one	table_name_two	erp_frequency	delete_flag	load_time
datax_dwd_fill_order_item_month_erp	fe_dwd.dwd_pub_order_item_recent_one_month	fe_temp.dwd_pub_order_item_recent_one_month	每日	1	2020-05-07 16:51:44
datax_dwd_fill_order_item_month_erp	fe_dwd.dwd_pub_order_item_recent_two_month	fe_temp.dwd_pub_order_item_recent_two_month	每日	1	2020-05-07 16:51:44

dwd_pub_order_item_recent_two_month_two
-- 修改上述json文件和存储过程（李世龙）

-- 朱星华 
唐进，下午好哇，这几个表需要用，要迁移到实例2的话大概多久能好？
fe.product_package            -- fe_dwd.dwd_product_package 今日处理
fe.sf_product_business_area   -- fe_dwd.dwd_sf_product_business_area 已同步
fe.product_area_pool          -- fe_dwd.dwd_product_area_pool 今日处理
fe.product_area_pool_item     -- fe_dwd.dwd_product_area_pool_item 今日处理
fe.product_status_change_log  -- fe_dwd.`dwd_product_status_change_log`  

-- 补全6月19号数据
fe_dwd.dwd_sc_bdp_warehouse_shipment_detail
fe_dwd.dwd_sc_bdp_warehouse_stock_daily 



----------------------------------------- 下周处理
-- 修改 dwd_shelf_product_day_all json文件
ALTER TABLE fe_dwd.`dwd_shelf_product_day_all`
ADD COLUMN `add_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间(sf_shelf_product_detail_flag.add_time)' AFTER `smart_fill_status`;

`add_time` DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
`add_user_id` BIGINT(20) NOT NULL DEFAULT '0' COMMENT '添加人员id',
  
fe.product_status_change_log  10327 -- fe_dwd.`dwd_product_status_change_log`  datatx同步

-- sp_newshelf_quality  每日05：31执行一次   dm_op_newshelf_quality  已完成
feods.fjr_newshelf_quality    76522  --  fe_dm.`dm_op_newshelf_quality` 


环境:实例1
-- 删除的表
select * from feods.D_MA_area_history_sales_data_daily;

-- 删除的存储过程
sp_D_MA_area_history_sales_data_daily
请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.

环境:实例1
要删除的表: 
select * from feods.d_ma_shelf_product_seckill_remove;

请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.

-- 实例1
-- 删除的表
select * from feods.fjr_shelf_archives; # fe_dm.dm_pub_shelf_archives opf_商机货架管理信息 每天

-- 删除的存储过程
sp_shelf_archives
请唐进验证并执行停止存储过程,验证无误后保留历史脚本并在实例上删除存储过程,再告知李世龙删除相应的表.

    #表  -- 已完成
    test.dm_ma_shelfredpacket_activity
    test.dm_ma_shelfredpacket_shelf;
    #存储过程
    dm_ma_shelf_red_packet
	
    #存储过程
    test.dm_ma_shelf_red_packet
	存储表过程都要替换 实例2

-- dm_op_pwh_reqsto_two 执行时间需调整 已完成
dm_op_pwh_reqsto_two	dm_op_pwh_reqsto_two	宋英南	已部署调度	每日	5:09	2020/7/4 5:09	2020/7/4 5:09	0.2	fe_dwd.dwd_pj_outstock2_day
dm_op_pwh_reqsto_two	dm_op_pwh_reqsto_two	宋英南	已部署调度	每日	5:09	2020/7/4 5:09	2020/7/4 5:09	0.2	fe_dwd.dwd_shelf_product_sto_sal_day30
dwd_shelf_product_sto_sal_day30	dwd_shelf_product_sto_sal_day30	李世龙	已部署调度	每日	5:14	2020/7/4 5:14	2020/7/4 5:22	7.6	fe_dwd.dwd_shelf_product_day_all
dwd_shelf_product_sto_sal_day30	dwd_shelf_product_sto_sal_day30	李世龙	已部署调度	每日	5:14	2020/7/4 5:14	2020/7/4 5:22	7.6	fe_dwd.dwd_shelf_product_sto_sal_30_days




世龙、唐进：
    实例1任务 sp_op_shelf_gmv_analysis，经验证数据后，可以切换到实例2使用，需要配合：
1、唐进帮忙删除存储过程 sp_op_shelf_gmv_analysis 及调度任务；
2、唐进处理完后，世龙帮忙删除fe_dm.dm_op_shelf_gmv_analysis;
以上，谢谢。

-- 修改dwd_package_information json文件
ALTER TABLE fe_dwd.`dwd_package_information`
ADD COLUMN `ADD_TIME`  DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间(fe.sf_package_item.ADD_TIME)'  AFTER `type_STATU_FLAG`;

-- 存储过程修改，全量同步历史数据 已完成
fe_dm.dm_lo_manager_performance_report_everyday_for_month   -- feods.D_LO_manager_performance_report_everyday_for_month   3222
 

-- 吴婷任务部署 已完成
dm_sc_preware_new_product_flag  大概6秒钟，最好是能在6点之前执行。麻烦帮我处理一下，谢谢！
-- 汤云峰任务部署 已完成
sp_dm_lo_area_performance_report_everyday     每天凌晨3点之前就行，可根据资源安排 

结果表 feods.D_LO_shelf_fill_timeliness_detail  数据量 1329129  -- fe_dm.dm_lo_shelf_fill_timeliness_detail  1329441
fe_dwd.dwd_en_combined_payment_order 72023同步结果表数据 已完成


--- 停止存储任务：  已完成
sh_city_unsalable_his -- 已停止
sp_D_LO_fillorder_urged_stat     -- 已停止
prc_d_ma_shelf_product_stock_temp -- 已停止
sp_d_sc_preware_fill_apply_result -- 已停止

-- datax同步 已完成
fe.sf_shelf_logistics_task_install  -- 41418

fe.pub_user_integral_record   -- 331809  同步T-1数据 已完成

dm_bill_check  已完成
fe_dm.dm_bill_check 修改json文件


feods.d_en_fx_balance  54358383 -- fe_dm.dm_en_fx_balance @唐进 这个表的数据实例1上历史数据没有同步完。帮忙全部同步一下。同步完成之后，告知我，把实例1上的历史数据进行删除操作


-- 以下表无kettle同步
T_BGJ_STOCKFQTY
T_SAL_OUTSTOCKENTRY_F
T_STK_INSTOCKENTRY_F
T_STK_OUTSTOCK
ZS_DC_BUSINESS_AREA
ZS_OUTSTOCK_DAY

sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_MATERIALGROUP_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_MATERIALGROUP.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_MATERIAL.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_MRBENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_MRB.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_MRAPPENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_MRAPP.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_RECEIVEENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_RECEIVE.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_INSTOCKENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_INSTOCK.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_STOCK_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_MATERIAL_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_SUPPLIER_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/V_BD_BUYER_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_POORDERENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_POORDER.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_INVENTORY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_STOCK.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_STOCKSTATUS_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_SAL_OUTSTOCKENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_OUTSTOCKAPPLY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_OUTSTOCKAPPLYENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BAS_ASSISTANTDATAENTRY_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_POORDERENTRY_F.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BAS_BILLTYPE.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_STOCKSTATUS.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_UNIT.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BGJ_STOCKNEWFQTY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_ORG_ORGANIZATIONS.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_ORG_ORGANIZATIONS_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_MRBENTRY_F.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_MISCELLANEOUS.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_MISCELLANEOUSENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_MISDELIVERY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_MISDELIVERYENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_STKTRANSFERAPP.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_STKTRANSFERAPPENTRY.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BAS_BILLTYPE_L.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_MRBFIN.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_INSTOCKFIN.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_STK_STKTRANSFERAPPENTRY_E.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_PRICELIST.ktr
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_PUR_PRICELISTENTRY.ktrf
sh /app/data-integration/pan.sh -file=/app/edw/mysql/ktr/T_BD_SUPPLIERBASE.ktr



-- 以下表无需datax同步到实例2
ZS_DC_BUSINESS_AREA  无需同步
datax_extraction_erp 同步去掉 sserp.ZS_DC_BUSINESS_AREA 因为kettle没有同步这个表

-- 星华任务部署
dwd_op_shelf_product_price_dispose_monitor
dm_op_shelf_product_type_mgmv


feods.user_research @唐进 这个按小青哥要求要改变运行时间

dwd_wangyi_data_extract_info -- 同步到实例2
dm_lo_area_performance_report_everyday -- 同步到实例2
DELETE FROM fe_dm.`dm_lo_area_performance_report_everyday` WHERE `sdate` >= @date_top;

fe_dwd.`dwd_shelf_day_his`这个表我添加了6个字段。你需要改下json文件
  `zone_code` VARCHAR(100) DEFAULT NULL COMMENT '片区ID(所属区域ID，引用sf_shelf_area_info.area_id)',
  `before_refund_GMV` DECIMAL(18,2) DEFAULT NULL COMMENT '之前月应退当日已退GMV',
  `refunding_GMV` DECIMAL(18,2) DEFAULT NULL COMMENT '当日应退未退GMV',
  `pay_amount_act` DECIMAL(18,2) DEFAULT NULL COMMENT '当日实收金额(不包含退款)',
  `refund_finish_amount` DECIMAL(18,2) DEFAULT NULL COMMENT '当月应退当日已退金额',
  `before_refund_amount` DECIMAL(18,2) DEFAULT NULL COMMENT '之前月应退当日已退金额',
  
 select count(1) from fe.sf_company_visit_log         union all         --> fe_dwd.`dwd_sf_company_visit_log` 这个表需要同步一下 dwd_sf_company_visit_log
 select count(1) from fe.sf_company_visit_info        union all         --> fe_dwd.`dwd_sf_company_visit_info`；
 select count(1) from fe.sf_company_customer_info     union all         --> fe_dwd.`dwd_sf_company_customer_info`
 
 count(1)
(数据量：371074)
(数据量：223001)
(数据量：222498)
 
 
 call test.prc_d_ma_user_flag1()
 这个也要改 ,还有 sh_member_research_crr_2 (放在我的分支下)
 
fe_dwd.dwd_en_combined_payment_order  48554 72023 同步结果表数据 已完成





sserp.T_SAL_OUTSTOCKENTRY_F  T_SAL_OUTSTOCKENTRY_F 这张表线上没有数据 不同步
sserp.T_STK_INSTOCKENTRY_F


feng1.T_SAL_OUTSTOCKENTRY_F    -- 查一下数据量0
feng1.T_STK_OUTSTOCKAPPLY      -- 需要提供线上建表语句
feng1.T_STK_MISDELIVERYENTRY   -- 需要提供线上建表语句
feng1.T_STK_MISCELLANEOUS      -- 需要提供线上建表语句
feng1.T_STK_MISCELLANEOUSENTRY -- 需要提供线上建表语句
feng1.T_PUR_POORDERENTRY       -- 需要提供线上建表语句

-- 英南任务部署
dm_op_new_shelf_sp_offstock 

dwd_shelf_product_day_all 这个观察一下，是否减少时间了 -- 世龙优化 
user_research -- 伟铨优化


sp_D_MA_area_history_sales_data_daily

其余的区域商品宽表，货架宽表his的这个也call一下，宽表或者KPI的优先处理

# 实例1
call sh_process.prc_d_ma_shelf_sale_daily(subdate(curdate(),1));
call sh_process.prc_d_ma_shelf_sale_weekly(subdate(curdate(),1));
call sh_process.prc_d_ma_shelf_sale_monthly(subdate(curdate(),1));

#实例2
call sh_process.dm_ma_shelf_sale_daily( subdate(curdate(),1));
call sh_process.dm_ma_shelf_sale_weekly(subdate(curdate(),1));
call sh_process.dm_ma_shelf_sale_monthly(subdate(curdate(),1));

-- 下周处理
fe_dwd.dwd_staff_score_distribute_detail  -- 5261671   (已完成)
fe_dwd.dwd_group_order_coupon_day         -- 30735628  这两个表需要同步到实例2上

fe.sf_shelf_check_detail_extend  57476 --> fe_dwd.`dwd_sf_shelf_check_detail_extend` (已完成)
fe.sf_user_present 257  -- fe_dwd.dwd_sf_user_present 全部同步 (已完成)


-- 吴婷任务部署
dm_sc_supplier_price_purchase_type (已完成)


-- 世龙兑换卡宽表部署  及同步到实例2 (已完成)
-- 吹防任务部署（实例1） (已完成)
-- 星华任务部署（实例2） (已完成)
fe_goods.sf_sale_channel_spec                  -- select count(1) from fe_dwd.`dwd_sf_sale_channel_spec`        union all
fe_group.sf_group_dictionary_item              -->select count(1) from  fe_dwd.`dwd_sf_group_dictionary_item`   union all
-- feods.d_en_emp_org                          -->select count(1) from  fe_dwd.`dwd_en_emp_org`                 union all
-- feods.zs_qy_phone_area                      -->select count(1) from   fe_dwd.`dwd_group_phone_area`          union all
-- feods.sap_pmp_hos_emp_base_info             -->select count(1) from  fe_dwd.`dwd_sap_pmp_hos_emp_base_info`  union all
-- fe_dwd.dwd_group_exchange_card                 select count(1) from   fe_dwd.dwd_group_exchange_card         union all
fe_goods.sf_group_order_third_rela             -->select count(1) from   fe_dwd.`dwd_sf_group_order_third_rela` union all
fe_order.sf_order_overstock_record             -->select count(1) from   fe_dwd.`dwd_sf_order_overstock_record`
fe.`sf_shelf_check_production_date`  476053  -->  fe_dwd.`dwd_sf_shelf_check_production_date`

-- 修改json文件 及存储过程  已完成
ALTER TABLE fe_dwd.`dwd_group_order_refound_address_day`
ADD COLUMN `refund_item_id`  BIGINT(20) NULL DEFAULT NULL COMMENT '退款订单ID' AFTER `pay_state`;


select count(1) from fe_goods.sf_sale_channel_spec       union all  -- 275594
select count(1) from fe_group.sf_group_dictionary_item   union all  -- 64
select count(1) from feods.d_en_emp_org                  union all  -- 2683482
select count(1) from feods.zs_qy_phone_area              union all  -- 2729
select count(1) from feods.sap_pmp_hos_emp_base_info     union all  -- 2688993
select count(1) from fe_goods.sf_group_order_third_rela  union all  -- 66927
select count(1) from fe_order.sf_order_overstock_record             -- 1120092

fe_dm.dm_op_shelf_product_fill_suggest_label -- 同步到实例2  修改json文件 全量同步
SELECT COUNT(1) FROM fe_dm.dm_op_shelf_product_fill_suggest_label -- 27670216


实例2中 fe_dwd.dwd_sf_shelf_apply 同步实例1中fe.sf_shelf_apply 157764 新增3个字段，但实例2中有些字段是没有的
好的，那还有 fe_dwd.dwd_sf_shelf_apply_record 158167 新增10个字段 、fe_dwd.dwd_sf_shelf_apply_addition_info 40486 新增一个字段 这两个表也有新增的字段需要同步下
-- 修改json文件
fe_dwd.dwd_sf_shelf_apply
fe_dwd.dwd_sf_shelf_apply_record
fe_dwd.dwd_sf_shelf_apply_addition_info



-- 修改json 文件 和 存储过程
ALTER TABLE fe_dwd.`dwd_fill_day_inc_recent_two_month`
ADD COLUMN `WAY_BILL_NO`  VARCHAR(80) DEFAULT NULL COMMENT '物流单号' AFTER `SHELF_DETAIL_ID`;

ALTER TABLE fe_dwd.`dwd_fill_day_inc_recent_two_month`
ADD COLUMN `AUDIT_REMARK`   VARCHAR(500) DEFAULT NULL COMMENT '审核说明' AFTER `FILL_AUDIT_TIME`;


-- datax同步任务部署
fe.`sf_product_fill_order`  239752 --> fe_dwd.`dwd_sf_product_fill_order_recent32`

-- 删除同时超过32天的
 DELETE FROM fe_dwd.`dwd_sf_product_fill_order_recent32` WHERE FILL_TIME < SUBDATE(CURDATE(),32) AND apply_time < SUBDATE(CURDATE(),32) AND send_TIME < SUBDATE(CURDATE(),32);
 
 
-- 删除当日新增的
  DELETE FROM fe_dwd.`dwd_sf_product_fill_order_recent32` WHERE apply_time >= DATE_SUB(CURDATE(), INTERVAL 1 DAY);
   
  DELETE FROM fe_dwd.`dwd_sf_product_fill_order_recent32`   
    WHERE FILL_TIME >= DATE_SUB(CURDATE(), INTERVAL 1 DAY);
    
  DELETE FROM fe_dwd.`dwd_sf_product_fill_order_recent32`      
     WHERE send_time >= DATE_SUB(CURDATE(), INTERVAL 1 DAY);
    
	
   fe.`sf_product_fill_order`
   where apply_time >= DATE_SUB(CURDATE(), INTERVAL 1 DAY) OR FILL_TIME >= DATE_SUB(CURDATE(), INTERVAL 1 DAY) OR send_time >= DATE_SUB(CURDATE(), INTERVAL 1 DAY)


-- 志省需求  新增存储过程 dwd_en_scan_order_daily
-- 李世龙    新增存储过程 dwd_csm_product_vote_submit_all
-- 英南调度任务 dm_shelf_product_cms_submit
-- 星华需求  sh_process.dm_op_shelf_product_fill_suggest_label 迁移到实例2 

-- feods.d_en_emp_org    2687252       fe_dwd.`dwd_en_emp_org`   1196287  重新同步
-- fe_dwd.`dwd_csm_product_vote_submit_all` 56289  这个宽表需要加急同步到实例2.英南要急用



存储过程	结果表	备注
CALL test.`sp_add_shelf_damaged`();	fe_dm.dm_add_shelf_damaged	已分析不处理
CALL test.sp_area_product_month('2020-06');	fe_dm.dm_op_area_product_month	已分析不处理
CALL test.`sp_area_product_pq4`();	fe_dm.dm_op_area_product_pq4	已分析不处理
CALL test.`sp_association_analysis_week`();	fe_dm.dm_op_area_product_countuser	已分析不处理
CALL test.`sp_association_analysis_week`();	fe_dm.dm_op_area_product_user	已分析不处理
CALL test.`sp_association_analysis_week`();	fe_dm.dm_op_association_analysis	已分析不处理
CALL test.`sp_dm_sc_preware_monthly_kpi`('2020-07-16');	fe_dm.dm_sc_preware_monthly_kpi	待处理


-- sp_add_shelf_damaged  已停止   dm_op_add_shelf_damaged 测试ok   26 sec  不部署（实例1已经停止调度）
结果表 ： feods.pj_zs_add_shelf_damaged   fe_dm.dm_op_add_shelf_damaged dm_op_add_shelf_damaged 无需同步历史数据

-- sp_area_product_month  每月1号 07:15   dm_op_area_product_month 测试ok  5 min 19 sec  已部署
结果表： feods.fjr_area_product_month  196257  fe_dm.dm_op_area_product_month  需全量同步历史数据


-- sp_area_product_pq4  每周一 05:01   dm_op_area_product_pq4  测试ok  1 sec 已部署
feods.fjr_area_product_pq4      fe_dm.dm_op_area_product_pq4  无需同步历史数据


-- sp_association_analysis_week  每周一 05:15   dm_op_association_analysis_week 测试ok 3min 已部署
feods.area_product_user        4273507 -- fe_dm.dm_op_area_product_user       需全量同步历史数据
feods.area_product_countuser   3104    -- fe_dm.dm_op_area_product_countuser  需全量同步历史数据
feods.fjr_association_analysis 113594  -- fe_dm.dm_op_association_analysis    需全量同步历史数据


-- sp_dm_sc_preware_monthly_kpi  每天  dm_sc_preware_daily_kpi  测试ok 1 min 28 sec 已部署
fe_dm.dm_sc_preware_monthly_kpi  4625    -- fe_dm.dm_sc_preware_daily_kpi     需全量同步历史数据
                                     -- fe_dm.dm_sc_preware_monthly_kpi   需全量同步历史数据
									 
									 
feods.D_LO_fulltime_manager_history_record 6248 -- fe_dwd.dwd_LO_fulltime_manager_history_record   同步到实例2 已完成


@唐进 麻烦帮我部署个实例2的任务，test.dm_sc_business_area_preware
放在fe_dm.`dm_prewarehouse_stock_detail`这个表之后



fe.sf_product_code  3405  -- fe_dwd.`dwd_sf_product_code` 这个表还请麻烦同步到实例2
fe.sf_shelf_check_detail_extend 58710   -- fe_dwd.dwd_sf_shelf_check_detail_extend  已同步
fe.sf_shelf_check_detail_extend_old_snapshot 104   -- fe_dwd.`dwd_sf_shelf_check_detail_extend_old_snapshot`



-- 英南的任务部署 
dm_op_s_new_product_offstock
fe.sf_user_present_exchange_record  404970 同步实例2 -- 朱慧敏


sp_D_LO_area_fulltime_reached_index_statistics  每日 06：06  -- dm_lo_area_fulltime_reached_index_statistics  测试ok  部署  停止调度datax同步任务： d_lo_area_fulltime_reached_index_statistics_erp
结果表 feods.d_lo_area_fulltime_reached_index_statistics 数据量 1325    -- fe_dm.dm_lo_area_fulltime_reached_index_statistics

sp_zs_fill_operation_kpi_for_management 每日 04：58                            -- dm_fill_operation_kpi_for_management  datax同步  zs_fill_operation_kpi_for_management_erp
结果表 feods.zs_fill_operation_kpi_for_management 数据量 94  无需同步历史数据  -- fe_dm.dm_fill_operation_kpi_for_management
唐进，帮忙同步下实例2 test.`d_op_shelf_product_valid_sale_tmp` 到实例1，谢谢



-- 同步数据差异很大原因查找  完成
-- feods.d_en_emp_org                          -->select count(1) from  fe_dwd.`dwd_en_emp_org`                 union all
-- 做个任务监控（失败任务） 
-- 吹防反馈盘点宽表问题 世龙已处理
-- 星华反馈fe库同步数据问题
-- 梳理fe库哪些表新增字段  完成
-- 爬虫
-- 延时等等
-- 宽表同步时间前推1天（数据量 CPU）
-- 伟铨周一耗时高任务拆分 完成
-- 调整执行时间（高CPU）+ 代码优化  完成
-- 货架商品宽表标识数据更新提前（王龙后期反馈）
-- 宽表数据校核（更新）

https://youdata.feng1.com/dash/632/editor?pid=8&did=2142   -- 报表分布及访问量
https://youdata.feng1.com/dash/730/editor?pid=8 --抽取明细可以直接访问这个报表  2019wangyTj.ok

dm_ma_shelf_sale_weekly 由现在的每日02：36 调整到每日04：24执行；  --完成
d_en_emp_org_erp 同步任务更新json文件：（需临时同步全部数据）  --完成

dm_op_new_shelf_suggest_list 同步到实例2  每日增量同步   --完成
DELETE FROM fe_dm.`dm_op_new_shelf_suggest_list`  WHERE stat_date=@this_week  OR stat_date<@two_month_date;
SET @this_week := ADDDATE(SUBDATE(CURRENT_DATE,WEEKDAY(CURRENT_DATE) + 1),1);
SET @two_month_date := SUBDATE(CURRENT_DATE,INTERVAL 2 MONTH);

部署英南任务：dm_op_fill_reason_classify  --完成
更新星华存储过程：  --完成

fe.product_price_apply        177713 商品调价申请表
fe.product_price_apply_audit  177712  这两个表能同步到实例2不  商品调价申请表


dm_shelf_manager_monitor_result 由现在的每日 02：47 调整到每日 02：40；  --完成
dm_op_smart_log 由现在的每日 02：48 调整到每日 03：34；    --完成
fe.`sf_shelf_apply_visit_company`  --> fe_dwd.`dwd_sf_shelf_apply_visit_company`这个表需要同步到实例2  --完成


ALTER TABLE fe_dwd.`dwd_fill_day_inc_recent_two_month`
ADD COLUMN `WAY_BILL_NO`  varchar(80) DEFAULT NULL COMMENT '物流单号' AFTER `SHELF_DETAIL_ID`;

ALTER TABLE fe_dwd.`dwd_fill_day_inc_recent_two_month`
ADD COLUMN `AUDIT_REMARK`   varchar(500) DEFAULT NULL COMMENT '审核说明' AFTER `FILL_AUDIT_TIME`;
补货最近两个月的。我添加了两个字段。大宽表没有添加 --完成


部署 dwd_lo_order_logistics_task_base_all 实例1 同步到实例2  --完成
SELECT COUNT(1) FROM fe_dwd.dwd_lo_order_logistics_task_base_all  -- 64003  完成


#dwd_group_emp_user_day 表从宽表中拆开，每月一号同步一次；
d_op_fill_day_sale_qty 表拆分子同步 00：41 CPU 高  --完成
zs_shelf_product_flag  拆子同步 00:32 CPU 高   --完成

#实例2 新建表存储过程
select * from test.dm_ma_sp_stopfill;  测试ok  0.5 min  --完成
call test.dm_ma_sp_stopfill(); #每天更新 每天只可以call一次,不然数据重复 今天不用call

#实例2 建表与存储过程
select * from test.dm_ma_sp_salestockinfo_daily_32;   测试ok  5 min 49 sec  --完成
call test.dm_ma_sp_salestockinfo_daily_32(); # 每天调度一次

feods.d_mp_boss_data_shelf6            -- 7020  dm_mp_boss_data_shelf6
feods.d_mp_day_sale_shelf6             -- 358   dm_mp_day_sale_shelf6
feods.d_mp_user_shelf6                 -- 1     dm_mp_user_shelf6   ok
feods.d_mp_boss_data_vending_machine   -- 7020  dm_mp_boss_data_vending_machine
feods.d_mp_day_sale_vending_machine    -- 358   dm_mp_day_sale_vending_machine
feods.d_mp_user_vending_machine        -- 1     dm_mp_user_vending_machine  ok

实例1 test：test.user_integral_exchange_new，存储过程test.user_integral_exchange_new


sp_association_analysis_week  
d_sc_warehouse_preware_stock_outbound  
fjr_user_miser_stat   停止调度 
星华吹防6个调度任务
d_op_machine_online_shelf @蔡松林 @唐进 这个表松林网易有数已经切换了。看下是否可执行调度停止删除的操作
d_op_machine_online_stat  这个表和上面是同一个存储过程。可一起停止
@唐进 d_op_smart_log 这个表网易有数无使用的。评估一下做停调度删除的操作


fe_dm.`dm_user_suspect`  数据重新全量同步 --完成
d_op_slot_his 这个表实例2需要补全历史数据。然后评估做删除操作

dm_op_shelf_week_month_sale  存储过程优化 星华的  由最近每天20多分钟优化到不到一分钟（执行计划错误，周更新的数据调整到周一非每天更新） --完成
dm_ma_user_integral_exchange_list  慧敏存储过程优化 由11分钟优化到1分多钟  --完成
dm_fill_operation_kpi_for_management 松林存储过程优化 由16分钟优化到4分钟  -- 完成
dm_op_kpi3_shelf7_nine  世龙存储过程优化 由18分钟优化到0.8分钟（切换两个月宽表后，因两个月宽表apply_time没有索引） -- 完成
dm_fill_shelf_action_total_history_two 宋南存储过程优化 由18分钟优化到5.6分钟  -- 完成

dataxt同步任务 pub_user_integral_record 需要修改json文件 --完成

ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `material_name`  VARCHAR(100) DEFAULT NULL COMMENT '物资名称' AFTER `type_name`; --完成

 ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `lng_bd` DECIMAL(18,5) DEFAULT NULL COMMENT '经度(百度坐标系)' AFTER `lat`; --完成

 ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `lat_bd` DECIMAL(18,5) DEFAULT NULL COMMENT '维度(百度坐标系)' AFTER `lng_bd`; --完成

fe_activity.sf_activity_user_integral_record     476742   fe_dwd.dwd_sf_activity_user_integral_record  --完成
fe.pub_member_level_record 同步到实例2  540869   fe_dwd.dwd_pub_member_level_record  --完成
fe.sf_product_area_city_relation --> dwd_sf_product_area_city_relation  这个表每周全量同步一下到实例2  --完成
fe.sf_shelf_machine_slot_template_item  -->  dwd_sf_shelf_machine_slot_template_item  --完成

dm_ma_user_integral_exchange_list 部署 朱慧敏  --完成  每周一 03:37 执行一次；
dm_op_out_product_stock_item  部署 朱星华  --完成  每日04:40 执行一次； 地区商品池退出品仓库有库存明细
dwd_auto_shelf_template  00:29执行 部署 李世龙   同步到实例2  --完成


需要把实例1的fe_dm.`dm_op_shelf_product_fill_update2`同步到实例2fe_dm.`dm_op_shelf_product_fill_update2`，时间在上午6:30之前。


CALL sh_process.dm_op_shelf_fill_sku_stock   -- 测试ok 55.409 sec  部署实例1  宋英南   2020-07-30 03:46:30 之后 每日 04:19执行
CALL sh_process. dm_op_shelf_product_fill_update2 -- 部署实例1  每天全量同步到实例2 1165581 测试ok  6 min 51 sec  d_op_shelf_product_fill_update差不多，即5:30-6:00之间   每日 05:18执行
CALL sh_process.dwd_group_product_sale_detail_month -- 测试ok  2 min 3 sec 部署实例1 定时抽取：每月1号运行一次，每次抽取上个月的数据  郑志省  2020-07-30 01:00:23  每日 01:39执行


部署 dm_ma_sp_plc 实例2 纪伟铨 测试ok 1 min 44 sec  2020-07-30 07:02:02 之后 每日07:20
部署 dm_op_manager_offstock_abnormal 实例2 宋英南 每日 测试ok 46.281 sec  每日07:08
部署 dwd_ma_menber_level_change 实例2 朱慧敏 每月1号执行  没有查到datax同步的 每月1号 03:37
部署 dm_op_shelf_price_grade 实例2 朱星华 每周一更新 测试ok  每周一 03:41

 
dwd_ma_menber_level_change

#实例2 新建
select * from test.dm_ma_sp_plc; # 货架商品生命周期清单
select * from test.dm_ma_sp_plc_his; # 历史货架商品生命周期历史
call sh_process.dm_ma_sp_plc(subdate(curdate(),1));

select * from fe_dm.dm_ma_sp_plc;      -- 4889235
select * from fe_dm.dm_ma_sp_stopfill; -- 315909    这两张搞定之后还要同步到实例1@唐进

SELECT COUNT(1) FROM fe.sf_machines_apply_gradient_bonus  -- 537 每日全量同步到实例2 fe_dwd.dwd_sf_machines_apply_gradient_bonus


datax同步任务：
dm_op_shelf_product_fill_update2  dm_op_shelf_product_fill_update2  全量
fe_dm.dm_ma_sp_plc                    fe_dm.dm_ma_sp_plc  增量
fe_dm.dm_ma_sp_stopfill               fe_dm.dm_ma_sp_stopfill 增量
fe.sf_machines_apply_gradient_bonus   fe.sf_machines_apply_gradient_bonus  全量

fe_dwd.dwd_op_city_grade
fe_dwd.dwd_op_scene_grade
fe_dwd.dwd_op_multiple_grade 临时


部署 dwd_ti_ebs_bdp_fy_emp_point 郑志省 每月1号调度 01:40 执行
部署 dwd_pub_comb_pay_without_weixin_result 实例1 测试ok 同步到实例2  5113 每日00:50执行
fe_dwd.dwd_lo_order_logistics_task_base_all 临时全量同步到实例2 66317
dwd_update_dwd_table_info     这个任务调整到3点左右执行。需要跟 dwd_pub_order_item_recent_two_month_two 错开  02;10
fe.pub_user_integral_growth   这个表需要同步到实例2哈，647万数据  -- fe.pub_user_integral_growth 

唐进下午好，fe_dm.dm_op_shelf_product_start_fill_label，这个表需要迁移至实例2，存储过程的逻辑我这边需要做修改，新逻辑会涉及到这三个表，
fe_dwd.dwd_op_product_type_blacklist_insert (2255条)，   -- fe_dwd.dwd_op_product_type_blacklist_insert  不定时同步 后面临时同步
fe_dwd.dwd_op_shelf_product_blacklist_insert (93670条)， -- fe_dwd.dwd_op_shelf_product_blacklist_insert 不定时同步 后面临时同步
fe.sf_shelf_product_type_black_catagory (9138条)，       -- fe_dwd.`dwd_sf_shelf_product_type_black_catagory`
这三个表可以先迁移到实例2便于我做脚本测试不~

fe_dwd.`dwd_group_product_sale_detail`  这个存储过程的表，需要同步到实例2  3557065  部署在实例 2无需同步实例1数据  -- 完成 dwd_group_product_sale_detail_month2 02:22 执行


修复约翰通数据

feods.fjr_user_miser_stat（待同步历史数据后可以删表）
需要同步历史数据
feods.fjr_user_miser_stat      （数据量：38645528 ）    truncate table fe_dm.dm_op_user_miser_stat      ;  先同步2019-07-01 （含）之后的数据 约1400万
feods.fjr_price_sensitive_stat （数据量：350727   ）    truncate table fe_dm.dm_op_price_sensitive_stat ;
这个存储过程涉及到两张表。需要将历史数据同步到实例2上。

dm_op_shelf_active_month 朱星华 任务部署 测试ok 0.3分钟 每日更新，每月1日结存上月数据。 --  已完成
实例2中sh_process.dm_op_shelf_active_week 需增加字段 -- 完成



世龙、唐进：
        如业务需求，需要对实例1的sp_op_false_stock_danger_level做调整，同时表结构也需要新增一个字段：
1、世龙帮忙将实例1和实例2的dm_op_false_stock_danger_level，新增字段shelf_product_danger_type，参考代码：
ALTER TABLE fe_dm.`dm_op_false_stock_danger_level` 
ADD COLUMN shelf_product_danger_type TINYINT(1) COMMENT '低销\高销判定得分' AFTER com_danger_level;
2、世龙调整完后，唐进帮忙更新附件存储过程并call，同时调度频率由原来的每月1次调整为每周一次，时间为每周一。
以上，谢谢。
-- dm_op_false_stock_danger_level_erp  同步由每月1号改为每周一号 ，并且修改json文件 dm_op_false_stock_danger_level  已完成

唐进早上好，实例2的 fe_dm.dm_op_area_product_month 这个表还没有7月的数据，麻烦帮忙看看是啥原因 
dm_op_shelf_product_fill_update2 存储过程执行超时原因

世龙、唐进：
    实例1迁移实例2之前有三个未完成删除的任务，现已解除关联，帮忙删除如下任务和表：
1、存储过程任务sp_op_package_shelf，结果表2张d_op_package_shelf、d_op_package_config，均可删除（星华说关联的任务已经停止调度，唐进帮忙查看一下）；
2、存储过程任务sp_kpi_unsku，结果表1张fjr_kpi_unsku，均可删除；
以上，帮忙抽空完成，谢谢。

-- 星华需求 部署任务  完成
-- 优化同步fe_temp下表   完成
-- 关注CPU  已处理实例1 和实例2的高CPU
-- 王龙反馈任务执行时间调整
-- 实例1 2 添加依赖关系是否正确信息 
-- 监控转为线上监控，添加qq告警 
-- 宽表01：00 同步CPU吃紧 同步数据量少 耗时多 已对fe_temp库下宽表做分区处理    完成
-- 取代一个月订单宽表（修改实例1 2的存储过程）  去掉每日一个月订单宽表的同步   完成


部署  dwd_shelf_product_near_date_change 实例2 李世龙  -- 暂时不调度
部署  dm_op_np_satisfaction_result_month 实例2 朱星华  数据已补全   补全从2019年10月至今数据 -- 月数据更新频率：每日更新，汇总数据每月1日结存上月数据，明细数据只保留最新数据 04：20 完成
部署  dm_op_np_satisfaction_result_week 实例2 朱星华  数据已补全     补全从2020-01-05月至今数据  -- 周数据更新频率：每周一更新，汇总数据每周一结存，明细数据只保留最新数据   04：23 完成
部署  dm_op_atv_and_associated 实例2 朱星华 补全从2019年1月至2020年8月数据  -- 每日更新，汇总数据每月1日结存上月数据 10：05 完成
部署  dm_ma_new_sp_stat 纪伟铨 实例2  05：02  -- 完成
部署  dm_ma_sp_plctype_daily 纪伟铨 实例2  1 min 32 sec  07：36 -- 完成

fe.sf_sham_upgoods_assign_record 9794  已部署 每日 00:22    --> fe_dwd.`dwd_sf_sham_upgoods_assign_record` 这个表同步到实例2上 每天全量同步 记录表，用 last_update_time 做replace into 吧
实例1的这两个表有更新，实例2要同步一下哈。fe_dwd.dwd_op_product_type_blacklist_insert，fe_dwd.dwd_op_shelf_product_blacklist_insert  朱星华 -- 已完成
fe.sf_shelf_product_up_record  8648  已部署 每日 00:23      --> fe_dwd.`dwd_sf_shelf_product_up_record`  使用last_update_time 做同步日期。使用add_time做删除，保留最近半年的数据
fe.sf_shelf_product_up_detail  211332   -- 待吹防确认


-- 将datax_web的 order_item 的bak去掉，改为每日01：00 调度 修改宽表同步json文件  完成
-- sf_risk_production_date_source 同步机制如下 已部署 每日 00:39:10
SELECT COUNT(DISTINCT a.`shelf_id`),COUNT(DISTINCT a.`product_id`),COUNT(a.`effective_detail_id`)
FROM fe.`sf_risk_production_date_source` a
JOIN fe.`sf_shelf` b ON a.`shelf_id` = b.`SHELF_ID` AND b.`DATA_FLAG` = 1 AND b.`SHELF_TYPE` = 9
;


#实例2建表
    # 目标表
select * from  test.dm_ma_newsp_s_daily;
select * from  test.dm_ma_newsp_su_daily;
select * from  test.dm_ma_newsp_su_weekly;
select * from  test.dm_ma_newsp_su_monthly;
    #存储过程
call test.dm_ma_new_sp_stat(subdate(curdate(),1));


-- zs_shelf_member_flag_erp  由现在的07：22 - 07：40 调整到 07：03
-- d_op_sp_sal_sto_detail_erp 由现在的 03：29 调整到 03:24 同步
dm_op_out_product_clear_efficiency_two 07:29执行  调整到08:33  网易有数 08:00:00的抽取调整  网易有数 07:38:00的抽取调整  -- 完成
csl_finance_instock_sales_outstock_table_erp  重新同步6月份数据
区域销售之今日小时销售 抽取任务更改执行计划，抽取时间缩短一半；
区域用户数 抽取任务更改执行计划，抽取时间由60多秒缩短到10多秒

部署 dm_op_shelf_sham_stock_hit  李吹防 实例2 每日更新 测试ok 1分钟  每日 09:03执行  -- 完成
部署 dm_op_shelf_product_start_fill_label2 朱星华 实例2 迁移  6分钟  每日 08:26执行  -- 完成
部署 dm_op_sp_avgsal90  朱星华 实例2  9分钟  每日 10:02  -- 完成
同步 fe.sf_shelf_product_fill_flag_apply -- 9463  已部署 每日 00:24 
迁移 dm_op_shelf_product_start_fill_label 到实例2 可以停止调度 dm_op_shelf_product_start_fill_label 并删表  05:46
同步历史数据 SELECT COUNT(1) FROM fe_dm.dm_op_shelf_product_start_fill_label 1348280
log表设置为秒级

@唐进  需要把新进销存表实例1 的feods.d_mp_purchase_sell_stock_summary 同步到实例2中 fe_dm.dm_mp_purchase_sell_stock_summary  -- 每月 1-10号每日全量同步 已处理
再把老进销存的同步 feods.`csl_finance_instock_sales_outstock_table`停止掉  -- 已停止

@唐进 由于新旧进销存结果存放在不同结果表中，因此需要修改test.`sh_dynamic_weighted_purchase_price`

#实例2建表
    # 目标表
select * from test.dm_ma_sp_plctype_daily;
    #存储过程
call test.dm_ma_sp_plctype_daily(); #每日运行

-- 费航宇需要删除的 0804
prc_d_en_fx_new_user_daily_balance    不可停止
prc_d_en_gross_margin_rate_order      不可停止
prc_d_en_order_user                   不可停止


-- 吴婷 0804
d_sc_warehouse_onload                   不可停止
pj_poorderlist_day                      不可停止
pj_prewarehouse_stock_detail_monthly    不可停止
pj_prewarehouse_stock_detail_weekly     不可停止
d_sc_shelf_stock_daily                  不可停止
pj_prewarehouse_coverage_rate           不可停止
pj_fill_order_efficiency                不可停止
d_op_dim_date                           不可停止
fjr_product_list_manager_week           不可停止



wt_order_item_twomonth_temp  这个表做停删操作。网易有数的，航宇今天停止掉。用两个月的表替换

dwd_group_product_sale_detail_month2  这个存储任务不跑数了吗？ 实例2 删除，部署在实例1

sf_order_item_temp 这个表，周三可以执行停删的操作。网易有数还有星华的两个报表在用，已经发她周三前进行切换掉

dm_mp_finance_month_area_income(DATE_FORMAT(SUBDATE(CURRENT_DATE,INTERVAL 1 day),'%Y-%m-01'),CURRENT_DATE)  蔡松林 08:11  -- 已部署


@唐进 sh_shelf_product_flag 这个存储过程中没有记录sql执行时间，  对那些执行时间长的存储过程先定位是哪些sql执行时间长。  -- 给耗时长的存储过程加sql执行时间  已加
重构实例1 sf_dw_task_log ，添加开始时间，和结束时间，耗时信息  -- 已处理

实例一test.`dm_mp_finance_month_area_income` 插7月份之前的数据进入fe_dm.`dm_mp_finance_month_area_income`之中 -- 已完成

fe.sf_shelf_product_log -- > fe_dwd.`dwd_sf_shelf_product_log`  151570
fe.sf_shelf_product_status_log -- > fe_dwd.`dwd_sf_shelf_product_status_log`  40526
fe.pub_import_shelf_product  -- > fe_dwd. dwd_pub_import_shelf_product  8353955  add_time 和 last_update_time 两个字段 动态保留最近两个月的数据。
@唐进 这个英南那边的一个紧急任务，第三个需要注意一下  ;数据量比较大，动态保留最近两个月的数据  -- 已完成

CALL sh_process.dwd_group_product_sale_detail_month -- 测试ok  2 min 3 sec 部署实例1 定时抽取：每月1号运行一次，每次抽取上个月的数据  郑志省  2020-07-30 01:00:23  每月1号 01:39执行

-- fe库表同步维护json文件

ALTER TABLE fe_dm.`dm_lo_fill_for_month_label`  -- 修改 json文件
ADD COLUMN delivered_type TINYINT(2) DEFAULT '0' COMMENT '签收类型 (默认是0,1-自动签收)' AFTER `month_fill_type`;

这个表加了一个字段。你的json文件需要修改一下

进进，帮我改过程了，dm_sc_preware_daily_report 这个对应的test已经修改了哈 -- 处理


sf_shelf_apply  修改 json文件
'shelf_name+varchar(50)+货架名称', 'supplier_id+bigint(20)+供货方id', 'product_supplier_type+int(2)+供货方类型'

sf_shelf_change_apply 修改 json文件
'fill_order_id+bigint(20)+订单号',

sf_shelf_logistics_task_change  修改 json文件
 'audit_status+tinyint(2)+审核状态：1-待审核 2-审核通过 3-审核不通过', 
 
sf_shelf_transactions   修改 json文件
  
  
SELECT COUNT(1) FROM fe.sf_company_customer_info  -- 247832 全量同步一次数据
SELECT COUNT(1) FROM fe_dwd.dwd_sf_product_fill_order_recent32  -- 312053 全量同步一次数据



UPDATE `sf_dw_task_log` SET start_time=IF(SUBSTRING_INDEX(loginfo,'%',-1)='',NULL,SUBSTRING_INDEX(loginfo,'%',-1)),end_time=createtime WHERE statedate>='2020-08-12'


UPDATE feods.`sf_dw_task_log` SET start_time=IF(SUBSTRING_INDEX(loginfo,'%',-1)='',NULL,SUBSTRING_INDEX(loginfo,'%',-1)),end_time=createtime WHERE statedate>='2020-08-12';
UPDATE feods.`sf_dw_task_log` SET run_time=ROUND(TIMESTAMPDIFF(SECOND,start_time,end_time)/60,1),
run_time_second= TIMESTAMPDIFF(SECOND,start_time,end_time)
WHERE statedate>='2020-08-11';


fe.sf_shelf_logistics_task_operation  438080 -- > fe_dwd.`dwd_sf_shelf_logistics_task_operation`需要把这个表同步到实例２上 已部署同步 00:40:20

fe_dwd.`dwd_shelf_product_weeksales_detail` 10656658 实例1的同步到实例2上 通过load_time同步，replace into的方式看下时间效率。如果耗时比较长，考虑全量同步  -- 先同步2020 年数据 7095439 明天同步调度
 
fe.sf_shelf_transfer_apply 54 --> fe_dwd.dwd_sf_shelf_transfer_apply  已部署同步 00:07
fe.sf_shelf_transfer_shelf_info --> fe_dwd.dwd_sf_shelf_transfer_shelf_info 已部署同步 00:07
这两个表目前数据量不大，建议用last_update_time做增量更新。历史数据由于星华着急用，我先手动copy过去。你那边按照增量同步到实例2上

fe.sf_order_timeout_follow_result_record --> fe_dwd.`dwd_sf_order_timeout_follow_result_record`  已部署同步 00:07
这个表目前数据量不大，建议用last_update_time做增量更新。历史数据，我先手动copy过去。你那边按照增量同步到实例2上

fe.sf_company fe_dwd.dwd_sf_company 这个表没有数据，看下是没有同步吗？  -- 已部署同步 00:07


feods.zs_qy_user_area 14139 -->fe_dwd.`dwd_en_user_area`
feodd.zs_qy_phone_area  2729 -->fe_dwd.`dwd_en_phone_area`
这两个表全量同步一下数据。是历史的数据需要保留一下

feods.zs_qingdaodaoru_20180804 207519 --> fe_dwd.`zs_qingdaodaoru_20180804`   完成
   
feods.zs_qingdaodaoru_20180903 1436 -->  fe_dwd.`zs_qingdaodaoru_20180903` 完成
这两个表同步到实例2上。同步完之后，告知我做删除操作

zs_qingdangdaoru_limit_qty  38 -- fe_dwd.zs_qingdangdaoru_limit_qty 完成
zs_qingdangdaoru_product_type 4783 -- fe_dwd.zs_qingdangdaoru_product_type 完成



-- 停掉两个月的订单同步任务（鑫森）
ALTER TABLE fe_dwd.`dwd_pub_order_item_recent_two_month`
ADD COLUMN `PAY_REMARK` VARCHAR(1000) DEFAULT NULL COMMENT '付款注释' AFTER `PAY_DATE`;

两个月的表需要添加一个字段。你修改一下json文件。temp的我也修改一下 dwd_pub_order_item_recent_two_month

ALTER TABLE fe_dwd.`dwd_check_base_day_inc`
ADD COLUMN `high_risk_flag` TINYINT(2) DEFAULT '0' COMMENT '高风险标记，1效期高风险虚库存 2非效期高风险虚库存' AFTER `date_empty_flag`;

这个表加了一个字段。我两个表都添加了。你记得修改一下json文件

dwd_lo_order_logistics_task_base_all 全量同步一次 汤云峰  69513  -- 已处理
dm_sc_preware_wave_cycle -- git比对


星华的任务
店主选品效果对比： dm_op_manager_selection_effect 部署实例2 每周一调度 测试ok 耗时 几秒钟 -- 已部署  每周一 09：59
-- 门店维度指标监控： dm_op_area_zone_behaviour 部署实例2 每周一调度   
dwd_op_shelf_product_price_dispose_monitor1 部署实例1 测试ok 停止调度dwd_op_shelf_product_price_dispose_monitor 实例2任务  08：27调度 -- 已部署 实例1已停止

dm_op_atv_and_associated 任务重新跑19年7月至今的数据，并修改存储过程  朱星华 -- 已处理
dm_op_np_satisfaction_result_month 从跑数据 -- 已处理
dm_op_np_satisfaction_result_week 从跑数据 -- 已处理



吹防需求  dm_op_shelf_product_confirm_risk  -- 部署在每日 08：23
dm_op_shelf_product_fill_update2_his -- 已部署 宋英南  每日 06：11

部署 dwd_shelf_product_weeksales_detail -- 实例1 每周一 12:21 调度 同步到实例2 13：03
feods.questionnaire_survey_member -- > fe_dwd.`questionnaire_survey_member` 完成

部署一个存储过程 dwd_lo_depot_refund_order  每天5点到8点间部署 实例1 结果表数据同步到实例2  松林  -- 每日 06：41 调度
 实例一到实例二的同步任务 fe_dwd.dwd_lo_depot_refund_order  -- 07:23 同步


fe_dwd.dwd_shelf_product_weeksales_detail 把这个表全量同步到实例2上  -- 已完成

    # 目标表
select * from test.dm_ma_plcgrowth_all_monthly; # 每月累计成熟货架商品成长周期
select * from test.dm_ma_plcgrowth_new_monthly;  # 每月新成熟货架商品成长周期
    #存储过程
call test.dm_ma_plcgrowth(subdate(curdate(),1)); #每日运行  -- 已部署 07：30

dwd_shelf_product_weeksales_detail  部署datax同步任务  每周一  更改实例2 的表结够 建分区表  -- 已完成


fjr_user_miser_stat 这个表的历史数据没有同步到实例2上  -- 已补全
d_op_sp_sale_detail  这个也做停删的操作吧  -- 不可停
pj_preware_sales_seven 这个也做停删的操作吧  -- 不可停
sp_users_day_stat   这个存储过程做停删的操作  -- 可以停


-- 已处理 转至 datax_web
datax_project_name	table_name_one	table_name_two	erp_frequency	delete_flag	remark	load_time
zs_shelf_flag_erp	feods.zs_shelf_flag	fe_dm.dm_shelf_flag	每日	1	\N	2020-05-07 16:51:44
zs_shelf_flag_erp	feods.zs_shelf_flag_his	fe_dm.dm_shelf_flag_his	每日	1	\N	2020-05-07 16:51:44
zs_shelf_flag_erp	feods.zs_shelf_product_flag	fe_dm.dm_shelf_product_flag	每日	1	\N	2020-05-07 16:51:44  -- 对应表由变化，重建实例2的表 停掉datax同步任务 转为datax_web部署

fe.sf_shelf_check  2416455 --> fe_dwd.`sf_shelf_check_recent32` 用  OPERATE_TIME  限定最近35天的数据。用 last_update_time  -- 已部署同步
来更新数据
数据保留35天。他们反馈说万一放假啥的，跑不了


停止 zs_area_product_sale_flag 部署datax_web 03:44 同步  -- 完成
dwd_order_item_refund_real_time.json 部署datax_web 改为replace  -- 完成


 SELECT * FROM feods.`sf_dw_task_log` WHERE task_name IN ('dm_op_shelf_price_sensitivity','dm_ma_user_stat_info')  -- 2：30之后CPU持续高的两个存储过程 查原因
 
  
 dwd_shelf_product_weeksales_detail  全量更新18年  19年数据 -- 完成
 
 @唐进  实例2的过程 dm_sc_poorderlist_day 按照 test.`pj_poorderlist_day`的更新一下哈，这个是之前优化过的 -- 完成


-- 下周处理
fe_dwd.dwd_shelf_base_day_all 这个表是每天00:30左右跑数的。
但是货架关联状态的fe.`sf_shelf_relation_record`是凌晨3:10更新。
所以需要@唐进 在3:30左右重跑一下货架的宽表，同步到实例2上。@all 有需要用货架绑定状态的，需要调整一下时间在4点之后。

-- 实例1 2点半CPU高处理
-- datax——web 切换 
-- 实例1 任务依赖实现 （关键任务）
-- 调整时间（fe同步到实例2）

sh_member_research_crr_2 加一个sql执行耗时记录   -- 完成
星华的两个存储过程迁移到实例1  结果表同步到实例2 停止调度实例2任务  -- 进行中
dwd_sc_bdp_warehouse_stock_daily_erp 切换到datax_web  -- 完成 
fe_to_dwd  fe_to_dwd2  切换到datax_web  -- 完成
货架商品的宽表同步  切换到datax_web  -- 完成

call sh_process.dm_ma_kpi_data_daily(subdate(curdate(),1));  新增存储过程  dm_ma_kpi_data_daily  测试ok  1分钟  03：18

'dwd_shelf_product_sto_sal_day30',
'dm_op_valid_danger_flag', --  调整到06：01
'dm_ma_shelf_sale_2week',
'dm_ma_shelf_product_temp',
'dm_fill_operation_kpi_for_management',
'dm_ma_shelf_product_monitor',
'dm_op_kpi_area_product_sat_rate',
'dm_ma_shelf_user_stat',
'dm_ma_user_monthly',
'dm_ma_user_weekly'

 
dm_op_flags_res_area_two 每周一 06：13-- 06：22  05:59
dm_op_offstock_five  每日 06：14-- 06:22
dm_ma_area_daily_two 每日 06：18-- 06:21  05:27

dm_op_machine_unsale_flag_two 07:06 07:09  06:22
dm_op_fill_not_push_order_stat 07:09 -07:12  06:29
dm_op_manager_offstock_abnormal  07:08-07:10  07:00

fe_dm.dm_op_shelf_product_fill_update2  同步到实例2 
fe_dwd.`dwd_out_of_system_auto_order_insert`

datax_project_name	table_name_one	table_name_two	erp_frequency	delete_flag	remark	load_time
-- datax_feods_d_op_fill_dwd_erp	feods.d_op_machine_fill_update	fe_dm.dm_op_machine_fill_update	每日	1	\N	2020-05-07 16:51:44
-- datax_feods_d_op_fill_dwd_erp	feods.d_op_shelf_product_fill_update	fe_dm.dm_op_shelf_product_fill_update	每日	1	\N	2020-05-07 16:51:44
-- datax_feods_d_op_fill_dwd_erp	feods.d_op_smart_shelf_fill_update	    fe_dm.dm_op_smart_shelf_fill_update	每日	1	\N	2020-05-07 16:51:44
-- datax_feods_d_op_fill_dwd_erp	feods.d_op_smart_shelf_fill_update_his	fe_dm.dm_op_smart_shelf_fill_update_his	每日	1	\N	2020-05-07 16:51:44

datax_project_name	table_name_one	table_name_two	erp_frequency	delete_flag	remark	load_time
d_op_auto_push_fill_date_erp	fe.sf_shelf_fill_day_config	fe_dwd.dwd_sf_shelf_fill_day_config	每日	1	\N	2020-05-07 16:51:44
-- d_op_auto_push_fill_date_erp	feods.d_op_auto_push_fill_date	fe_dm.dm_op_auto_push_fill_date	每日	1	\N	2020-05-07 16:51:44
-- d_op_auto_push_fill_date_erp	feods.d_op_auto_push_fill_date_his	fe_dm.dm_op_auto_push_fill_date_his	每日	1	\N	2020-05-07 16:51:44

datax_project_name	table_name_one	table_name_two	erp_frequency	delete_flag	remark	load_time
dwd_fillorder_requirement_information_erp	fe_dwd.dwd_fillorder_requirement_information	fe_dwd.dwd_fillorder_requirement_information	每日	1	\N	2020-05-07 16:51:44


dm_op_shelf_product_start_fill_label
dm_op_shelf_product_fill_suggest_label -- 部署实例1 时间23：30左右 同步到实例2  完成

op_shelf_week_product_stock_detail_tmp  这个表看下能否从实例1删除掉? 回复：这个表现在是保留近4个月的数据，当时是考虑到有时候一些临时需求可以用到，和星华沟通，可以只保留近一周的数据（100多万），因为货架周动销率的任务d_op_shelf_active_week每天执行都要用到，所以该表作为中间表不删。
d_op_su_shelfcross_stat 做停删操作？ 回复：这个表没有azkaban任务用到，可以在存储过程里面把这个表的数据更新删掉
sp_kpi2_unsku_shelf  这个存储过程可以做停删操作了？  回复： 这个任务的结果表 fjr_kpi2_unsku_shelf（正式运营商品满足率） 没有其他azkaban调度任务用到，网易有数抽取任务：运营kpi2_SKU不足货架数 也已经禁用了，可以做停删操作，该任务没有迁移到实例2；
sp_users_day_stat 确定一下这个任务是否停掉了。表是否能删除 回复： 任务之前已停止，结果表已删除
sp_op_sto_cdays  这个存储任务做停删的操作？ 回复：实例1无任务用到，网易有数没有任务用到，没有迁移到实例2，可以停止 d_op_sto_cdays



 # 目标表
select * from test.dm_ma_sp_sale_daily; # 1542 万
# 存储过程
call test.dm_ma_sp_sale_daily(subdate(curdate(),1));  -- 完成 06：06

sp_op_fill_day_sale_qty_erp 同步任务切换到datax_web 5分钟 并且前推至02：06同步  -- 完成
sp_dm_sc_preware_monthly_kpi  这个存储过程也停掉 -- 完成
sh_prewarehouse_coverage_rate  这个要停掉 sp_dm_sc_preware_monthly_kpi -- 完成

    如业务需求，fe_dm.`dm_op_shelf_product_trans_out_list`目前开发在实例1使用，而之前说统一在实例2建表给开发使  -- 完成
1、fe_dm.dm_op_shelf_product_trans_out_list 和 fe_dm.dm_op_shelf_product_trans_out_his 目前实例1任务无关联（唐进帮忙再确认下）；
2、确认无关联后，唐进帮忙把实例1 sp_op_shelf_product_trans_out_list 存储过程停掉并删除；从实例2 dm_op_shelf_product_trans_out_list 同步到实例1使用，数据量10万左右，同步频率：每天；
3、以上处理完成后，世龙帮忙删除实例1 报表fe_dm.dm_op_shelf_product_trans_out_his（实例2已经有截存，实例1不需要了）。

#实例2 变更表与存储过程
    # 目标表
select * from test.dm_ma_shelf_sale_daily;
select * from test.dm_ma_shelf_sale_weekly;
select * from test.dm_ma_shelf_sale_monthly;
    #存储过程
call test.dm_ma_shelf_sale_daily(current_date,0);
call test.dm_ma_shelf_sale_weekly(subdate(curdate(),1));
call test.dm_ma_shelf_sale_monthly(subdate(curdate(),1));

select * from test.dm_ma_shelf_sale_daily;为实时任务 必须找未运行时间同时替换

feods.dm_ma_shelfInfo_extend  同步到实例2 -- 完成

修改json文件 -- 完成
ALTER TABLE fe_dwd.`dwd_shelf_day_his`  
ADD COLUMN `online_GMV`  DECIMAL(18,2) DEFAULT '0.00' COMMENT '线上系统GMV' AFTER `users`;

ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `online_pay_amount`  DECIMAL(41,2) DEFAULT '0.00' COMMENT '线上系统实收' AFTER `online_GMV`;


还有fe_dm.dm_op_shelf_sku_situation，这个表可以只保留一个月的数据 -- 已处理


fjr_area_product_dfill 这个执行停删的操作

fe_dm.`dm_op_kpi_unsku` 我查不到实例2 的存储过程，帮我看下这个存储过程什么时候开始跑，什么时候跑完

dm_prewarehouse_stock_detail           -- 2020-08-18 01:26:47 调整到 03：22
dm_finance_instock_sales_outstock_two  -- 2020-08-01 02:04:44 无任务依赖  调整到03：40
dm_sc_business_area_preware            -- 2020-08-18 02:22:47 无任务依赖 调整到03：46
dm_lo_zone_daily_data                  -- 2020-08-18 01:48:47 无任务依赖  调整到 03：10
dm_op_shelf_gmv_split                  -- 2020-08-18 02:02:47 无任务依赖  调整到 03：11
dm_lo_campus_manager_level             -- 2020-08-18 02:05:47 无任务依赖  调整到 03：27
dwd_lo_school_order_item               -- 2020-08-18 02:06:47 无任务依赖  调整到 03：28
dwd_shelf_machine_slot_history         -- 2020-08-18 02:07:47 无任务依赖  调整到 03：29
dm_pub_shelf_grade                     -- 2020-08-18 02:09:47  可以调整到04：20之前 调整到 03：34
dwd_lo_prewarehouse_fill_order_item_month   -- 2020-08-18 02:11:47 无任务依赖  调整到 03：37
dm_op_type_revoke_close_day             -- 2020-08-18 02:18:47 无任务依赖 调整到 03：38
dm_lo_manager_performance_report_everyday_for_month   -- 2020-08-18 02:17:47 无任务依赖  调整到03：40
dm_pub_user_integral_result             -- 2020-08-18 02:19:47  无任务依赖  调整到03：41
dm_op_newshelf_quality                  -- 2020-08-18 02:20:47 无任务依赖  调整到03：43
dm_op_ds7p_sal_fil                      -- 2020-08-18 02:21:47 无任务依赖  调整到03：43
dm_op_shelf_product_type_mgmv           -- 2020-08-18 02:20:47 无任务依赖  调整到03：44
-- dwd_op_dim_date_three                -- 2020-08-18 02:30:47 暂时不调整 很多任务依赖
dm_ma_shelf_sale_monthly                -- 2020-08-18 02:37:47  无任务依赖  调整到03：47
dm_sc_oms_stock_daily                   -- 2020-08-18 02:44:47 无任务依赖  调整到03：47
dm_manager_shelf_statistic_result       -- 2020-08-18 02:44:47  无任务依赖  调整到03：57
dm_mp_shelf_stat_monitor                -- 2020-08-18 02:45:47 无任务依赖  调整到03：48
dm_op_type_revoke_active_num            -- 2020-08-18 02:45:47 无任务依赖 调整到03：49
dm_new_product_gmv                      -- 2020-08-18 02:46:47  调整到09：50之前即可  调整到03：50




dm_finance_instock_sales_outstock_two	dm_mp_finance_statement_log
dm_finance_instock_sales_outstock_two	dm_mp_lead_warehouse_temp_table_main
dm_lo_campus_manager_level	dm_lo_campus_manager_level
dm_lo_manager_performance_report_everyday_for_month	dm_lo_manager_performance_report_everyday_for_month
dm_lo_manager_performance_report_everyday_for_month	dwd_lo_fulltime_manager_history_record
dm_lo_zone_daily_data	dm_lo_zone_daily_data
dm_manager_shelf_statistic_result	dm_manager_shelf_statistic_result
dm_ma_shelf_sale_monthly	dm_ma_shelf_sale_monthly
dm_mp_shelf_stat_monitor	dm_mp_shelf_stat_monitor
dm_new_product_gmv	dm_new_product_gmv
dm_op_ds7p_sal_fil	dm_op_ds7p_sal_fil
dm_op_newshelf_quality	dm_op_newshelf_quality
dm_op_shelf_gmv_split	dm_op_shelf_gmv_split
dm_op_shelf_product_type_mgmv	dm_op_shelf_product_type_mgmv
dm_op_type_revoke_active_num	dm_op_type_revoke_active_num
dm_op_type_revoke_close_day	dm_op_type_revoke_close_day
dm_prewarehouse_stock_detail	dm_prewarehouse_stock_detail
dm_pub_shelf_grade	dm_pub_shelf_grade
dm_pub_user_integral_result	dm_ma_user_integral_statistic
dm_sc_business_area_preware	dm_sc_business_product_preware_stock_daily
dm_sc_oms_stock_daily	dm_sc_oms_stock_daily
dwd_lo_prewarehouse_fill_order_item_month	dwd_lo_prewarehouse_fill_order_item_month
dwd_lo_school_order_item	dwd_lo_school_order_item
dwd_shelf_machine_slot_history	dwd_shelf_machine_slot_history




唐进好：
  
    该需求需要新增2个调度任务，  -- 完成
   test.dm_sc_new_product_estimate_weekly(subdate(curdate(),1));  每周一执行， 06:00
   test.dm_sc_new_product_estimate_monthly(subdate(curdate(),1));  每月1号执行， 06:28

执行时间大概有3分钟，调度时间看你这边安排，8点钟之前能执行完就好。


sh_order_item_twomonth 确定一下这个任务是否停止了 ? 回复： 8月10号经婷姐确认任务可停止，也执行停止调度，具体的表数据要不要删除需要婷姐确认。
sp_op_shelf_user_month_stat  看下这个任务是否能停删？回复：该任务暂时不能停，有好几个任务使用到到其中的三个结果表
d_ma_new_product_daily_statistics 看下这个存储过程是否能停删？ 回复：该表没有被其他任务用到，其对应的任务另一个结果表 fe_dm.dm_ma_area_daily 也没有被其他任务用到。
表 feods.pj_boss_data_history 能否删除？回复：该表数据4月份就停止更新，没有被其他任务用到，可以删除。

sp_d_mp_boss_data_shelf6 这个做停删的操作?  回复： 对应的调度任务7月24号已停止，还有一个表可以删掉，其他的表你之前已经删掉了；
d_ma_unsalable 这个做停删的操作？回复：这个表没有被其他任务用到，可以停删。对应的调度任务已停止调度。
fjr_kpi_np_inqty 这个表 做停删操作？ 回复：该表去年底数据已停止更新，调度任务已停止，可删除。
prc_project_process_source_aim_table_info_bak 看下这个备份的表，能不能删除？回复：可删除。
fjr_st_fill_stat 这个表确定一下是否能删除？ 回复：该表数据今年4月份已停止更新，可删除。
d_op2_shelf7_product_sale 这个表确定一下是否能删除？回复：该表今年2月份已停止更新数据，可删除。
d_en_zd_scan_order 看下这个表能否删除？回复：该表没有对应的任务更新数据，可删除。
fe_dwd.dwd_sf_shelf_product_weeksales_detail 实例2的，帮我确认一下是否能删除? 回复：可以停止，并停止datax同步任务


ALTER TABLE fe_dwd.`dwd_relation_dc_prewarehouse_shelf_day_all`
ADD COLUMN `WHETHER_CLOSE` INT(2) DEFAULT '2' COMMENT '是否关闭(1：是、2：否)DICT' AFTER `shelf_id`;
这个表添加了一个字段。你需要修改一下json文件


sp_abnormal_order.fjr_abnormal_order_shelf_product 这个表看能否停止了？回复：对应的表没有其他azkaban任务用到，网易有数的抽取也禁用了，但是对应的存储过程包括4个结果表，两个网易有数抽取用到，两个禁用，另一个禁用的 fjr_abnormal_order_user 应该也可以删了。
表 zs_day_sale_total 确定一下是否能删除? 回复：该表数据今年4月份已停止更新，可删除。
表 d_op_routine_self 确定一下是否能删除？ 回复：该表没有任务用到，网易有数也没有用到，可删除。
prc_d_ma_high_gross.d_ma_high_gross 确定一下是否能删除？ 回复：没有azkaban任务用到，网易有数也没有用到，应该可以删除。确定删除，需要告诉我停止调度任务。-- 已停止
d_en_mall_week1_channel_user 确定一下是否能删除？ 回复：该表去年7月份就没有更新数据，可以删除。
feods.d_en_wastage_item 确认一下是否能删除？ 回复：该表没有数据，也没有对应的存储过程，可以删除。
fjr_newshelf_quality。feods.fjr_newshelf_quality 看下能否删除？ 回复：该表没有被其他azkaban调度任务用到，网易有数的抽取任务也禁用了，应该可以删掉，确定删掉后，我停止调度任务。 -- 已停止
feods.d_en_group_admin_emp  这个表不确定是否能删除。无表用到，又担心可能有用。建议同步到实例2的dw_history下。然后删除实例1上的数据。回复：该表去年11月份数据已停止更新。回复：数据已同步到实例2备份，表可以删掉。
表 d_op_machine_unsale_flag 需确定是否能删除 ？ 回复：该表数据今年4月份已停止更新，可删除。
prc_d_en_qz_emp_order。feods.d_en_qz_emp_order  这个存储任务对应的表是否能删除？ 回复：该表去年11月份就已停止更新数据，可删除。
d_en_mall_week_channel_user 这个表确定一下是否能删除？回复：该表去年11月份就已停止更新数据，可删除。
feods.fjr_price_sensitive_stat_month  确定一下这个表能否做停删的操作？回复：该表没有被任务用到，也迁移至实例2，对应的调度任务（每月1号）将停止掉。 -- 已停止
sp_op_product_shelf_stat。feods.d_op_dim_product_area_normal  这个存储过程和表是否能删除？ 回复：该表不可以删除，sp_op_offstock 任务用到。
prc_d_ma_shelf_paytype_sale_monthly。d_ma_shelf_paytype_sale_monthly 表和存储过程做停删的操作。停掉存储任务后删除 ? 回复： 该任务6月份已停止，表可以删除。
sh_area_sale_dashboard。pj_area_sale_dashboard_history  这个看下是否能停删操作？ 回复：history的表作为中转，当天用完当天清空数据，该调度任务不可停止，其中结果表：feods.pj_area_sale_dashboard，网易有数在使用。
d_op_sp_avgsal7 看下这个表能否在实例1做停删？ 回复：不可以删除，因为 zs_shelf_product_flag 这个调度任务在使用。
sp_kpi2_shelf_gmv_uprate_month。feods.fjr_kpi2_shelf_gmv_uprate_month 看下这个存储过程和表能否删除？ 回复：该表azkaban和网易有数都没有用到，可以删除，确定删除后，我停止调度任务。 -- 已停止
d_op_shelf_active_week 这个表已经在实例2上有了，看下实例1上能否做删除操作？ 回复：该表对应的任务已迁移至实例2，但是实例1还有任务在使用，暂时不可删除。
feods.pj_city_unsalable_his 看下这个表能否删除？  回复：该任务7月份就已停止，没有azkaban任务用到，网易有数也没有用到，可以删除。
feods.fjr_fill_area_product_stat 这个表能否删除？ 回复：该表数据今年4月份就已停止更新了，任务已迁移至实例2，可以删除
sh_outstock_day。sf_order_item_temp  这个存储过程中的表是可以停掉的。在存储过程中注释掉。回复：temp表没有azkaban任务和网易有数任务用到，是否能删需要找婷姐确认，对应的存储过程不能停止调度。如果可删表，需要修改存储过程。


#实例2 迁移   -- 完成
    # 目标表
select * from fe_dm.dm_ma_autoshelf_kpi_daily ;
select * from fe_dm.dm_ma_AutoShelf_SalesFlag_kpi_daily  ;
    #存储过程
call test.dm_ma_autoshelf_kpi(subdate(curdate(),1));  05:29  

-- prc_d_ma_shelf_sale 调整到 01:38
-- sh_area_sale_dashboard  07:08 调整到 07:03
-- prc_dm_ma_area_shelfType_kpi_weekly  07:18 调整到 07:23


-- 朱星华任务部署 dm_op_shelf_product_zerosale_monitor 实例2 测试ok 耗时6分钟 每日更新，不需要结存  每日06：23执行一次
-- 慧敏任务部署 dwd_ma_member_level_ulc_record 实例2  测试ok 每月一号调度  耗时 10分钟  03:27
-- 伟铨任务部署 dm_ma_sectype_kpi_daily 测试ok 每日 30sec  停止调度实例1任务 每天 07：52
-- 伟铨任务部署 dm_ma_sectype_kpi_monthly 测试ok 每日 1.5分钟  停止调度实例1任务 每天 07：56
实例2的fe_dwd.sf_shelf_check_recent32 这个表，云峰要求动态保留62天的数据。你那边帮忙修改一下。数据量不大，大概总共50W左右  -- 已处理
test.`d_sc_preware_kpi`有做部分调整，已测试，时间降低2分钟，麻烦更新到实例2中对应存储过程。 -- 已处理  dm_sc_preware_kpi  改为每周一执行

看下实例1 feods.shelf_product_14days_stock 是否可以删除掉了。
fe_dwd.dwd_shelf_product_day_all_recent_32  包含了最近14天的数据了？ 回复：是可以替换，但是因为任务调度时间的原因，已经加上32天宽表结存数据量很大，导致任务耗时较久。建议不替换，采取每次依赖的任务执行完后，将该表数据清空处理。
实例1表feods.d_sc_preware_shelf_sales_daily 做停删操作? 回复： 这个表可以删掉，没有azkaban和网易有数任务用到，但是需要修改存储过程。具体表数据清理需要找婷姐确认。
帮我看下 fe_dwd.dwd_user_order_id 这个表能不能删除？回复：这个表可以删
看下 feods.d_op_routine_classification 这个表能否删除? 回复：这个表应该是之前家荣自己梳理做的运营的表，对其他任务无影响，可以删除。
看下feods.sf_third_user_balance_day 这个表能否删除？ 回复：这个表不能删除，是将数据同步到实例2，实例1没有其他任务用到，网易有数也没有用到实例1的表和实例2同步表。如果需要删掉表，则停止实例1任务调度和同步任务。
feods.fjr_flag5_shelf  做停删的操作? 对应的任务已停止调度，可删

select * from fe_dm.dm_ma_HighProfit_list_monthly @唐进 这个每个月同步一次到实例2 回复： 每月1号 07:36 同步到实例2   -- 已处理
DELETE FROM fe_dm.dm_ma_HighProfit_list_monthly WHERE sdate= DATE_FORMAT(SUBDATE(CURRENT_DATE,INTERVAL 1 MONTH),'%Y-%m-01')  
select * from fe_dm.dm_ma_sectype_kpi_daily;
select * from fe_dm.dm_ma_sectype_kpi_monthly;@李世龙

#实例2 迁移报表
    # 目标表
select * from fe_dm.dm_ma_sectype_kpi_daily;
select * from fe_dm.dm_ma_sectype_kpi_monthly;
    #存储过程
call test.dm_ma_sectype_kpi_daily(subdate(curdate(),1));  --  每天 07：52
call test.dm_ma_sectype_kpi_monthly(subdate(curdate(),1));  -- 每天 07：56


SELECT COUNT(1) FROM dm_op_s_offstock WHERE sdate='2020-08-25' -- 173206  每日05:55同步
SELECT COUNT(1) FROM dm_op_offstock_s7 WHERE sdate='2020-08-25' -- 3002   每日05:55同步


唐进好： -- 完成

     需求1、2需要修改下列存储过程，已测试，可call，麻烦修改一下，谢谢~
     (1) test.sp_d_sc_preware_daily_report 
    （2）test.sp_dm_sc_preware_monthly_kpi
   

星华脚本更新 dm_op_new_shelf_suggest_list 对应的同步任务也需要更新 dm_op_new_shelf_suggest_list_erp -- 完成
李世龙任务部署 dwd_shelf_transaction_exception_info 实例1 同步到实例2
脚本优化 dm_op_shelf_product_zerosale_monitor 
脚本优化 dwd_ma_member_level_ulc_record
zs_shelf_member_flag_erp 同步任务拆成一个表同步，同步到实例2后 通过存储过程调度 将数据写入history表  feods.zs_shelf_member_flag 同步 20分钟 -- 完成
dm_shelf_member_flag_history 实例2 每周一结存 07;29执行  -- 完成
伟铨任务部署 dm_ma_users_all_weekly 实例2  停止实例1   CALL sh_process.dm_ma_users_all_weekly(CURRENT_DATE())  -- 测试ok 4.7分钟 每周跑一次  每周一 04：12 完成
fe.sf_shelf_workbench_follow_result_record -- > fe_dwd.`dwd_sf_shelf_workbench_follow_result_record`  同步到实例2. 数据比较少，就全量同步吧 完成

#实例2 新建报表
    # 目标表
select * from test.dm_ma_area_shelftype_kpi_daily; 
select * from test.dm_ma_area_shelftype_kpi_weekly;
select * from test.dm_ma_area_shelftype_kpi_monthly;
    #存储过程
call sh_process.dm_ma_area_shelftype_kpi_daily(subdate(curdate(),1)); #5s 每天  -- 测试ok 部署实例2 每日 02:43 完成
call sh_process.dm_ma_area_shelftype_kpi_weekly(subdate(curdate(),1)); #4m 每天 -- 测试ok 部署实例2 每日 03:28 完成 调整到04：40
call sh_process.dm_ma_area_shelftype_kpi_monthly(subdate(curdate(),1)); #2m 每天 -- 测试ok 部署实例2 每日 04:10 完成
dm_ma_shelf_info_daily  每日运行 call sh_process.dm_ma_shelf_info_daily(subdate(curdate(),1));  -- 测试ok 1.5分钟   每日 07:28 完成


  重构前置仓模块存储过程，需要增加存储过程
  test.dwd_sc_preware_product_outbound_fill() -- 前置仓出库宽表  测试ok 10sec 部署实例2   每日 05:43 完成
  test.`dwd_sc_preware_product_sales`()       -- 前置仓销售宽表 测试ok 2分钟 部署实例2    每日 02:52 完成
  test.dm_sc_preware_product_stat(subdate(current_date,1)) -- 前置仓综合指标宽表，此过程最晚不能超过6:35 测试ok 0.4min 部署实例2 每日 06:10 完成
  
  dm_sc_preware_balance 06:12 调整到 05:32  -- 完成
  dm_sc_preware_wave_cycle 06:31 调整到 05:44 -- 完成
  
  feods.d_sc_preware_wave_cycle --> dm_sc_preware_wave_cycle  需补全历史数据  完成

  
  吹防任务部署 dm_pub_shelf_product_sale_sum_90 实例2  -- 耗时5分钟 每月3号 02:18 实例2调度，同步到实例1的时间是每月3号02：42 完成 

  
ALTER TABLE fe_dwd.`dwd_fill_day_inc`  -- 修改json文件 完成
ADD COLUMN `WAY_BILL_NO` VARCHAR(80) DEFAULT NULL COMMENT '物流单号' AFTER `SHELF_DETAIL_ID`;



唐进，  -- 已完成
         帮忙在实例一按序号的顺序部署以下的存储过程：
          1.  dm_mp_sales_cost_sublist             12：10 调整到 每日 01：22   每月2号 06：00-09：00之间 06:02
          2.  dm_mp_sales_income_sublist           12：17 调整到 每日 01：25   每月2号 06：00-09：00之间 06:05
          3.  dm_mp_loss_total_sublist             12：26 调整到 每日 02：57   每月2号 06：00-09：00之间 07:20
          4.  dm_mp_withstand_loss_sublist         12：35 调整到 每日 03：33   每月2号 06：00-09：00之间 07:25
          5.  dm_mp_depot_remain_sublist           12：46 调整到 每日 04：38   每月2号 06：00-09：00之间 07:41
          6.  dm_mp_prewarehouse_remain_sublist    12：49 调整到 每日 04：41   每月2号 06：00-09：00之间 07:43
          7.  dm_mp_shelf_remain_sublist           12：53 调整到 每日 07：45   每月2号 06：00-09：00之间 07:45
          8.  dm_mp_purchase_sell_stock_summary    13：06 调整到 每日 08：20   每月2号 06：00-09：00之间 08:20
         每个月1号的11:30 ~ 13:30之间跑上个月整月的数据，你根据存储过程的时长来调控跑数时间，如有疑问，及时沟通，谢谢。

call sh_process.dm_mp_sales_cost_sublist(date_format(subdate(current_date,interval 1 month),'%Y-%m-01'),date_format(current_date,'%Y-%m-01'));  -- 1 min 49 sec           12：10
call sh_process.dm_mp_sales_income_sublist(date_format(subdate(current_date,interval 1 month),'%Y-%m-01'),date_format(current_date,'%Y-%m-01'));  -- 3 min 10 sec         12：17
call sh_process.dm_mp_loss_total_sublist(date_format(subdate(current_date,interval 1 month),'%Y-%m-01'),date_format(current_date,'%Y-%m-01'));   -- 3 min 8 sec           12：26
call sh_process.dm_mp_withstand_loss_sublist(date_format(subdate(current_date,interval 1 month),'%Y-%m-01'),date_format(current_date,'%Y-%m-01'));  -- 5 min 30 sec       12：35
call sh_process.dm_mp_depot_remain_sublist(date_format(subdate(current_date,interval 1 month),'%Y-%m-01'),date_format(current_date,'%Y-%m-01'));  -- 3.180 sec            12：46
call sh_process.dm_mp_prewarehouse_remain_sublist(date_format(subdate(current_date,interval 1 month),'%Y-%m-01'),date_format(current_date,'%Y-%m-01'));  -- 4.120 sec     12：49
call sh_process.dm_mp_shelf_remain_sublist(date_format(subdate(current_date,interval 1 month),'%Y-%m-01'),date_format(current_date,'%Y-%m-01'));  -- 6 min 53 sec         12：53
call sh_process.dm_mp_purchase_sell_stock_summary(date_format(subdate(current_date,interval 1 month),'%Y-%m-01'),date_format(current_date,'%Y-%m-01'));  -- 19 min 47 sec 13：06
		 

sf_manager_operate_log     -->fe_dwd.`dwd_sf_manager_operate_log`  这个表迁移到实例2上 已完成
fe.sf_shelf_machine_fault  -- >fe_dwd.`dwd_sf_shelf_machine_fault`  这个表迁移到实例2上.时间你来安排 已完成

fe_temp.sf_product_activity_item  sf_product_activity_item_erp 切换到datax-web  00:49:50 -- 已完成

fe_dwd.dwd_shelf_machine_slot_type  -- 调整到03：20 
fe_dwd.dwd_group_emp_user_day  -- 改为每月1号同步一次
dm_mp_finance_month_area_income -- 调整到08：11


这个存储过程 sp_kpi_avggmv_month 的表 fjr_kpi_ns_avggmv_month 可停止。另外一张表还在切换中。可看下？ 回复：这个表可以删掉，另外一张表我看了一下没有任务用到
看下这个表：fjr_kpi_ns_avggmv_month 能否在存储过程中删除掉？ 回复：实例1无其他任务依赖此任务结果表，feods.fjr_kpi_avggmv_month 这个结果表应该也可以删除，网易有数抽取已禁用，可以删除
看下这个表：d_op_shelf_info_month 能否在存储过程中删除掉？回复：该表可以删掉，存储过程不能停
看下这个表 d_op_product_area_shelftype_dfill 是否有依赖。我已经把脚本里的表注释掉了。看下是否有其它依赖。没有，我就删除掉这个表？回复： 这个表没有其他任务用到，注释后可以删掉 -- 存储过程代码已注释该表
feods.d_op_shelf_info_month 在实例1上做停删的操作？ 回复：这个表可以删掉，没有任务用到，我将对应的存储过程中这个表的代码注释掉。-- 存储过程代码已注释
sp_kpi_avggmv_week.fjr_kpi_ns_avggmv_week 这个存储过程是否可停删的操作？ 回复： 实例1无其他任务依赖此任务结果表，feods.fjr_kpi_avggmv_week这个结果表应该也可以删除，网易有数抽取已禁用，可以删除 -- 已停止调度
sh_shelf_level_ab 这个存储过程做停删的操作? 回复：实例1无其他任务依赖此任务结果表，网易有数抽取已禁用，可以删除 -- 存储过程只保留一个表 供开发使用

prc_d_en_order_user 调整到01：09  -- 已调整

    该需求需要更新实例2中对应过程  -- 已完成
CALL test.`dm_sc_preware_product_stat`
CALL test.`sp_d_sc_preware_balance`
CALL test.`sp_d_sc_preware_daily_report`



将0902切换的datax_web任务mapping表维护一下  -- 完成
婷姐任务部署：dm_sc_preware_suggest_fill_match_days ，每周一 实例2  -- 测试ok 耗时0.3分钟 每周一 07：42 完成
云峰任务部署：dwd_shelf_check_recent62 每日  部署实例1 同步实例2    -- 测试ok 耗时3秒  每日03：31实例1调度 同步到实例2时间 03：45：30  完成
李吹防任务部署 dwd_shelf_transaction_exception_info 实例1 同步到实例2  -- 先全量更新数据  每日01：08执行，01：26全量同步到实例2 完成

星华任务部署 dm_op_shelf7_abnormal_product_sum_two 实例2 -- 测试ok 耗时6秒 每日04：41 完成
星华任务部署 dm_op_shelf7_product_sale_month 实例2       -- 测试ok　耗时　40秒　每日 09：54 完成

星华任务部署 dm_op_order_sku_relation 实例2 -- 测试ok 耗时15分钟 需优化后再部署 完成




dm_op_shelf_type_product_sale_month 这个存储过程需要迁移到实例2上。实例1上的历史数据同步一下到实例2上。 然后实例1上的评估一下是否可停删操作
prc_dm_ma_area_shelfType_kpi_daily.feods.dm_ma_area_shelfType_kpi_daily  这个存储任务和表做停删的操作？回复： 这个需要找伟铨确认能不能停止调度，目前还在调度中……
fe_dm.dm_ma_users_all_weekly  实例1的表做停删的操作？回复：这个之前就给你反馈了，你后续记录一下吧。


feods.d_op_product_shelf_dam_month 这个表做停删的操作? 回复：这个表没有任务用到，可以删除。


星华：这个表能帮忙迁移到实例2吗，fe.machine_product_change_apply -- 完成 每日00：42全量同步 
ALTER TABLE fe_dwd.`dwd_shelf_product_weeksales_detail`  -- 完成
ADD COLUMN `w53` INT(11) NOT NULL DEFAULT '0' COMMENT '第53周销量标识' AFTER `w52`;  这个表添加了一个字段。你的json文件需要修改一下

   该需求需要增加调度任务 test.dm_sc_preware_suggest_fill_match_days(subdate(curdate(),1)），已测试，可以call ; 
   
参数为日期 t-1，每周一执行一次，时间满足依赖任务执行就好，要在8点钟之前执行都没有问题；

call sh_process.dm_sc_preware_suggest_fill_match_days(subdate(curdate(),1));


shelf_product_stock_7days_tmp

feods.d_op_offshelf  做停删操作? 回复： 这个表没有被其他azkaban任务用到，网易有数任务也已禁用，可以删除，但是需要停掉掉任务 sp_op_offshelf -- 已停止
feods.d_op_shelf_board_month 做停删操作？回复：不可停止，实例1同步结果表数据到实例2，如果要删除，需要确认实例2的表可以删除。
feods.d_op_fill3_detail  做停删的操作？回复：实例1无任务用到，但是实例1数据是直接同步到实例2，网易有数抽取有使用，不可删除该表
feods.shelf_product_stock_7days_tmp 做停删的操作？ 回复：该表无其他任务使用，但是结果表有任务用到，不可以删除。 
feods.D_MA_area_product_sales_data_daily 做停删的操作？ 回复：该表没有其他任务使用，网易有数任务也已禁用，可以删掉。sp_D_MA_area_product_sales_data_daily -- 已停止
feods.d_op_shelfs_area 做停删的操作？回复：实例1同步结果表数据到实例2，无azkaban用到但是有网易有数用到，不可以删除
feods.d_op_shelfs_dstat 做停删的操作？回复：实例1同步结果表数据到实例2，无azkaban 无网易有数用到，但不可以删除，因为同一个存储过程中有表依赖这个表，所以不可删除。
feods.d_op_shelf_firstfill 做停删的操作？ 回复： 实例1无任务用到，但是实例1数据是直接同步到实例2使用，有任务使用，不可删除
sp_abnormal_order  这个存储过程都可以删除。回复： 已停止调度   -- 已停止

dwd_shelf_check_recent62 全量同步到实例2 -- 已同步
feods.zs_product_dim 帮我确定一下能否删除？回复：可以删，没有任务用到，数据到18年底就没有更新了。

d_op_product_shelf_stat   (回复： 可以删)   
d_op_product_shelf_sto_month（回复：不可以删，对应的存储过程sp_op_product_shelf_stat只保留这一个表的加工）
d_op_product_shelf_dam_month   (回复： 可以删)
d_op_product_shelf_sal_month (回复： 可以删)
d_op_dim_product_area_normal (回复： 可以删)
d_op_product_area_stat_month (回复： 可以删)
d_op_product_area_sal_month_large (回复： 可以删)
d_op_product_shelf_sal_month_large (回复： 可以删)


feods.d_ma_activity_remove_area_product  回复：没有对应的存储过程更新数据，也没有其他任务用到，可以删除
feods.d_ma_temp_shelf_product_info 回复：没有对应的存储过程更新数据，也没有其他任务用到，可以删除
feods.shelf_sku_stock_7days_tmp  这三个表做停删的操作 回复：之前已经反馈了，这个表不能删



feods.d_ma_wechat_community_user 做停删的操作? 回复： 这个表没有任务用到，应该可以删除，但是我看了一下这个是店主维表，看有没有利用价值。
feods.dm_ma_area_shelfType_kpi_daily  找伟铨确定删除？回复：已经停止调实例1的任务调度，可删除
feods.pj_shelf_check_month 这个做停删的操作。网易有数用到的表已经禁用掉了？回复：这个表没有被其他任务用到，我已经将该任务停止了调度。
这三个表做停删的操作：d_op_product_area_shelftype_dgmv 回复：这个任务sp_op_product_shelf_stat 在使用，不能删
d_op_product_area_shelftype_wgmv 回复：这个表之前已经反馈过删掉
d_op_product_area_shelftype_mgmv 回复：这个表之前已经反馈过删掉

以这个为准
-- 存储过程中产生的表，如果没有用到，可以进行注释掉。
feods.pj_preware_sales_seven (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
feods.d_sc_preware_outbound_seven_day (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
feods.d_sc_preware_outbound_three_day (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
feods.d_sc_preware_fill_seven_day (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
feods.preware_outbound_monthly (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
feods.d_sc_warehouse_outbound_forteen (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
feods.d_sc_warehouse_outbound_forteen_total (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
feods.d_sc_warehouse_outbound_daily  (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
fe_dm.dm_sc_warehouse_outbound_monthly_total (回复：可以删除，因为没有任务用到，已在脚本中注释掉）
fe_dm.dm_sc_warehouse_stock_monthly (回复：可以删除，因为没有任务用到，已在脚本中注释掉）




实例2的这个表要停删 sf_shelf_check_recent32

shelf_product_14days_stock
shelf_product_stock_14days
pj_area_sale_dashboard_history  这三个表能不能删除掉。用临时表代替？ 
feods.d_op_dim_date 确定一下是否能做停删的操作


  DELETE
  FROM
    feods.fjr_shelf_wgmv
  WHERE sdate = @week_end;  ADDDATE(SUBDATE(SUBDATE(CURRENT_DATE, 1), WEEKDAY(SUBDATE(CURRENT_DATE, 1))), 6)
  
    DELETE
  FROM
    feods.fjr_shelf_mgmv
  WHERE month_id = @y_m;   DATE_FORMAT(SUBDATE(CURRENT_DATE, 1), '%Y-%m')
  
feods.fjr_shelf_wgmv                        fe_dm.dm_shelf_wgmv  -- 31648  每日03：45：00 同步到实例1
feods.fjr_shelf_mgmv                        fe_dm.dm_shelf_mgmv  -- 30920  每日03：45：00 同步到实例1
  
  
  
DELETE FROM fe_dm.dm_shelf_mgmv WHERE month_id=DATE_FORMAT(SUBDATE(CURRENT_DATE, 1), '%Y-%m')
DELETE FROM fe_dm.dm_shelf_wgmv WHERE sdate = ADDDATE(SUBDATE(SUBDATE(CURRENT_DATE, 1), WEEKDAY(SUBDATE(CURRENT_DATE, 1))), 6)
  


d_mp_weixin_payment   feods.d_en_fx_balance 需要全量同步一次 目前实例2还没有任务用到


    该需求需要修改实例2对应存储过程：
     test.dm_sc_preware_product_stat
     test.sp_d_sc_preware_wave_cycle
	 

fe_dm.`dm_op_su_stat` 
fe_dm.`dm_op_su_u_stat`
fe_dm.`dm_op_su_s_stat` 需要将实例2的这三个表同步到实例1上

你上面这个操作完成之后告知我一下。时间尽量和实例1的 d_op_su_uptolm_stat 的时间01:45分保持一致 回复：实例2的对应的任务根据依赖关系调度时间在2点多，同步到实例1的时间无法保持和实例1一致。

	 
-- 开发已经调整好时间，后续需要修改实例1 和实例2的调度任务时间
方法名	执行时间	任务描述	调整后执行时间	日志关键字
everyDayExecuteUpdateShelfProductSalesFlag	3:30	每天凌晨三点三十分修改货架商品的销量标识	2:10	定时任务更新未对接系统的货架销售标识耗时
everyDayUpdateShelfProductRiskFlag	4:10	每天凌晨4点10更新货架商品风险标识	2:20	每天凌晨2点20更新自贩机商品明细数据的风险标识耗时

-- 核对datax——web切换任务数据  完成
-- 维护fe库 字段属性 字段数量 防止datax同步出错 
-- 建datax同步任务的监控 完成 
-- sserp.T_STK_MISDELIVERYENTRY 考虑到增量同步数据量的异常情况 根据需要设置为每月1号全量同步一次
-- 监控脚本 1.添加去除非正式调度任务时段的记录 2.防止每月一号调度 执行时间为每月一号
-- 切换剩下的datax任务


-- 已更新json文件
ALTER TABLE fe_dwd.`dwd_prewarehouse_base_day`
ADD COLUMN `REVOKE_TIME` DATETIME DEFAULT NULL COMMENT '撤架时间' AFTER `SHELF_STATUS`;

ALTER TABLE fe_dwd.`dwd_prewarehouse_base_day`
ADD COLUMN `operation_time` DATETIME DEFAULT NULL COMMENT '前置仓运营时间' AFTER `REVOKE_TIME`;


维护fe库 字段属性 字段数量 防止datax同步出错  更新实例2fe同步过来的表所有不为null的字段
完成金蝶数据源切换及46个表同步                   -- 完成
azkaban任务监控（实例1 实例2） 实例1好实现 实例2 -- 已完成实例2 datax同步任务监控 azkaban调度任务监控
datax同步任务监控（失败任务告警及任务影响）      -- 完成
完成任务失败导致同时触发导致CPU高的构思          -- 完成
sserp表完成切换 并且处理了数据不一致的问题       -- 完成
监控脚本 1.添加去除非正式调度任务时段的记录

部署世龙的两个任务
1.sp_kpi2_shelf_gmv_uprate_week
3.dwd_shelf_product_production_date_change -- 每日 10：40 耗时3分钟    部署实例2在其他时间段 12点多  生产日期拉链表
4.dwd_shelf_product_near_date_change       -- 每日 10：50 耗时2.5分钟  部署实例2其他时间段   临期计算开始日期拉链表
5.dwd_shelf_product_first_fill_time_change -- 每日 11：00 耗时2.5分钟  部署实例2其他时间段  第一次上架时间的拉链表
6.dwd_shelf_product_risk_source_change     -- 每日 11：10 耗时2分钟    部署实例2   风险来源拉链表
7.dwd_shelf_product_danger_flag_change     -- 每日 10：40 耗时2分钟    部署实例2   风险标识拉链表
8.dwd_shelf_product_new_flag_change        -- 每日 11：40 耗时2分钟    部署实例2   新品标识拉链表
9.dwd_shelf_product_shelf_fill_flag_change  -- 每日

2.dwd_pub_supplier_machine_bill_all  01:26  01:40同步到实例2
 fe_group.sf_group_contract  -- > fe_dwd.dwd_sf_group_contract
 fe_group.sf_group_contract_shelf -- > fe_dwd.`dwd_sf_group_contract_shelf`
 fe_group.sf_group_supply  -- > fe_dwd.`dwd_sf_group_supply`
 fe_dwd.dwd_pub_supplier_machine_bill_all  --  fe_dwd.dwd_pub_supplier_machine_bill_all
 
 
 INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('sf_group_contract_erp','fe_group.sf_group_contract','fe_dwd.dwd_sf_group_contract','每日');
 INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('sf_group_contract_shelf_erp','fe_group.sf_group_contract_shelf','fe_dwd.dwd_sf_group_contract_shelf','每日');
 INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('sf_group_supply_erp','fe_group.sf_group_supply','fe_dwd.dwd_sf_group_supply','每日');
 INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('dwd_pub_supplier_machine_bill_all_erp','fe_dwd.dwd_pub_supplier_machine_bill_all','fe_dwd.dwd_pub_supplier_machine_bill_all','每日');



call  `dwd_en_order_blacklist`() 调度每天凌晨  -- 费航宇 已部署 00：30

唐进好：-- 已修改

 该需求需要修改对应存储过程，已测试，可以call
test.dm_sc_new_product_estimate_weekly
,test.dm_sc_new_product_estimate_monthly


唐进好：-- 已修改
     
实例2 test.sh_outstock_day 有 优化，麻烦同步更新一下，已测试，谢谢！

唐进好： -- 已完成和修改

     需要新增一个存储过程，并修改2个存储过程：
-- 新建 CALL test.`dm_sc_preware_pp_ap_stat`(subdate(curdate(),1)) ； 前置仓层专题多层级表汇总，每天执行，t-1，最好在7点半之前运行; 耗时3分钟  每日06：17执行
-- 修改 test.`dwd_sc_preware_product_outbound_fill`(subdate(current_date,1))；由于补货订单状态变化，因此循环更新n天数据;
-- 修改 test.`sp_d_sc_warehouse_preware_stock_outbound`   优化 过程

星华任务部署：dm_op_shelf_product_30_zerosale_sum  -- 每周二 08：53
星华任务部署：dwd_op_shelf7_slot_item_monitor -- 每日 06：11  耗时5分钟

原来通过feods.`d_en_org_area`同步到实例2上，现在改成fe_dwd.`dwd_en_org_area`表同步到实例2上。
fe_dwd.`dwd_en_org_area` --  fe_dwd.`dwd_en_org_area`


实例1上的
prc_d_en_order_user  存储过程对应的四张表
d_en_user_channle_first   -->  dm_en_user_channle_first
d_en_order_user           -->  dm_en_order_user                             
d_en_new_user_balance     -->  dm_en_new_user_balance
sf_third_user_balance_day -->  dm_pub_third_user_balance_day



ALTER TABLE fe_dwd.dwd_pub_activity_order_shelf_product
ADD COLUMN `REAL_TOTAL_PRICE` DECIMAL(18,2) DEFAULT '0.00' COMMENT '实际应付金额_商品' AFTER `DISCOUNT_AMOUNT`;


ALTER TABLE fe_dwd.dwd_pub_activity_order_shelf_product
ADD COLUMN `COMBINED_PRICE` DECIMAL(10,2) DEFAULT '0.00' COMMENT '活动优惠金额(activity.COMBINED_PRICE)' AFTER `REAL_TOTAL_PRICE`;


ALTER TABLE fe_dwd.dwd_pub_activity_order_shelf_product
ADD COLUMN `sense` INT(11) DEFAULT NULL COMMENT '订单商品组合类型（1.正常显示，2.商品中逗号的）' AFTER `COMBINED_PRICE`;

这个表添加三个字段。你修改一下json文件。我修改实例1和2的表。包括temp下的表

#实例2 新增存储过程
    # 目标表
select * from test.dm_ma_life_cycle_monthly;

    #存储过程
call test.dm_ma_life_cycle_monthly(subdate(curdate(),1)); #每天 耗时2分钟  每日 07：52  -- 完成

下周三升级mysql 需要对实例1的脚本进行排查
朱星华的任务部署 -- 已处理
朱慧敏的py文件修改

修复依赖关系漏洞  -- 只要当天没有按时执行就是已停止  ； 在查执行状态的时候也需要根据是否未true进行查，否则很容易出现导致依赖的任务执行频率发生错该，导致任务执行延时



#实例2 新增表与存储过程
    # 目标表
select * from test.dm_ma_kpi_monthly ; -- 测试ok 时间设置04:09 完成
    #存储过程
call test.dm_ma_kpi_monthly(subdate(curdate(),1)); #每天上班前

调整user_research 因为升级修改了crr4的脚本


#实例2 新增表与存储过程
    # 目标表
rename table test.dm_ma_plc_kpi_daily to fe_dm.dm_ma_plc_kpi_daily; -- 测试ok 耗时1min 每日07：36 完成
    #存储过程
call test.dm_ma_plc_kpi_daily(subdate(curdate(),1)); #每天



存储过程添加注释说明（计划一两周内完成） -- 已丰声通知
每周五调度统计实例1和实例2的fe库表字段数 -- 已完成 待调度
同步表数据一致性校核  -- 待完成
同步表风险点梳理 -- 已完成
执行超时等待 -- 已完成
脚本优化  吹防嫌疑人监控优化 -- 由原来的1分多钟（不稳定是几十分钟） 优化到12秒钟

dm_pub_area_product_stat 03：56 调整到04：01  同步任务调整到04：17  -- ok 
prc_dm_ma_shelfInfo_extend 06：59调整到06：49 -- ok 

#实例2 新增表与存储过程
    # 目标表
rename table test.dm_ma_coupon_use_weekly to fe_dm.dm_ma_coupon_use_weekly;  
    #存储过程
call test.dm_ma_coupon_use_weekly(subdate(curdate(),1)); #每周一 -- 每周一02：37


唐进，
         帮忙在实例一按序号的顺序部署以下的存储过程：
          1.  call sh_process.dm_mp_purchase_sell_stock_daily_shelf(subdate(current_date,1),current_date); 每日 03：23 耗时8分钟
          2.  call sh_process.dm_mp_purchase_sell_stock_daily_prewarehouse(subdate(current_date,1) , current_date); 每日 03：36 耗时0.8分钟 dm_mp_product_purchase_sell_stock_daily
          3.  call sh_process.dm_mp_purchase_sell_stock_daily_depot(subdate(current_date,1) , current_date); 每日 03：45耗时0.2分钟

         通过传参每天更新昨日的数据，根据存储过程的时长和依赖来安排即可，如有疑问，及时沟通，谢谢。
		 

唐进好：
    该需要需要修改对应存储过程，历史数据不可回溯，不要call
   1、test.dm_sc_preware_product_stat  
   2、test.sp_d_sc_preware_daily_report   -- dm_sc_preware_daily_report
   
   
   
#实例2 变更表与存储过程
    # 目标表
select * from test.dm_ma_sectype_kpi_daily;
    #存储过程
call test.dm_ma_sectype_kpi_daily(subdate(curdate(),1)); #每天

-- 李吹防 每日调度 实例2 05：16
CALL sh_process.dm_op_shelf_product_risk_stock


过滤掉周一下午执行的任务，防止上午的任务一直等待延时
伟铨优化 sh_shelf_flag 由6分钟优化到4分钟
唐进优化松林脚本 dm_mp_withstand_loss_sublist 由原来的7/8分钟优化到1分钟
唐进优化松林脚本 dm_mp_purchase_sell_stock_summary 由原来的15分多钟优化到12分钟
唐进优化松林脚本 dm_mp_loss_total_sublist 
唐进优化航宇脚本 dwd_en_fx_consumption_rate_report_to_fhy 由10多分钟 7 min 10 sec
唐进优化航宇脚本 dwd_en_fx_receive_rate_report_to_fhy 由6多分钟 3多分钟
唐进优化松林脚本 dm_product_fill_number_sorting  由10多分钟优化到几分钟


航宇任务部署
dwd_en_fx_consumption_rate_report_to_fhy -- 耗时8分钟 每月1号 03：30
dwd_en_fx_receive_rate_report_to_fhy     -- 耗时3分钟 每月1号 03：14

fe_dwd.dwd_group_order_coupon_day 同步到实例2 根据add_time同步当天的数据，replace   -- 完成 每日01：26同步

世龙优化 dwd_group_order_coupon_day 由原来的4分多钟优化到不到1分钟

dwd_fill_day_inc_recent_two_month 01:57 调整到01：51
dwd_user_day_inc_to_dwd 01：32 调整到 01：28

dwd_group_wallet_log_business 调整为每日同步 改为增量同步  -- 完成

@唐进好：

     实例2世龙活动宽表已更新，新建存储过程 test.dm_sc_shelf_promote_result   CALL sh_process.dm_sc_shelf_promote_result(SUBDATE(CURRENT_DATE,1));  -- 每日 07：22

频率：每天一次，时间同实例1 sp_d_sc_shelf_promote_result；  
迁移：将实例1中feods.d_sc_shelf_promote_result 同步到实例2中fe_dm.dm_sc_shelf_promote_result（已建表）；



feods.`BI_storage_cost_price_main_table`   -- fe_dwd.BI_storage_cost_price_main_table
feods.D_MP_Lead_warehouse_temp_table_main  -- fe_dwd.D_MP_Lead_warehouse_temp_table_main
feods.D_MP_shelf_system_temp_table_main    -- fe_dwd.D_MP_shelf_system_temp_table_main
feods.D_MP_storage_verify_temp_table_main  -- fe_dwd.D_MP_storage_verify_temp_table_main
feods.D_MP_finance_statement_log           -- fe_dwd.D_MP_finance_statement_log
 



唐进，
         麻烦帮忙停掉实例一以下两个储存过程的调度，这是老进销存脚本的调度任务，已确认可以停掉：
         sp_d_mp_shelf_access_sales_stock
         sp_finance_instock_sales_outstock
		 
		 
fe.`sf_prewarehouse_apply`  --> fe_dwd.dwd_sf_prewarehouse_apply
fe.`sf_prewarehouse_apply_bind_shelf`  --> fe_dwd.dwd_sf_prewarehouse_apply_bind_shelf

dwd_lo_depot_refund_order 调整到06：03

sp_shelf_product_detail 调整到07：44
-- 调整以下三个网易有数抽取任务的时间
区域有库存货架数_new
经规--临期下架库存
dm_op_shelf_product_danger_month



唐进好：

    需要新增存储过程 CALL test.dm_sc_shelf_ap_sto_sal_stat_daily(T-1)，明天添加就好;  -- 每日04：31 test.dm_sc_product_ap_shelf_sto_sal_stat_daily (t-1)
    参数：T-1
    频率：每天执行一次；
    任务时间：只要依赖不冲突，能在7点之前跑完就好；
    用时：1分40秒左右；

吹防任务部署  耗时2秒钟
dm_fault_online_solve_96h  -- 每日04：10

 dm_op_package_config_two 调整到05：57 预计 06：04执行完
 
 dm_op_offstock_integrate -- 每日06：27调度
 dm_op_su_shelfcross_stat_eight -- 调整到02：10
 
 sp_shelf_profile_week  -- 已停止
 
 shelf_sku_stock_7days_tmp  这个存储过程，可以用我的fe_dwd.dwd_shelf_day_his 里面的skus 和库存数替换掉。你看下 然后就可以解耦 sh_area_sale_dashboard 这个存储过程中的表了  -- 已切换完成 shelf_sku_stock_7days_tmp任务已停止
 
 d_op_product_area_shelftype_dgmv  在实例1上使用了一天的数据。可以做成物理临时表。这个表对应到实例2上是脚本生成的。因此可以在脚本中把这个表中的数据清空掉。你核对一下。如果能清空数据，你就直接在脚本中加上清空的操作。然后反馈给我，我修改一下我维护的信息   -- 已改为临时表
 
 dm_op_shelf_type_product_sale_month 这个存储过程在实例2上已经实现了。实例1上没有保留的必要。评估一下能否删除实例1上的存储过程和表  -- 你休陪产假前将问题反馈给你了，这个有问题，暂时不能停止
 dwd_relation_dc_prewarehouse_shelf_day_all  这个存储过程里面，婷姐修改添加了一下货架的宽表。你看下时间上是否有冲突。原来的宽表是没有红框的表的  -- 不影响的，因为婷姐的那个business_area是她自己维护的，还有一个是货架宽表，基本没影响
 
 
 
 prc_d_ma_user_flag1 
 dm_op_su_shelfcross_stat_eight -- 调整到02：10
 
 营销工具
 
 sp_op_shelf_user_month_stat  01：45--01：59
 
 prc_d_ma_user_flag1 02：18  调整到 03：11
 dm_op_su_shelfcross_stat_eight 02：54-- 03：09 -- 调整到02：10 耗时15分钟 02：30前执行完 ，02：40同步（包含700多万数据同步 耗时7分钟，1000万数据同步 耗时10分钟）  03：00前同步完
 
 
 dm_op_valid_danger_flag  调整到04：30
 
 
 需要新增2个存储过程：
（1） test.`dm_sc_new_product_taste_weekly`(T-1) ;  每周一，时间不冲突就好，大概1分钟40秒；   -- 每周一 06:06
（2） test.`dm_sc_new_product_taste_monthly`(T-1) ; -- 每月1号，大概需要3分钟； -- 每月1号 06:45
 
 d_sc_active_result，d_sc_promote_shelf_list
 SELECT * FROM feods.`prc_project_relationship_detail_info`WHERE source_table IN ('feods.d_sc_active_result','feods.d_sc_promote_shelf_list')

 
 -- 吹防任务部署
 dwd_check_extend_recent_62     -- 2分钟  每日 01：24  同步时间：01：51
 -- 李世龙
 dwd_pub_product_area_pool_item -- 2秒 每日00：42 同步时间：每日00：54


CALL sh_process.dwd_datax_table_check_rows_num_not_fe  -- 2 min 19 sec

CALL sh_process.dwd_datax_table_check_rows_num2_not_fe  -- 2 min 9 sec



drop table if exists fe_dwd.`dwd_shelf_city_weather_day_hour`;
CREATE TABLE fe_dwd.`dwd_shelf_city_weather_day_hour` (
  `city_name` varchar(32) NOT NULL COMMENT '城市名',
  `sdate` varchar(16) NOT NULL COMMENT '日期',
  `current_temperature` decimal(3,1) DEFAULT NULL COMMENT '当前气温（℃）',
  `wind_direction` varchar(32) DEFAULT NULL COMMENT '当前风向',
  update_time varchar(32) comment '网站天气数据更新时间',
  temp_list varchar(128) comment '未来时段天气变化',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据采集入库时间',
  PRIMARY KEY (`city_name`,`sdate`,add_time)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='货架所在城市天气信息表（到天小时粒度）'


https://weather.cma.cn/web/weather/58367.html
20.8
无持续风向 微风
2020/10/26 15:55更新
['17:00', '20:00', '23:00', '02:00', '05:00', '08:00', '11:00', '14:00'] ['19.7℃', '18.3℃', '17.3℃', '16.7℃', '16℃', '17.6℃', '21.8℃', '22.3℃']
https://weather.cma.cn/web/weather/59289.html

 fe_data.`sf_shelf_product_counted_record`  -- fe_dwd.`dwd_sf_shelf_product_counted_record` 完成
 
 https://lishi.tianqi.com/shenzhen/202009.html
 
 sserp.T_STK_MISDELIVERYENTRY  --> 同步到实例2  （吹防）
 
 #实例2 新增表与存储过程  --（伟铨） 完成
    # 目标表
select * from test.dm_ma_marketing_fee;
    #存储过程
call test.dm_ma_marketing_fee(subdate(curdate(),1)); #每天


fe.user_member_wallet  --> dwd_user_member_wallet 同步至实例2上。通过 WALLET_ID 做主键，LAST_UPDATE_TIME 做每天增量同步。执行时间建议在3-5点之间。 世龙 完成

-- 英南任务部署 call sh_process.dm_op_prewarehouse_monitor  每日07：26  完成

-- 婷姐sserp表同步到实例1 ods层 t_bd_supplier T_BD_SUPPLIER已部署同步到实例1 完成  
-- 同步到实例2 完成
sserp.T_BD_SUPPLIER -- fe_dwd.dwd_sserp_t_bd_supplier  (每日全量同步）
sserp.T_BGJ_STOCKFQTY -- fe_dwd.dwd_sserp_t_bgj_stockfqty (每日结存）


dwd_group_wallet_log_business  -- 调整到 00：40

prc_d_en_gross_margin_rate_order  -- 调整到 00：41

dm_op_area_product_level  -- 星华 实例2  每日 04：12 完成
dm_op_shelf_product_fill_season_factor  -- 英南 实例1 06：22 只跑一次 完成


dwd_relation_dc_prewarehouse_shelf_day_all 00：32 -00：33 这个表的时间调整到fe_dwd.`dwd_shelf_base_day_all` 00：34--00：36  这个表之后。

dwd_shelf_day_his 00：37 用到 dwd_relation_dc_prewarehouse_shelf_day_all 00：32 -00：33

dwd_shelf_base_day_all 由现在的00：34 调整到00：30 
dwd_relation_dc_prewarehouse_shelf_day_all 由现在的00：32 调整到 00：35

dm_en_fx_balance_three  -- 实例2 世龙
pj_poorderlist_day 帮我评估一下，这个存储过程在实例1上是否可删除 -- 已注释掉在途的表

唐进好：-- 吴婷

   该需求需要修改过程 
  test.sp_d_sc_preware_daily_report  -- dm_sc_preware_daily_report
  test.dm_sc_preware_product_stat
  
唐进好：
该需求需要修改对应存储过程，暂不call，数据无法追溯
1、test.dm_sc_preware_product_stat 
2、test.sp_d_sc_preware_wave_cycle  -- dm_sc_preware_wave_cycle

天气对水饮 泡面 月活和复购


@朱星华 
dm_op_shelf_price_sensitivity
dm_op_shelf_sku_situation     这两个表在实例1上的。需要迁移到实例2上。

我有存储过程跑的结果不一样，麻烦帮我核对一下  -- 已处理
sh_process.dm_sc_new_product_estimate_weekly 和test.dm_sc_new_product_estimate_weekly的差别
sh_process.dm_sc_new_product_estimate_monthly 和test.dm_sc_new_product_estimate_monthly

fe_dm.`dm_op_shelf_product_risk_stock` 这个表可以3-13号，不需要跑数据，然后其他时间跑数据，每月2号结存上月的数据.主要是一些审核是在1号进行，所以2号的数据才是都审核玩的  -- 完成

慧敏任务部署 dm_ma_activity_tmp_tag -- 实例1 22：35 执行 耗时一分钟 完成


-- hadoop搭建 已完成
export HADOOP_HOME=/opt/modules/hadoop-2.8.5
export PATH=$PATH:$HADOOP_HOME/bin:$HADOOP_HOME/sbin


fe_goods.sf_group_product_audit  -- fe_dwd.dwd_sf_group_product_audit   这个表根据 last_update_time 增量更新到实例2上  完成 00：50：10 同步

-- 迁移朱星华任务到实例2 同步到实例1  -- 已切换
dm_op_shelf_price_sensitivity  02：30之后即可 耗时0.5min  每日02：37调度  每日02：55 同步到实例1  由每日执行改为每月执行 同步任务改为每月同步 
dm_op_shelf_sku_situation      04：30之后即可 耗时1.5min  每日04：14调度  每日05：01 同步到实例1
李吹防任务部署 实例1 每日00：47 执行 同步到实例2 每日 01：05   --完成
dwd_pub_supplier_machine_apply_settle_bill 耗时0秒  

-- 优化 dm_op_product_area_sal_month_large_eight，dm_op_shelf_product_30_zerosale_sum 执行计划走错，优化后时间可以缩短0.3-0.6分钟 --完成

-- 天气数据有异常（1.以下三个城市天气抓取错误，2.最高最低问题没有正负号）  已处理
无锡市  --巫溪     wuxi1
泰州市  -- 台州    taizhou2
清远市  -- 清原    qingyuan3

-- 新增的同步表没有加入存储过程计算数据量 完成
dwd_update_dwd_table_info 02：10调整到 02：08
dm_ma_high_gross 06：14调整到06：22

-- 约翰通数据抓取 已完成 
-- api  -- 已解决
-- token  -- 已解决
-- request payload 参数传递  -- 已解决
-- 存在的问题 各种字段的对应关系以及字段内各类别对应关系解析（包括各种金额之间计算的对应关系） -- 待和业务确认



feods.user_research   -- fe_dm.dm_pub_user_research 已同步一周数据


call sh_process.dm_ma_temp_data_jwq(curdate());   实例1  这周六七点10分跑 -- 07：10 已完成

#实例2 新增表与存储过程  -- 每日02：40
    # 目标表
select * from test.dm_ma_product_flag;
    #存储过程
call test.dm_ma_product_flag(); #每天越早越好




月销量明细  d_op_shelf_firstfill 月销存明细 -- 世龙任务部署 均部署在实例2  已完成

sp_op_sp_sale_detail -- dm_op_sp_sale_detail  测试ok 0.6min  每日调度 02：30 之后即可 每日02：39
结果表：feods.d_op_sp_sale_detail      -- fe_dm.dm_op_sp_sale_detail 增量量更新 两个实例当月份数据量一致  先不同步历史数据

sp_op_shelf_info                       -- dm_op_shelf_firstfill_two 测试ok 0.4min 每日调度 02：30 之后即可  每日02：50
结果表：feods.d_op_shelf_firstfill     -- dm_op_shelf_firstfill 全量更新 两个实例数据量一致       部署后需要停掉同步任务  d_op_shelf_firstfill_erp
结果表：feods.d_op_fill3_detail        -- dm_op_fill3_detail    增量量更新   两个实例数据量一致   部署后需要停掉同步任务  d_op_fill3_detail_erp

sp_op_sp_sal_sto_detail                -- dm_op_sp_sal_sto_detail   测试ok 1min  在调度任务  dm_op_sp_sale_detail 之后即可 每日02：56
结果表：feods.d_op_sp_sal_sto_detail   -- fe_dm.dm_op_sp_sal_sto_detail 部署后需要停掉同步任务  d_op_sp_sal_sto_detail_erp



#实例2 迁移 对应实例1 prc_dm_ma_HighProfit_list_monthly（每月1号07：23）  测试ok   -- 需要同步历史数据量 实例2调度 然后数据同步到实例1  停止 dm_ma_highprofit_list_monthly_erp 同步，停止实例1调度 已完成
    # 目标表
select * from fe_dm.dm_ma_highprofit_list_monthly;  -- 每月1号 07：06 同步到实例1时间：每月1号07：23
    #存储过程
call test.dm_ma_highprofit_list_monthly(curdate());


prc_d_en_gross_margin_rate_order  -- dm_en_gross_margin_rate_user_day_five   有问题
 
dwd_en_combine_shop_order -- 航宇 部署实例2 每日 02：42

-- 待处理  不然实例2的数据会越来越多
dwd_pub_activity_order_shelf_product  load_time >= DATE_FORMAT(DATE_ADD(NOW(), INTERVAL 0 DAY),'%Y-%m-%d')  --temp表未分区
-- 两个实例宽表数据核对

实例1-实例2
dwd_check_base_day_inc:18693437 - 18693543 = -106
dwd_fill_day_inc_recent_two_month:11875905 - 11907510 = -31605
dwd_fill_day_inc:13161289 - 41956432 = -28795143
dwd_group_order_refound_address_day: 10735177 - 10735177 = 0
dwd_order_item_refund_day:30796450 - 30796450 = 0
dwd_pub_activity_order_shelf_product:6971269  - 3380404 = 3590865
dwd_pub_order_item_recent_two_month:14042103 - 14152339 = -110236
dwd_shelf_day_his:13089450 - 13089450 = 0
dwd_user_day_inc:10329590 - 10329590 = 0
dwd_activity_invitation_information:14223609 - 14223989 = -380


-- 唐进需要跟进处理  需要迁移到实例2上去
dm_op_autoshelf_stock_and_sale （每周一）          -- dm_op_autoshelf_stock_and_sale 测试ok 耗时少于1分钟 待下周验证数据后切换
d_op_shelf_active_week （每日）                    -- 很早就切换了  实例1的 dm_op_autoshelf_stock_and_sale（每周一） 任务依赖该表
op_shelf_week_product_stock_detail_tmp （每周一）  -- 很早就切换了  实例1 d_op_shelf_active_week （每日） 任务依赖这个表

实例1依赖关系： 无  --> op_shelf_week_product_stock_detail_tmp (每周一)-->  d_op_shelf_active_week (每日,调整为每周一) --> dm_op_autoshelf_stock_and_sale （每周一） --> 无


dm_ma_activity_user_join_temp -- 朱慧敏 部署实例1 测试ok 8秒



 fe_dwd.`dwd_op_shelf_product_activity_item` @唐进  需要把这个表同步到实例2上。只需同步一次
 
 
 test.sh_preware_product_sale
 
 
dm_ma_coupon_shelf_daily  第一次跑在 7:04 4小时一次
prc_dm_ma_coupon_bi_daily 第一次跑在 7:05 2小时一次
dm_ma_discount_activity_shelf_daily 第一次跑在 7:02 4小时一次
-- 已完成调整
SELECT * FROM feods.`sf_dw_task_log` WHERE task_name='dm_ma_coupon_shelf_daily'                -- 03:27 07:27  11:27 每隔4小时跑一次   第一次跑在 7:04 4小时一次
SELECT * FROM feods.`sf_dw_task_log` WHERE task_name='prc_dm_ma_coupon_bi_daily'               -- 03:02 07:02  11:02 每隔4小时跑一次   第一次跑在 7:05 2小时一次
SELECT * FROM feods.`sf_dw_task_log` WHERE task_name='dm_ma_discount_activity_shelf_daily'     -- 03:28 07:28  11:28 每隔4小时跑一次   第一次跑在 7:02 4小时一次


#实例2 新建
    # 目标表  每小时执行一次 尽量靠近0点执行  -- 已完成
select * from test.dm_ma_shelf_sale_houly;
    #存储过程
call test.dm_ma_shelf_sale_houly(curdate(),0);

-- 调整抽取实例1网易有数8点的任务
-- 实例2优化
优化 dm_op_order_sku_relation               -- @time_109--@time_111  时间缩减 0.6分钟  索引问题 （优化效果不明显）
优化 dm_fill_shelf_action_total_history_two -- @time_2--@time_3 时间缩短2分钟 执行计划走错
优化 dwd_shelf_product_sto_sal_day30        -- 进行中 
优化 dwd_check_base_day_inc_to_dwd          -- 需要建立 SHELF_ID, PRODUCT_ID , CHECK_ID 索引  已修改索引
优化 dwd_op_shelf7_slot_item_monitor        -- 强制走索引  @time_6--@time_7  @time_8--@time_9  6.7 优化到2.3分钟
优化 dwd_pub_order_item_recent_two_month_two  -- 62天建分区表  删数据耗时占了一半时间



-- 已完成4个表同步
1、T_STK_STKTRANSFEROUT       分布式调出单基础信息，
2、T_STK_STKTRANSFEROUTENTRY  分布式调出单明细
3、T_STK_STKTRANSFERINENTRY   分布式调入单明细
4、T_STK_STKTRANSFERIN        分布式调入单基础信息

INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('T_STK_STKTRANSFEROUT','feng1.T_STK_STKTRANSFEROUT','sserp.T_STK_STKTRANSFEROUT','每日');
INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('T_STK_STKTRANSFEROUTENTRY','feng1.T_STK_STKTRANSFEROUTENTRY','sserp.T_STK_STKTRANSFEROUTENTRY','每日');
INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('T_STK_STKTRANSFERINENTRY','feng1.T_STK_STKTRANSFERINENTRY','sserp.T_STK_STKTRANSFERINENTRY','每日');
INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('T_STK_STKTRANSFERIN','feng1.T_STK_STKTRANSFERIN','sserp.T_STK_STKTRANSFERIN','每日');


fjr_abnormal_nsale_shelf_product  我上午迁到 fe_dm库先了。dm_op_abnormal_nsale_shelf_product 。刚汤云峰反馈这个表可以删除了。你帮我再确定一下是否可以删除  -- 可以删除

需要将fe_dwd.dwd_group_dictionary 同步到实例2上。已经建好表。每天同步即可。时间你来限定 



ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `BUSINESS_CHARACTERISTICS` TINYINT(2) DEFAULT NULL COMMENT '公司所在地方的商业特性(1: CBD写字楼区、2: 工业区、3: 商住混合区、4:住宅区、5: 商业区、6:政府单位、9: 其他)' AFTER `cover_num`;
添加了一个字段



-- 检查 已完成
ALTER TABLE fe_dwd.`dwd_shelf_product_day_all`
ADD COLUMN `LAST_UPDATE_TIME` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间' AFTER `add_user_id`;  这个表添加一个字段。我等下改下dataXXX


test.sp_d_sc_preware_balance  test.dm_sc_preware_product_stat  -- 修改 已完成


进进，麻烦帮我查一下 test.`sp_d_sc_warehouse_preware_stock_outbound`
和test.`sp_d_sc_preware_daily_report`执行时间，看看有么有可能 sp_d_sc_warehouse_preware_stock_outbound 这个更早执行？ 



实例2 任务更换:  -- 已完成
dm_ma_shelf_sale_daily 原任务停止,
call sh_process.dm_ma_shelf_sale_daily(subdate(curdate(),1)); 替换原任务,每天尽早执行一次.  -- call test.dm_ma_shelf_sale_daily(curdate(),0);  每日 02：36
call sh_process.dm_ma_shelf_sale_daily_realtime(curdate());  每天半小时执行一次.(同原来安排时间一致)  即每日00：10 开始 每隔半小时执行一次  





进进，麻烦帮我查一下 `dm_sc_warehouse_sku_shelf_cnt_two`  -- 已完成
和 dm_sc_preware_daily_report（06：38） 执行时间，看看有么有可能 dm_sc_warehouse_sku_shelf_cnt_two （07：52）这个更早执行？
dm_warehouse_product_presence      由现在地07：19 调整到04：29
dm_sc_warehouse_stock_monthly_five 由现在地07：32 调整到05：55
dm_sc_warehouse_sku_shelf_cnt_two  由现在地07：52 调整到06：28

-- 唐进需要跟进处理  需要迁移到实例2上去 已完成
dm_op_autoshelf_stock_and_sale （每周一）            -- dm_op_autoshelf_stock_and_sale 测试ok 耗时少于1分钟 待下周验证数据后切换
d_op_shelf_active_week （每周一）                    -- 很早就切换了  实例1的 dm_op_autoshelf_stock_and_sale（每周一） 任务依赖该表
op_shelf_week_product_stock_detail_tmp （每周一）    -- 很早就切换了  实例1 d_op_shelf_active_week （每周一） 任务依赖这个表
实例1依赖关系： 无  --> op_shelf_week_product_stock_detail_tmp (每周一 05:44:00)-->  d_op_shelf_active_week (每日,调整为每周一 09:51:00) --> dm_op_autoshelf_stock_and_sale （每周一） --> 无
实例1依赖关系： 无  --> dm_op_shelf_week_product_stock_detail_tmp (每周一 05:44:00)-->  dm_op_shelf_active_week (每日调整为每周一 09:51:00) --> dm_op_autoshelf_stock_and_sale （每周一 10：14） --> 无


-- d_op2_shelf_grade              每日04：12 耗时 10秒钟    朱星华     dm_pub_shelf_grade 测试ok  结果表无需同步，待该任务部署后，停止datax同步任务  d_op_shelf_grade_erp   
-- d_op_type_revoke_close_day     每日00：14 耗时3秒钟  需同步历史数据 dm_op_type_revoke_close_day 测试ok  李吹防
-- d_op_type_revoke_active_num    每日07：55  需同步历史数据  dm_op_type_revoke_active_num 测试ok  李吹防
-- d_op2_shelf_day_avg_gmv        每日03：06 耗时约1分钟 需同步历史数据 dm_shelf_day_avg_gmv  测试ok 朱星华
-- d_op_sp_avgsal7                每日09：45 耗时10秒钟   每天全量更新 无需同步历史数据  dm_op_sp_avgsal_recent_week   测试ok 朱星华  
-- op_shelf_week_product_stock_detail_tmp  每周一 03：22 无需同步历史数据    dm_op_shelf_week_product_stock_detail_tmp 测试ok 朱星华
-- d_op_shelf_type_product_sale 每周一09：40 耗时小于1分钟 需同步历史数据      dm_op_shelf_type_product_sale  测试ok  朱星华
-- d_op_shelf_active_week       每日03：27 耗时10秒 需同步历史数据   dm_op_shelf_active_week  测试ok  朱星华


-- CPU 情况监控

-- hive

-- 星华任务

-- 吹防任务部署  已完成
fe_dwd.dwd_sserp_T_BAS_BILLTYPE、 fe_dwd.dwd_sserp_T_BAS_BILLTYPE_L、 fe_dwd.dwd_sserp_T_STK_MISDELIVERY  、fe_dwd.dwd_sserp_T_STK_MISDELIVERYENTRY
fe_dwd.dwd_sserp_t_bas_billtype、 fe_dwd.dwd_sserp_t_bas_billtype_l、 fe_dwd.dwd_sserp_t_stk_misdelivery  、fe_dwd.dwd_sserp_t_stk_misdeliveryentry


-- 已完成部署同步
`sf_shelf_logistics_task_revoke` -->   fe_dwd.`dwd_sf_shelf_logistics_task_revoke`
`sf_shelf_logistics_task_move`   -->   fe_dwd.`dwd_sf_shelf_logistics_task_move`

 
select * from test.dm_ma_business_optunity_record ;
select * from test.dm_ma_business_optunity_stat_monthly;


    #存储过程 @唐进 每天调度一次
call test.dm_ma_business_optunity(subdate(curdate(),1));

dm_en_user_product_label_three 部署实例2 耗时一分钟   3个对应结果表数据需要同步到实例1，开发使用
-- 三个表全量同步
fe_dm.dm_en_product_sales_30day
fe_dm.dm_en_user_product_label
fe_dm.dm_en_product_label



@李世龙 @唐进 还需要同步一个表  -- 已完成部署同步
fe.sf_shelf_revoke_bak   -- fe_dwd.dwd_sf_shelf_revoke_bak
select * from fe.sf_channel_record 需要同步到实例2@李世龙  -- fe_dwd.dwd_sf_channel_record

dm_op_shelf_type_product_sale_unnatural -- 星华任务 部署实例2 已完成

fe_dm.`dm_op_shelf_product_risk_stock`   这个表从实例2同步到实例1  李吹防 每月20号同步一次本月数据 -- 已完成

唐进好： -- 已完成

改需求需要修改test中对应存储过程
test.`sp_d_sc_preware_wave_cycle`  -- dm_sc_preware_wave_cycle
test.`dm_sc_preware_new_product_flag`
test.`sp_d_sc_preware_daily_report`;  -- dm_sc_preware_daily_report
test.`dwd_sc_preware_product_sales`
test.`dm_sc_preware_product_stat`


ALTER TABLE fe_dwd.`dwd_user_day_inc`
ADD COLUMN `OPEN_ID` VARCHAR(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '用户在第三方平台的标识' AFTER `OPEN_TYPE`;


fe.`sf_shelf_revoke_specific_reason`  --> fe_dwd.`dwd_sf_shelf_revoke_specific_reason`  这个同步到实例2上。是维度表。全量同步即可。时间你来安排 已完成


唐进好：

     该需求需要修改 test.sp_warehouse_product_presence 对应存储出过程，麻烦更新一下；

-- dwd_pub_out_of_system_shelf_day_his 李世龙 部署实例1 每月4号 00：47

将 实例2的fe_dm.`dm_op_business_product_max_source` 同步到实例1上fe_dm.`dm_op_business_product_max_source`
每周1（实例2是每周一2:58分跑数的），同步时间你来安排。通过add_time 增量添加数据


sp_d_sc_preware_daily_report  -- dm_sc_preware_daily_report
dm_sc_preware_product_stat


dm_en_distribute_rank
prc_d_ma_shelf_sale_daily   
dm_op_shelf_fill_sku_stock

call sh_process.prc_d_ma_shelf_sale_daily(date_add(curdate(),interval -1 day))	

-- 实例1优化
优化 dm_en_distribute_rank 存储过程 执行计划走错 耗时由10几分钟缩减到1分钟 执行计划
优化 dwd_en_distribute_detail_fx 存储过程 耗时由6份多钟优化到0.5分钟以内   执行计划以及删除数据的时候索引字段运用了函数，导致索引失效
优化 dwd_en_fx_distribute_to_bdp 存储过程 耗时由4份多钟优化到0.2分钟以内   执行计划
-- 实例2优化
优化 dm_op_out_product_clear_efficiency_two 存储过程 @time_4--@time_5 耗时由6分多钟优化到4分多，减少2.5分钟
优化 dm_op_out_product_suggest_list 存储过程 @time_10--@time_12 耗时由2.8分多钟优化到1分，减少1.5分钟
优化 dm_op_association_analysis_week
优化 dm_op_product_list_manager_week 


-- 朱慧敏任务部署 实例2
由于需求需要，现需要部署实例2 dm库存储过程，辛苦唐进进行部署，谢谢。
实例2存储过程：sh_process.dm_ma_user_life_cycle。
更新频率：每周一更新一次

-- 实例2调整
prc_dm_ma_user_perfect_product  由每日02：23 调整到每日 02：14
dm_en_fx_balance_three          由每日02：35 调整到 每日 01：41
dm_ma_marketing_fee             由每日02：36 调整到 每日 01：39
dm_ma_business_optunity         由每日02：37 调整到 每日 01：40
dm_op_sp_sale_detail            由每日02：39 调整到 每日 01：44
dm_ma_user_life_cycle           -- 已部署 每周一 02：15
dm_ma_user_sale_weekly 时间设置在02：05，预计02：06执行完
dwd_pub_order_item_recent_two_month_two 时间改到01：10 耗时15分钟，预计01：25执行完
dm_op_su_shelfcross_stat_eight 时间改到01：53 耗时20分钟 预计02：13执行完
dm_ma_user_life_cycle 时间设置在02：15，耗时15分钟 预计02：30之前执行完

-- 实例1调整
dwd_shelf_product_day_all_update 由每日03：37 调整到 每日 02：47 预计03：00执行完
同步任务 dwd_shelf_product_day_all_erp 由每日03：57 （耗时14分钟）调整到 每日 03：10  预计03：25同步完


Dear 唐进：-- 待处理

            现需要把实例1  feods.user_research迁移至实例2 fe_dm.dm_pub_user_research，辛苦唐进进行存储过程的部署，谢谢。
            实例2存储过程：sh_process.sh_member_research_crr_1
                                      sh_process.sh_member_research_crr_2
                                      sh_process.sh_member_research_crr_3
                                      sh_process.sh_member_research_crr_4
            更新频率：每周一更新一次，任务时间需重新评估安排。

-- 修改json文件 全量同步数据
ALTER TABLE fe_dwd.`dwd_group_order_coupon_day`
ADD COLUMN  `received_platform` TINYINT(2) NOT NULL COMMENT '领取的平台 1，能量站 2，商城 3，店主 4，社区拼团 5，自贩机app  字典platform'
 AFTER `received_time`;
 
-- 世龙实例1存储过程更新 dwd_group_order_refound_address_day  已完成
-- 吹防任务部署 dm_op_shelf_product_discount_type 实例1 每周四 03：32 已完成

唐进好：

   麻烦更新一下test存储过程，
`sp_d_sc_preware_daily_report`  -- dm_sc_preware_daily_report
`sp_d_sc_preware_wave_cycle`  -- dm_sc_preware_wave_cycle
dm_sc_preware_product_stat  -- dm_sc_preware_product_stat

call sh_process.dm_sc_preware_product_stat(subdate(current_date,1));
call sh_process.dm_sc_preware_wave_cycle(subdate(current_date,1));
call sh_process.dm_sc_preware_daily_report(subdate(current_date,1));

再帮我更新一下这个 sp_d_sc_preware_daily_report


dwd_pub_discount_card_refund 世龙任务部署实例1 每日00：27执行  同步到实例2  00：54同步到实例2
部署时间要放在 dwd_shelf_day_his （00：37）这个存储过程前面。我要把这个数据融入到货架历史宽表里面  
 
ALTER TABLE fe_dwd.`dwd_pub_out_of_system_shelf_day_his`
ADD COLUMN  `shelf_type` VARCHAR(10) DEFAULT NULL COMMENT '订单来源,auto:智能柜 yht:自贩机'
 AFTER `shelf_id`;

 dwd_pub_out_of_system_shelf_day_his.AFTER_PAYMENT_MONEY 字段删除
 

ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `CARD_PAYMENT_MONEY` DECIMAL(20,2) DEFAULT '0.00' COMMENT '先享卡补款金额' AFTER `AFTER_PAYMENT_MONEY`;


唐进好：
   该需求需要更新test中 
   
sp_d_sc_preware_daily_report  -- dm_sc_preware_daily_report
dm_sc_preware_product_stat    -- dm_sc_preware_product_stat



实例2的 dwd_user_open_id 这个表要删除掉。看下是否有影响 


@唐进 麻烦帮我同步  test.`dwd_sc_dc2_instock_info`，test.`dwd_sc_dc2_outstock_info`，test.`dwd_sc_dc2_warehouse_stock_info` 

将这几个表的数据，同步到实例2的fe_dwd中对应的表  -- 已完成

fe.sf_instock_info 每天同步前天数据到         fe_dwd.dwd_sc_dc2_instock_info     dwd_sc_sub_dc_instock_info
fe.sf_outstock_info 每天同步前天数据到        fe_dwd.dwd_sc_dc2_outstock_info    dwd_sc_sub_dc_outstock_info
fe.sf_warehouse_stock_info 每天同步前天数据到 fe_dwd.dwd_sc_dc2_warehouse_stock_info   dwd_sc_sub_dc_warehouse_stock_info
 

进进，麻烦帮我更新一下test.d_sc_preware_sku_satisfy  -- dm_sc_preware_sku_satisfy

唐进好：
    麻烦修改需要对应存储过程，可以call，有问题再沟通 -- 已完成
test.dm_sc_preware_product_stat，       -- dm_sc_preware_product_stat
test.sp_d_sc_preware_daily_report       -- dm_sc_preware_daily_report
test.d_sc_preware_sku_satisfy（已修改） -- dm_sc_preware_sku_satisfy
 

帮我把实例2的 dwd_pub_work_day 同步到实例1上。我只更新了实例2的 -- 已完成

实例任务清理计划收集
实例2user_research部署 任务时段调整
hive测试 测试user_research的执行效率
添加datax同步任务，azkaban调度任务对网易有数的影响监控  -- 完成
梳理目前实例1 2 分区 以免超出分区导致任务报错  -- 完成


-- 梳理目前实例1 2 分区 以免超出分区导致任务报错
-- 实例1 7个表修改分区
ALTER TABLE feods.pj_area_sale_dashboard ADD PARTITION (PARTITION p202201 VALUES LESS THAN ('2022-02-01') ENGINE = InnoDB));
ALTER TABLE fe_dm.dm_prewarehouse_stock_detail ADD PARTITION (PARTITION p202112 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB);
ALTER TABLE feods.d_op_sp_sale_detail ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE feods.d_op_sp_sal_sto_detail ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE feods.d_op_sp_stock_detail ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE feods.d_op_sp_stock_detail_after ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE feods.d_sc_preware_daily_report ADD PARTITION (PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB);

-- 实例2 17个表修改分区
ALTER TABLE fe_dm.dm_area_sale_dashboard ADD PARTITION (PARTITION p202012 VALUES LESS THAN ('2021-01-01') ENGINE = INNODB);
ALTER TABLE fe_dm.dm_ma_shelf_sale_weekly ADD PARTITION (PARTITION p2021 VALUES LESS THAN ('2022-01-01') ENGINE = InnoDB);
ALTER TABLE fe_dm.dm_op_product_shelf_dam_month ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dm.dm_op_product_shelf_sal_month ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dm.dm_op_product_shelf_stat ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dm.dm_op_product_shelf_sto_month ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dm.dm_op_sp_sale_detail ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dm.dm_op_sp_sal_sto_detail ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dm.dm_prewarehouse_stock_detail ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dm.dm_sc_preware_product_stat ADD PARTITION (PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = INNODB);
ALTER TABLE fe_dm.dm_sc_preware_daily_report ADD PARTITION (PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = INNODB);
ALTER TABLE fe_dm.dm_prewarehouse_stock_outbound_detail ADD PARTITION (PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = INNODB);
ALTER TABLE fe_dwd.dwd_sc_preware_product_sales_stat ADD PARTITION (PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB);
ALTER TABLE fe_dwd.dwd_sf_coupon_use ADD PARTITION (PARTITION p202101 VALUES LESS THAN ('2021-02-01') ENGINE = InnoDB);
ALTER TABLE fe_dwd.dwd_shelf_product_stock_detail ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dwd.dwd_shelf_product_stock_detail_after ADD PARTITION (PARTITION p202101 VALUES IN ('2021-01') ENGINE = InnoDB);
ALTER TABLE fe_dwd.dwd_sf_product_fill_order_recent32 ADD PARTITION (PARTITION p2021q01 VALUES LESS THAN ('2021-04-01') ENGINE = InnoDB);


ALTER TABLE fe_dwd.`dwd_group_order_refound_address_day`
ADD COLUMN `order_user_name` VARCHAR(50) DEFAULT NULL COMMENT '下单人名称' AFTER `order_user_id`;

ALTER TABLE fe_dwd.`dwd_group_order_refound_address_day`
ADD COLUMN  `refund_pay_type_o` TINYINT(1) DEFAULT NULL COMMENT '支付类型 1微信二维码支付，2手工线下支付,4E币支付' AFTER `refund_amount_order`;

ALTER TABLE fe_dwd.`dwd_group_order_refound_address_day`
ADD COLUMN  `refund_finish_time_o` DATETIME DEFAULT NULL COMMENT '退款到账时间' AFTER `refund_pay_type_o`;


 fe_dwd.dwd_group_order_refound_address_day  这个表从实例1全量同步到实例2上一下。里面添加了新的字段 -- 已完成
 
 @唐进 fe_dwd.dwd_inv_lot_att_from_bdp , fe_dwd.`dwd_inv_lot_loc_id_from_bdp` 每日同步到实例2不做结存，truncate表，每天只同步当前的数据就好 -- 吴婷 已完成
 fe_dwd.`dwd_pub_out_of_system_shelf_day_his` 实例1的这个表需要全量同步到实例2上一次。吹防将基础数据更新了。我也得全量更新一下。-- 已完成
 
 
 ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `ACTUAL_FILL_amount` DECIMAL(18,2) DEFAULT '0.00' COMMENT '上架金额' AFTER `ACTUAL_FILL_NUM`;

-- shipment表同步失败后实例2受影响的任务
CALL sh_process.dm_sc_warehouse_stock_monthly_five(SUBDATE(CURDATE(),1));
CALL sh_process.dm_sc_warehouse_sku_shelf_cnt_two(SUBDATE(CURDATE(),1));
CALL sh_process.dm_sc_warehouse_balance(SUBDATE(CURDATE(),1));
CALL sh_process.dm_sc_warehouse_purchase_forecast(SUBDATE(CURDATE(),0));



dm_pub_user_research1 02:32 耗时10分钟 预计02：42执行完 ok
dm_pub_user_research2 02:58 耗时20分钟 预计03：20执行完 ok
dwd_shelf_product_day_south_his_four  由现在的每日 04：16 调整到03：25  已调
dm_op_area_product_level 由现在每周一 04：12 调整到每周一 03:50 已调
dwd_lo_prewarehouse_fill_order_item_month  每日03：37 调整到每日 02:26  已调
dm_pub_user_research3 03:30 耗时12分钟 预计03：45执行完 
dm_pub_user_research4 03:55 耗时40分钟 预计04：40执行完 

实例1
-- dwd_group_activity_order_day

dwd_update_dwd_table_info

实例2
dwd_check_base_day_inc_to_dwd
dwd_pub_order_item_recent_two_month_two


优化信息：
英南优化 sp_op_false_stock_danger_level 
唐进优化 dwd_group_activity_order_day 
世龙优化 dwd_pub_order_item_recent_two_month_two


唐进好：

    该需求需要修改test中存储过程对应任务，已测试，可以call，有问题再沟通 -- 已完成

test.`sp_d_sc_warehouse_preware_stock_outbound`   -- dm_sc_warehouse_sku_shelf_cnt_two
test.`sp_d_sc_warehouse_balance`                  -- dm_sc_warehouse_balance
test.`sp_d_sc_warehouse_out_record`               -- dm_sc_warehouse_stock_monthly_five

CALL sh_process.dm_sc_warehouse_stock_monthly_five(SUBDATE(CURDATE(),1));
CALL sh_process.dm_sc_warehouse_sku_shelf_cnt_two(SUBDATE(CURDATE(),1));
CALL sh_process.dm_sc_warehouse_balance(SUBDATE(CURDATE(),1));



进进，周一帮我调一下调度时间哈，fe_dm.`dm_sc_warehouse_balance`这个要提前，最好能赶到6点20之前做完  -- 回复：以调整到 06：10

fe.sf_smart_breach_order  -- fe_dwd.`dwd_sf_smart_breach_order` 同步到实例2上。通过 last_update_time 做增量更新，breach_id做replace替换
。每天更新。同步时间你来安排  -- 已完成
 
 
dm_sc_preware_sku_satisfy 调整到05：00
dm_op_shelf_product_zerosale_monitor  调整到06：14
dm_op_stock_three 调整到06：17
dm_sc_warehouse_balance 调整到 06：10


dwd_shelf_machine_info
ALTER TABLE fe_dwd.`dwd_shelf_machine_info`
ADD COLUMN `iccid` VARCHAR(32) DEFAULT NULL COMMENT '设备2000上报的iccid值' AFTER `MID`;


1、dm_op_user_miser_stat 网易有数和其他工程都没有依赖到，
维度跟 fe_dm.dm_ma_user_sale_weekly 部分字段重合，可直接使用 dm_ma_user_sale_weekly 这个表。
如做停删操作，miser_tag，orders_top_flag 标签字段需要恢复历史数据。因此，请世龙、唐进@李世龙 @唐进 评估是否可做停删处理
2、dm_op_user_miser_stat 存储过程 dm_op_price_sensitive_stat_two 涉及到几个价格敏感度分析表，辛苦伟铨评估下是否可先保留待删除@纪伟铨


@唐进 帮忙把 dm_op_fill_not_push_order 这个任务的调度时间调到6点半前，谢谢  -- 调整 06:25  对应的同步任务： dm_op_auto_push_fill_date2_his_erp 调整到06:23 耗时10秒钟


进进，麻烦帮我看一下，fe_dm.dm_warehouse_product_presence 这个又没有可能提前到4点以前？ -- 已调整

dm_pub_area_product_stat_erp 04:17  实例1 dm_pub_area_product_stat 调整到03:07 同步任务 dm_pub_area_product_stat_erp 调整到 03：20
dwd_pj_outstock2_day          04:24 调整到 03:43
dm_warehouse_product_presence 04:29 调整到 03:46



唐进好：-- 已完成

   该需求需要修改对应存储过程，可以call，有问题再沟通。
   test.d_sc_preware_sku_satisfy   -- dm_sc_preware_sku_satisfy
   test.dm_sc_preware_new_product_flag  -- dm_sc_preware_new_product_flag
唐进好：

    该需求需要修改对应存储过程：test.`sp_d_sc_warehouse_preware_stock_outbound`，可以call，有问题再沟通； -- dm_sc_warehouse_sku_shelf_cnt_two

	call sh_process.dm_sc_preware_new_product_flag;
	call sh_process.dm_sc_preware_sku_satisfy;
	CALL sh_process.dm_sc_warehouse_sku_shelf_cnt_two(SUBDATE(CURDATE(),1));
	
 世龙任务部署 dwd_en_fx_balance_change  -- 已部署 01：45
 唐进好： -- 已完成

    该需要需要修改一下 test.sp_d_sc_profit_monthly_shelf_product，有问题再沟通，可以明天再修改。
	
	
	
feods.`d_sc_preware_daily_report` 实例 1  -- 已处理
fe_dm.dm_sc_preware_daily_report 实例2 增量同步一天的数据，实例1保存的数据保存最近1个月就好
@世龙 请将 实例1 feods.d_sc_preware_daily_report 重命名到 fe_dm.dm_sc_preware_daily_report
@王辉 请将fe_data库的存储过程 prc_sync_data_d_sc_preware_daily_report 里面的表 feods.d_sc_preware_daily_report 改为 fe_dm.dm_sc_preware_daily_report
 
 
唐进好： 
该需求需要修改对应过程
test.sp_d_sc_warehouse_preware_stock_outbound;  -- dm_sc_warehouse_sku_shelf_cnt_two
test.dm_sc_preware_new_product_flag;            -- dm_sc_preware_new_product_flag
test.`d_sc_preware_sku_satisfy`;                -- dm_sc_preware_sku_satisfy
test.`sp_d_sc_preware_daily_report`             -- dm_sc_preware_daily_report
test.`dm_sc_preware_product_stat`               -- dm_sc_preware_product_stat


call sh_process.dm_sc_preware_new_product_flag();
call sh_process.dm_sc_preware_sku_satisfy();
call sh_process.dm_sc_preware_product_stat(SUBDATE(CURDATE(),1));
call sh_process.dm_sc_warehouse_sku_shelf_cnt_two(SUBDATE(CURDATE(),1));
call sh_process.dm_sc_preware_daily_report(SUBDATE(CURDATE(),1));


-- 实例 sh_update_if_buy_this_week 跟进是否要迁移到实例2更新本周是否购买字段  （慧敏跟进）

调实例2的任务时间 给flag1 flag2 腾出CPU资源 预计总耗时70分钟


唐进还请帮忙call一下存储过程sh_process.sp_op_dim_date，同步完了也需要call实例2对应的任务，等我确认好更新没问题后，这个存储过程 dm_op_out_product_suggest_list 也需要重call一下，感谢。-- 已处理

feods.`d_sc_preware_daily_report` 实例 1  -- 已处理
fe_dm.dm_sc_preware_daily_report 实例2 增量同步一天的数据，实例1保存的数据保存最近1个月就好


test.d_sc_preware_sku_satisfy         -- dm_sc_preware_sku_satisfy
test.`dm_sc_preware_new_product_flag` -- dm_sc_preware_new_product_flag


test.prc_d_ma_user_flag1，test.prc_d_ma_user_flag2

dwd_group_order_refound_address_day 这个同步到实例2上
-- 周一开会讨论关于开发用表的约定

-- 吴婷开发用到的直接的表。 
fe.sf_product_fill_order_item
fe.sf_product_fill_order
fe.sf_prewarehouse_stock_detail
feods.d_sc_preware_balance
sserp.T_BD_MATERIAL
feods.zs_product_dim_sserp
feods.d_sc_preware_wave_cycle
feods.d_sc_preware_outbound_seven_day
feods.wt_warehouse_business_area
feods.PJ_OUTSTOCK2_DAY
fe_dwd.dwd_sc_bdp_warehouse_stock_daily
fe_dwd.dwd_relation_dc_prewarehouse_shelf_day_all
fe.sf_shelf_product_detail
fe_dwd.dwd_product_base_day_all
feods.pj_preware_sales_fifteen
fe_dwd.dwd_shelf_base_day_all
feods.pj_preware_shelf_sales_thirty
feods.d_sc_preware_sku_satisfy
feods.d_sc_preware_fill_frequency

sp_d_sc_warehouse_preware_stock_outbound  -- dm_sc_warehouse_sku_shelf_cnt_two
dm_sc_preware_new_product_flag            -- dm_sc_preware_new_product_flag
call sh_process.dm_sc_preware_new_product_flag();
call sh_process.dm_sc_warehouse_sku_shelf_cnt_two(SUBDATE(CURDATE(),1));

test.pj_poorderlist_day

sp_d_sc_warehouse_preware_stock_outbound  -- dm_sc_warehouse_sku_shelf_cnt_two
dm_sc_preware_new_product_flag  -- dm_sc_preware_new_product_flag

dwd_user_day_inc_to_dwd 改到01：25
dwd_fill_day_inc_recent_two_month 改到01：40

test.sh_dynamic_weighted_purchase_price

smart_transaction_check_log  --> fe_dwd.`dwd_smart_transaction_check_log` -- 每日00：54
通过add_time 来增量添加。调度时间你来定


-- 开发用到的表
实例2
dm_area_product_sale_flag
dm_bill_check
dm_op_shelf_product_start_fill_label  #恢复补货
dm_op_shelf_product_fill_suggest_label  #停止补货
dm_op_out_product_stock_item	#商品明细
dm_lo_fill_for_month_label
sf_sham_assign_record
dm_op_shelf_product_fill_update2
dm_lo_zone_daily_data
dwd_shelf_base_day_all

-- 李世龙任务部署
智能货架交易信息宽表  -- 已部署实例1 01：28 每日 01：48 同步到实例2
前置仓每日库存明细表  -- 已部署每日 12:30

-- 英南任务部署
dm_op_shelf_product_offstock_association -- 每月1号 07：31 加依赖关系
dm_op_offstock2  依赖 dm_op_shelf_product_offstock_association 每日9点前调度  每日 07 ：00 
dm_op_offstock2 不加依赖关系 每日 05：25左右跑


-- 检查ok
ALTER TABLE fe_dwd.`dwd_check_base_day_inc`
ADD COLUMN `is_virtual_stock` TINYINT(2) DEFAULT '0' COMMENT '是否虚库存' AFTER `REMARK`;


尊敬的用户，您好！
您的SSLVPN权限将于2020年12月17日晚上23:00正式回收，后续将通过顺丰无边界办公客户端替代SSLVPN远程接入功能，请尽快按如下步骤操作：

1、请您检查电脑桌面是否已安装顺丰无边界办公客户端。
2、如您还未安装顺丰无边界办公客户端，请参考操作指引自行下载安装：http://mainioa.sf-express.com/d

3、如您如上操作之后，依旧无法正常访问相关内部资源，直接联系服务台（9533876）咨询或报障处理。

顺丰无边界办公系统介绍（内含丰声群二维码）：http://imsp-mms.sf-express.com/sfimms/template/html/contentpc


-- 检查ok
ALTER TABLE fe_dwd.`dwd_check_extend_recent_62`
ADD COLUMN `is_virtual_stock` TINYINT(2) DEFAULT '0' COMMENT '是否虚库存' AFTER `REMARK`;

ALTER TABLE fe_dwd.`dwd_check_extend_recent_62`
ADD COLUMN `high_risk_flag` TINYINT(2) DEFAULT '0' COMMENT '高风险标记，1效期高风险虚库存 2非效期高风险虚库存' AFTER `is_virtual_stock`;



SELECT DATE_FORMAT(SUBDATE(CURDATE(),INTERVAL 1 YEAR),"%Y-%m") 

SELECT * FROM test.`sql_log_info` WHERE task_name IN ('prc_d_ma_user_flag1','prc_d_ma_user_flag2') AND stime>='2020-12-10 19:18:47' AND stime<='2020-12-10 20:26:39'
GROUP BY task_name


task_name	SUM(run_time)
prc_d_ma_user_flag1	36.8
prc_d_ma_user_flag2	31.1

CPU 平均在40%

id	statedate	task_name	loginfo	start_time	end_time	run_time	run_time_second
139489	2020-12-14	dm_pub_user_research1	朱慧敏@shprocess@%	2020-12-14 02:32:05	2020-12-14 02:42:39	10.60	634
139525	2020-12-14	dm_pub_user_research2	朱慧敏@shprocess@%	2020-12-14 02:58:05	2020-12-14 03:13:15	15.20	910
139569	2020-12-14	dm_pub_user_research3	朱慧敏@shprocess@%	2020-12-14 03:30:05	2020-12-14 03:42:36	12.50	751
139654	2020-12-14	dm_pub_user_research4	朱慧敏@shprocess@%	2020-12-14 03:55:05	2020-12-14 04:34:58	39.90	2393

SELECT * FROM fe_dwd.`dwd_sf_dw_task_log` WHERE task_name LIKE '%dm_pub_user_research%' AND task_name NOT LIKE '%delay%' AND statedate>='2020-12-14'


SELECT * FROM fe_dwd.`dwd_prc_project_process_source_aim_table_info` WHERE project LIKE '%dm_pub_user_research%'


SELECT * FROM fe_dwd.`dwd_sf_dw_task_log` WHERE statedate>='2020-12-14' AND start_time>='2020-12-14 04:30:00' AND task_name NOT LIKE '%delay%' AND  start_time<'2020-12-14 06:30:00'

SELECT * FROM fe_dwd.`dwd_sf_dw_task_log` WHERE start_time>='2020-12-18 04:30:00' AND start_time<'2020-12-18 06:30:00' AND task_name NOT LIKE '%delay%'

dwd_shelf_product_sto_sal_30_days 调到 03：40 耗时 5分钟 预计 03:45执行完 



task_name	SUM(run_time)
prc_d_ma_user_flag1	36.8  时间设置再 04：50之后
prc_d_ma_user_flag2	31.1  预计设置05:51 - 06：21
CPU 平均在40%

-- dm_op_shelf_product_zerosale_monitor 由06：14调整到06：43 耗时7分钟 抽取设置再07：28 ok
-- dm_sc_preware_pp_ap_stat   由06：17调整到06：23 耗时 4分钟 ok 无网易有数
-- dm_ma_high_gross           由06：22调整到07：39 耗时2分钟  ok
-- dm_prewarehouse_stock_detail_weekly_monthly 由05：52调整到03：43 耗时2分钟  ok 提前不涉及网易
-- dm_op_shelf_type_flag      由05：56调整到07：42 耗时2分钟  ok   
-- dm_op_shelf7_offstock_reason 调整到07：06 ok

dm_fill_operation_kpi_for_management 停止调度
dm_op_kpi2_area_product_satis_rate   停止调度
dm_op_kpi2_outlet_rate     停止调度
dm_lo_campus_manager_level 停止调度
dwd_lo_school_order_item   停止调度
dm_op_ds7p_sal_fil  停止调度
dm_op_price_sensitive_stat_month 停止调度
dm_op_price_sensitive_stat_month_nation 停止调度
dm_product_fill_number_sorting  停止调度
dm_op_kpi_np_out_week 停止调度
dm_op_kpi2_product_new_out_sto_rate 停止调度
dm_manager_shelf_performance_label 停止调度
dm_op_kpi_gmv_month_three  停止调度
dm_op_kpi_np_gmv_week_three 停止调度


 
部署 dm_op_shelf_fill_stock_abnormal 实例2 英南 每日08：15
部署 dwd_pub_out_of_system_shelf_day_his_day 实例1 朱星华 每日09：40 

实例1新增任务优先级（优先级1 表示前置任务失败，该任务需要重新执行；优先级为2的表示前置任务失败，该任务无需重新执行）-- 需大家反馈
pj_shelf_level_ab  停止调度

唐进，fe.sf_product_machine_slot 这个表在实例2没有，我用之前的查询指引查了下，能不能帮忙把这个表同步到实例2？ -- 星华  已部署同步


fe.sf_product_supplier_relation -->  fe_dwd.`dwd_sf_product_supplier_relation`  已部署
通过last_update_time 同步到实例2，用supplier_relation_id replace into 进行插入


dm_op_manual_fill_monitor 调整到08:18  网易有数抽取调整到08:38  -- 已完成


-- 航宇任务部署 已完成 每月1号 03：52
实例1 新增存储过程，如test.`dm_fx_annual_reporta`()
跑数需要近3000s，调度需保证凌晨5点前跑完
设置为2021-01-01 凌晨3点调度

云峰任务部署 dwd_lo_dangerous_manager_log 实例2 -- 已完成 同步到实例1
select * from fe_dm.dm_op_shelf_product_discount_type  -- 同步到实例2 纪伟铨  每周四03:53同步


dm_op_shelf_gmv_analysis_month  -- 英南反馈此任务用约翰通前一天的数据，那无需根据依赖关系执行 将等待超时的关系删掉  实例2任务优先级正在收集中……

dm_shelf_product_cms_submit       已调整到 03:22  调整到03:16
dm_sc_new_product_estimate_weekly 已调整到 06:43 网易有数任务无需调整
dm_op_kpi_area_product_sat_rate 已调整到 07:39 dm_op_kpi_area_product_sat_rate 网易有数抽取设置 08：31
dm_op_price_sensitive_stat_two  已调整到 02:51
dm_op_flag5_shelf_stat_two      已调整到 04:00
dm_op_price_sensitive_stat_nation  停止调度
dm_op_avgqty_fill_dayst_stat_two   停止调度 
dm_ma_shelf_sale_2week 调整到03：01 （每周一05：22点的CPU很高）
dm_op_kpi_np_flag5_sto  调整到04：26
dwd_shelf_product_price_tag  调整到05：06

-- 检查ok
ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `product_supplier_type` INT(1) DEFAULT NULL COMMENT '供货方类型数据字典 productSupplierType；1前置仓；2仓库;3供应商直供:4无'  AFTER `is_prewarehouse_cover`;


-- 已部署实例2
task_name	SUM(run_time)
prc_d_ma_user_flag1	20  预计设置04:53 - 05:18  -- dm_shelf_member_flag1  04:53
prc_d_ma_user_flag2	35  预计设置05:50          -- dm_shelf_member_flag2  05:50  改成05：38

CPU 平均在40%

id	statedate	task_name	loginfo	start_time	end_time	run_time	run_time_second
139489	2020-12-14	dm_pub_user_research1	朱慧敏@shprocess@%	2020-12-14 02:32:05	2020-12-14 02:42:39	10.60	634
139525	2020-12-14	dm_pub_user_research2	朱慧敏@shprocess@%	2020-12-14 02:58:05	2020-12-14 03:13:15	15.20	910
139569	2020-12-14	dm_pub_user_research3	朱慧敏@shprocess@%	2020-12-14 03:30:05	2020-12-14 03:42:36	12.50	751
139654	2020-12-14	dm_pub_user_research4	朱慧敏@shprocess@%	2020-12-14 03:55:05	2020-12-14 04:34:58	39.90	2393

-- 婷姐任务部署及数据量监控 完成
`dm_fi_zhongtai_check_monthly`这个月度来一次就好  0.7分钟
`dm_fi_zhongtai_daily_detail`  0.1分钟
`dm_fi_zhongtai_original_detail`这两个每天 1分钟
 
dm_fi_zhongtai_check_monthly  依赖 dm_fi_zhongtai_original_detail
dm_fi_zhongtai_daily_detail   依赖 dm_fi_zhongtai_original_detail

大概8点半吧


sp_shelf_archives  feods.fjr_shelf_archives   这个存储过程对应的表都已经解耦完成。可以删除了。保留表结构和存储过程即可  -- 实例1调度任务已停止，同步任务已停止
然后这个存储过程用到的表 feods.zs_shelf_manager_flag 也可以删除了


-- 周一处理
2.实时货架商品的数据：
  例如：库存必须在晚上23:00提供数据到实例2   在晚上10:45分之前完成这个操作

  dwd_shelf_product_day_all 存储过程在晚上 10:09 跑数，然后 10：37同步到实例2上，直接替换                          -- 已完成 存储过程在晚上 10:09 跑数，然后 10：37同步到实例2上

3.补货实时数据  放在two_month 上     在晚上10:45分之前完成这个操作       
   例如：必须在晚上23:00提供数据到实例2
   
   将 fe_dwd.`dwd_fill_day_inc_recent_real_time` 的数据同步到 fe_dwd.`dwd_fill_day_inc_recent_two_month`
 
补货的数据，用这个在10:50（1分钟跑出来） 跑出来结果同步到实例2的 fe_dwd.`dwd_fill_day_inc_recent_two_month` 供使用。  -- 已完成 存储过程在晚上 22：50 跑数，然后 22：57同步到实例2上



select * from test.dm_ma_shelf_product_flag;
select * from test.dm_ma_shelf_product_flag_his;
#存储过程
call test.dm_ma_shelf_product_flag(curdate()); #每天  -- 已部署每日23：00


fe_dwd.dwd_user_day_inc  帮我把实例1的这个表的数据全量同步到实例2上一下。大概1000W的样子  -- 已完成


-- 优化 dm_shelf_manager_monitor_result 存储过程 
-- 抓取农副产品数据

-- 检查没问题
ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `fill_skus`  INT(11) DEFAULT '0'  COMMENT '开启补货sku' AFTER `stock_sum`;

ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `fill_or_sto_skus`  INT(11) DEFAULT '0'  COMMENT '开启补货or有库存sku' AFTER `stock_sum`;

-- 吴婷任务部署 已完成
@唐进 麻烦实例2新建存储过程，无参数，每天跑，尽量早一点，大概2秒钟
test.dm_sc_ap_newproduct_indate()

-- 伟铨任务确认
fe_dm.dm_ma_usertype_sale_daily #会用到,取数或者将来做报表
fe_dm.dm_ma_newsp_s_daily #被其他表依赖
fe_dm.dm_ma_shelf_product_monitor #取数分析用
fe_dm.dm_ma_sp_plc_his #保留变动的历史数据,重跑代价大
fe_dm.dm_ma_sp_plc_backup #备份历史数据,方便重跑恢复
fe_dm.dm_shelf_member_flag_history #备份历史数据方便取数查询

-- 英南优化任务
dm_op_package_config_two
dm_op_valid_danger_flag

-- 维护同步任任务开发表信息 11个表


fe_temp.dwd_pub_activity_order_shelf_product   的表删了重建。然后将fe_dwd.dwd_pub_activity_order_shelf_product 的activity_id 的类型由bigint改成varchar.开发的表就是varchar


-- 年终总结
2020年的工作分为以下几个部分：
1.Azkaban调度平台管理及维护工作，主要如下：
1).实例迁移：完成300多个Azkaban调度任务从实例1迁移到实例2，及Azkaban任务迁移实例2数据一致性监控等工作；
2).任务部署：完成400多个Azkaban任务线上部署调度，包括前期测试及后期失败修复工作；
3).任务监控：在原有任务失败告警的基础上，完成了更详细的任务失败监控告警，确保能够快速定位对后置依赖的Azkaban任务影响以及网易有数抽取任务的影响；
4).平台稳定可靠性：
完成两个实例CPU资源使用率的优化工作，目前CPU使用率整体控制在80%以下，Azkaban调度任务执行更加稳定可靠；
因相关权限回收，更新存储过程次数超过1300次，降低维护人员个人误操作风险，保证任务稳定可靠执行；
完成Azkaban调度任务脚本优化共23个，总的耗时减少160分钟以上，减少任务对CPU资源的多度消耗；
优化Azkaban调度平台，设计并完成近300个调度任务的前置任务执行超时等待工作，确保调度任务根据依赖关系执行；

2.Datax调度平台管理及维护工作，主要如下：
1).Datax同步切换：完成160多个Datax同步任务从datax切换到datax_web平台工作；
2).任务部署：完成330多个任务线上部署调度，包括测试及数据验证工作；
3).任务监控：
完成了更详细的任务失败监控告警，确保能够快速定位对后置依赖的Azkaban任务影响以及网易有数抽取任务的影响；
完成实例1和实例2同步表数据一致性以及建表语句信息监控，确保实例2源头数据准确可靠；

3.Hive测试平台搭建工作，主要如下：
1).完成测试环境hadoop搭建及测试工作；
2).完成测试环境hbase搭建工作；
3).完成测试环境hive搭建及测试工作；
4).完成测试环境sqoop搭建及测试工作，实现大数据平台和mysql之间数据双向同步；
5).完成测试环境hive web界面搭建工作，实现在web界面执行sql相关操作；
6).完成测试环境spark搭建及测试工作；
待测试平台搭建及功能测试完成后，预计2021年3月份完成线上平台搭建。

4.其他方面工作
1).完成金蝶数据Kettle同步任务到Datax同步任务的切换，总共包含51个表，同步时间由之前每天130多分钟缩减到30分钟以内；
2).积极主动协助组内同事查找数据异常问题原因，并做数据修复工作；
3).完成3个爬虫抓取数据工作，其中1个任务因其他原因暂停；

回顾2020年工作，还有很多做的不到位的地方，争取在新的一年将本职工作做的更好，并且也希望能够积极做一些主动创新方面的工作。


停止调度：
dm_sc_oms_stock_daily 实例2 吴婷
dwd_en_scan_order_daily  实例1 航宇
prc_d_ma_next_week_birthday  实例1 黎尼和
prc_dm_ma_area_shelfType_kpi_monthly
dm_ma_area_shelfType_kpi_weekly
prc_dm_ma_shelf_info_daily
prc_dm_ma_kpi_data_daily
dm_op_new_shelf_sp_offstock
sp_dm_lo_order_logistics_task_data


dwd_pub_activity_order_shelf_product  全量同步到实例2上，load_time已经改到7天以前了  -- 完成
-- 实例1 三个表切换到fe_dm库 需更换datax同步任务 azkaban调度存储过程 统计实例1数据量脚本 完成
feods.d_op_shelf_board_month --   fe_dm.dm_pub_shelf_board_month
feods.fjr_shelf_board --   fe_dm.dm_pub_shelf_board
feods.d_op_shelfs_area  --  fe_dm.dm_pub_shelfs_area



本周停止调度任务 -- 已停止
dm_mp_week_kpi_monitor  -- 吴婷
sh_preware_outbound_fill -- 吴婷
sh_preware_product_sale -- 吴婷
sp_d_sc_preware_balance -- 吴婷
d_sc_preware_sku_satisfy -- 吴婷
sp_d_sc_preware_wave_cycle -- 吴婷
d_sc_preware_new_product_flag -- 吴婷
dm_op_kpi_unsku  -- 英南
dm_op_shelf_type_flag -- 吹防
dm_op_area_out_product_purchase -- 朱星华
dm_op_area_product_pq4 -- 星华
dwd_en_combine_shop_order -- 费航宇
dm_op_offstock_not_push_order -- 宋英南
dm_en_third_user_balance_his 


-- 已处理 
     由于前置仓补货现在数据近期已改为由实例2生成并同步到实例1的模式，因此原先实例1中相关任务或者表在确定无依赖之后，可以删除。
（1） 实例1中 sp_d_sc_preware_daily_report之前依赖了下列过程，如果没有被其他任务依赖，可停止：
`d_sc_preware_new_product_flag`
`d_sc_preware_sku_satisfy`
`sh_preware_outbound_fill`
`sh_preware_product_sale`
`sp_d_sc_preware_balance`
`sp_d_sc_preware_daily_report`
`sp_d_sc_preware_wave_cycle`

（2）相关数据表
feods.`d_sc_preware_balance`
feods.`d_sc_preware_fill_frequency`
feods.`d_sc_preware_new_product_flag`
feods.`d_sc_preware_sales_daily`
feods.`d_sc_preware_sku_satisfy`
feods.`d_sc_preware_wave_cycle`
feods.`pj_preware_sales_fifteen`
feods.`pj_preware_shelf_sales_thirty`
feods.`preware_fill_daily`
feods.`preware_outbound_daily`
feods.`preware_outbound_forteen_day`
feods.`preware_outbound_weekly`
feods.d_sc_preware_daily_report
fe_dm.`dm_sc_warehouse_preware_stock_outbound` -- 此表不能删除
 
-- 李吹防任务部署
dm_shelf_product_high_danger_zero_stock 每日 03:49 调度 同步任务 dm_shelf_product_high_danger_zero_stock_erp 每日 03:58
-- 清理datax同步任务 比如开发用到实例2的表现在迁移到实例1 

-- 优化同步任务 d_op_sp_stock_detail_erp  和 d_op_sp_stock_detail_after_erp  同步时间在原来的基础上均减少2分多钟，降低了实例2 02:43--02:53的CPU资源

dm_op_kpi2_sale_vs_stock_week 调整到 05:15 -- 调整原因：每周一 05:46CPU高
sc_前置仓日报 网易有数任务 由07:12 调整到 07:58 -- 调整原因： 每天 07:12开始CPU高
dwd_lo_dangerous_manager_log 实例2 调整到03:47   dwd_lo_dangerous_manager_log_erp 调整到03:59


-- 伟铨货架商品表实例2数据验证ok，下一步待停止实例1任务，实例2数据同步到实例1给开发使用

dm_ma_user_perfect_product  每周一执行一次  -- 以调整


------------- 以下待处理
Dear 唐进：

           辛苦唐进部署实例1存储过程，谢谢。
           实例1存储过程：sh_process.dm_ma_activity_product_flag，耗时2分钟 更新频率：每天晚上22:30，活动结束25日停止调度。
-- 部署慧敏任务
dm_ma_activity_product_flag 每日22：32执行一次


-- 伟铨货架商品表实例2数据验证ok，下一步待停止实例1任务，实例2数据同步到实例1给开发使用
#dm_shelf_flag dm_shelf_flag_his
# 迁移货架标签到实例2
select * from test.dm_ma_shelf_flag;
select * from test.dm_ma_shelf_flag_his;
select * from test.dm_ma_shelf_flag_weekly; 
select * from test.dm_ma_shelf_flag_monthly ;
#过程
call test.dm_ma_shelf_flag(current_date);         #每天晚上11点过后  -- 每日23：45 同实例1
call test.dm_ma_shelf_flag_weekly(current_date);  #每周一上午9点前   -- 每周一 08：13
call test.dm_ma_shelf_flag_monthly(current_date); #每月1号上午9点前 -- 每月1号 07：57
-- 部署伟铨任务
dm_ma_shelf_flag
dm_ma_shelf_flag_weekly
dm_ma_shelf_flag_monthly


受影响的任务,停止调度实例1任务之前
sh_member_research_crr_2  每周一
prc_sync_data_zs_shelf_flag 每日
sp_product_list_manager_week 每周一
开发脚本有使用到  feods..zs_shelf_flag
网易有数任务用到  feods..zs_shelf_flag



-- 吹防  已处理
由于春节放假，临期品需提前下架，现麻烦帮忙：
1、修改下存储过程（详见附件）；
2、表：fe_dm.dm_op_product_week_insert  和 fe_dm.dm_op_shelf_product_confirm_risk 
1月18号（不含）之后的部署暂停，2月8号恢复部署，此外需要1月20号，将存储过程改回来，谢谢！

-- 部署英南任务：
dm_op_fill_day_sale_qty_20210115 部署实例1 更新时间：2021年1月16日 1点左右；更新频率：仅执行1次，后续无需执行。 -- 00：58执行
dm_op_area_homo_offstock_day 部署实例2  并安排调度任务，调度频率：每天，调度时间：每天上午9点前  -- 06：02

实例2 fe_dm.sf_sham_assign_record 建立 fe_dm.sf_sham_assign_record_bak备份之前历史数据，现建实例1到实例2的同步任务，每日增量同步

汤云峰任务部署 同步到实例2 fe_dwd.dwd_lo_shelf_source_log 帮忙部署一下实例1，每天晚上11点左右，然后同步实例2  -- 完成 部署在 22:57  23:20同步到实例2 


fe_bill.sf_shelf_loss_bill  同步到实例2 -- 完成

-- 完成检查
ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `shelf_log`  TINYINT(1) DEFAULT NULL COMMENT '货架标签(1、普通新增,2、挪点新增,3、置换新增,4、普通撤架,5、挪点撤架,6、置换撤架)' AFTER `shelf_type_desc`;

ALTER TABLE fe_dwd.`dwd_shelf_base_day_all`
ADD COLUMN `shelf_log`  TINYINT(1) DEFAULT NULL COMMENT '货架标签(1、普通新增,2、挪点新增,3、置换新增,4、普通撤架,5、挪点撤架,6、置换撤架)' AFTER `shelf_type_desc`;


-- 处理fe库同步数据量不一致原因 和最近新增同步表数据核对 优先级信息  各自的存储过程放到git下
-- 更新调度任务信息 更新网易有数抽取信息（抓取）


    # 实例2目标表 -- 已完成
select * from test.dm_ma_user_product_list;

    #替换存储过程
call test.prc_dm_ma_user_perfect_product();
@李世龙 @唐进 顺便改成每天跑一次



-- 已修改
# 表
select * from test.dm_ma_sp_plc_his;#替换fe_dm.dm_ma_sp_plc_his;
# 修改存储过程
call test.dm_ma_sp_plc(subdate(current_date,1));


唐进好：-- 已完成

    该需求需要修改对应存储过程：
test.sp_d_sc_warehouse_preware_stock_outbound
test.sp_warehouse_product_presence


-- 已处理 
    需要新增存储过程,test.dm_sc_preware_onload();  
1、无参数
2、每天跑，大概3点左右执行就行，
3、时长大概2秒


-- 已检查
ALTER TABLE fe_dwd.`dwd_en_distribute_detail_fx`
ADD COLUMN `emp_customer_id` BIGINT(20) DEFAULT NULL COMMENT '员工所属企业id' AFTER `emp_user_id`;
-- 已全量同步
fe_dwd.dwd_en_distribute_detail_fx   这个表我更新了一下历史数据。需要全量同步到实例2上。删除实例2的表


ALTER TABLE fe_dwd.`dwd_order_item_refund_real_time`
ADD COLUMN `pay_amount_product` DECIMAL(10,2) DEFAULT NULL COMMENT '支付金额_商品' AFTER `pay_amount`;


-- 8个表维护  完成

dwd_order_item_refund_day_inc  改为每日 00：27
dwd_shelf_day_his 改为每日00：40

-- 部署吹防任务： dm_op_shelf_product_confirm_risk_status 完成
-- 更新实例2 任务 dm_op_shelf_sku_situation2 需要添加依赖 完成
-- @唐进 修改过程 sp_warehouse_product_presence 完成


-- 周四英南的6个调度任务执行失败，均因为字段长度的原因导致的
'dm_op_cal_fill_reasonable_month_two',
'dm_op_s_new_product_offstock',
'dm_op_area_product_monitor',
'dm_op_warehouse_monitor',
'dm_op_area_high_stock_three',
'dm_op_manager_product_trans_monitor'

-- 汤云峰反馈 需将实例2的调度任务停止调度 dwd_lo_node_monitor_data_after_cleanout ，实例2的数据从实例1同步
实例1 feods.`d_lo_node_monitor_data_after_cleanout` 到 实例2 fe_dwd.`dwd_lo_node_monitor_data_after_cleanout`的同步需要手工全量做一次，实例1那边有一些脏数据我手工剔除了
停止实例1 sp_D_LO_node_monitor_data_after_cleanout 新增同步任务  dwd_lo_node_monitor_data_after_cleanout_erp


-- 已检查 ok
ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `refund_finish_amount_gmv`   DECIMAL(18,2) DEFAULT '0.00' COMMENT '当日应退当月已退gmv(使用退款金额作为gmv)' AFTER `refunding_GMV`;

ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `refund_finish_amount_gmv`   DECIMAL(18,2) DEFAULT '0.00' COMMENT '当日应退当月已退gmv(使用退款金额作为gmv)' AFTER `refunding_GMV`;



-- 已检查 ok
ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `fill_orders` INT(30) DEFAULT '0' COMMENT '上架订单数' AFTER `onway_num`;

-- 实例1 调度任务新增晚上调度 晚上同步 每天晚上十一点前 更新一次数据  
select * from fe_dwd.dwd_shelf_base_day_all;    22:52 同步到实例2时间 22：57
select * from fe_dwd.dwd_product_base_day_all;  22:52 同步到实例2时间 22：58


CALL sh_process.dm_op_fill_order_abnormal; 每天上午9点前执行  每日 03：53
CALL sh_process.dm_op_manager_fill_stat; 每天上午9点前执行    每日 03：21
CALL sh_process.dm_op_shelf_fill_stat; 每周一上午9点前执行（一周一次） 每周一 03：22

2、唐进帮忙新增附件存储过程并call（test改成fe_dm），并安排调度任务：
    dm_op_shelf_fill_stat   每周一上午9点前执行（一周一次）；
    dm_op_manager_fill_stat 和 dm_op_fill_order_abnormal 每天上午9点前执行；
以上，希望今天完成，谢谢。


dwd_sf_product_fill_order_recent32  实例2的这个表。汤云峰根据业务需要，需要保留近2个月的数据 -- 已改62天



存储过程汇总/实例1/运营部门/dm_op_shelf_product_fill_update2.sql
存储过程汇总/实例1/运营部门/dm_op_shelf_product_fill_update2_pm.sql
存储过程汇总/实例2/运营部门/dm_op_offstock2.sql
存储过程汇总/实例2/运营部门/dm_op_stock_reach_ratio.sql

存储过程汇总/实例2/运营部门/dm_op_area_product_fill_monitor.sql 
存储过程汇总/实例2/运营部门/dm_op_prewarehouse_monitor.sql
存储过程汇总/实例2/运营部门/dm_op_warehouse_monitor.sql

fe_dm.dm_ma_shelf_flag_weekly; 每周一同步一次   每日08：18同步
fe_dm.dm_ma_shelf_flag_monthly; 每月一号同步一次    每日08：06同步
fe_dm.dm_ma_shelf_sale_monthly ; 每天同步一次     每日03：54同步
 这三个需要从实例2 同步到实例1​
 

 
fe_dm.dm_ma_shelf_flag_weekly; 每周一同步一次  每周一 08：13  耗时1分钟 每日08：18同步
fe_dm.dm_ma_shelf_flag_monthly; 每月一号同步一次  每月1号 07：57 耗时3分钟 每日08：06同步
fe_dm.dm_ma_shelf_sale_monthly ; 每天同步一次  每日03：47 耗时1分钟  每日03：54同步
 这三个需要从实例2 同步到实例1​
 
 
 INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('dm_ma_shelf_flag_weekly_erp','fe_dm.dm_ma_shelf_flag_weekly','fe_dm.dm_ma_shelf_flag_weekly','每日');
 INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('dm_ma_shelf_flag_monthly_erp','fe_dm.dm_ma_shelf_flag_monthly','fe_dm.dm_ma_shelf_flag_monthly','每日');
 INSERT INTO fe_dwd.`dwd_datax_table_mapping_info`(datax_project_name,table_name_one,table_name_two,erp_frequency)
VALUES('dm_ma_shelf_sale_monthly_erp','fe_dm.dm_ma_shelf_sale_monthly','fe_dm.dm_ma_shelf_sale_monthly','每日'); 
 
 @唐进  麻烦更新一下过程 ： 存储过程汇总/实例2/采购部门/dm_sc_profit_monthly_shelf_product.sql  -- 已完成
 
 
 
 ALTER TABLE fe_dwd.`dwd_shelf_day_his`
ADD COLUMN `payment_fund` decimal(18,2) DEFAULT '0.00' COMMENT '对公补款' AFTER `online_pay_amount`;


ALTER TABLE fe_dwd.`dwd_pub_activity_order_shelf_product`
ADD COLUMN `platform_num` TINYINT(1) NOT NULL DEFAULT '1' COMMENT '平台：1，能量站 2，商城 3，店主 4，社区拼团 5，自贩机app  字典platform' AFTER `platform`;


dwd_shelf_day_his 这个存储过程帮我重头再执行一遍。我改了一下，发现不适合又改回去了



@唐进  麻烦更新一下过程 ： 存储过程汇总/实例1/企业部门/dm_en_distribute_rank.sql


ALTER TABLE fe_dwd.`dwd_pub_activity_order_shelf_product`
ADD COLUMN `ORDER_DATE`  DATETIME NOT NULL COMMENT '订单创建日期(即fe.sf_order_activity的PAY_DATE)' AFTER `pay_date`;



ALTER TABLE fe_dwd.`dwd_check_base_day_inc`
ADD COLUMN `REMARK_check`  VARCHAR(200) DEFAULT NULL COMMENT '审核结果(sf_shelf_check.remark)' AFTER `remark`;​


ALTER TABLE fe_dwd.`dwd_fill_day_inc`
ADD COLUMN `old_shelf_id` BIGINT(20) DEFAULT NULL COMMENT '旧货架ID（针对初始商品包订单转移）' AFTER `SHELF_ID`;


唐进，这三个帮忙更新并call，谢谢
存储过程汇总/实例2/运营部门/dm_op_offstock_top10.sql
存储过程汇总/实例1/运营部门/dm_op_shelf_product_fill_update2.sql
存储过程汇总/实例1/运营部门/dm_op_shelf_product_fill_update2_pm.sql


-- 朱慧敏 停止下面调度任务 已完成
dm_ma_activity_shelf_product_flag 停止实例2调度任务
dm_ma_activity_shelf_product_flag_erp 停止同步任务
-- 英南 停止下面调度任务 已完成
dm_op_offstock_five
dm_op_offstock_area7_six
dm_op_offstock_integrate
dm_op_s_new_product_offstock
dm_op_shelf_offstock
dm_op_shelf7_offstock_reason
dm_op_manager_offstock_abnormal
dm_op_shelf_offstock_reason
dm_op_offstock_not_push_order
dm_op_s_offstock_erp
dm_op_offstock_s7_erp

-- 伟铨
call test.dm_ma_area_shelftype_kpi_dm(subdate(current_date,1)); #新增  -- 已部署在每日02:13执行
call sh_process.dm_ma_area_shelftype_kpi_daily(); #暂停  -- 已停止调度
call sh_process.dm_ma_area_shelftype_kpi_monthly(); #暂停 -- 已停止调度


-- 伟铨优化
sh_shelf_flag 优化了一下


-- 已停止
实例2 存储过程停止:
dm_ma_shelf_flag
dm_ma_shelf_product_flag

'fe_dm.dm_ma_shelf_product_flag_tmp',
'fe_dm.dm_ma_shelf_product_flag_his',
'fe_dm.dm_ma_shelf_flag',
'fe_dm.dm_ma_shelf_flag_his'

由于原来的方案风险较大,故停止实例2的标签调度及使用,谢谢

-- 已停止
sp_op_false_stock_danger_level 实例1 调度任务停止，切换为对应的实例2任务 dm_op_false_stock_danger_level 每周一执行
dm_op_false_stock_danger_level_erp 同步任务由实例1同步到实例2 切换为由实例2同步到实例1

-- 朱星华
-- dwd_shelf_product_first_fill_time_change_record 同步到实例2




丰享-积分类型 07：14 -- 07：23  改为 08:47





/* By YouData (TransId: hqpe6TqYodSssSmwqGy2N9) */SELECT * FROM ( SELECT SUBDATE(CURDATE(),INTERVAL 1 DAY) 截止日期, t.积分类别, COUNT(DISTINCT t.工号) AS 积分授予人数, SUM(t.派发金额) 授予积分金额 FROM ( SELECT d.distribute_period AS 归属月份,a.auth_name, e.job_number 工号, e.emp_user_name 员工姓名, e.dept 部门, i.item_name 积分类别, d.distribute_amount 派发金额 , ( CASE WHEN d.distribute_status = 2 THEN '已领取' WHEN d.distribute_status = 1 THEN '待派发' WHEN d.distribute_status = 3 THEN '已取消' WHEN d.distribute_status = 6 THEN '未领用' WHEN d.distribute_status = 7 THEN '待手动领取' ELSE '' END ) distribute_status FROM `fe_group`.sf_group_distribute_plan_detail d JOIN fe_group.sf_group_distribute_plan p ON p.distribute_plan_id = d.distribute_plan_id AND d.add_time < CURDATE() JOIN fe_group.sf_group_customer c ON c.group_customer_id = p.group_customer_id JOIN fe_group.sf_group_emp e ON e.emp_user_id = d.emp_user_id JOIN fe_group.sf_group_dictionary_item i ON i.item_id = d.welfare_item_dict_id JOIN fe_group.sf_group_auth a ON a.bind_group_customer_id = c.group_customer_id WHERE d.`data_flag` = 1 AND p.`data_flag` = 1 AND c.`data_flag` = 1 AND e.`data_flag` = 1 AND a.`data_flag` = 1 AND d.distribute_amount >= 0.1 )t GROUP BY t.积分类别 ) AS `t`	


丰享-积分类型 07：14 -- 07：23  改为 07:25




/* By YouData (TransId: vPDUDqGe5mM5AhhhYb8hzQ) */SELECT * FROM ( SELECT CASE WHEN c.pay_type = 1 THEN '微信支付' WHEN c.pay_type = 2 THEN '手工线下支付' WHEN c.pay_type = 3 THEN '月结付款' WHEN c.pay_type = 4 THEN 'E币支付' WHEN c.pay_type = 5 THEN '顺银支付' WHEN c.pay_type = 6 THEN '顺手付云闪付' WHEN c.pay_type = 7 THEN '招行一卡通' WHEN c.pay_type =8 THEN '微信委托扣款' WHEN c.pay_type = 9 THEN '餐卡支付' WHEN c.pay_type = 10 THEN '顺手付一码付' WHEN c.pay_type = 11 THEN '企业代扣' WHEN c.pay_type = 12 THEN '小蜜蜂积分支付' WHEN c.pay_type = 13 THEN '升腾支付' WHEN c.pay_type = 14 THEN '兑换卡兑换' WHEN c.pay_type = 15 THEN '中国移动和包支付' WHEN c.pay_type = 16 THEN '组合支付' WHEN c.pay_type = 22 THEN '微信H5支付' WHEN c.pay_type = 23 THEN '微信刷脸支付' WHEN c.pay_type = 24 THEN '丰侠支付' WHEN c.pay_type = 26 THEN '云闪付直连免密支付' WHEN c.pay_type = 27 THEN '招行免密支付' WHEN c.pay_type = 29 THEN '劳保支付' WHEN c.pay_type = 30 THEN '慰问支付' WHEN c.pay_type = 31 THEN '万翼支付' END AS 支付类型 -- ,b.sale_channel -- ,CASE WHEN b.order_from=2 THEN d.ITEM_NAME -- WHEN b.order_from=3 THEN '企业购' -- WHEN b.order_from=1 THEN '销售助手' END AS 渠道 , CASE WHEN b.order_from = 1 THEN '销售助手' WHEN b.order_from = 3 THEN '企业采购' WHEN b.order_from = 2 AND b.sale_channel = '0' THEN '丰e能量站' WHEN b.order_from = 2 AND b.sale_channel = 'PAYQB' THEN '平安壹钱包' WHEN b.order_from = 2 AND b.sale_channel = 'QYFL' THEN '企业福利前台' WHEN b.order_from = 2 AND b.sale_channel = 'SFIM' THEN '丰声渠道' WHEN b.order_from = 2 AND b.sale_channel = 'ST_PAY' THEN '升腾' WHEN b.order_from = 2 AND b.sale_channel = 'XMF' THEN '小蜜丰' WHEN b.order_from = 2 AND b.sale_channel = 'ZCWL' THEN '中创物流' WHEN b.order_from = 2 AND b.sale_channel = 'SF_COD' THEN '顺丰cod' WHEN b.order_from = 2 AND b.sale_channel = 'zxcy' THEN '正心诚意' WHEN b.order_from = 2 AND b.sale_channel = 'ZD' THEN '中电' WHEN b.order_from = 2 AND b.sale_channel = '1001' THEN '中小月结' WHEN b.order_from = 2 AND b.sale_channel = 'SF_FX' THEN '丰侠' WHEN b.order_from = 2 AND b.sale_channel = 'SYHNQ' THEN '速运湖南区兑换卡消费' WHEN b.order_from = 2 AND b.sale_channel = 'YKTQD' THEN '亿咖通渠道' WHEN b.order_from = 2 AND b.sale_channel = 'YKTKJQD' THEN '浙江亿咖通科技有限公司' WHEN b.order_from = 2 AND b.sale_channel = 'BJDC' THEN '北京订餐' WHEN b.order_from = 2 AND b.sale_channel = 'ZDKQD' THEN '中电科渠道' WHEN b.order_from = 2 AND b.sale_channel = 'WYYC' THEN '万翼云城' WHEN b.order_from = 2 AND b.sale_channel = 'FAYD' THEN '福安移动' WHEN b.order_from = 2 AND b.sale_channel = '6393' THEN '新版企业福利验收周洲' WHEN c.pay_type = 2 THEN '手工线下' ELSE d.channel_name END AS '渠道' ,b.order_id ,b.order_user_id -- ,CASE WHEN b.order_type=5 THEN '饿了么订单' ELSE '其他订单' END AS 订单类型 , CASE WHEN b.order_type = 1 THEN '实物订单' WHEN b.order_type = 2 THEN '虚拟订单' WHEN b.order_type = 3 THEN '第三方充值订单' WHEN b.order_type = 4 THEN '欧非卡密商品订单' WHEN b.order_type = 5 THEN '饿了么订单' WHEN b.order_type = 6 THEN '网易严选订单' WHEN b.order_type = 7 THEN '顺丰优选订单' WHEN b.order_type = 8 THEN '美餐订单' WHEN b.order_type = 9 THEN '生活缴费' WHEN b.order_type = 10 THEN '拼团订单' WHEN b.order_type = 11 THEN '滴滴订单' WHEN b.order_type = 12 THEN '京东' WHEN b.order_type = 13 THEN '口碑到店' WHEN b.order_type = 14 THEN '票牛' WHEN b.order_type = 15 THEN '本来生活' WHEN b.order_type = 16 THEN '天虹现金券' WHEN b.order_type = 17 THEN '库盒' WHEN b.order_type = 18 THEN '饿了么团餐' WHEN b.order_type = 19 THEN '苏宁订单' WHEN b.order_type = 20 THEN '丰食订单' WHEN b.order_type = 21 THEN '易点券' WHEN b.order_type = 22 THEN '光汇云油订单' WHEN b.order_type = 23 THEN '线下扫码' WHEN b.order_type = 24 THEN '大地保险订单' WHEN b.order_type = 25 THEN '丰修' else b.order_type END AS '订单类型' ,DATE(b.order_date) AS 日期 ,b.sale_total_amount ,b.freight_amount 订单运费 ,b.order_total_amount 订单实收order -- ,b.sale_total_amount + b.freight_amount AS gmv ,CASE WHEN order_type = 5 THEN b.sale_total_amount ELSE b.freight_amount+b.sale_total_amount END AS gmv ,ABS(IFNULL(b.order_discount_amount,0)) + IFNULL(c.pay_discount_amount,0) AS discount_amount ,b.purchase_total_amount 采购价 ,b.order_discount_amount 订单折扣order ,c.pay_amount 订单实收pay ,c.pay_amount - IFNULL(sgorp.refund_amount,0) AS 订单实收 ,c.pay_discount_amount 订单折扣pay ,CASE WHEN c.pay_state=1 THEN '未支付' WHEN c.pay_state=2 THEN '已支付' END AS 支付状态 ,c.pay_time ,op.open_id 第三方标识 ,op.open_type ,org.emp_code 工号 ,org.curr_area 当前所属区 ,org.org_name ,org.dept_code 网点代码 ,sgorp.refund_amount AS 退款 FROM fe_goods.sf_group_order b LEFT JOIN fe.sf_channel_record d ON b.sale_channel=d.channel_code STRAIGHT_JOIN fe_goods.sf_group_order_pay c ON b.order_id=c.order_id LEFT JOIN fe.pub_user_open op ON op.user_id = b.order_user_id AND op.open_type IN ('XMF', 'SFIM') LEFT JOIN feods.`d_en_emp_org` org ON org.emp_code = LPAD(op.open_id,8,'0') LEFT JOIN fe_goods.`sf_group_order_refund_pay` sgorp ON (sgorp.order_id = b.order_id AND sgorp.state = 2) WHERE c.pay_state = 2 #已支付 AND b.data_flag = 1 AND c.data_flag = 1 AND (b.order_date BETWEEN SUBDATE(DATE_FORMAT(CURDATE(),'%Y-%m-01'),INTERVAL 3 MONTH) AND CURDATE()) #and b.order_date>='2019-09-01' and b.order_date<'2020-01-01' #and b.order_date < CURDATE() #AND b.purchase_total_amount >= 1 #去掉产品测试 GROUP BY b.order_id ) AS `t`	



福利商城之日周月报表  07：36 --07：41



/* By YouData (TransId: m7k634Dpsa2BAEZLH1NVsy) */SELECT * FROM ( SELECT tt.order_user_id AS 用户id ,tt.open_id AS 工号 ,COUNT(DISTINCT tt.order_date) AS 总购买次数 ,COUNT(DISTINCT tt.渠道) AS 渠道数量 ,SUM(tt.订单实收1) AS 总实收1 ,SUM(tt.订单折扣1) AS 总订单折扣1 ,SUM(tt.订单实收) AS 总订单实收 ,SUM(tt.订单折扣) AS 总订单折扣 ,MIN(tt.order_date) AS 首次购买时间 ,MAX(tt.order_date) AS 最近一次购买时间 ,GROUP_CONCAT(tt.购买商品 SEPARATOR '++') FROM ( SELECT t.order_user_id, t.open_id, t.order_id, t.order_date, t.渠道,SUM(t.real_total_amount) AS 订单实收1, SUM(t.discount_total_amount) AS 订单折扣1 ,CASE WHEN t.pay_amount IS NULL THEN 0 ELSE t.pay_amount END AS 订单实收 ,CASE WHEN t.pay_discount_amount IS NULL THEN 0 ELSE t.pay_discount_amount END AS 订单折扣 ,GROUP_CONCAT(t.product_name SEPARATOR '--') AS 购买商品 FROM (SELECT d.ITEM_NAME AS 渠道 ,CASE WHEN b.order_from=1 THEN 'bd下单' WHEN b.order_from=2 THEN '用户自主下单' WHEN b.order_from=3 THEN '企业用户下单'END AS 订单来源 ,b.order_date ,b.order_user_id ,po.open_id ,b.order_user_name ,b.order_id ,REPLACE(REPLACE(REPLACE(a.product_name,CHAR(13),''),CHAR(9),''),CHAR(10),'') AS product_name ,a.quantity ,a.purchase_unit_price ,a.sale_unit_price ,a.origin_sale_unit_price ,a.discount_total_amount ,a.real_total_amount ,c.pay_amount ,c.pay_discount_amount FROM fe_goods.sf_group_order_item a JOIN fe_goods.sf_group_order b ON a.order_id=b.order_id JOIN fe_goods.sf_group_order_pay c ON b.order_id=c.order_id JOIN fe.pub_user_open po ON po.USER_ID = b.order_user_id LEFT JOIN fe.pub_dictionary_item d ON b.sale_channel=d.ITEM_VALUE and d.dictionary_id=192 WHERE a.data_flag=1 AND b.data_flag=1 AND pay_state = 2 AND b.order_date BETWEEN SUBDATE(CURDATE(),INTERVAL 3 MONTH) AND SUBDATE(CURDATE(),INTERVAL 1 DAY) GROUP BY b.order_user_id,b.order_id,a.product_name ORDER BY b.order_user_id,b.order_id )t GROUP BY t.order_user_id,t.order_id,t.渠道 )tt GROUP BY tt.order_user_id ORDER BY COUNT(DISTINCT tt.order_date) DESC ) AS `t`	


企业用户复购  07：31 --07：36





/* By YouData (TransId: iMaxyFvtQ6hHu26xwpNzrH) */SELECT * FROM ( SELECT a.shelf_id AS '前置仓ID', t3.shelf_code AS '前置仓编码', t3.shelf_name AS '前置仓名称', t6.PRODUCT_ID AS '商品ID', t6.PRODUCT_CODE2 AS '商品FE码', t6.PRODUCT_NAME AS '商品名称', t4.business_name AS '区域', t4.city_name AS '城市', t5.sf_code AS '管理员工号', t5.real_name AS '管理员名称', a.CHECK_ID AS '盘点ID', CASE WHEN b.check_type = 1 THEN '普通盘点' WHEN b.check_type = 2 THEN '过期盘点' WHEN b.check_type = 3 THEN '撤架盘点' WHEN b.check_type = 4 THEN '巡检盘点' WHEN b.check_type = 5 THEN '前置仓效期盘点' END AS '盘点类型', CASE WHEN a.AUDIT_STATUS = 1 THEN '待审核' WHEN a.AUDIT_STATUS = 2 THEN '已审核' WHEN a.AUDIT_STATUS = 3 THEN '-' END AS '审核状态', b.OPERATE_TIME AS '盘点时间', t9.avg_sale_price AS sale_price, SUM(a.STOCK_NUM) AS '库存数量', SUM(a.STOCK_NUM * t7.purchase_price) AS '库存金额', SUM(a.CHECK_NUM) AS '盘点数量', SUM(a.CHECK_NUM * t7.purchase_price) AS '盘点金额', SUM(CASE WHEN b.check_type = 5 THEN a.total_error_num ELSE a.ERROR_NUM END) AS '差异数量', SUM(CASE WHEN b.check_type = 5 THEN IFNULL(a.total_error_num * t7.purchase_price,0) ELSE IFNULL(a.ERROR_NUM * t7.purchase_price,0) END) AS '差异金额', SUM(CASE WHEN a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.AUDIT_ERROR_NUM WHEN a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM,0) + IFNULL(t8.other_audit_error_num,0) END) AS '审核通过后差异数量', SUM(CASE WHEN a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) WHEN a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) + IFNULL(t8.other_audit_error_num * t7.purchase_price,0) END) AS '审核通过后差异金额', SUM(CASE WHEN a.ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM WHEN a.ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num END) AS '货物破损数量', SUM(CASE WHEN a.ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN IFNULL(a.ERROR_NUM * t7.purchase_price,0) WHEN a.ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.total_error_num * t7.purchase_price,0) END) AS '货物破损金额', SUM(CASE WHEN a.ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.AUDIT_ERROR_NUM WHEN a.ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM,0) + IFNULL(t8.other_audit_error_num,0) END) AS '货物破损审核后异常数量', SUM(CASE WHEN a.ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) WHEN a.ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) + IFNULL(t8.other_audit_error_num * t7.purchase_price,0) END) AS '货物破损审核后异常金额', SUM(CASE WHEN a.ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM WHEN a.ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num END) AS '商品过期数量', SUM(CASE WHEN a.ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM * t7.purchase_price WHEN a.ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num * t7.purchase_price END) AS '商品过期金额', SUM(CASE WHEN a.ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.AUDIT_ERROR_NUM WHEN a.ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM,0) + IFNULL(t8.other_audit_error_num,0) END) AS '商品过期审核后异常数量', SUM(CASE WHEN a.ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) WHEN a.ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) + IFNULL(t8.other_audit_error_num * t7.purchase_price,0) END) AS '商品过期审核后异常金额', SUM(CASE WHEN a.ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM WHEN a.ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num END) AS '盘点盗损数量', SUM(CASE WHEN a.ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM * t7.purchase_price WHEN a.ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num * t7.purchase_price END) AS '盘点盗损金额', SUM(CASE WHEN a.ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.AUDIT_ERROR_NUM WHEN a.ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM,0) + IFNULL(t8.other_audit_error_num,0) END) AS '盘点盗损审核后异常数量', SUM(CASE WHEN a.ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) WHEN a.ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) + IFNULL(t8.other_audit_error_num * t7.purchase_price,0) END) AS '盘点盗损审核后异常金额', SUM(CASE WHEN a.ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM WHEN a.ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num END) AS '商品质量异常数量', SUM(CASE WHEN a.ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM * t7.purchase_price WHEN a.ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num * t7.purchase_price END) AS '商品质量异常金额', SUM(CASE WHEN a.ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.AUDIT_ERROR_NUM WHEN a.ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM,0) + IFNULL(t8.other_audit_error_num,0) END) AS '商品质量审核后异常数量', SUM(CASE WHEN a.ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) WHEN a.ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) + IFNULL(t8.other_audit_error_num * t7.purchase_price,0) END) AS '商品质量审核后异常金额', SUM(CASE WHEN a.ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM WHEN a.ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num END) AS '其他差异数量', SUM(CASE WHEN a.ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.ERROR_NUM * t7.purchase_price WHEN a.ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN a.total_error_num * t7.purchase_price END) AS '其他差异金额', SUM(CASE WHEN a.ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN a.AUDIT_ERROR_NUM WHEN a.ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM,0) + IFNULL(t8.other_audit_error_num,0) END) AS '其他差异审核后异常数量', SUM(CASE WHEN a.ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) WHEN a.ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN IFNULL(a.AUDIT_ERROR_NUM * t7.purchase_price,0) + IFNULL(t8.other_audit_error_num * t7.purchase_price,0) END) AS '其他差异审核后异常金额' FROM fe.sf_shelf_check_detail a LEFT JOIN fe.sf_shelf_check b ON a.check_id = b.check_id LEFT JOIN fe.sf_shelf t3 ON b.shelf_id = t3.shelf_id LEFT JOIN feods.`fjr_city_business` t4 ON t3.`CITY` = t4.`CITY` LEFT JOIN fe.pub_shelf_manager t5 ON t3.manager_id = t5.manager_id LEFT JOIN fe.`sf_product` t6 ON a.PRODUCT_ID = t6.PRODUCT_ID LEFT JOIN (SELECT a.stat_month,a.business_area,a.product_code2,a.purchase_price FROM feods.`wt_monthly_manual_purchase_price` a GROUP BY a.stat_month,a.business_area,a.product_code2) t7 ON t4.business_name = t7.business_area AND t6.PRODUCT_CODE2 = t7.product_code2 AND DATE(t7.stat_month) = LAST_DAY(b.operate_time) LEFT JOIN fe.sf_shelf_check_detail_extend t8 ON a.DETAIL_ID = t8.detail_id LEFT JOIN fe_dm.`dm_pub_area_product_stat` t9 ON t9.sdate = SUBDATE(CURDATE(),1) AND t9.business_name = t4.business_name AND t9.PRODUCT_ID = a.PRODUCT_ID WHERE b.shelf_id IN (SELECT DISTINCT warehouse_id AS shelf_id FROM fe.sf_prewarehouse_dept_detail) AND b.operate_time >= SUBDATE(ADDDATE(CURRENT_DATE,INTERVAL -DAY(CURRENT_DATE)+1 DAY),INTERVAL 6 MONTH) AND b.operate_time < ADDDATE(LAST_DAY(CURRENT_DATE),1) GROUP BY a.shelf_id, a.CHECK_ID, t6.PRODUCT_ID, DATE(b.OPERATE_TIME) ORDER BY a.shelf_id,DATE(b.OPERATE_TIME),t6.PRODUCT_ID ) AS `t`	


	
前置站盘点商品明细（不含效期盘点）  07：36 --07：38



存储过程汇总/实例2/运营部门/dm_op_preware_fill_match_daily.sql
@唐进  dm_op_preware_fill_match_daily 新建过程，时间8点钟之前就好，每日

CALL sh_process.dm_op_preware_fill_match_daily(SUBDATE(CURDATE(),1))



实例1存储过程 dm_ma_activity_product_flag 停止调度哈




@唐进  实例1 dm_mp_purchase_sell_stock_summary这个有优化
还有这个dm_mp_loss_total_sublist


进进，fe_dwd.dwd_prewarehouse_base_day ：增加了 region_name,CITY_NAME 这两个字段，实例一实例二已经加了这两个字段@唐进


进进，我已经建好表了，帮伟铨把这个表SELECT COUNT(1) FROM fe.sf_product_activity_scope >全量同步至实例二  fe_dwd.`dwd_product_activity_scope`




dm_lo_manager_performance_report_everyday_for_month 实例2任务调整到02：00，因为03：40CPU资源高
dm_prewarehouse_stock_detail_weekly_monthly　实例２任务调整到03:24,因为03：43CPU高


实例1 存储过程停止调度：sh_process.dm_ma_market_discount_activity，sh_process.dm_ma_activity_product_flag
实例2存储过程：sh_process.dm_ma_activity_flag5_product 停止调度，同时停止同步实例1


fe_dwd.dwd_sf_activity_user_join fe_dwd.dwd_sf_activity_user_join_item 这两个表是不是可以删掉 实例2

sf_activity_user_join





@唐进  需要部署存储过程， dm_op_preware_lack_reason，你等下看我部署一下


ALTER TABLE fe_dwd.`dwd_shelf_base_day_all` ADD is_new INT DEFAULT 0 COMMENT "是否新装(0:2021年3月1日之前激活、挪点、测试;1:2021年3月1日之后激活)" AFTER BUSINESS_CHARACTERISTICS