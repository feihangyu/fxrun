

-- 查询实例2当日azkaban任务执行超时等待的任务有哪些
SELECT * FROM fe_dwd.`sql_log_info` WHERE sdate=CURDATE() AND sql_str='@wait_time1--@wait_time2' AND run_time>0;

-- 查询实例2当日azkaban任务执行超时等待的任务对应的结果表及维护人信息 (用于网易有数抽取)
SELECT a.process,CONCAT(a.aim_base,'.',a.aim_table),a.aim_table_cname,b.maintainer 
FROM fe_dwd.`dwd_prc_project_process_source_aim_table_info` a
JOIN (SELECT project,maintainer FROM fe_dwd.`dwd_prc_project_process_info` GROUP BY  project,maintainer) b 
ON a.project=b.project 
WHERE a.process IN (
               SELECT DISTINCT SUBSTRING_INDEX(SUBSTRING_INDEX(task_name,'shprocess.',-1),'(',1) FROM fe_dwd.`sql_log_info` WHERE sdate=CURDATE() AND sql_str='@wait_time1--@wait_time2' AND run_time>0   -- 查询等待的任务
               ) AND LENGTH(a.aim_table)>2
GROUP BY a.process,CONCAT(a.aim_base,'.',a.aim_table),a.aim_table_cname,b.maintainer
;



-- 查询存储过程执行信息（什么时候开始执行，什么时候结束，耗时等信息） 
SELECT * FROM feods.`sf_dw_task_log` WHERE task_name='dwd_order_item_refund_day_inc' ;    -- 实例1 task_name 为存储过程名

-- 因为实例1 sf_dw_task_log 表不能直接查询开始时间和结束时间以及耗时信息，可以通过以下脚本查询
SELECT statedate, task_name,start_time,end_time,ROUND(run_time/60,1) AS run_time,run_time AS run_time_second FROM (
SELECT 
statedate,
task_name,
SUBSTRING_INDEX(loginfo,'%',-1) AS start_time,
createtime AS end_time,
TIMESTAMPDIFF(SECOND,SUBSTRING_INDEX(loginfo,'%',-1),createtime) AS run_time
FROM feods.sf_dw_task_log WHERE statedate='2020-08-10' AND loginfo NOT LIKE 'fjr%'
UNION ALL 
SELECT 
statedate,
task_name,
LEFT(RIGHT(loginfo,30),19) AS start_time,
createtime AS end_time,
TIMESTAMPDIFF(SECOND,LEFT(RIGHT(loginfo,30),19),createtime) AS run_time
FROM feods.sf_dw_task_log WHERE statedate='2020-08-10' AND loginfo LIKE 'fjr%'
) s WHERE s.task_name='dwd_order_item_refund_day_inc';                                   -- 实例1 task_name 为存储过程名  statedate为只是日期


SELECT * FROM fe_dwd.`dwd_sf_dw_task_log` WHERE task_name='dm_ma_shelf_product_monitor' ; -- 实例2 task_name 为存储过程名

-- 查询存储过程中某个sql执行耗时信息
SELECT* FROM feods.`sql_log_info` WHERE task_name='sh_member_research_crr_1' AND sql_str='@time_1--@time_3'       ;           -- 实例1 task_name 为存储过程名 ，sql_str为sql位置
SELECT* FROM fe_dwd.`sql_log_info` WHERE task_name='dm_op_product_area_sal_month_large_eight' AND sql_str='@time_1--@time_2' ;-- 实例1 task_name 为存储过程名 ，sql_str为sql位置

-- 查询存储过程信息（该存储过程所属调度工程，用的源表，写入的结果表）
SELECT * FROM feods.`prc_project_process_source_aim_table_info` WHERE PROCESS='dwd_order_item_refund_day_inc' ;   -- 实例1 PROCESS 为存储过程名
SELECT * FROM fe_dwd.`dwd_prc_project_process_source_aim_table_info` WHERE PROCESS='dm_ma_shelf_product_monitor' ;-- 实例1 PROCESS 为存储过程名

-- 查询存储过程依赖信息（其中dependent_project 为依赖的任务，不清楚可以看表信息）
SELECT * FROM feods.`prc_project_relationship_info` WHERE project IN (
SELECT project FROM feods.`prc_project_process_source_aim_table_info`  
WHERE PROCESS='dwd_order_item_refund_day_inc'     
GROUP BY project) ;  -- 实例1 PROCESS 为存储过程名

SELECT * FROM fe_dwd.`dwd_prc_project_relationship_detail_info` WHERE PROCESS='dm_ma_shelf_product_monitor'; -- 实例2 PROCESS 为存储过程名


-- 查datax同步信息（实例1和实例2的映射关系） dwd_datax_table_mapping_info 位于实例2
SELECT * FROM fe_dwd.dwd_datax_table_mapping_info  WHERE delete_flag=1 and table_name_one='feods.pj_zs_goods_damaged' ;   -- 知道实例1的表名
SELECT * FROM fe_dwd.dwd_datax_table_mapping_info  WHERE delete_flag=1 and table_name_two='fe_dm.dm_op_false_stock_danger_level' ;-- 知道实例2的表名
SELECT * FROM fe_dwd.dwd_datax_table_mapping_info  WHERE delete_flag=1 and datax_project_name='pj_zs_goods_damaged_erp' ; -- 知道datax同步任务名


-- 已切换到datax_web的同步任务用以下方法查询同步信息
SELECT 
CONCAT(b.job_desc,'_erp') AS '同步任务名',a.table_name_one AS '实例1表名',a.table_name_two AS '实例2表名',
b.trigger_time AS '同步开始时间',
b.handle_time AS '同步结束时间',
TIMESTAMPDIFF(SECOND,b.trigger_time,b.handle_time) AS '同步耗时（单位秒)'
FROM fe_dwd.`dwd_datax_table_mapping_info` a
JOIN fe_datax.job_log b
ON SUBSTRING_INDEX(a.table_name_one,'.',-1)=b.job_desc
AND  b.handle_code=200  #b.trigger_time>=CURRENT_DATE AND
AND a.table_name_two='fe_dwd.dwd_sf_shelf_machine_product_change'  -- 实例2表名
AND a.delete_flag=1;



SELECT 
CONCAT(b.job_desc,'_erp') AS '同步任务名',a.table_name_one AS '实例1表名',a.table_name_two AS '实例2表名',
b.trigger_time AS '同步开始时间',
b.handle_time AS '同步结束时间',
TIMESTAMPDIFF(SECOND,b.trigger_time,b.handle_time) AS '同步耗时（单位秒)'
FROM fe_dwd.`dwd_datax_table_mapping_info` a
JOIN fe_datax.job_log b
ON SUBSTRING_INDEX(a.table_name_one,'.',-1)=b.job_desc
AND  b.handle_code=200  #b.trigger_time>=CURRENT_DATE AND
AND a.table_name_one='fe.sf_shelf_machine_product_change'  -- 实例1表名
AND a.delete_flag=1;



-- 查看datax任务执行情况
SELECT * FROM fe_dwd.dwd_datax_excute_info_detective WHERE datax_project_name='pj_zs_goods_damaged_erp' ;  -- 知道datax同步任务名
SELECT * FROM fe_dwd.dwd_datax_excute_info_detective WHERE datax_table_name like '%pj_zs_goods_damaged%';  -- 知道实例1的表名



-- 查询表被哪个存储过程用到（包含存储过程是否在正常调度，调度时间信息）
SELECT b.update_frequency,b.start_time,a.* FROM feods.`prc_project_process_source_aim_table_info` a 
JOIN (SELECT project,update_frequency,start_time FROM feods.`prc_project_relationship_info` GROUP BY project ,update_frequency,start_time) b
ON a.project=b.project
WHERE a.source_table='pj_zs_goods_damaged' ;   -- 实例1 source_table 为表名


SELECT * FROM fe_dwd.`dwd_prc_project_relationship_detail_info` WHERE source_table='fe_dm.dm_pj_zs_goods_damaged'; -- 实例2 为表名 （需要带库名）