import os
import re
import pymysql
import time

#清空指定路径下的文件内容
def clear(text_path):
    with open(text_path, 'w') as f1:
        f1.seek(0)
        f1.truncate()
    print("清空数据")

#返回path1目录下的所有文件 存放在file_list中
def get_path_file(path1,file_list):
    if os.path.isdir(path1):
        files=os.listdir(path1)
        for f in files:
            new_path=os.path.join(path1,f)
            #print(new_path)
            if os.path.isdir(new_path):
                get_path_file(new_path,file_list)
            else:
                file_list.append(new_path)
            #get_path_file(new_path)
    return file_list

def extract_develop_table_intofile(file_list):  #需要将目录中存在目录的情况列出来
    for fl in file_list:  #获取每个目录下的文件
        fp=open(fl,'r',encoding='utf-8')
        each_file=fp.readlines()
        fp.close()
        for ef in each_file:
            com = re.compile(r'.+_.+_.+')  # 匹配类似表的字符串，因为开发的没有带库名，所以采用这种方式匹配
            a = re.search(com, ef)
            if a:
                aim_path = r'd:\user\01387858\desktop\反馈\第一次清洗'
                ao = a.group()
                # print(ao)
                with open(aim_path, 'a+', encoding='utf-8') as fs:
                    fs.write('目录：%s￥%s\n' % (fl,ao))  # 将同一个目录下所以的文件内容都写入另一个文件保存
                #time.sleep(0.01)
        time.sleep(0.1)



def final_filter():
    aim_path = r'd:\user\01387858\desktop\反馈\第一次清洗'
    obj=open(aim_path, 'r', encoding='utf-8').readlines()
    num=len(obj)
    print(num)
    for o in obj:  #遍历每个语句
        #if '目录：' not in o:
        sspath=o.split('￥')[0].split('开发脚本\\')[-1]
        #sspath2 = o.split('￥')[0].split('\\')[-1]
        #sspath='mapper\\'+sspath1+'\\'+sspath2
        sql_str=o.split('￥')[-1]
        com=re.compile(r'.+_.+_.+')  #匹配类似表的字符串，因为开发的没有带库名，所以采用这种方式匹配
        o_list=sql_str.replace('\t',' ').replace(',',' ').replace('"','').replace('`','').replace('.',' ').replace('=',' ').replace('(',' ').replace(')',' ').replace('/>',' ').split(' ')
        for ol in o_list:
            rs = re.search(com, ol)
            if rs:
                filter_path = r'd:\user\01387858\desktop\反馈\第二次清洗'
                res=rs.group()
                #print(ao)
                with open(filter_path, 'a+', encoding='utf-8') as fss:
                    fss.write('%s￥%s\n'%(sspath,res))  # 将同一个目录下所以的文件内容都写入另一个文件保存
        #print(sspath,o_list)
        time.sleep(0.1)

def get_result():
    npath=r'd:\user\01387858\desktop\反馈\第二次清洗'
    obj=open(npath, 'r', encoding='utf-8').read().split('\n')
    print('未去重：',len(obj))
    obj=list(set(obj))
    num=len(obj)
    print('去重后：',num)
    new_obj={i.split('￥')[-1]:i.split('￥')[0] for i in obj}
    #print(new_obj)
    #实例1
    conn1 = pymysql.connect(
        host='gz-cdb-2huk27sw.sql.tencentcdb.com',
        port=63298,
        user='feprocess',
        passwd='Tak()#Pause2019',
        db='feods',
        charset='utf8')
    cursor1 = conn1.cursor()
    table_coll1 = ('',)
    try:
        sql='''
        SELECT DISTINCT CONCAT(table_schema,'.',table_name,'￥base1') FROM `information_schema`.`TABLES` WHERE table_schema IN ('fe_dwd','fe_dm','feods','sserp','fe_data')
        '''
        cursor1.execute(sql)
        table_coll1=cursor1.fetchall()
        snum1 = cursor1.rowcount
        print(snum1)
    except Exception as e:
        print(e)

    table_coll = table_coll1
    ooo_list=[]
    for tt in table_coll: #table_coll分析库表集合
        if tt[0].split('.')[1].split('￥')[0] in new_obj.keys():  #表，不带库名
            database=tt[0].split('.')[1].split('￥')[-1]
            p=new_obj.get(tt[0].split('.')[1].split('￥')[0])
            tname=tt[0]
            ooo_list.append([p,tname.split('￥')[0],database])
    # print(ooo_list)
    try:
        #先将表进行清空
        truncate_sql='''
        truncate table fe_dwd.dwd_developer_use_analyze_table;
        '''
        cursor1.execute(truncate_sql)
        conn1.commit()
        # 插入最新的数据
        insert_sql = '''
         insert INTO fe_dwd.dwd_developer_use_analyze_table(fpath,extract_table_name,data_base) values(%s,%s,%s)
        '''
        cursor1.executemany(insert_sql, ooo_list)
        conn1.commit()
        print('insert ok')
    except Exception as e:
        conn1.rollback()
        print(e)
    finally:
        cursor1.close()
        conn1.close()

if __name__ == '__main__':
    base0_path = r'd:\user\01387858\desktop\开发脚本\data\data-service\src\main\resources\mybatis\mapper'  # 开发脚本代码本地仓库
    file_list = []
    file_list=get_path_file(base0_path,file_list)
    extract_develop_table_intofile(file_list)
    final_filter()
    get_result()

