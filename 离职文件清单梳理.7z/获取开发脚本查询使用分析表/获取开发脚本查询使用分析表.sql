

先执行git路径下的脚本： fe_data_analysis_group\唐进\离职文件清单梳理\获取开发脚本查询使用分析表\get_development_table.py
将开发的脚本相关信息写入表 fe_dwd.dwd_developer_use_analyze_table 后再执行下面的sql

-- 开发脚本提取分析库表
UPDATE fe_dwd.dwd_developer_use_analyze_table a
JOIN test.`fe_data_mapping_table` b
ON a.extract_table_name=b.fe_data_table
SET a.is_mapping=1,
    a.source_table_name=b.analyze_table;
   
   
UPDATE fe_dwd.dwd_developer_use_analyze_table a 
SET a.source_table_name=a.extract_table_name
WHERE source_table_name IS NULL;
