CREATE TABLE `dm_en_wastage_item` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `user_id` bigint(20) DEFAULT NULL COMMENT '下单人员ID',
  `sale_channel` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '销售渠道',
  `pay_type` varchar(7) DEFAULT NULL COMMENT '支付类型',
  `order_date` date DEFAULT NULL COMMENT '订单日期',
  `product_name` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `first_category_name` varchar(100) DEFAULT NULL COMMENT '商品一级分类',
  `pay_amount` decimal(18,2) DEFAULT NULL COMMENT '支付金额',
  `sale_total_amount` decimal(18,2) DEFAULT '0.00' COMMENT '商品实收',
  `freight_amount` decimal(18,2) DEFAULT '0.00' COMMENT '商品运费',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`pid`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_sale_channel` (`sale_channel`),
  KEY `idx_order_date` (`order_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='最近60-30天有购买 最近30天未购买用户最近一单购买明细'