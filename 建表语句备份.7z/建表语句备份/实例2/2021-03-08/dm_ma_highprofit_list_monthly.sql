CREATE TABLE `dm_ma_highprofit_list_monthly` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date NOT NULL COMMENT '统计月',
  `business_area` varchar(50) NOT NULL COMMENT '地区',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `profit_rate` decimal(18,4) DEFAULT '0.0000' COMMENT '毛利率',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `unique_key` (`sdate`,`business_area`,`product_id`),
  KEY `idx_last_update_time` (`business_area`)
) ENGINE=InnoDB AUTO_INCREMENT=9900 DEFAULT CHARSET=utf8mb4 COMMENT='每月高毛利地区商品清单'