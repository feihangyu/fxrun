CREATE TABLE `dwd_pub_auto_shelf_undock_insert` (
  `pid` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `MID` varchar(50) DEFAULT NULL COMMENT 'MID',
  `shelf_code` varchar(100) DEFAULT NULL COMMENT '货架编码',
  `shelf_id` int(10) NOT NULL COMMENT '货架ID',
  `business_name` varchar(50) DEFAULT NULL COMMENT '地区',
  `shelf_status` varchar(50) DEFAULT NULL COMMENT '设备状态',
  `manufacturer_name` varchar(100) DEFAULT NULL COMMENT '厂商名称',
  `shelf_type` varchar(20) DEFAULT NULL COMMENT '货架类型',
  `oper_way` decimal(10,2) DEFAULT NULL COMMENT '合作方式',
  `machine_type` varchar(20) DEFAULT NULL COMMENT '设备型号',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COMMENT='智能柜未对接设备清单(吹防维护)'