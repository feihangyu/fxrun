CREATE TABLE `dm_op_kpi2_product_new_out_sto_rate` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date DEFAULT '0000-00-00' COMMENT '日期',
  `version_id` varchar(100) DEFAULT '' COMMENT '版本号',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `if_new` tinyint(4) DEFAULT '0' COMMENT '是否新品',
  `if_out` tinyint(4) DEFAULT '0' COMMENT '是否淘汰品',
  `qty_sto` int(11) DEFAULT '0' COMMENT '库存数量',
  `val_sto` decimal(18,2) DEFAULT '0.00' COMMENT '库存金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`business_name`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10705250 DEFAULT CHARSET=utf8mb4 COMMENT='新品与淘汰品库存占比'