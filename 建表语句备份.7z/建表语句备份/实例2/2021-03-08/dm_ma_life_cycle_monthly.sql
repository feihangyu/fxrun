CREATE TABLE `dm_ma_life_cycle_monthly` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL COMMENT '月',
  `life_cycle_type` varchar(100) NOT NULL COMMENT '生命周期类型名称',
  `life_cycle` varchar(100) NOT NULL COMMENT '生命周期名称',
  `life_cycle_detail` varchar(100) NOT NULL COMMENT '生命周期细类名称',
  `gmv` decimal(12,2) NOT NULL DEFAULT '0.00',
  `amount` decimal(12,2) NOT NULL DEFAULT '0.00',
  `fee_marketing` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '营销费用',
  `rate_marketing` decimal(5,4) DEFAULT '0.0000',
  `roi` decimal(10,2) DEFAULT '0.00' COMMENT '投入产出比',
  PRIMARY KEY (`pid`),
  KEY `idx_sdate` (`sdate`),
  KEY `idx_life_cycle` (`life_cycle`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=5342 DEFAULT CHARSET=utf8mb4