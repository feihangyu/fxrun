CREATE TABLE `dwd_lo_prewarehouse_fill_order_item_month` (
  `task_record_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '表主键ID',
  `smonth` int(6) DEFAULT NULL COMMENT '统计月份',
  `order_id` bigint(20) NOT NULL COMMENT '订单ID',
  `SUPPLIER_ID` bigint(20) NOT NULL COMMENT '发货货架/前置仓ID',
  `shelf_id` bigint(20) NOT NULL COMMENT '收货货架/前置仓ID',
  `task_id` bigint(20) DEFAULT NULL COMMENT '串点任务ID(非串点任务则为 NULL)',
  `fill_type` int(2) DEFAULT NULL COMMENT '前置站订单类型(1:入库、2:出库、3:前置站间调货)',
  `FILL_TIME` datetime DEFAULT NULL COMMENT '上架时间',
  `PRODUCT_ID` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `QUALITY_NUM` int(5) DEFAULT NULL COMMENT '商品数量',
  `PURCHASE_PRICE` decimal(18,2) DEFAULT NULL COMMENT '采购价',
  `data_flag` tinyint(2) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`task_record_id`),
  KEY `idx_order_id` (`order_id`),
  KEY `idx_smonth` (`smonth`)
) ENGINE=InnoDB AUTO_INCREMENT=529752066 DEFAULT CHARSET=utf8mb4 COMMENT='前置站进出订单明细表'