CREATE TABLE `dm_op_abnormal_order_user` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `user_id` bigint(20) NOT NULL COMMENT '会员id',
  `orders` smallint(6) DEFAULT '0' COMMENT '订单数',
  `shelfs` smallint(6) DEFAULT '0' COMMENT '货架数',
  `skus` smallint(6) DEFAULT '0' COMMENT 'sku数',
  `quantity` bigint(20) DEFAULT '0' COMMENT '购买数量',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `val_cost` decimal(18,2) DEFAULT '0.00' COMMENT '成本',
  `discount_amount` decimal(18,2) DEFAULT '0.00' COMMENT '订单优惠金额',
  `coupon_amount` decimal(18,2) DEFAULT '0.00' COMMENT '优惠券优惠金额',
  `third_discount_amount` decimal(18,2) DEFAULT '0.00' COMMENT '第三方优惠金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83372 DEFAULT CHARSET=utf8mb4 COMMENT='订单异常监控_用户'