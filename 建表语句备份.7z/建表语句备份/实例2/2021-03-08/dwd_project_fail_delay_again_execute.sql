CREATE TABLE `dwd_project_fail_delay_again_execute` (
  `sdate` date NOT NULL COMMENT '日期',
  `project` varchar(128) NOT NULL COMMENT '任务名',
  `dependent_project` varchar(128) NOT NULL COMMENT '依赖的任务名',
  `d_start_time` varchar(32) DEFAULT NULL COMMENT '任务（即project)原计划执行时间',
  `project_repair_time` datetime DEFAULT NULL COMMENT '依赖任务（即dependent_project)修复时间',
  `dp_will_start_time` datetime DEFAULT NULL COMMENT '依赖任务（即dependent_project）修复后，任务（即project）将会执行时间',
  PRIMARY KEY (`sdate`,`project`,`dependent_project`),
  KEY `idx_dp_will_start_time` (`dp_will_start_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='工程调度失败后依赖工程执行时间信息'