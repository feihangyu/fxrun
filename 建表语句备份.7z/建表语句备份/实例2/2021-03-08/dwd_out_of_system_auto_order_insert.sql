CREATE TABLE `dwd_out_of_system_auto_order_insert` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `order_id` varchar(50) DEFAULT NULL COMMENT '订单id',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架id',
  `shelf_from` varchar(50) DEFAULT NULL COMMENT '货架来源',
  `third_shelf_id` varchar(50) DEFAULT NULL COMMENT '第三方货架id',
  `order_date` datetime DEFAULT NULL COMMENT '下单时间',
  `pay_date` datetime DEFAULT NULL COMMENT '支付时间',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `PRODUCT_NAME` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `sale_price` decimal(18,2) DEFAULT NULL COMMENT '商品单价',
  `quantity` int(11) DEFAULT NULL COMMENT '销售数量',
  `pay_amount` decimal(18,2) DEFAULT NULL COMMENT '支付金额(包含退款))',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  KEY `idx_sf_order_paytime` (`pay_date`),
  KEY `idx_sf_order_order_id` (`order_id`),
  KEY `idx_sf_order_product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=616781 DEFAULT CHARSET=utf8mb4 COMMENT='智能柜未对接数据(李吹防维护)'