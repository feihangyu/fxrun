CREATE TABLE `dwd_mp_cmbc_payment` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date DEFAULT NULL COMMENT '统计日期',
  `order_date` datetime DEFAULT NULL COMMENT '订单日期',
  `pay_time` datetime DEFAULT NULL COMMENT '支付日期',
  `order_id` bigint(20) NOT NULL COMMENT '订单编号',
  `CMBC_pay_type` varchar(20) DEFAULT NULL COMMENT '招行支付类型',
  `CMBC_pay_id` varchar(32) DEFAULT NULL COMMENT '流水号',
  `GMV` decimal(18,2) DEFAULT '0.00' COMMENT '招行GMV',
  `pay_amount` decimal(18,2) DEFAULT '0.00' COMMENT '付款金额',
  `third_amount` decimal(18,2) DEFAULT '0.00' COMMENT '招行优惠金额',
  `shelf_type` varchar(30) DEFAULT NULL COMMENT '货架类型',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_payment_sdate` (`sdate`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=290352 DEFAULT CHARSET=utf8mb4 COMMENT='经规-财务对账-招行支付明细'