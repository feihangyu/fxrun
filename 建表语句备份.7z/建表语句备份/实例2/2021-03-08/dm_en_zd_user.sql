CREATE TABLE `dm_en_zd_user` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `customer_user_id` bigint(20) DEFAULT NULL COMMENT '消费端用户ID',
  `group_customer_id` bigint(20) DEFAULT NULL COMMENT '企业id',
  `group_name` varchar(200) DEFAULT NULL COMMENT '企业名称',
  `emp_user_name` varchar(100) DEFAULT NULL COMMENT '姓名',
  `mobile` varchar(11) DEFAULT NULL COMMENT '手机号',
  `emp_user_id` bigint(20) DEFAULT NULL COMMENT '员工id',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  KEY `idx_dwd_group_emp_user_id` (`emp_user_id`),
  KEY `idx_dwd_group_customer_user_id` (`customer_user_id`),
  KEY `idx_dwd_group_mobile` (`mobile`),
  KEY `idx_group_customer_id` (`group_customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1024 DEFAULT CHARSET=utf8mb4 COMMENT='中电打标签表'