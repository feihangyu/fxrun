CREATE TABLE `dwd_sf_prewarehouse_supplier_detail` (
  `detail_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '前置仓供应商详情编号',
  `supplier_id` bigint(20) DEFAULT NULL COMMENT '供应商编号',
  `warehouse_id` bigint(20) DEFAULT NULL COMMENT '仓库编号',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT NULL COMMENT '添加人编号',
  `last_update_user_id` bigint(20) DEFAULT NULL COMMENT '最后修改人编号',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `data_flag` tinyint(1) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  PRIMARY KEY (`detail_id`),
  KEY `FK_prewarehouseSupplier_supplierId` (`supplier_id`),
  KEY `FK_prewarehouseSupplier_warehouseId` (`warehouse_id`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=905 DEFAULT CHARSET=utf8mb4 COMMENT='前置仓供应商关系信息'