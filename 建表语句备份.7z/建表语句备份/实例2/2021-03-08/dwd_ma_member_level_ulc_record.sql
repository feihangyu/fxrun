CREATE TABLE `dwd_ma_member_level_ulc_record` (
  `month_id` date NOT NULL COMMENT '每月第一天日期',
  `user_id` int(10) NOT NULL COMMENT '用户ID',
  `create_date` datetime DEFAULT NULL COMMENT '创建日期',
  `member_level` int(10) DEFAULT NULL COMMENT '当月用户等级',
  `ulc` int(10) DEFAULT NULL COMMENT '用户生命周期：1:导入期,2:成长期,3:成熟期,4:休眠期,5:流失期',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`month_id`,`user_id`),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户等级与生命周期月统计表'
/*!50100 PARTITION BY LIST (EXTRACT(MONTH FROM month_id))
(PARTITION p1 VALUES IN (1) ENGINE = InnoDB,
 PARTITION p2 VALUES IN (2) ENGINE = InnoDB,
 PARTITION p3 VALUES IN (3) ENGINE = InnoDB,
 PARTITION p4 VALUES IN (4) ENGINE = InnoDB,
 PARTITION p5 VALUES IN (5) ENGINE = InnoDB,
 PARTITION p6 VALUES IN (6) ENGINE = InnoDB,
 PARTITION p7 VALUES IN (7) ENGINE = InnoDB,
 PARTITION p8 VALUES IN (8) ENGINE = InnoDB,
 PARTITION p9 VALUES IN (9) ENGINE = InnoDB,
 PARTITION p10 VALUES IN (10) ENGINE = InnoDB,
 PARTITION p11 VALUES IN (11) ENGINE = InnoDB,
 PARTITION p12 VALUES IN (12) ENGINE = InnoDB) */