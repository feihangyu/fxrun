CREATE TABLE `dm_ma_user_product_list` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `user_id` bigint(20) NOT NULL,
  `product_id` bigint(20) NOT NULL,
  `first_buy_day` date NOT NULL COMMENT '第一次购买时间',
  `last_buy_day` date NOT NULL COMMENT '最后一次购买时间',
  `first_qty` smallint(6) NOT NULL DEFAULT '0' COMMENT '第一次购买数量',
  `last_qty` smallint(6) NOT NULL DEFAULT '0' COMMENT '最后一次购买数量',
  `all_qty` mediumint(9) NOT NULL DEFAULT '0' COMMENT '总购买数量',
  `sale_price` decimal(6,2) NOT NULL DEFAULT '0.00' COMMENT '最近购买价格',
  PRIMARY KEY (`user_id`,`product_id`),
  KEY `idx_last_buy_day` (`last_buy_day`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户购买商品清单'