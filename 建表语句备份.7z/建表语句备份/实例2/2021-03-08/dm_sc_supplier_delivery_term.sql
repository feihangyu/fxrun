CREATE TABLE `dm_sc_supplier_delivery_term` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `region_area` varchar(20) DEFAULT NULL COMMENT '大区',
  `business_area` varchar(20) DEFAULT NULL COMMENT '区域',
  `short_name` varchar(30) DEFAULT NULL COMMENT '供应商缩写',
  `supplier_name` varchar(50) DEFAULT NULL COMMENT '供应商名称',
  `contract_delivery` int(4) DEFAULT NULL COMMENT '合同交期',
  `supplier_a_type` varchar(20) DEFAULT NULL COMMENT '供应区域类型',
  `supplier_p_type` varchar(20) DEFAULT NULL COMMENT '供应商品类型',
  `delivery_term` decimal(7,4) DEFAULT NULL COMMENT '近2个月交期',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_business_suppliername` (`business_area`,`short_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4096 DEFAULT CHARSET=utf8mb4 COMMENT='采购供应商类型及交期'