CREATE TABLE `dwd_sf_user_profile_survey_answer` (
  `answer_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '用户职场形象信息收集回答id',
  `survey_id` bigint(20) NOT NULL COMMENT '问卷调查id',
  `question_id` bigint(20) NOT NULL COMMENT '问卷调查的问题id',
  `order_num` int(11) NOT NULL COMMENT '问卷调查的问题序号',
  `content` varchar(500) NOT NULL DEFAULT '' COMMENT '回答内容',
  `content_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '答案id',
  `user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '用户ID',
  `data_flag` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`answer_id`),
  KEY `idx_profile_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=434787 DEFAULT CHARSET=utf8mb4 COMMENT='用户职场形象信息收集回答表'