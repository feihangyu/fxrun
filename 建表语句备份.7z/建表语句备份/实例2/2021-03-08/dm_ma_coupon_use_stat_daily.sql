CREATE TABLE `dm_ma_coupon_use_stat_daily` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT,
  `sdate` date NOT NULL,
  `coupon_id` bigint(20) NOT NULL,
  `coupon_name` varchar(50) DEFAULT NULL,
  `coupon_usage` varchar(50) DEFAULT NULL,
  `cost_dept` varchar(20) DEFAULT NULL COMMENT '费用归属部门',
  `business_type` varchar(20) DEFAULT NULL COMMENT '优惠券业务类型',
  `discount_type` varchar(20) DEFAULT NULL COMMENT '折扣类型',
  `reach_amount` decimal(10,2) DEFAULT NULL COMMENT '订单金额',
  `discount_amount` decimal(10,1) DEFAULT NULL COMMENT '优惠金额',
  `discount` decimal(10,1) DEFAULT NULL COMMENT '优惠力度（折扣）',
  `use_num` mediumint(9) DEFAULT NULL COMMENT '使用数量',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `idx_sdate_coupon_id` (`sdate`,`coupon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=965290 DEFAULT CHARSET=utf8mb4 COMMENT='每日优惠券使用统计'