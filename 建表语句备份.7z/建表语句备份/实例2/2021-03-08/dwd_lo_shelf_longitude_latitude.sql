CREATE TABLE `dwd_lo_shelf_longitude_latitude` (
  `type_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架编号',
  `lng` decimal(18,5) DEFAULT NULL COMMENT '经度',
  `lat` decimal(18,5) DEFAULT NULL COMMENT '维度',
  `data_flag` tinyint(2) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`type_id`),
  KEY `idx_shelf_id` (`shelf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=809872 DEFAULT CHARSET=utf8mb4 COMMENT='货架经纬度信息表(wgs84坐标系)'