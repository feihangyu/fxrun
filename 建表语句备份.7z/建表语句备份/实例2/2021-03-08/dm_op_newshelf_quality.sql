CREATE TABLE `dm_op_newshelf_quality` (
  `sdate` date NOT NULL COMMENT '日期',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `exploit_type` int(2) DEFAULT '1' COMMENT '开拓类型(1:业务开发、2:公司申请)(dict)',
  `revoke_status` int(2) DEFAULT NULL COMMENT '字典名：frevokestatus；撤架状态(1:正在运营、2:撤架审核中、3:审核通过、4:审核不通过、5:待盘点、6:待交接、7:撤架完成、8:待处理)',
  `users` int(11) DEFAULT '0' COMMENT '14天内用户数',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT '14天内gmv',
  `payment_money` decimal(18,2) DEFAULT '0.00' COMMENT '14天内补付款',
  `add_user` varchar(32) DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`sdate`,`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='新装货架质量'