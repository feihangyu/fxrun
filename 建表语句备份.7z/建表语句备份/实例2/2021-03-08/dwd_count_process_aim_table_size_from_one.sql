CREATE TABLE `dwd_count_process_aim_table_size_from_one` (
  `sdate` date NOT NULL COMMENT '日期',
  `table_name` varchar(128) NOT NULL COMMENT '表名',
  `process_name` varchar(128) DEFAULT NULL COMMENT '所属存储过程名',
  `nums` bigint(20) DEFAULT NULL COMMENT '数据量',
  `maintainer` varchar(32) DEFAULT NULL COMMENT '维护人员',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`sdate`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='实例2存储过程结果表数据统计'