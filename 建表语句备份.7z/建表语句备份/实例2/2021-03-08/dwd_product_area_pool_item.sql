CREATE TABLE `dwd_product_area_pool_item` (
  `papi_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `pap_id` bigint(20) DEFAULT NULL COMMENT '地区商品池id',
  `shelf_type` bigint(20) DEFAULT NULL COMMENT '货架类型',
  `suggest_quantity` int(10) unsigned DEFAULT NULL COMMENT '标配数量',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`papi_id`),
  UNIQUE KEY `uk_papi_papId_shelfType` (`pap_id`,`shelf_type`)
) ENGINE=InnoDB AUTO_INCREMENT=109849 DEFAULT CHARSET=utf8mb4 COMMENT='地区商品池明细表'