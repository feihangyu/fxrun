CREATE TABLE `dm_ma_business_optunity_record` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `apply_time` datetime NOT NULL COMMENT '申请日期时间',
  `bo_shelf_type` varchar(100) NOT NULL COMMENT '申请货架类型',
  `business_optunity_source` varchar(100) NOT NULL COMMENT '商机来源',
  `channel_code` varchar(100) DEFAULT NULL COMMENT '推广渠道',
  `company_name` varchar(100) DEFAULT NULL COMMENT '公司名称',
  `apply_user_id` bigint(20) DEFAULT NULL COMMENT '申请用户id',
  `user_type` varchar(100) DEFAULT NULL COMMENT '申请用户类型',
  `apply_audit_status_desc` varchar(100) NOT NULL COMMENT '商机审核状态',
  PRIMARY KEY (`pid`),
  KEY `idx_apply_time` (`apply_time`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=1360418 DEFAULT CHARSET=utf8mb4 COMMENT='商机明细记录\r\n'