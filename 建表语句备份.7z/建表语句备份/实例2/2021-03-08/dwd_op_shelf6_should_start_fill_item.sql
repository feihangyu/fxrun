CREATE TABLE `dwd_op_shelf6_should_start_fill_item` (
  `week_end` datetime NOT NULL COMMENT '周最后一天',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `product_type` varchar(32) DEFAULT NULL COMMENT '商品类型',
  `sales_flag` int(2) DEFAULT NULL COMMENT '销售等级',
  `shelf_fill_flag` varchar(2) DEFAULT NULL COMMENT '补货标识',
  `stock` bigint(20) DEFAULT '0' COMMENT '大仓库存',
  `pre_stock` bigint(20) DEFAULT '0' COMMENT '前置仓库存',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`week_end`,`shelf_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='智能货柜需开启补货商品明细'