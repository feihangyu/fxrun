CREATE TABLE `dm_sc_warehouse_stock_monthly` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `smonth` varchar(20) DEFAULT NULL COMMENT '月份',
  `region_area` varchar(50) DEFAULT NULL COMMENT '大区',
  `business_area` varchar(50) DEFAULT NULL COMMENT '区域',
  `warehouse_number` varchar(30) DEFAULT NULL COMMENT '仓库编码',
  `warehouse_name` varchar(50) DEFAULT NULL COMMENT '仓库名称',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品ID',
  `product_code2` varchar(100) DEFAULT NULL COMMENT '商品FE编码',
  `product_name` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `stock_quantity` int(10) NOT NULL COMMENT '库存量',
  `qualityqty` int(10) DEFAULT NULL COMMENT '正品库存量',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `uqk_smonth_business_product` (`smonth`,`business_area`,`product_code2`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_warehouse_product` (`warehouse_number`,`product_code2`)
) ENGINE=InnoDB AUTO_INCREMENT=2069321 DEFAULT CHARSET=utf8mb4 COMMENT='大仓月度BDP累计库存汇总'