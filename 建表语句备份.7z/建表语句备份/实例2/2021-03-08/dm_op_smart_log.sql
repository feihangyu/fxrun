CREATE TABLE `dm_op_smart_log` (
  `kid` bigint(20) NOT NULL DEFAULT '0' COMMENT '主键',
  `mflag` tinyint(1) DEFAULT '0' COMMENT '去重标识',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架编码',
  `user_id` bigint(20) DEFAULT '0' COMMENT '用户id',
  `operation_type` int(11) DEFAULT NULL COMMENT '交易状态',
  `operation_result` int(11) DEFAULT NULL COMMENT '操作结果',
  `operation_time` datetime DEFAULT NULL COMMENT '操作时间',
  `operation_remark` varchar(512) DEFAULT NULL COMMENT '备注',
  `transaction_id` varchar(32) DEFAULT NULL COMMENT '交易id',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`kid`),
  KEY `shelf_id` (`shelf_id`),
  KEY `operation_time` (`operation_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='智能货架开门记录'