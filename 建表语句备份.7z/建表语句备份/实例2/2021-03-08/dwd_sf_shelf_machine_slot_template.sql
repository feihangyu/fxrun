CREATE TABLE `dwd_sf_shelf_machine_slot_template` (
  `slot_template_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `template_no` varchar(10) DEFAULT NULL COMMENT '模版编码',
  `template_name` varchar(20) DEFAULT NULL COMMENT '模版名称',
  `machine_type_id` varchar(10) DEFAULT NULL COMMENT '模版适用机器型号id',
  `data_flag` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加人编号',
  `last_update_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后修改人编号',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`slot_template_id`),
  UNIQUE KEY `idx_template_no` (`template_no`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COMMENT='贩卖机货道模版表'