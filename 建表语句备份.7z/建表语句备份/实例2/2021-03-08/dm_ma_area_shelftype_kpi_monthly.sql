CREATE TABLE `dm_ma_area_shelftype_kpi_monthly` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL,
  `business_area` varchar(50) NOT NULL,
  `shelf_type` varchar(50) NOT NULL,
  `shelfs` mediumint(9) DEFAULT '0',
  `shelfs_sale` bigint(20) NOT NULL DEFAULT '0' COMMENT '有销售货架数',
  `GMV` decimal(15,2) DEFAULT '0.00',
  `amount` decimal(15,2) DEFAULT '0.00',
  `orders` bigint(21) DEFAULT '0',
  `users` bigint(21) DEFAULT '0',
  `users_reorder` mediumint(9) DEFAULT '0',
  `discount_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  `coupon_amount` decimal(14,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`sdate`,`business_area`,`shelf_type`),
  KEY `idx_business_area` (`business_area`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区货架类型月报'