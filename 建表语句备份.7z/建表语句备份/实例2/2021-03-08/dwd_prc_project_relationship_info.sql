CREATE TABLE `dwd_prc_project_relationship_info` (
  `project` varchar(128) NOT NULL DEFAULT '' COMMENT '工程名',
  `start_time` varchar(32) DEFAULT NULL COMMENT '开始时间',
  `start_time_day` datetime DEFAULT NULL COMMENT '当日开始时间',
  `end_time_day` datetime DEFAULT NULL COMMENT '当日结束时间',
  `run_time` decimal(18,1) DEFAULT NULL COMMENT '运行耗时',
  `update_detail` varchar(32) DEFAULT NULL COMMENT '更新频率（日 周 月）',
  `update_frequency` varchar(64) DEFAULT NULL COMMENT '更新频率',
  `dependent_project` varchar(128) NOT NULL DEFAULT '' COMMENT '依赖的工程名',
  `d_start_time` datetime DEFAULT NULL COMMENT '依赖工程开始时间',
  `d_end_time` datetime DEFAULT NULL COMMENT '依赖工程结束时间',
  `d_update_detail` varchar(32) DEFAULT NULL COMMENT '依赖工程更新频率（日 周 月）',
  `d_update_frequency` varchar(64) DEFAULT NULL COMMENT '依赖工程更新频率',
  `is_true` char(4) DEFAULT NULL COMMENT '依赖关系是否正确',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`project`,`dependent_project`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='工程之间的依赖关系表'