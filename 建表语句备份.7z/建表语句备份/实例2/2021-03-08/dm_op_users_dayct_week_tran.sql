CREATE TABLE `dm_op_users_dayct_week_tran` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `users_week` int(11) DEFAULT '0' COMMENT '周当天新增用户数',
  PRIMARY KEY (`row_id`)
) ENGINE=InnoDB AUTO_INCREMENT=90844 DEFAULT CHARSET=utf8mb4 COMMENT='周每日新增用户'