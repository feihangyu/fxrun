CREATE TABLE `dwd_sf_pay_requirement` (
  `requirement_id` bigint(20) NOT NULL COMMENT '支付需求单',
  `order_id` bigint(20) DEFAULT NULL COMMENT '订单编号',
  `requirement_type` varchar(20) DEFAULT 'shopOrder' COMMENT '需求类型（shopOrder. 商城订单）',
  `pay_method_codes` varchar(50) DEFAULT NULL COMMENT '支付方式编码逗号隔开:e币支付:EPay;微信:WX_PAY',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '支付金额',
  `pay_state` tinyint(1) DEFAULT NULL COMMENT '支付状态(1:未支付、2:已支付、3:已退款)',
  `remark` varchar(512) DEFAULT NULL COMMENT '备注字段',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`requirement_id`),
  KEY `idx_order_id` (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='支付需求单表'