CREATE TABLE `dwd_sf_product_machine_slot` (
  `product_slot_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '关系id',
  `product_id` bigint(20) DEFAULT '0' COMMENT '商品扩展id',
  `slot_type_id` tinyint(3) DEFAULT '0' COMMENT '货道类型id',
  `data_flag` tinyint(1) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人编号',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人编号',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`product_slot_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_slot_type_id` (`slot_type_id`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=9140 DEFAULT CHARSET=utf8mb4 COMMENT='商品包商品和货道类型关系表（多对多）'