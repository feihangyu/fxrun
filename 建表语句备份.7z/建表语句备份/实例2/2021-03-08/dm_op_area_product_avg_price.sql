CREATE TABLE `dm_op_area_product_avg_price` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `business_name` varchar(32) NOT NULL COMMENT '地区',
  `shelf_type` varchar(32) NOT NULL COMMENT '货架类型',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `version` varchar(50) DEFAULT NULL COMMENT '版本号',
  `product_type` varchar(32) DEFAULT NULL COMMENT '商品类型',
  `amount` bigint(20) DEFAULT '0' COMMENT '销量',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT '本月gmv',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`month_id`,`business_name`,`shelf_type`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区商品平均单价'