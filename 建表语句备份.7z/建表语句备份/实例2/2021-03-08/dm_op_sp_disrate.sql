CREATE TABLE `dm_op_sp_disrate` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架编号',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `product_name` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `out_date` date DEFAULT NULL COMMENT '淘汰日期',
  `stock_frag` varchar(32) DEFAULT NULL COMMENT '周转天数区间',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `shelf_id` (`shelf_id`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2883541 DEFAULT CHARSET=utf8mb4 COMMENT='淘汰品建议折扣_货架商品'