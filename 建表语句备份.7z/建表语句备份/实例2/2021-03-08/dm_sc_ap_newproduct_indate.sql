CREATE TABLE `dm_sc_ap_newproduct_indate` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `business_area` varchar(30) DEFAULT NULL COMMENT '区域',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `product_code2` varchar(20) DEFAULT NULL COMMENT '商品FE编码',
  `product_type` varchar(20) DEFAULT NULL COMMENT '商品运营类型,由于有的品引入即为原有品，因此在此预留字段',
  `rank` tinyint(4) DEFAULT NULL COMMENT '占位值-0:第一次引入，非0：同品可以根据数字大小查看多次引入顺序',
  `ptime` date NOT NULL COMMENT '发布日期',
  `version_id` varchar(20) DEFAULT NULL COMMENT '发布的版本号',
  `pub_cnt` tinyint(4) DEFAULT NULL COMMENT '延续期数',
  `ltime` date DEFAULT NULL COMMENT '最后一个版本时间',
  `version_last` varchar(20) DEFAULT NULL COMMENT '最后版本',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_business_product` (`business_area`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8192 DEFAULT CHARSET=utf8mb4 COMMENT='新品引入版本及时间'