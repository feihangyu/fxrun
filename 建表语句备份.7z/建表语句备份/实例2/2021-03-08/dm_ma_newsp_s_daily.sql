CREATE TABLE `dm_ma_newsp_s_daily` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL COMMENT '日',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `grade` varchar(10) DEFAULT '无' COMMENT '货架等级',
  `business_area` varchar(100) NOT NULL DEFAULT '其他' COMMENT '区域',
  `shelf_type2` smallint(6) NOT NULL DEFAULT '0' COMMENT '终端类型(1 货架 2 冰箱冰柜 3 自贩机 4 智能柜)',
  `users_stock` int(11) NOT NULL DEFAULT '0' COMMENT '满足尝新条件货架用户数',
  `users_newsale` int(11) NOT NULL DEFAULT '0' COMMENT '尝新用户数',
  `stocks_new` int(11) NOT NULL DEFAULT '0' COMMENT '新品库存量',
  `sp_new` int(11) NOT NULL DEFAULT '0' COMMENT '新品货架商品数',
  UNIQUE KEY `uk` (`sdate`,`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='每日新品货架用户数统计'