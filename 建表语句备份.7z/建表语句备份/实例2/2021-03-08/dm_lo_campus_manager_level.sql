CREATE TABLE `dm_lo_campus_manager_level` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键序号',
  `STAT_DATE` date DEFAULT NULL COMMENT '统计日期(本月1号代表上个月)',
  `MANAGER_ID` bigint(20) DEFAULT NULL COMMENT '校园店主编号',
  `manager_name` varchar(50) DEFAULT NULL COMMENT '店主名称',
  `pay_amount` decimal(18,2) DEFAULT NULL COMMENT '总实收金额',
  `manager_gmv` decimal(18,2) DEFAULT NULL COMMENT '总GMV',
  `manager_level` int(2) DEFAULT NULL COMMENT '店主等级标签(1:黄金楼主、2:白金楼主、3:钻石楼主、4:星耀楼主、5:王者楼主、6:荣耀楼主)',
  `last_level_interval` decimal(18,2) DEFAULT NULL COMMENT '与上一个等级相差的GMV',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=80640 DEFAULT CHARSET=utf8mb4 COMMENT='校园货架店主等级标签'