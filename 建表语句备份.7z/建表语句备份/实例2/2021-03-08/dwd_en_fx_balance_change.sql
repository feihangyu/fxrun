CREATE TABLE `dwd_en_fx_balance_change` (
  `pid` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `WALLET_ID` bigint(20) DEFAULT NULL COMMENT '钱包ID',
  `BALANCE` decimal(18,2) DEFAULT '0.00' COMMENT '余额',
  `start_date` date DEFAULT '0000-00-00' COMMENT '开始日期',
  `end_date` date DEFAULT '0000-00-00' COMMENT '开始日期',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `idx_waller_balance_p_id` (`WALLET_ID`,`BALANCE`,`start_date`,`end_date`),
  KEY `idx_start_date` (`start_date`)
) ENGINE=InnoDB AUTO_INCREMENT=24275123 DEFAULT CHARSET=utf8mb4 COMMENT='丰享用户E币账户余额截存数据拉链表'