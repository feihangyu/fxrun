CREATE TABLE `dm_sc_profit_monthly_sp` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stat_month` varchar(30) DEFAULT NULL COMMENT '统计月',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架id',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `quantity` int(10) DEFAULT NULL COMMENT '销量',
  `GMV` decimal(18,4) DEFAULT '0.0000' COMMENT 'GMV',
  `avg_sale_price` decimal(18,4) DEFAULT '0.0000' COMMENT '平均销售价',
  `purchase_price` decimal(18,4) DEFAULT '0.0000' COMMENT '采购价',
  `discount_amount` decimal(18,4) DEFAULT '0.0000' COMMENT '折扣金额',
  `purchase_amount` decimal(18,4) DEFAULT '0.0000' COMMENT '采购金额',
  `profit` decimal(18,4) DEFAULT '0.0000' COMMENT '毛利额',
  `profit_rate` decimal(18,4) DEFAULT '0.0000' COMMENT '毛利率',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `unique_key` (`stat_month`,`shelf_id`,`product_id`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=30277171 DEFAULT CHARSET=utf8mb4 COMMENT='每月毛利/货架/商品'