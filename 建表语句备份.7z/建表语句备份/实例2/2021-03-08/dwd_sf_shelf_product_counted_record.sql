CREATE TABLE `dwd_sf_shelf_product_counted_record` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `warehouse_id` bigint(20) NOT NULL COMMENT '前置仓编号',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `add_reason` tinyint(2) DEFAULT '0' COMMENT '录入原因',
  `check_id` bigint(20) DEFAULT NULL COMMENT '盘点编号',
  `ADD_TIME` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '待盘点添加时间',
  `LAST_UPDATE_TIME` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=590270 DEFAULT CHARSET=utf8mb4 COMMENT='前置仓商品效期待盘点表'