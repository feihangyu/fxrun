CREATE TABLE `dm_op_shelf_gmv_split` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `discount_order` bigint(20) DEFAULT '0' COMMENT '折扣订单数',
  `discount_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '折扣订单gmv',
  `coupon_order` bigint(20) DEFAULT '0' COMMENT '优惠券订单数',
  `coupon_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '优惠券订单gmv',
  `third_dis_order` bigint(20) DEFAULT '0' COMMENT '第三方优惠订单数',
  `third_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '第三方优惠gmv',
  `over100_order` bigint(20) DEFAULT '0' COMMENT 'gmv>=100订单数',
  `order100_gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv>=100gmv',
  `normal_pay_type_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '主流支付途径gmv',
  `user_num` int(11) DEFAULT NULL COMMENT '用户去重数',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  `foodcard_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '餐卡gmv',
  PRIMARY KEY (`month_id`,`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架每月gmv拆分(字典中当月付款GMV的口径)'