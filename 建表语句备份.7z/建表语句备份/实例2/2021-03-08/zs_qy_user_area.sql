CREATE TABLE `zs_qy_user_area` (
  `pid` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` varchar(20) DEFAULT NULL COMMENT '企业购买用户id',
  `phone` varchar(11) DEFAULT NULL COMMENT '用户电话',
  `area_` varchar(20) DEFAULT NULL COMMENT '货架区域',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_phone` (`phone`)
) ENGINE=InnoDB AUTO_INCREMENT=17929 DEFAULT CHARSET=utf8mb4 COMMENT='企业用户区域'