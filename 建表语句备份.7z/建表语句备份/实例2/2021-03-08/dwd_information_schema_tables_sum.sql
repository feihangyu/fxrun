CREATE TABLE `dwd_information_schema_tables_sum` (
  `sdate` date NOT NULL DEFAULT '0000-00-00' COMMENT '日期',
  `TABLE_SCHEMA` varchar(64) NOT NULL DEFAULT '' COMMENT '数据库',
  `TABLE_NAME` varchar(64) NOT NULL DEFAULT '' COMMENT '表名',
  `LENGTH_G` bigint(21) unsigned DEFAULT NULL COMMENT '容量',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`sdate`,`TABLE_SCHEMA`,`TABLE_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='数据库表统计数据增长信息'