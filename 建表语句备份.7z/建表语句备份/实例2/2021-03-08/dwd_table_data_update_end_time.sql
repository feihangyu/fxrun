CREATE TABLE `dwd_table_data_update_end_time` (
  `sdate` date NOT NULL DEFAULT '0000-00-00' COMMENT '统计日期',
  `table_name` varchar(64) NOT NULL DEFAULT '' COMMENT '表名',
  `update_end_time` datetime DEFAULT NULL COMMENT '数据更新时间',
  PRIMARY KEY (`sdate`,`table_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='表数据最近更新时间'