CREATE TABLE `dm_ma_kpi_monthly` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL COMMENT '月',
  `shelf_type2` varchar(100) NOT NULL COMMENT '终端类型',
  `index_name` varchar(100) NOT NULL COMMENT '指标名称',
  `index_goal` decimal(14,4) NOT NULL DEFAULT '0.0000' COMMENT '指标目标值',
  `index_value` decimal(14,4) NOT NULL DEFAULT '0.0000' COMMENT '指标达成值',
  `index_value_lm` decimal(14,4) NOT NULL DEFAULT '0.0000' COMMENT '指标上月达成值',
  `index_value_change` decimal(14,4) NOT NULL DEFAULT '0.0000' COMMENT '指标达成值环比',
  PRIMARY KEY (`sdate`,`shelf_type2`,`index_name`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4