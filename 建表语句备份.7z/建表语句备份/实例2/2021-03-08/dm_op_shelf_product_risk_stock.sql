CREATE TABLE `dm_op_shelf_product_risk_stock` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `month_id` char(7) NOT NULL COMMENT '月份',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架ID',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `production_date` date DEFAULT NULL COMMENT '生产日期',
  `danger_flag` int(2) DEFAULT NULL COMMENT '风险标识',
  `stock_quantity` int(3) DEFAULT '0' COMMENT '基础清理库存数量',
  `stock_val` decimal(18,2) DEFAULT '0.00' COMMENT '基础清理库存金额',
  `stock_val2` decimal(18,2) DEFAULT '0.00' COMMENT '清理后临期金额',
  `operate_time` datetime DEFAULT NULL COMMENT '大盘最近一次盘点时间',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  KEY `idx_month_id` (`month_id`),
  KEY `idx_shelf_id` (`shelf_id`,`product_id`),
  KEY `idx_product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8028029 DEFAULT CHARSET=utf8mb4 COMMENT='风险4、5商品商品下架情况'