CREATE TABLE `dwd_project_priority_with_table` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `project` varchar(128) DEFAULT NULL COMMENT '工程名',
  `source_table` varchar(128) DEFAULT NULL COMMENT '依赖源表',
  `dependent_project` varchar(128) DEFAULT NULL COMMENT '依赖的工程名（后缀erp标识datax同步任务）',
  `priority` tinyint(1) DEFAULT NULL COMMENT '优先级(1：优先级高；2：优先级低)',
  `remark` varchar(32) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=1840 DEFAULT CHARSET=utf8mb4 COMMENT='工程与依赖任务表之间的优先级信息(重要勿删！)'