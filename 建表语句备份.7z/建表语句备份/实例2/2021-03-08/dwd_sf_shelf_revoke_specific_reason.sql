CREATE TABLE `dwd_sf_shelf_revoke_specific_reason` (
  `reason_id` tinyint(2) NOT NULL AUTO_INCREMENT COMMENT '原因id',
  `revoke_reason` varchar(200) DEFAULT NULL COMMENT '撤架具体原因',
  `responsibility_classification` varchar(50) DEFAULT NULL COMMENT '责任归类',
  `responsibility_division` varchar(50) DEFAULT NULL COMMENT '责任细分',
  PRIMARY KEY (`reason_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COMMENT='撤架具体原因表'