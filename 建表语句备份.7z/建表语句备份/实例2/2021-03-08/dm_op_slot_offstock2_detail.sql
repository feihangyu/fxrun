CREATE TABLE `dm_op_slot_offstock2_detail` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `slot_id` bigint(20) NOT NULL COMMENT '货道ID',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架ID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `shelf_status_classify` varchar(10) DEFAULT NULL COMMENT '货架状态分类',
  `stock_num` int(8) DEFAULT NULL COMMENT '货道库存数',
  `sec_stock_num` int(8) DEFAULT NULL COMMENT '副柜库存数',
  `offstock_reason` varchar(20) DEFAULT NULL COMMENT '缺货原因',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`row_id`),
  KEY `idx_shelf_product` (`shelf_id`,`product_id`),
  KEY `idx_slot_id` (`slot_id`)
) ENGINE=InnoDB AUTO_INCREMENT=196606 DEFAULT CHARSET=utf8mb4 COMMENT='自贩机货道维度缺货率_昨日明细'