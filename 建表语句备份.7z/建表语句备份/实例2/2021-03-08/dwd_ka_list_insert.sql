CREATE TABLE `dwd_ka_list_insert` (
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='KA货架名单_吹防维护'