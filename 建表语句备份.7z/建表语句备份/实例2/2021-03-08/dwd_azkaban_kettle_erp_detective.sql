CREATE TABLE `dwd_azkaban_kettle_erp_detective` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `sdate` date NOT NULL DEFAULT '0000-00-00' COMMENT '日期',
  `kettle_project_name` varchar(128) DEFAULT NULL COMMENT '同步任务名',
  `kettle_table_name` varchar(128) DEFAULT NULL COMMENT '同步表名',
  `start_time` datetime DEFAULT NULL COMMENT '任务启动时刻',
  `end_time` datetime DEFAULT NULL COMMENT '任务结束时刻',
  `run_time` decimal(8,1) DEFAULT '0.0' COMMENT '任务总计耗时(分钟)',
  `in_nums` int(11) DEFAULT '0' COMMENT '表输入记录数',
  `out_nums` int(11) DEFAULT '0' COMMENT '表输出记录数',
  `excute_status` varchar(32) DEFAULT NULL COMMENT '任务执行状态',
  `fail_reason` text COMMENT '执行失败原因',
  `erp_type` tinyint(4) DEFAULT NULL COMMENT '同步类型（1：表示全量同步；2：表示增量同步）',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='azkaban调度的kettle同步任务执行监控'