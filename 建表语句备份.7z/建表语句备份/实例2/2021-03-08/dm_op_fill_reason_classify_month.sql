CREATE TABLE `dm_op_fill_reason_classify_month` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `month_id` varchar(10) NOT NULL COMMENT '月份',
  `business_name` varchar(10) DEFAULT NULL COMMENT '地区',
  `zone_code` varchar(10) DEFAULT NULL COMMENT '片区ID',
  `manager_id` bigint(20) DEFAULT NULL COMMENT '店主ID',
  `reason_classify` varchar(20) DEFAULT NULL COMMENT '原因',
  `reason_ct` bigint(20) DEFAULT NULL COMMENT '原因记录数',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_month_id` (`month_id`),
  KEY `idx_manager_id` (`manager_id`)
) ENGINE=InnoDB AUTO_INCREMENT=795561 DEFAULT CHARSET=utf8mb4 COMMENT='补货后的缺货原因月份截存'