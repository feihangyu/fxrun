CREATE TABLE `dwd_sf_shelf_apply_visit_company` (
  `relation_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '关联编号',
  `record_id` bigint(20) DEFAULT NULL COMMENT '货架申请编号',
  `company_id` bigint(20) DEFAULT NULL COMMENT '公司编号',
  `apply_type` tinyint(2) DEFAULT '0' COMMENT '申请类型(0,货架申请 1,自贩机申请 2,包到盗损申请)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人编号',
  `data_flag` tinyint(1) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  PRIMARY KEY (`relation_id`),
  KEY `idx_company_id` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4499 DEFAULT CHARSET=utf8mb4 COMMENT='货架申请与拜访客户关联信息表'