CREATE TABLE `dm_ma_newsp_su_monthly` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL COMMENT '月',
  `grade` varchar(10) DEFAULT '无' COMMENT '货架等级',
  `business_area` varchar(100) NOT NULL DEFAULT '其他' COMMENT '区域',
  `shelf_type2` smallint(6) NOT NULL DEFAULT '0' COMMENT '终端类型(1 货架 2 冰箱冰柜 3 自贩机 4 智能柜)',
  `shelfs_stock` int(11) NOT NULL DEFAULT '0' COMMENT '有新品货架数',
  `shelfs_newsale` int(11) NOT NULL DEFAULT '0' COMMENT '尝新货架数',
  `users_stock` int(11) NOT NULL DEFAULT '0' COMMENT '满足尝新条件货架用户数',
  `users_newsale` int(11) NOT NULL DEFAULT '0' COMMENT '尝新用户数',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `uk` (`sdate`,`grade`,`business_area`,`shelf_type2`)
) ENGINE=InnoDB AUTO_INCREMENT=272109 DEFAULT CHARSET=utf8mb4 COMMENT='每月新品用户货架统计'