CREATE TABLE `dm_ma_user_integral_statistic` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `get_integral_user_num` int(10) DEFAULT '0' COMMENT '获取积分用户数',
  `consume_integral_user_num` int(10) DEFAULT '0' COMMENT '消耗积分用户数',
  `accumulated_get_integral` bigint(25) DEFAULT '0' COMMENT '用户获取积分总计',
  `accumulated_consume_integral` bigint(25) DEFAULT '0' COMMENT '用户消耗积分总计',
  `integral_balance` bigint(25) DEFAULT '0' COMMENT '积分余额',
  `exchange_user_num` int(10) DEFAULT '0' COMMENT '每日参与积分兑换用户数量',
  `lottery_user_num` int(10) DEFAULT '0' COMMENT '每日参与积分抽奖用户数量',
  `exchange_consume_integral` bigint(25) DEFAULT '0' COMMENT '每日积分兑换用户消耗的积分',
  `lottery_consume_integral` bigint(25) DEFAULT '0' COMMENT '每日积分抽奖用户消耗的积分',
  `exchange_coupon_user_num` int(10) DEFAULT '0' COMMENT '每日积分兑换获取优惠券转化用户数量',
  `lottery_coupon_user_num` int(10) DEFAULT '0' COMMENT '每日积分抽奖获取优惠券转化用户数量',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  KEY `k_sdate` (`sdate`)
) ENGINE=InnoDB AUTO_INCREMENT=18455 DEFAULT CHARSET=utf8mb4 COMMENT='积分表动日统计表'