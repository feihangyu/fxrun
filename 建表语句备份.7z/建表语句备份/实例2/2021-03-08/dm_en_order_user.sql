CREATE TABLE `dm_en_order_user` (
  `user_id` bigint(20) NOT NULL COMMENT '商城下单用户id',
  `sdate` date DEFAULT NULL COMMENT '更新日期',
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商场下单用户id'