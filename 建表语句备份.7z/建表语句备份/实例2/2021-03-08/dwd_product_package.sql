CREATE TABLE `dwd_product_package` (
  `product_package_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '商品包主键id',
  `area_id` bigint(20) DEFAULT NULL COMMENT '地区id',
  `shelf_type` tinyint(4) DEFAULT NULL COMMENT '货架类型',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `suggest_quantity` int(10) unsigned DEFAULT NULL COMMENT '标配数量',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`product_package_id`),
  UNIQUE KEY `uk_product_package_areaIdShelfTypeProductId` (`area_id`,`shelf_type`,`product_id`),
  KEY `idx_product_package_productId` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=53833 DEFAULT CHARSET=utf8mb4 COMMENT='商品包表'