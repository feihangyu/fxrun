CREATE TABLE `dm_op_sto_cdays` (
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `sto_qty` int(11) DEFAULT NULL COMMENT '库存',
  `ld_sto` date DEFAULT NULL COMMENT '最近有库存日期',
  `ld_nsto` date DEFAULT NULL COMMENT '最近无库存日期',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `update_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`shelf_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架商品库存状态'