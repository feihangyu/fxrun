CREATE TABLE `dwd_op_firstfill_product_sale_item` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `suggest_quantity` bigint(20) DEFAULT NULL COMMENT '初始商品包标配',
  `pool_suggest_quantity` bigint(20) DEFAULT NULL COMMENT '地区商品池标配',
  `fill_time` date DEFAULT NULL COMMENT '首次补货上架日期',
  `actual_fill_num` bigint(20) DEFAULT NULL COMMENT '实际上架量',
  `stock_quantity` bigint(20) DEFAULT NULL COMMENT '当前架上库存量',
  `7_amount` bigint(20) DEFAULT '0' COMMENT '上架7日内销量',
  `7_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '上架7日内gmv',
  `14_amount` bigint(20) DEFAULT '0' COMMENT '上架14日内销量',
  `14_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '上架14日内gmv',
  `days_sto` bigint(20) DEFAULT '0' COMMENT '月有库存天数',
  `sto_shelf` bigint(20) DEFAULT '0' COMMENT '地区月有库存货架数',
  `sale_shelf` bigint(20) DEFAULT '0' COMMENT '地区月有销售货架数',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`month_id`,`shelf_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='新装货架初始补货商品销售明细'