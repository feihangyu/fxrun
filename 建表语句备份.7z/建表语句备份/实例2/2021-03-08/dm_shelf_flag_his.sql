CREATE TABLE `dm_shelf_flag_his` (
  `sdate` date NOT NULL DEFAULT '0000-00-00',
  `shelf_id` bigint(10) NOT NULL DEFAULT '0',
  `ext1` int(2) NOT NULL DEFAULT '0' COMMENT '货架等级(1	新装,2	甲,3	乙,4	丙,5	丁)',
  `ext4` int(2) NOT NULL DEFAULT '0' COMMENT '定向货架分类(1:核心货架 ,2:高潜力货架,3:新终端,0:其他)',
  `ext5` int(2) NOT NULL DEFAULT '0' COMMENT '货架库存状态：(1:库存充足,2:库存超80%,3:库存不足80% ,0:其他)',
  `ext26` int(11) NOT NULL DEFAULT '0' COMMENT '货架每日等级(0:其他,1:撤架,2:新装,3:新关联,4:低价值,5:普通,6:中,7:高)',
  `ext27` int(11) NOT NULL DEFAULT '0' COMMENT '单选扩展标签27',
  PRIMARY KEY (`sdate`,`shelf_id`),
  KEY `idx_shelf_id` (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架标签历史'