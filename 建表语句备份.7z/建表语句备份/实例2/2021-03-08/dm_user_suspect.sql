CREATE TABLE `dm_user_suspect` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `ORDER_ID` bigint(20) NOT NULL COMMENT '订单编号',
  `user_id` varchar(20) NOT NULL COMMENT '用户id',
  `ORDER_DATE` datetime NOT NULL COMMENT '订单创建日期',
  `gmv` decimal(18,2) DEFAULT NULL COMMENT 'GMV',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`),
  KEY `idx_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=250021 DEFAULT CHARSET=utf8mb4 COMMENT='嫌疑人短信推送表(航宇供开发使用)'