CREATE TABLE `dwd_prc_project_process_info` (
  `project` varchar(128) NOT NULL DEFAULT '' COMMENT '工程名',
  `process_name` varchar(128) NOT NULL DEFAULT '' COMMENT '存储过程名',
  `p_function` varchar(256) DEFAULT NULL COMMENT '存储过程作用',
  `dimension` varchar(64) DEFAULT NULL COMMENT '统计维度',
  `projects_after_failure` text COMMENT '失败后受影响的工程',
  `num` int(4) DEFAULT '0' COMMENT '受影响的工程数',
  `maintainer` varchar(16) DEFAULT NULL COMMENT '维护人员',
  `remark` varchar(64) DEFAULT NULL COMMENT '备注',
  `email` varchar(64) DEFAULT NULL COMMENT '邮箱',
  `qq_email` varchar(64) DEFAULT NULL COMMENT 'QQ邮箱',
  PRIMARY KEY (`project`,`process_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='工程与存储工程之间的映射关系表'