CREATE TABLE `dwd_lo_fulltime_manager_history_record` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `STAT_DATE` int(20) DEFAULT NULL COMMENT '统计月份',
  `MANAGER_ID` bigint(20) DEFAULT NULL COMMENT '店主ID',
  `sf_code` varchar(50) DEFAULT NULL COMMENT '顺丰工号',
  `real_name` varchar(100) DEFAULT NULL COMMENT '店主名称',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=16094 DEFAULT CHARSET=utf8mb4 COMMENT='全职店主名单历史记录'