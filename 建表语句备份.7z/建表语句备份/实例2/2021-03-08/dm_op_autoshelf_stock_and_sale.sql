CREATE TABLE `dm_op_autoshelf_stock_and_sale` (
  `week_end` date NOT NULL COMMENT '周最后一天',
  `business_name` varchar(32) NOT NULL DEFAULT '' COMMENT '地区',
  `sto_sku` int(11) DEFAULT '0' COMMENT '周有库存sku',
  `sale_sku` int(11) DEFAULT '0' COMMENT '周有销售sku',
  `stock` decimal(18,2) DEFAULT '0.00' COMMENT '周日库存金额',
  `week_amount` int(11) DEFAULT '0' COMMENT '周销量',
  `week_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '周gmv',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`week_end`,`business_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='自贩机周货架动销率及库销比'