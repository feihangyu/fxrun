CREATE TABLE `dwd_shelf_product_sto_sal_month_start_end` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '日期',
  `business_name` varchar(100) NOT NULL COMMENT '区域名称',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `sale_price` decimal(18,2) DEFAULT NULL COMMENT '销售价',
  `purchase_price` decimal(18,2) DEFAULT NULL COMMENT '采购价',
  `sal_qty` int(5) DEFAULT '0' COMMENT '销量',
  `gmv` decimal(8,2) DEFAULT '0.00' COMMENT 'GMV',
  `stock_quantity` int(3) DEFAULT '0' COMMENT '库存数量(期初库存,如2号即2号零点1号24点)',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `sdate` (`sdate`,`shelf_id`,`product_id`),
  KEY `idx_dwd_order_his_shelf_product_id` (`shelf_id`,`product_id`),
  KEY `idx_dwd_order_his_product_id` (`product_id`),
  KEY `idx_dwd_order_his_shelf_product_stock_quantity` (`stock_quantity`)
) ENGINE=InnoDB AUTO_INCREMENT=64257015 DEFAULT CHARSET=utf8mb4 COMMENT='货架商品存销售(只有月末月初,包含负库存。期初数据，指当天零点的结存)'