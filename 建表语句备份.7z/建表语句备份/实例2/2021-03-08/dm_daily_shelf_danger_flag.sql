CREATE TABLE `dm_daily_shelf_danger_flag` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date NOT NULL DEFAULT '0000-00-00' COMMENT '统计日',
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架ID',
  `danger_rate` decimal(18,4) DEFAULT '0.0000' COMMENT '临期库存金额占比',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `unique_key` (`sdate`,`shelf_id`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='12月以来/每日临期占比'