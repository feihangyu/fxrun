CREATE TABLE `dm_product_fill_number_sorting_bak` (
  `pid` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `smonth` int(20) DEFAULT NULL COMMENT '统计月份',
  `business_area` varchar(32) DEFAULT NULL COMMENT '地区',
  `product_code` varchar(100) DEFAULT NULL COMMENT '商品编码',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品ID',
  `product_name` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `actual_send_num` int(3) DEFAULT NULL COMMENT '实际发货量',
  `fill_qty` bigint(20) DEFAULT NULL COMMENT '补货订单数',
  `row_seq` int(3) DEFAULT NULL COMMENT '补a货订单数排名',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=792726 DEFAULT CHARSET=utf8mb4 COMMENT='地区商品补货量频次排名结果表'