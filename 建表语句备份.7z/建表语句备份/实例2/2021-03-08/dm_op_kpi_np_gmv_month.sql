CREATE TABLE `dm_op_kpi_np_gmv_month` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `region` varchar(32) DEFAULT NULL COMMENT '大区名称',
  `business_area` varchar(32) NOT NULL DEFAULT '' COMMENT '地区名称',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `product_fe` varchar(100) DEFAULT NULL COMMENT '商品fe编码',
  `product_name` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `gmv_profit` decimal(18,2) DEFAULT '0.00' COMMENT '毛利gmv',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`month_id`,`business_area`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='新品gmv占比月表'