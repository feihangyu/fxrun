CREATE TABLE `dm_op_users_dayct_tran` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `users` int(11) DEFAULT '0' COMMENT '当天新增用户数',
  PRIMARY KEY (`row_id`)
) ENGINE=InnoDB AUTO_INCREMENT=89596 DEFAULT CHARSET=utf8mb4 COMMENT='每日新增用户'