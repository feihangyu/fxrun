CREATE TABLE `dwd_sf_activity_user_integral_record` (
  `record_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录id',
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户id',
  `member_level` tinyint(2) DEFAULT NULL COMMENT '会员等级',
  `receive_time` datetime DEFAULT NULL COMMENT '领取时间',
  `gift_obj_id` varchar(60) DEFAULT NULL COMMENT '奖品',
  `activity_id` bigint(20) DEFAULT NULL COMMENT '活动id',
  `activity_type` tinyint(2) DEFAULT NULL COMMENT '活动类型',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`record_id`,`add_time`) USING BTREE,
  KEY `idx_user_id` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=1791756 DEFAULT CHARSET=utf8mb4 COMMENT='会员等级领取礼包记录表'