CREATE TABLE `dm_op_manual_fill_stat_total` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `month_id` varchar(8) NOT NULL COMMENT '日期',
  `business_name` varchar(32) NOT NULL COMMENT '区域',
  `order_qty` int(8) DEFAULT NULL COMMENT '人工申请订单数',
  `surplus_order_qty` int(8) DEFAULT NULL COMMENT '人工申请超量订单数',
  `abnormal_order_qty` int(8) DEFAULT NULL COMMENT '人工申请异常订单数',
  `surplus_order_ratio` decimal(4,2) DEFAULT NULL COMMENT '人工申请超量订单占比',
  `abnormal_order_ratio` decimal(4,2) DEFAULT NULL COMMENT '人工申请异常占比',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_stat_date_area` (`month_id`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=256 DEFAULT CHARSET=utf8mb4 COMMENT='补货人工申请订单异常统计汇总表'