CREATE TABLE `dm_subtype_price_stat` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `month_id` char(7) NOT NULL DEFAULT '0000-00' COMMENT '月份(预测下月)',
  `data_range` tinyint(4) NOT NULL DEFAULT '0' COMMENT '数据范围类型:0当前全量,1去年同比三个月',
  `business_name` varchar(32) NOT NULL DEFAULT '0' COMMENT '地区名称',
  `sub_type_id` tinyint(4) NOT NULL DEFAULT '0' COMMENT '三级分类',
  `top_price` decimal(18,2) DEFAULT '0.00' COMMENT '售价峰值',
  `low_price` decimal(18,2) DEFAULT '0.00' COMMENT '售价左区间',
  `high_price` decimal(18,2) DEFAULT '0.00' COMMENT '售价右区间',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `month_id` (`month_id`,`data_range`,`business_name`,`sub_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=458084 DEFAULT CHARSET=utf8mb4 COMMENT='类别价格月预测'