CREATE TABLE `dwd_sserp_zs_dc_business_area` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `BUSINESS_AREA` varchar(36) DEFAULT NULL,
  `BIG_AREA` varchar(36) DEFAULT NULL,
  `DC_CODE` varchar(36) DEFAULT NULL,
  `SAFT_DAY` int(11) DEFAULT NULL,
  PRIMARY KEY (`pid`),
  KEY `idx_zs_dc_business_area_dc_code` (`DC_CODE`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4