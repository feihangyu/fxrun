CREATE TABLE `dm_shelf_day_avg_gmv` (
  `month_id` char(7) NOT NULL DEFAULT '' COMMENT '月份',
  `business_name` varchar(100) DEFAULT NULL COMMENT '地区',
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架id',
  `shelf_type` varchar(32) DEFAULT NULL COMMENT '货架类型',
  `shelf_status` varchar(32) DEFAULT NULL COMMENT '货架状态',
  `ACTIVATE_TIME` date DEFAULT NULL COMMENT '激活日期',
  `REVOKE_TIME` date DEFAULT NULL COMMENT '撤架日期',
  `after_pay` decimal(20,2) DEFAULT NULL COMMENT '补付款',
  `gmv` decimal(18,2) DEFAULT NULL COMMENT 'gmv',
  `total` decimal(18,2) DEFAULT NULL COMMENT '补付款+gmv',
  `days` decimal(18,1) DEFAULT NULL COMMENT '折算天数',
  `day_gmv` decimal(18,2) DEFAULT NULL COMMENT '日均gmv',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  `holiday_total` decimal(18,2) DEFAULT '0.00' COMMENT '节假日gmv(含补付款)',
  `no_holiday_days` decimal(18,1) DEFAULT '0.0' COMMENT '不含节假日折算工作日',
  PRIMARY KEY (`month_id`,`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架日均gmv'