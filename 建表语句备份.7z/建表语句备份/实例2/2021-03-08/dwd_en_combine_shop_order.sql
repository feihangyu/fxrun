CREATE TABLE `dwd_en_combine_shop_order` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `parent_order_pay_id` bigint(20) DEFAULT '0' COMMENT '合并支付时会生成一条父订单id，该字段指向合并支付的父订单id',
  `order_id` bigint(20) unsigned NOT NULL DEFAULT '0' COMMENT '订单ID,如果为父订单则订单ID为0',
  `pay_time_goods` datetime DEFAULT NULL COMMENT '支付时间 sf_group_order_pay',
  `zh_pay_type_pay` varchar(32) DEFAULT NULL COMMENT '组合支付类型',
  `zh_pay_amount_pay` decimal(10,2) DEFAULT NULL COMMENT '组合支付金额',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  KEY `idx_order_id_pay` (`parent_order_pay_id`),
  KEY `idx_order_id_re` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=404291 DEFAULT CHARSET=utf8mb4 COMMENT='商城组合支付结果表_dwd'