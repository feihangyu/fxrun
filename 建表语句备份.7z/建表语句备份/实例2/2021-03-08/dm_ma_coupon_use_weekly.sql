CREATE TABLE `dm_ma_coupon_use_weekly` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL COMMENT '周一日期',
  `coupon_id` bigint(20) NOT NULL COMMENT '活动ID',
  `coupon_name` varchar(20) DEFAULT NULL COMMENT '活动名称',
  `coupon_usage` varchar(200) NOT NULL COMMENT '优惠券用途',
  `issue_start_time` date NOT NULL COMMENT '活动开始时间',
  `issue_end_time` date NOT NULL COMMENT '活动结束时间',
  `shelfs_get` mediumint(9) NOT NULL DEFAULT '0' COMMENT '领取货架',
  `shelfs_used` mediumint(9) NOT NULL DEFAULT '0' COMMENT '使用货架',
  `num_get` int(11) NOT NULL DEFAULT '0' COMMENT '领取数量',
  `num_used` int(11) NOT NULL DEFAULT '0' COMMENT '使用数量',
  `coupon_amount` decimal(10,2) NOT NULL DEFAULT '0.00' COMMENT '优惠券费用',
  `gmv` decimal(12,2) NOT NULL DEFAULT '0.00',
  PRIMARY KEY (`sdate`,`coupon_id`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='优惠券使用周报'