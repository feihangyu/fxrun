CREATE TABLE `dwd_op_unstock_detail_week` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `week_end` date NOT NULL COMMENT '周最后一天',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `sales_flag` tinyint(4) DEFAULT NULL COMMENT '销量标识',
  `sto_qty` int(11) DEFAULT '0' COMMENT '库存数量',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `week_end` (`week_end`,`shelf_id`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=44546789 DEFAULT CHARSET=utf8mb4 COMMENT='爆畅平缺货周明细'