CREATE TABLE `dwd_op_scene_grade` (
  `scene_name` varchar(32) DEFAULT NULL COMMENT '场景名称',
  `scene_grade` varchar(10) DEFAULT NULL COMMENT '场景等级',
  `is_regular_customer` varchar(10) DEFAULT NULL COMMENT '是否固定客户群',
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COMMENT='场景等级表-商品组'