CREATE TABLE `dm_op_machine_online_shelf` (
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架',
  `records` bigint(20) DEFAULT NULL COMMENT '记录数',
  `min_change_time` datetime DEFAULT NULL COMMENT '最早变更时间',
  `max_change_time` datetime DEFAULT NULL COMMENT '最晚变更时间',
  `max_change_time_on` datetime DEFAULT NULL COMMENT '最近在线时间',
  `max_change_time_off` datetime DEFAULT NULL COMMENT '最近掉线时间',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='机器在线_货架'