CREATE TABLE `dm_op_user_firstday_tran` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `first_pur_date` date DEFAULT NULL COMMENT '第一次购买日期',
  `user_id` bigint(20) DEFAULT NULL COMMENT '会员id',
  PRIMARY KEY (`row_id`),
  KEY `idx_business_name_user_id` (`business_name`,`user_id`),
  KEY `idx_first_pur_date` (`first_pur_date`)
) ENGINE=InnoDB AUTO_INCREMENT=17320308 DEFAULT CHARSET=utf8mb4 COMMENT='用户最早购买'