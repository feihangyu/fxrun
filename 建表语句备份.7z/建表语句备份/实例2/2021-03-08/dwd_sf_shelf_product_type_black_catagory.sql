CREATE TABLE `dwd_sf_shelf_product_type_black_catagory` (
  `catagory_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `shelf_id` bigint(20) DEFAULT '0' COMMENT '货架编号',
  `sub_type_id` bigint(20) DEFAULT '0' COMMENT '商品三级分类',
  `reason_type` tinyint(2) DEFAULT NULL COMMENT '原因类型',
  `remark` varchar(200) DEFAULT NULL COMMENT '备注',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`catagory_id`),
  KEY `idx_shelf_id` (`shelf_id`),
  KEY `idx_sub_type_id` (`sub_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=139596 DEFAULT CHARSET=utf8mb4 COMMENT='货架商品黑名单品类表'