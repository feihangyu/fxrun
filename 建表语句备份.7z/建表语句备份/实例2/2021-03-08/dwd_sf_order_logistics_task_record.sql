CREATE TABLE `dwd_sf_order_logistics_task_record` (
  `task_record_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '表主键ID',
  `order_id` bigint(20) DEFAULT NULL COMMENT '订单 ID',
  `config_info_id` bigint(20) DEFAULT NULL COMMENT '承运商配置id (对应表sf_carrier_config_info)',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架/前置仓 ID',
  `task_id` bigint(20) DEFAULT NULL COMMENT '任务ID',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`task_record_id`),
  KEY `idx_sf_order_logistics_task_record_shelf_id` (`shelf_id`),
  KEY `idx_sf_order_logistice_task_record_order_id` (`order_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=127939 DEFAULT CHARSET=utf8mb4 COMMENT='任务订单记录表'