CREATE TABLE `dwd_sf_shelf_check_detail_extend` (
  `extend_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `detail_id` bigint(20) DEFAULT '0' COMMENT '盘点详情表Id',
  `other_error_num` int(11) DEFAULT '0' COMMENT '其它异常数量',
  `other_audit_error_num` int(11) DEFAULT '0' COMMENT '其它异常审核通过量',
  `other_error_reason` tinyint(2) DEFAULT '0' COMMENT '其它异常原因：字典CheckErrorReason  1-货物破损（如鼠害），2-商品临期/过期，3-无原因，4-商品质量问题（如漏气、鼓包等）',
  `other_error_photo` varchar(2000) DEFAULT NULL COMMENT '其它异常凭证(照片路径)',
  `other_audit_type` varchar(50) DEFAULT NULL COMMENT '其它异常审核说明多选字典：auditType，1-提报图片与商品名称不符，2-商品未到临期时间，3-商品已过期，4-提报的凭证和异常原因不符，9-其他，5-提报的商品数量不符，6-未拍出生产日期，7-大头笔未写或不规范，10-虚假盘点（非商品照片）',
  `other_audit_remark` varchar(500) DEFAULT '' COMMENT '审核备注',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`extend_id`),
  KEY `idx_extend_detailId` (`detail_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=95068 DEFAULT CHARSET=utf8mb4 COMMENT='盘点详情扩展表'