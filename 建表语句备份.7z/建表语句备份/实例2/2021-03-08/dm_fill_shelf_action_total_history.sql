CREATE TABLE `dm_fill_shelf_action_total_history` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date DEFAULT NULL,
  `stype1` varchar(128) DEFAULT NULL COMMENT '处理措施',
  `stype_ren` varchar(32) DEFAULT NULL COMMENT '责任人',
  `if_all_time` varchar(32) DEFAULT NULL COMMENT '是否全职',
  `if_prewarehouse` varchar(32) DEFAULT NULL COMMENT '是否前置仓',
  `city_name` varchar(32) DEFAULT NULL COMMENT '城市名称',
  `shelf_level_sim` varchar(32) DEFAULT NULL COMMENT '货架等级_归类',
  `shelf_status_sim` varchar(32) DEFAULT NULL COMMENT '货架状态_归类',
  `stock_type` varchar(32) DEFAULT NULL COMMENT '库存类型',
  `stock_sku_type` varchar(32) DEFAULT NULL COMMENT '库存SKU类型',
  `shelf_qty` bigint(20) DEFAULT NULL COMMENT '货架数',
  `queh_value` decimal(18,2) DEFAULT '0.00' COMMENT '缺货损失金额',
  `stock_value` decimal(18,2) DEFAULT '0.00' COMMENT '库存金额',
  `stock_value_5` decimal(18,2) DEFAULT '0.00' COMMENT '严重滞销库存占比',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2208453 DEFAULT CHARSET=utf8mb4 COMMENT='补货货架分类汇总表历史'