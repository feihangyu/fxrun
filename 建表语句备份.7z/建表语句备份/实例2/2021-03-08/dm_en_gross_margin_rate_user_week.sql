CREATE TABLE `dm_en_gross_margin_rate_user_week` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sdate` varchar(9) DEFAULT NULL COMMENT '统计日期',
  `sale_channel` varchar(50) DEFAULT NULL COMMENT '渠道',
  `gross_margin` varchar(5) DEFAULT NULL COMMENT '毛利率分层',
  `gross_margin_avg` decimal(23,2) DEFAULT NULL COMMENT '平均毛利率',
  `gmv` decimal(41,2) DEFAULT NULL COMMENT 'gmv',
  `amount` decimal(40,2) DEFAULT NULL COMMENT '实收',
  `purchase_total_amount` decimal(40,2) DEFAULT NULL COMMENT '采购总价',
  `oorder_num` bigint(21) NOT NULL DEFAULT '0' COMMENT '订单数',
  `user_num` bigint(21) NOT NULL DEFAULT '0' COMMENT '用户数',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `uk_sdate_channel_gm` (`sdate`,`sale_channel`,`gross_margin`),
  KEY `kc` (`sale_channel`),
  KEY `ka` (`add_time`)
) ENGINE=InnoDB AUTO_INCREMENT=3105 DEFAULT CHARSET=utf8mb4 COMMENT='丰e商城用户毛利分层周统计'