CREATE TABLE `dm_op_lowstorate_area_product` (
  `sdate` date NOT NULL DEFAULT '0000-00-00' COMMENT '统计日期',
  `business_name` varchar(100) NOT NULL COMMENT '地区',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `days` bigint(20) DEFAULT '0' COMMENT '到仓天数',
  `aim` decimal(18,2) DEFAULT '0.00' COMMENT '目标值',
  `sto_rate` decimal(18,4) DEFAULT '0.0000' COMMENT '上架率',
  `at_dim` tinyint(2) DEFAULT '0' COMMENT '是否达标',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`sdate`,`business_name`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区运营质量诊断-新品投放不达标明细'