CREATE TABLE `dm_op_out_product_sale_through_rate` (
  `sdate` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '日期',
  `business_name` varchar(32) NOT NULL DEFAULT '' COMMENT '地区',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `product_type` varchar(32) DEFAULT NULL COMMENT '商品类型',
  `version` varchar(100) DEFAULT NULL COMMENT '版本号',
  `out_date` date DEFAULT NULL COMMENT '淘汰日期',
  `cum_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '累计gmv',
  `cum_fill` decimal(18,2) DEFAULT '0.00' COMMENT '累计补货金额',
  `cum_miss_total` decimal(18,2) DEFAULT '0.00' COMMENT '累计货损金额',
  `cum_damage_total` decimal(18,2) DEFAULT '0.00' COMMENT '累计盗损金额',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`sdate`,`business_name`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='淘汰品售罄率'