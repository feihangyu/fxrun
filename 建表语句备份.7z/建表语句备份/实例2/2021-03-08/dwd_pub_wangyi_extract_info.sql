CREATE TABLE `dwd_pub_wangyi_extract_info` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `model_id` varchar(16) DEFAULT NULL COMMENT '模型id',
  `status` varchar(16) DEFAULT NULL COMMENT '状态',
  `tableId` varchar(16) DEFAULT NULL COMMENT '表id',
  `tableExprId` varchar(16) DEFAULT NULL COMMENT '抽取id',
  `tableName` varchar(64) DEFAULT NULL COMMENT '表名',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=5335 DEFAULT CHARSET=utf8mb4 COMMENT='网易有数抽取信息分析(费航宇)'