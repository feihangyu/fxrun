CREATE TABLE `dm_op_area_stock_change` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date NOT NULL COMMENT '日期',
  `business_name` varchar(10) DEFAULT NULL COMMENT '地区',
  `stock_val` decimal(10,2) DEFAULT NULL COMMENT '期末滞销金额',
  `stock_val1` decimal(10,2) DEFAULT NULL COMMENT '期初滞销金额',
  `sub_part` decimal(10,2) DEFAULT NULL COMMENT '清理滞销金额',
  `add_part` decimal(10,2) DEFAULT NULL COMMENT '新增滞销金额',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_sdate_area` (`sdate`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=18108 DEFAULT CHARSET=utf8mb4 COMMENT='风险45库存金额变动趋势分析'