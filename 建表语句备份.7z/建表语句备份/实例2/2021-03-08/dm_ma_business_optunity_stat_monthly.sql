CREATE TABLE `dm_ma_business_optunity_stat_monthly` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL COMMENT '申请月份',
  `business_optunity_source` varchar(100) NOT NULL COMMENT '商机来源',
  `bo_cnt` int(11) NOT NULL DEFAULT '0' COMMENT '总商机数据量',
  `bo_sucess_cnt` int(11) NOT NULL DEFAULT '0' COMMENT '商机成功数量',
  KEY `sdate` (`sdate`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商机月统计'