CREATE TABLE `dm_ma_product_flag` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `type_id` smallint(100) DEFAULT NULL COMMENT '商品类别id,可以多个',
  `type_id_bin` int(11) DEFAULT NULL COMMENT '商品类别二进制，倒排后转十进制，如1,3,4二进制为1011，倒排为1101,十进制为13',
  `ext1` int(2) DEFAULT '0' COMMENT '灰度测试',
  `ext2` int(2) DEFAULT '0' COMMENT '扩展标签2',
  `ext_bin_1` int(2) DEFAULT '0' COMMENT '扩展二进制标签1',
  `ext_bin_2` int(2) DEFAULT '0' COMMENT '扩展二进制标签2',
  PRIMARY KEY (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='商品标签'