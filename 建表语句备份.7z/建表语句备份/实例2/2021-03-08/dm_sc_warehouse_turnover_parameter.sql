CREATE TABLE `dm_sc_warehouse_turnover_parameter` (
  `pid` int(10) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stock_flag` varchar(20) DEFAULT NULL COMMENT '库存标签',
  `saleflag_protype` varchar(100) DEFAULT NULL COMMENT '类型-销售等级',
  `aim_turnover_day` tinyint(2) DEFAULT NULL COMMENT '目标周转天',
  `turnover_level` varchar(30) DEFAULT NULL COMMENT '库存周转等级',
  `turnover_days` varchar(20) DEFAULT NULL COMMENT '库存周转天数',
  `left_value` decimal(5,2) DEFAULT NULL COMMENT '小阈值',
  `right_value` decimal(5,2) DEFAULT NULL COMMENT '大阈值',
  `equal` varchar(4) DEFAULT NULL COMMENT '闭包侧,l:左侧,r：右侧',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COMMENT='仓库周转参数表'