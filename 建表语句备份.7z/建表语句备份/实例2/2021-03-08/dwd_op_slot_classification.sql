CREATE TABLE `dwd_op_slot_classification` (
  `concode` char(6) NOT NULL COMMENT '类别码',
  `creason` varchar(100) DEFAULT NULL COMMENT '原因分类',
  `coutput` varchar(500) DEFAULT NULL COMMENT '输出结果',
  PRIMARY KEY (`concode`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架监控分类'