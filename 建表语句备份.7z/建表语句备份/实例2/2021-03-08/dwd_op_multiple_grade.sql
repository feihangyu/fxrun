CREATE TABLE `dwd_op_multiple_grade` (
  `item_name` varchar(32) DEFAULT NULL COMMENT '名称',
  `multiple_grade` int(10) DEFAULT NULL COMMENT '综合价格等级',
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8mb4 COMMENT='综合等级表-商品组'