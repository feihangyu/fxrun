CREATE TABLE `dm_op_shelf_active_month` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `business_name` varchar(100) DEFAULT NULL COMMENT '地区',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `shelf_type` varchar(32) DEFAULT NULL COMMENT '货架类型',
  `shelf_status` varchar(32) DEFAULT NULL COMMENT '货架状态',
  `revoke_status` varchar(32) DEFAULT NULL COMMENT '撤架状态',
  `sto_sku` bigint(20) DEFAULT NULL COMMENT '有库存sku',
  `sale_sku` bigint(20) DEFAULT NULL COMMENT '有销售sku',
  `active_rate` decimal(18,6) DEFAULT NULL COMMENT '动销率',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`month_id`,`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架月动销率'