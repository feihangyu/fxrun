CREATE TABLE `dm_op_fill3_detail` (
  `order_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '补货订单编号',
  `product_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '商品编号',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架编号',
  `fill_time` datetime DEFAULT NULL COMMENT '上架时间',
  `apply_time` datetime NOT NULL COMMENT '申请时间',
  `purchase_price` decimal(18,2) DEFAULT '0.00' COMMENT '采购价',
  `actual_apply_num` int(3) DEFAULT '0' COMMENT '实际申请补货量',
  `actual_send_num` int(3) DEFAULT '0' COMMENT '实际发货量',
  `actual_sign_num` int(3) DEFAULT '0' COMMENT '实际签收量',
  `actual_fill_num` int(3) DEFAULT '0' COMMENT '实际补货量',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`order_id`,`product_id`),
  KEY `shelf_id` (`shelf_id`),
  KEY `fill_time` (`fill_time`),
  KEY `apply_time` (`apply_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='初始商品包补货明细'