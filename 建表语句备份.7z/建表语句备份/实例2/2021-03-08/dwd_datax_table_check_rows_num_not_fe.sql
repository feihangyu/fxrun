CREATE TABLE `dwd_datax_table_check_rows_num_not_fe` (
  `sdate` date NOT NULL COMMENT '日期',
  `table_name` varchar(128) NOT NULL COMMENT '表名',
  `data_base` tinyint(1) NOT NULL DEFAULT '2' COMMENT '数据所属实例(1:实例1，2:实例2)',
  `nums` bigint(20) DEFAULT NULL COMMENT '数据量',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`sdate`,`table_name`,`data_base`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='datax同步表(非fe库)数据核对'