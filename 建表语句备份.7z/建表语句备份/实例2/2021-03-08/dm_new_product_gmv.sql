CREATE TABLE `dm_new_product_gmv` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `order_date` datetime DEFAULT NULL COMMENT '支付日期',
  `business_area` varchar(100) NOT NULL COMMENT '地区',
  `product_id` bigint(20) DEFAULT '0' COMMENT '商品编号',
  `product_code2` varchar(100) NOT NULL COMMENT '地区',
  `product_name` varchar(100) NOT NULL COMMENT '商品名称',
  `product_type` varchar(100) NOT NULL COMMENT '商品类型',
  `quantity` bigint(20) DEFAULT NULL COMMENT '销售数量',
  `GMV` decimal(18,2) DEFAULT NULL COMMENT 'GMV',
  `discount_amount` decimal(18,2) DEFAULT NULL COMMENT '折扣金额',
  `real_total_price` decimal(18,2) DEFAULT NULL COMMENT '实际销售金额',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_zs_new_product_gmv_date` (`order_date`,`business_area`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1316101 DEFAULT CHARSET=utf8 COMMENT='新品GMV监控'