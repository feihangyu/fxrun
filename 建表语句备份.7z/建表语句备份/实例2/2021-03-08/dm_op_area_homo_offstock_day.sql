CREATE TABLE `dm_op_area_homo_offstock_day` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `stat_date` date NOT NULL COMMENT '日期',
  `business_name` varchar(20) NOT NULL COMMENT '地区',
  `sub_type_name` varchar(20) DEFAULT NULL COMMENT '商品三级分类',
  `appraise_offstock_ct` int(8) DEFAULT NULL COMMENT '考核缺货记录数',
  `appraise_total_ct` int(8) DEFAULT NULL COMMENT '考核总记录数',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`row_id`),
  KEY `idx_sdate` (`stat_date`),
  KEY `idx_business` (`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=59335 DEFAULT CHARSET=utf8mb4 COMMENT='地区三级分类维度同质化商品缺货率近2年每天'