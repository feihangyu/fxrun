CREATE TABLE `dwd_op_area_zone_behaviour_item` (
  `week_end` date NOT NULL COMMENT '周最后一天',
  `business_name` varchar(32) NOT NULL COMMENT '地区',
  `zone_name` varchar(32) DEFAULT NULL COMMENT '片区',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `grade` varchar(32) DEFAULT NULL COMMENT '上月货架等级',
  `np_stock_rate` decimal(18,4) DEFAULT '0.0000' COMMENT '新品库存金额占比',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT '月gmv',
  `in_aim` int(2) DEFAULT NULL COMMENT '近30天上新sku是否达标',
  `is_no_top` int(2) DEFAULT NULL COMMENT '是否爆款未上过',
  `active_rate` decimal(18,4) DEFAULT '0.0000' COMMENT '近30天货架动销率',
  `is_top_active` int(2) DEFAULT NULL COMMENT '近30天货架动销率是否>50%',
  `out_rate` decimal(18,4) DEFAULT '0.0000' COMMENT '淘汰品库存金额占比',
  `gmv_pre_order` decimal(18,2) DEFAULT '0.00' COMMENT '月客单价',
  `sku_pre_order` decimal(18,2) DEFAULT '0.00' COMMENT '月sku连带率',
  `load_time` datetime NOT NULL COMMENT '更新时间',
  PRIMARY KEY (`week_end`,`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='门店指标表现-货架明细'