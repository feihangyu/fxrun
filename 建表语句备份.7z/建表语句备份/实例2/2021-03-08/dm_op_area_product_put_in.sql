CREATE TABLE `dm_op_area_product_put_in` (
  `p_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  `sdate` date NOT NULL COMMENT '统计日期',
  `business_area` varchar(32) NOT NULL COMMENT '地区',
  `warehouse_id` bigint(20) DEFAULT NULL COMMENT '前置仓id',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `all_shelfs` bigint(20) DEFAULT '0' COMMENT '可配置总货架数',
  `smart_shelfs` bigint(20) DEFAULT '0' COMMENT '可配置智能设备数',
  `cover_shelfs` bigint(20) DEFAULT '0' COMMENT '前置仓覆盖货架数(货架类型1,2,3,6,7)',
  `in_shelfs` bigint(20) DEFAULT '0' COMMENT '计划开启货架数(货架类型1,2,3)',
  `qty` bigint(20) DEFAULT '0' COMMENT '计划补货量',
  `product_type` varchar(100) DEFAULT NULL COMMENT '商品类型',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`p_id`),
  KEY `idx_area_pro` (`business_area`,`product_id`),
  KEY `idx_sdate` (`sdate`)
) ENGINE=InnoDB AUTO_INCREMENT=294904 DEFAULT CHARSET=utf8mb4 COMMENT='地区商品前置仓投放计划'