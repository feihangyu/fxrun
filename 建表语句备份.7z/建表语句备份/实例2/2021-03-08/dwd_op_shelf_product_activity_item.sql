CREATE TABLE `dwd_op_shelf_product_activity_item` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `start_time` datetime NOT NULL COMMENT '开始时间',
  `end_time` datetime NOT NULL COMMENT '结束时间',
  `activity_name` varchar(50) NOT NULL COMMENT '活动名称',
  `activity_type` tinyint(4) DEFAULT NULL COMMENT '活动类型 1:促销，2 加价购 3满件优惠 4组合销售 5-拼团, 6-满减优惠,7-新版组合销售,8-换购,10-第二件优惠',
  `discount_type` tinyint(4) DEFAULT NULL COMMENT '优惠方式 1，打折 2,降价 3，优惠价',
  `discount_value` decimal(10,2) DEFAULT NULL COMMENT '优惠值（按优惠类型来）',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`id`),
  KEY `idx_shelf_id_slot_no` (`shelf_id`,`product_id`,`start_time`,`end_time`)
) ENGINE=InnoDB AUTO_INCREMENT=2254142 DEFAULT CHARSET=utf8mb4 COMMENT='活动明细表(宋英南测试用)'