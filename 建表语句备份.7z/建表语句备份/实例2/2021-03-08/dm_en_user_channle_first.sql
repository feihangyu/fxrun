CREATE TABLE `dm_en_user_channle_first` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sdate` date DEFAULT NULL COMMENT '更新日期',
  `user_id` bigint(20) DEFAULT NULL COMMENT '下单人员ID',
  `sale_channel` varchar(20) DEFAULT '0' COMMENT '销售渠道0丰e能量站，1中小月结',
  `order_time` datetime DEFAULT NULL COMMENT '首单时间',
  `order_date` date DEFAULT NULL COMMENT '首单日期',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `ck_us_ch` (`user_id`,`sale_channel`),
  KEY `order_date` (`order_date`)
) ENGINE=InnoDB AUTO_INCREMENT=637132 DEFAULT CHARSET=utf8mb4 COMMENT='福利商城各渠道新用户首单日期'