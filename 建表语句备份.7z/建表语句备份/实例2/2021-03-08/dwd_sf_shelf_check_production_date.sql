CREATE TABLE `dwd_sf_shelf_check_production_date` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `check_id` bigint(20) DEFAULT NULL COMMENT '盘点单号',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `production_date` date DEFAULT NULL COMMENT '生产日期',
  `before_check_num` int(11) DEFAULT '0' COMMENT '盘点前批次数量',
  `after_check_num` int(11) DEFAULT '0' COMMENT '盘点后批次数量',
  `audit_status` int(2) DEFAULT '1' COMMENT '审核状态(1:待审核、2:通过审核、3:不通过审核)',
  `audit_reason` tinyint(2) DEFAULT NULL COMMENT '前置仓效期批次审核不通过原因 dict:CheckDateAuditReason',
  `photos` varchar(2048) DEFAULT NULL COMMENT '生产批次图片url绝对地址,以逗号隔开',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`id`),
  KEY `idx_check_id` (`check_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1237119 DEFAULT CHARSET=utf8mb4 COMMENT='前置仓效期盘点商品批次明细表'