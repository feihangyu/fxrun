CREATE TABLE `dwd_sc_business_region` (
  `area_id` tinyint(4) NOT NULL COMMENT '区域id',
  `business_area` varchar(20) NOT NULL COMMENT '区域名称',
  `region_area` varchar(10) NOT NULL COMMENT '大区名称',
  `district` varchar(10) DEFAULT NULL COMMENT '南北区域',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`business_area`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='采购部门区域对照表'