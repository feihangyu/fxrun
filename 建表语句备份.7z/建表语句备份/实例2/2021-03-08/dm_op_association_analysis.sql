CREATE TABLE `dm_op_association_analysis` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `week_end` date DEFAULT NULL COMMENT '周最后一天',
  `business_code` int(11) DEFAULT '0' COMMENT '地区编码',
  `business_area` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_id_a` bigint(20) DEFAULT NULL COMMENT 'a商品编号',
  `product_id_b` bigint(20) DEFAULT NULL COMMENT 'b商品编号',
  `users_all` bigint(20) DEFAULT NULL COMMENT '总用户数',
  `users_a` bigint(20) DEFAULT NULL COMMENT 'a商品用户数',
  `users_b` bigint(20) DEFAULT NULL COMMENT 'b商品用户数',
  `users_ab` bigint(20) DEFAULT NULL COMMENT 'ab商品共有用户数',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`)
) ENGINE=InnoDB AUTO_INCREMENT=131071 DEFAULT CHARSET=utf8mb4 COMMENT='关联分析'