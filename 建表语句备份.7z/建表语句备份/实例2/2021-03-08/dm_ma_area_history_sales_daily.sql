CREATE TABLE `dm_ma_area_history_sales_daily` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `order_date` date DEFAULT NULL COMMENT '订单创建日期',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架ID',
  `order_status` int(11) DEFAULT NULL COMMENT '订单状态',
  `amount` decimal(18,2) DEFAULT NULL COMMENT '实收金额',
  `gmv` decimal(18,2) DEFAULT NULL COMMENT '销售金额',
  `cogs` decimal(18,2) DEFAULT NULL COMMENT '采购金额',
  `order_num` bigint(20) DEFAULT NULL COMMENT '订单数量',
  `user_num` bigint(20) DEFAULT NULL COMMENT '用户数量',
  `COUPON_AMOUNT` decimal(18,2) DEFAULT NULL COMMENT '优惠券优惠金额',
  `DISCOUNT_AMOUNT` decimal(18,2) DEFAULT NULL COMMENT '订单优惠金额',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `uk` (`order_date`,`shelf_id`,`order_status`),
  KEY `idx_shelf` (`shelf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11156685 DEFAULT CHARSET=utf8mb4 COMMENT='区域销售之历史销售数据统计结果表'