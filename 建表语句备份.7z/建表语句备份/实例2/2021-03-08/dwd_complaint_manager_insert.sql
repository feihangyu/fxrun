CREATE TABLE `dwd_complaint_manager_insert` (
  `pid` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `complaint_date` date DEFAULT NULL COMMENT '投诉受理日期',
  `business_name` varchar(100) NOT NULL COMMENT '区域名称',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架ID',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `MANAGER_ID` bigint(20) DEFAULT NULL COMMENT '店主ID',
  `reason_type` int(2) DEFAULT NULL COMMENT '投诉责任类型(1:站长责任、2:店主责任、3:物流责任、4:系统原因、5:无法确定)',
  `complaint_reason` varchar(100) DEFAULT NULL COMMENT '投诉原因',
  PRIMARY KEY (`pid`),
  KEY `IDX_dm_shelf_id` (`shelf_id`),
  KEY `IDX_dm_product_id` (`product_id`),
  KEY `IDX_dm_SHELF_MANAGERID` (`MANAGER_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=842 DEFAULT CHARSET=utf8mb4 COMMENT='店主被投诉记录(云峰维护)'