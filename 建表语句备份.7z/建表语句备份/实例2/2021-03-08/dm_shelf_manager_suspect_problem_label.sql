CREATE TABLE `dm_shelf_manager_suspect_problem_label` (
  `pid` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `smonth` int(6) DEFAULT NULL COMMENT '统计日期',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架ID',
  `manager_id` bigint(20) DEFAULT NULL COMMENT '店主ID',
  `manager_name` varchar(100) DEFAULT NULL COMMENT '店主名称',
  `manager_star` varchar(100) DEFAULT NULL COMMENT '店主星级',
  `fill_num` int(3) DEFAULT NULL COMMENT '补货次数',
  `operate_num` int(3) DEFAULT NULL COMMENT '盘点次数',
  `shelf_gmv` decimal(18,2) DEFAULT NULL COMMENT '货架GMV',
  `suspect_problem_label` varchar(100) DEFAULT NULL COMMENT '疑似牌面问题标签',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_shelf_manager_suspect_shelf_id` (`smonth`,`shelf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3440697 DEFAULT CHARSET=utf8mb4 COMMENT='货架疑似排面问题标签结果表'