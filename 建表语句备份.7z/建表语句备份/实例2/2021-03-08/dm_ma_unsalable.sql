CREATE TABLE `dm_ma_unsalable` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sdate` date DEFAULT NULL COMMENT '统计日期',
  `business_name` varchar(100) DEFAULT NULL COMMENT '地区',
  `GMV` decimal(18,2) DEFAULT NULL COMMENT '销售额',
  `QTY` int(11) DEFAULT NULL COMMENT '销售数量',
  `DISCOUNT_AMOUNT` decimal(18,2) DEFAULT NULL COMMENT '折扣金额',
  `SALE_SHELF_NUM` int(11) DEFAULT NULL COMMENT '有销售货架数',
  `on_shelf_stock_qty` int(11) DEFAULT NULL COMMENT '在架库存数量',
  `on_shelf_stock_shelf_num` int(11) DEFAULT NULL COMMENT '在架库存货架数',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `pay_aoumnt` decimal(18,2) DEFAULT NULL COMMENT '实收',
  PRIMARY KEY (`pid`),
  KEY `k_sdate` (`sdate`)
) ENGINE=InnoDB AUTO_INCREMENT=26097 DEFAULT CHARSET=utf8mb4 COMMENT='严重滞销品9大指标日统计'