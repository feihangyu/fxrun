CREATE TABLE `dm_ma_marketingtools_weekly` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `tools_type_id` smallint(6) NOT NULL COMMENT '营销工具类型ID',
  `tools_type_name` varchar(50) NOT NULL DEFAULT '其他' COMMENT '营销工具类型',
  `user_type_activity` smallint(6) NOT NULL DEFAULT '0' COMMENT '用户类型ID',
  `user_type_activity_name` varchar(50) NOT NULL DEFAULT '其他' COMMENT '用户类型',
  `users_join` bigint(20) DEFAULT '0' COMMENT '参与人数',
  `users_buy` bigint(20) DEFAULT '0' COMMENT '购买人数',
  `users_rebuy` bigint(20) DEFAULT '0' COMMENT '二次购买人数',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `uk` (`sdate`,`tools_type_id`,`user_type_activity`),
  KEY `idx_tools` (`tools_type_id`),
  KEY `idx_user_type` (`user_type_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='营销工具数据周报'