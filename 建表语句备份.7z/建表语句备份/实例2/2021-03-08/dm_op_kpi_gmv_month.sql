CREATE TABLE `dm_op_kpi_gmv_month` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `region` varchar(32) DEFAULT NULL COMMENT '大区名称',
  `business_area` varchar(32) NOT NULL DEFAULT '' COMMENT '地区名称',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`month_id`,`business_area`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='gmv月表'