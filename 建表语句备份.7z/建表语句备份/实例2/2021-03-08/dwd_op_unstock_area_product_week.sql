CREATE TABLE `dwd_op_unstock_area_product_week` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `week_end` date NOT NULL COMMENT '周最后一天',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `sales_flag` tinyint(4) DEFAULT NULL COMMENT '销量标识',
  `shelfs` int(11) DEFAULT NULL COMMENT '货架数',
  `shelf_list` blob COMMENT '货架明细',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `week_end` (`week_end`,`business_name`,`product_id`,`sales_flag`)
) ENGINE=InnoDB AUTO_INCREMENT=1327142 DEFAULT CHARSET=utf8mb4 COMMENT='爆畅平缺货地区商品周汇总'