CREATE TABLE `dm_op_kpi_np_out_week` (
  `sdate` date NOT NULL COMMENT '日期',
  `version` varchar(100) DEFAULT NULL COMMENT '清单版本号',
  `region` varchar(32) DEFAULT NULL COMMENT '大区名称',
  `business_area` varchar(32) NOT NULL DEFAULT '' COMMENT '地区名称',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `product_fe` varchar(100) DEFAULT NULL COMMENT '商品fe编码',
  `product_name` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `out_flag` tinyint(4) DEFAULT '0' COMMENT '是否已淘汰',
  `stoval` decimal(18,2) DEFAULT '0.00' COMMENT '库存金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`sdate`,`business_area`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='新品转淘汰库存周表'