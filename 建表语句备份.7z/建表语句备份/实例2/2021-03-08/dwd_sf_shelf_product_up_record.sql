CREATE TABLE `dwd_sf_shelf_product_up_record` (
  `record_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '上货编号',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架编号',
  `operate_time` datetime DEFAULT NULL COMMENT '操作时间',
  `operator_id` bigint(20) DEFAULT NULL COMMENT '操作人人编号',
  `shelf_photos` varbinary(1000) DEFAULT NULL COMMENT '货架照片(照片路径)',
  `is_auto_up` tinyint(1) DEFAULT '0' COMMENT '是否自动上货 1-是、0-否',
  `longitude` decimal(18,5) DEFAULT NULL COMMENT '上货地点定位经度(gps坐标系)',
  `latitude` decimal(18,5) DEFAULT NULL COMMENT '上货地点定位纬度(gps坐标系)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT NULL COMMENT '添加人编号',
  `last_update_user_id` bigint(20) DEFAULT NULL COMMENT '最后修改人编号',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `data_flag` int(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  PRIMARY KEY (`record_id`),
  KEY `FK_shelfid_operatetime` (`shelf_id`,`operate_time`)
) ENGINE=InnoDB AUTO_INCREMENT=149757 DEFAULT CHARSET=utf8mb4 COMMENT='上货记录表'