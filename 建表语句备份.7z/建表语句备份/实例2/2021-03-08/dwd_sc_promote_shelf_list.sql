CREATE TABLE `dwd_sc_promote_shelf_list` (
  `shelf_id` int(11) NOT NULL COMMENT '货架id',
  `business_area` varchar(20) DEFAULT NULL COMMENT '区域',
  PRIMARY KEY (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='促销货架id'