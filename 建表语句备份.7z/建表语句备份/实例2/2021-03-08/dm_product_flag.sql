CREATE TABLE `dm_product_flag` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `type_id` smallint(100) DEFAULT NULL COMMENT '商品类别id,可以多个',
  `type_id_bin` int(11) DEFAULT NULL COMMENT '商品类别二进制，倒排后转十进制，如1,3,4二进制为1011，倒排为1101,十进制为13',
  `ext1` int(2) DEFAULT '0' COMMENT '灰度测试',
  `ext2` int(2) DEFAULT '0' COMMENT '扩展标签2',
  `ext_bin_1` int(2) DEFAULT '0' COMMENT '扩展二进制标签1',
  `ext_bin_2` int(2) DEFAULT '0' COMMENT '扩展二进制标签2',
  `data_flag` tinyint(2) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `uk_product_flag_productId` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4096 DEFAULT CHARSET=utf8mb4 COMMENT='商品标签'