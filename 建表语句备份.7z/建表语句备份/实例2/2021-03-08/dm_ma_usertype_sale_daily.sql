CREATE TABLE `dm_ma_usertype_sale_daily` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL COMMENT '日',
  `user_type` smallint(6) NOT NULL COMMENT '用户类型(1 总,2 新用户,3 成长期近1周有购买,4 成熟期近1周有购买,5 成熟期回流,6 休眠期回流,7 流失期回流)',
  `GMV` decimal(15,2) DEFAULT '0.00' COMMENT 'GMV',
  `pay_amount` decimal(15,2) DEFAULT '0.00' COMMENT '销售金额',
  `users` bigint(21) DEFAULT '0' COMMENT '用户数',
  `no_dct_gmv` decimal(15,2) DEFAULT '0.00' COMMENT '无优惠产生的GMV',
  PRIMARY KEY (`sdate`,`user_type`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='每日货架商城各用户类型销售统计'