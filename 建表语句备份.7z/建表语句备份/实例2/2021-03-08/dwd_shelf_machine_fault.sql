CREATE TABLE `dwd_shelf_machine_fault` (
  `fault_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架id',
  `mid` varchar(32) DEFAULT NULL COMMENT '第三方货架编号',
  `slot_code` varchar(32) DEFAULT NULL COMMENT '货道编号',
  `fault_type` int(11) DEFAULT NULL COMMENT '故障类型',
  `fault_name` varchar(256) DEFAULT NULL COMMENT '故障说明',
  `report_time` datetime DEFAULT NULL COMMENT '上报时间',
  `solve_time` datetime DEFAULT NULL COMMENT '解决时间',
  `fault_status` int(11) DEFAULT NULL COMMENT '故障状态',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`fault_id`),
  KEY `Idx_shelf_id` (`shelf_id`),
  KEY `Idx_report_time` (`report_time`),
  KEY `idx_sf_shelf_machine_fault_slot_code` (`slot_code`),
  KEY `idx_mid_slot_code` (`mid`,`slot_code`)
) ENGINE=InnoDB AUTO_INCREMENT=202287 DEFAULT CHARSET=utf8mb4 COMMENT='机器故障表_dw'