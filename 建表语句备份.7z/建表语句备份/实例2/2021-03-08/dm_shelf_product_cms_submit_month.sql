CREATE TABLE `dm_shelf_product_cms_submit_month` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `month_id` varchar(10) DEFAULT NULL COMMENT '月份',
  `business_name` varchar(20) DEFAULT NULL COMMENT '区域',
  `CITY_NAME` varchar(20) DEFAULT NULL COMMENT '城市',
  `zone_code` varchar(20) DEFAULT NULL COMMENT '门店ID',
  `zone_name` varchar(50) DEFAULT NULL COMMENT '门店',
  `product_id` bigint(10) NOT NULL COMMENT '商品ID',
  `PRODUCT_CODE2` varchar(20) DEFAULT NULL COMMENT '商品编码',
  `PRODUCT_NAME` varchar(50) DEFAULT NULL COMMENT '商品名称',
  `submit_status` tinyint(1) DEFAULT NULL COMMENT '闭环状态',
  `ct` int(8) DEFAULT NULL COMMENT '记录数',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_shelf_id_product_id_time` (`product_id`),
  KEY `idx_submit_status` (`submit_status`)
) ENGINE=InnoDB AUTO_INCREMENT=387541 DEFAULT CHARSET=utf8mb4 COMMENT='用户催补货统计表_月份'