CREATE TABLE `dwd_sf_operate_result` (
  `result_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `item_id` bigint(20) DEFAULT NULL COMMENT '对应操作项主键',
  `func_type` tinyint(2) DEFAULT NULL COMMENT '功能类型：1-撤架管理',
  `operate_type` tinyint(2) DEFAULT NULL COMMENT '操作类型：1-审核通过,2-审核不通过',
  `refer_id` bigint(20) DEFAULT NULL COMMENT '关联功能主键',
  `item_result` varchar(20) DEFAULT NULL COMMENT '操作结果',
  `item_remark` varchar(200) DEFAULT NULL COMMENT '备注信息',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT NULL COMMENT '添加人编号',
  `last_update_user_id` bigint(20) DEFAULT NULL COMMENT '最后修改人编号',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `data_flag` int(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  PRIMARY KEY (`result_id`),
  KEY `idx_sf_operate_result_referId_funcType_operateType` (`func_type`,`operate_type`,`refer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=460566 DEFAULT CHARSET=utf8mb4 COMMENT='操作结果表'