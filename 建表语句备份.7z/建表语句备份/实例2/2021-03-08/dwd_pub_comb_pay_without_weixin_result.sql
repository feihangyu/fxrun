CREATE TABLE `dwd_pub_comb_pay_without_weixin_result` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `business_area` varchar(100) NOT NULL COMMENT '区域名称',
  `zone_name` varchar(100) DEFAULT NULL COMMENT '片区名称(所属区域名称）',
  `ORDER_ID` bigint(20) NOT NULL COMMENT '订单编号',
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架编号',
  `shelf_type` int(2) DEFAULT NULL COMMENT '货架类型',
  `PAY_TIME` datetime DEFAULT NULL COMMENT '支付时间',
  `PAY_TYPE` char(2) DEFAULT NULL COMMENT '支付类型: 1：wxPay，2：ebPay，3:ssfCcbPay',
  `PAY_ID` varchar(64) DEFAULT NULL COMMENT '付款编号',
  `GMV` decimal(10,2) DEFAULT '0.00' COMMENT 'GMV',
  `PAY_AMOUNT` decimal(10,2) DEFAULT '0.00' COMMENT 'PAY_AMOUNT',
  `third_discount_amount` decimal(18,2) DEFAULT '0.00' COMMENT '第三方优惠金额',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  KEY `IDX_shelf_district_area` (`business_area`,`shelf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10633 DEFAULT CHARSET=utf8mb4 COMMENT='组合支付非微信支付的结果表'