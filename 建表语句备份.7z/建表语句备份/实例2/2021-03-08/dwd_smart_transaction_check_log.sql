CREATE TABLE `dwd_smart_transaction_check_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `transaction_exception_id` bigint(20) DEFAULT NULL COMMENT '异常id',
  `remark` varchar(500) DEFAULT NULL COMMENT '审核记录',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人编号',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`log_id`),
  KEY `idx_exception_id` (`transaction_exception_id`)
) ENGINE=InnoDB AUTO_INCREMENT=309182 DEFAULT CHARSET=utf8mb4 COMMENT='智能柜异常订单审核日志'