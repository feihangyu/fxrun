CREATE TABLE `dm_op_offstock_high_growth` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date NOT NULL COMMENT '日期',
  `business_name` varchar(20) NOT NULL COMMENT '地区',
  `product_id` bigint(10) NOT NULL COMMENT '商品ID',
  `reason_classify` varchar(50) DEFAULT NULL COMMENT '原因分类',
  `PRODUCT_CODE2` varchar(20) DEFAULT NULL COMMENT '商品FE',
  `PRODUCT_NAME` varchar(50) DEFAULT NULL COMMENT '商品名称',
  `offstock_ct` bigint(20) DEFAULT NULL COMMENT '货架缺货记录数',
  `ct` bigint(20) DEFAULT NULL COMMENT '货架总记录数（爆畅平）',
  `offstock_rate` decimal(8,2) DEFAULT NULL COMMENT '总缺货率',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_sdate_area_product_id` (`sdate`,`business_name`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=614303 DEFAULT CHARSET=utf8mb4 COMMENT='地区高增长商品缺货率'