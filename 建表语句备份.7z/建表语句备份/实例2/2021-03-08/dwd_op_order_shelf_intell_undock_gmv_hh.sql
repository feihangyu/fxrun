CREATE TABLE `dwd_op_order_shelf_intell_undock_gmv_hh` (
  `merch` varchar(50) NOT NULL COMMENT '所属子商家',
  `order_id` varchar(50) NOT NULL COMMENT '订单号',
  `shelf_id` varchar(50) NOT NULL COMMENT '设备名称',
  `MID` varchar(50) DEFAULT NULL COMMENT '设备编号',
  `if_pay` varchar(10) DEFAULT NULL COMMENT '支付状态',
  `pay_type` varchar(10) DEFAULT NULL COMMENT '支付方式',
  `mobile` varchar(32) DEFAULT NULL COMMENT '手机号',
  `data_flag` varchar(10) DEFAULT NULL COMMENT '售后状态',
  `real_money` decimal(18,2) DEFAULT NULL COMMENT '订单总额',
  `GMV` decimal(18,2) DEFAULT NULL COMMENT '优惠前金额',
  `if_fr` varchar(10) DEFAULT NULL COMMENT '是否分润',
  `order_date` datetime DEFAULT NULL COMMENT '订单日期',
  `pay_date` datetime DEFAULT NULL COMMENT '支付时间',
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='哈哈未对接智能柜销售数据'