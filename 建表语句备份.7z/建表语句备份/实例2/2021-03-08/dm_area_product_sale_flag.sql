CREATE TABLE `dm_area_product_sale_flag` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `PRODUCT_ID` bigint(20) DEFAULT NULL COMMENT '商品ID',
  `PRODUCT_NAME` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `business_area` varchar(100) DEFAULT NULL COMMENT '区域名称',
  `ykc_shelf_qty` bigint(20) DEFAULT NULL COMMENT '有库存货架数',
  `avg_qty` decimal(10,2) DEFAULT NULL COMMENT '日架均销量',
  `avg_qty_14` decimal(10,2) DEFAULT NULL COMMENT '14天日架均销量',
  `yxs_shelf_qty` bigint(20) DEFAULT NULL COMMENT '有销售货架数',
  `yxshjzb` decimal(10,2) DEFAULT NULL COMMENT '有销售货架占比',
  `sale_level` varchar(100) DEFAULT '' COMMENT '销售等级',
  `sdate` date DEFAULT NULL COMMENT '日期',
  PRIMARY KEY (`pid`),
  KEY `idx_sdate_business_area_product_id` (`sdate`,`business_area`,`PRODUCT_ID`),
  KEY `idx_business_area_product_id` (`business_area`,`PRODUCT_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=712942 DEFAULT CHARSET=utf8mb4 COMMENT='区域商品销售标识'