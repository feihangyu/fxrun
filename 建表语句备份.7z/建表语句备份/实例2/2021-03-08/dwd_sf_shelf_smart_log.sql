CREATE TABLE `dwd_sf_shelf_smart_log` (
  `kid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架编码',
  `operation_type` int(11) DEFAULT NULL COMMENT '交易状态（1：开门成功 2：开门失败 3：关门 4：下单失败 5：下单成功 6：支付失败 7：支付成功）',
  `operation_result` int(11) DEFAULT NULL COMMENT '操作结果（1：成功 2：失败）',
  `operation_time` datetime DEFAULT NULL COMMENT '操作时间',
  `operation_remark` varchar(512) DEFAULT NULL COMMENT '备注',
  `transaction_id` varchar(32) DEFAULT NULL COMMENT '交易id',
  `data_flag` tinyint(1) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加人编号',
  `last_update_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后修改人编号',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`kid`),
  UNIQUE KEY `idx_transaction_id_operation_type` (`transaction_id`,`operation_type`),
  KEY `idx_sf_smart_shelf_log_shelf_id` (`shelf_id`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=59876276 DEFAULT CHARSET=utf8mb4 COMMENT='智能货架交互记录'