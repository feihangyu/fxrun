CREATE TABLE `dwd_pub_large_amount_order` (
  `ORDER_ID` bigint(20) NOT NULL COMMENT '订单编号',
  `pay_date` datetime NOT NULL COMMENT '支付时间',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架号',
  `GMV` decimal(18,2) DEFAULT '0.00' COMMENT 'GMV',
  `pay_amount` decimal(10,2) DEFAULT NULL COMMENT '实收金额',
  `discount_amount` decimal(18,2) DEFAULT '0.00' COMMENT '折扣金额(gmv减去实收)',
  `PRODUCT_NUM` int(3) DEFAULT '0' COMMENT '商品总数',
  `load_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`ORDER_ID`,`pay_date`),
  KEY `FK_ProductFillOrder_Shelf` (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='批量订单_dwd'