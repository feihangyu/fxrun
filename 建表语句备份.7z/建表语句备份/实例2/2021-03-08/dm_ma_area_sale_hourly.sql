CREATE TABLE `dm_ma_area_sale_hourly` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日',
  `hour` tinyint(4) NOT NULL COMMENT '小时点',
  `business_area` varchar(20) DEFAULT 'other' COMMENT '地区',
  `sale_num` decimal(15,0) DEFAULT '0' COMMENT '销量',
  `GMV` decimal(15,2) DEFAULT '0.00' COMMENT 'gmv',
  `amount` decimal(15,2) DEFAULT '0.00' COMMENT '实收',
  `discount_amount` decimal(15,2) DEFAULT '0.00' COMMENT '折扣金额',
  `coupon_amount` decimal(15,2) DEFAULT '0.00' COMMENT '优惠券金额',
  `order_num` bigint(21) DEFAULT '0' COMMENT '订单数',
  `user_num` bigint(21) DEFAULT '0' COMMENT '用户数',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `sdate_city_name` (`sdate`,`hour`,`business_area`),
  KEY `idx_area` (`business_area`)
) ENGINE=InnoDB AUTO_INCREMENT=13567 DEFAULT CHARSET=utf8mb4 COMMENT='市场同比环比对比数据小时维度'