CREATE TABLE `dm_ma_autoshelf_salesflag_kpi_daily` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT,
  `sdate` date NOT NULL COMMENT '日期',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `sales_flag` bigint(20) NOT NULL COMMENT '销售标识',
  `shelf_code` varchar(40) DEFAULT NULL COMMENT '货架编码',
  `business_characteristics` varchar(20) DEFAULT NULL COMMENT '公司所在地方的商业特性',
  `gmv` decimal(15,2) DEFAULT '0.00' COMMENT 'gmv',
  `sale_quantity` mediumint(9) DEFAULT '0' COMMENT '销售数量',
  `order_num` bigint(21) DEFAULT '0' COMMENT '订单数',
  `stock_quantity` mediumint(9) DEFAULT '0' COMMENT '凌晨库存数量',
  `sale_sku` smallint(6) DEFAULT '0' COMMENT '有销售sku',
  `stock_sku` smallint(6) DEFAULT '0' COMMENT '有库存SKU',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `ids_sdate_shelfid_salesflag` (`sdate`,`shelf_id`,`sales_flag`),
  KEY `idx_shelfid` (`shelf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14641243 DEFAULT CHARSET=utf8mb4 COMMENT='自贩机货架销售等级日报'