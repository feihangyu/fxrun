CREATE TABLE `dwd_shelf_product_shelf_fill_flag_change` (
  `pid` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `shelf_fill_flag` varchar(2) DEFAULT NULL COMMENT '补货标识(1:正常补货、2:停止补货)',
  `start_date` date DEFAULT '0000-00-00' COMMENT '开始日期',
  `end_date` date DEFAULT '0000-00-00' COMMENT '开始日期',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `idx_shelf_id_product_id` (`shelf_id`,`product_id`,`start_date`,`end_date`),
  KEY `idx_shelf_detail_id` (`product_id`),
  KEY `idx_stat_date` (`start_date`)
) ENGINE=InnoDB AUTO_INCREMENT=46942889 DEFAULT CHARSET=utf8mb4 COMMENT='销量标识拉链表'