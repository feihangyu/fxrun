CREATE TABLE `dm_op_valid_danger_flag` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `shelf_id` int(8) NOT NULL COMMENT '货架ID',
  `product_id` int(8) NOT NULL COMMENT '商品ID',
  `STOCK_QUANTITY` int(8) DEFAULT NULL COMMENT '库存数量',
  `danger_type` tinyint(1) DEFAULT NULL COMMENT '高风险类型',
  `product_date` datetime DEFAULT NULL COMMENT '生产日期',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `idx_shelf_id_product_id_type` (`shelf_id`,`product_id`,`danger_type`)
) ENGINE=InnoDB AUTO_INCREMENT=720886 DEFAULT CHARSET=utf8mb4 COMMENT='货架高效期风险商品标签'