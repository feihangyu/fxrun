CREATE TABLE `dm_sc_supplier_type_profit` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `month_id` varchar(20) DEFAULT NULL COMMENT '月份',
  `short_name` varchar(30) DEFAULT NULL COMMENT '供应商缩写',
  `supplier_name` varchar(50) DEFAULT NULL COMMENT '供应商名称',
  `supplier_area` varchar(30) DEFAULT NULL COMMENT '供应区域',
  `supplier_type` varchar(30) DEFAULT NULL COMMENT '供应商品类型',
  `delivery_term` decimal(10,4) DEFAULT NULL COMMENT '入库加权交期',
  `order_satisfy` decimal(10,4) NOT NULL COMMENT '订单满足率',
  `drinking_prate` decimal(10,4) NOT NULL COMMENT '水饮毛利率',
  `snack_prate` decimal(10,4) NOT NULL COMMENT '休食毛利率',
  `fast_prate` decimal(10,4) NOT NULL COMMENT '速食毛利率',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_month` (`month_id`),
  KEY `idx_supplier` (`short_name`)
) ENGINE=InnoDB AUTO_INCREMENT=116231 DEFAULT CHARSET=utf8mb4 COMMENT='采购供应商类型及毛利'