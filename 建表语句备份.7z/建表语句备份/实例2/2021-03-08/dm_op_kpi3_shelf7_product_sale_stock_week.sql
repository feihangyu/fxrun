CREATE TABLE `dm_op_kpi3_shelf7_product_sale_stock_week` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `business_name` varchar(100) DEFAULT NULL COMMENT '地区',
  `machine_type_id` bigint(20) DEFAULT NULL COMMENT '贩卖机型号',
  `shelfs_sale` int(11) DEFAULT '0' COMMENT '有销售货架数',
  `shelfs_sale_shipped` int(11) DEFAULT '0' COMMENT '有销售货架数_成功出货',
  `shelfs_stock` int(11) DEFAULT '0' COMMENT '有库存货架数',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`product_id`,`business_name`,`machine_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=277386 DEFAULT CHARSET=utf8mb4 COMMENT='自贩机商品每周动销'