CREATE TABLE `dwd_city_business` (
  `CITY` varchar(20) NOT NULL COMMENT '市编码',
  `CITY_NAME` varchar(32) DEFAULT NULL COMMENT '市名称',
  `BUSINESS_CODE` int(11) NOT NULL DEFAULT '0' COMMENT '地区编码',
  `area_id` int(11) DEFAULT NULL COMMENT '商品地区ID',
  `business_name` varchar(100) CHARACTER SET utf8mb4 NOT NULL COMMENT '地区',
  `PROVINCE` varchar(20) DEFAULT NULL COMMENT '省编码',
  `PROVINCE_NAME` varchar(32) DEFAULT NULL COMMENT '省名称',
  `REGION_CODE` int(11) NOT NULL DEFAULT '0' COMMENT '大区编码',
  `REGION_NAME` varchar(32) DEFAULT NULL COMMENT '大区名称',
  `latitude` tinyint(3) unsigned DEFAULT '0' COMMENT '纬度',
  `longitude` tinyint(3) unsigned DEFAULT '0' COMMENT '经度',
  `city_name_py` varchar(32) DEFAULT NULL COMMENT '城市拼音名',
  PRIMARY KEY (`CITY`),
  KEY `cb_area` (`business_name`),
  KEY `idx_city_name` (`CITY_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='城市地区表'