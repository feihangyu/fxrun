CREATE TABLE `dm_pub_third_user_balance_day` (
  `balance_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `open_id` varchar(40) NOT NULL COMMENT '第三方用户ID',
  `balance` decimal(10,2) NOT NULL COMMENT '第三方余额',
  `channel` varchar(20) NOT NULL COMMENT '接入渠道',
  `sdate` date NOT NULL COMMENT '结存日期',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`balance_id`),
  KEY `idx_open_id` (`open_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4979783 DEFAULT CHARSET=utf8mb4 COMMENT='第三方余额表'