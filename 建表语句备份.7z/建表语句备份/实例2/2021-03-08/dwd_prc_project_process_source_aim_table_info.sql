CREATE TABLE `dwd_prc_project_process_source_aim_table_info` (
  `pid` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `project` varchar(128) DEFAULT NULL COMMENT '工程名',
  `process` varchar(128) DEFAULT NULL COMMENT '存储过程名',
  `source_base` varchar(32) DEFAULT NULL COMMENT '源表库',
  `source_table` varchar(128) DEFAULT NULL COMMENT '源表英文名',
  `source_table_cname` varchar(128) DEFAULT NULL COMMENT '源表中文名',
  `aim_base` varchar(32) DEFAULT NULL COMMENT '结果表库',
  `aim_table` varchar(128) DEFAULT NULL COMMENT '结果表英文名',
  `aim_table_cname` varchar(128) DEFAULT NULL COMMENT '结果表中文名',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2025 DEFAULT CHARSET=utf8mb4 COMMENT='工程_存储过程_源表_结果表信息'