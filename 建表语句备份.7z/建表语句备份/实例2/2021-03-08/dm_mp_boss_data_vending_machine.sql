CREATE TABLE `dm_mp_boss_data_vending_machine` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `report_day` date DEFAULT NULL COMMENT '报告日期',
  `row_num` bigint(10) DEFAULT NULL COMMENT '序号',
  `stime` varchar(100) DEFAULT NULL COMMENT '时间',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `GMV` decimal(18,2) DEFAULT NULL COMMENT 'GMV',
  `ACTIVATE_shelf_qty` bigint(20) DEFAULT NULL COMMENT '新增货架数',
  `REVOKE_shelf_qty` bigint(20) DEFAULT NULL COMMENT '撤架货架数',
  `shelfs_status2` int(11) DEFAULT '0' COMMENT '当天激活状态货架数',
  `shelf_qty` bigint(20) DEFAULT NULL COMMENT '激活货架数',
  `user_qty` bigint(20) DEFAULT NULL COMMENT '用户数',
  `order_qty` bigint(20) DEFAULT NULL COMMENT '订单数',
  `discount` decimal(18,2) DEFAULT NULL COMMENT '优惠',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=10951 DEFAULT CHARSET=utf8mb4