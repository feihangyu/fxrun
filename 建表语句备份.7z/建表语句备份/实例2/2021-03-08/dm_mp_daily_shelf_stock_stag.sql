CREATE TABLE `dm_mp_daily_shelf_stock_stag` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date DEFAULT NULL COMMENT '统计日期',
  `daily_remain_shelf` int(11) NOT NULL COMMENT '当日留存货架',
  `stock_shelf_cnt` int(11) NOT NULL COMMENT '有库存货架数',
  `no_stock_shelf` int(11) NOT NULL COMMENT '0库存货架数',
  `stock_lack_shelf` int(11) NOT NULL COMMENT '库存不足货架数',
  `stag_shelf_cnt` int(11) NOT NULL COMMENT '滞销品占比超60%货架数',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_sdate` (`sdate`)
) ENGINE=InnoDB AUTO_INCREMENT=514 DEFAULT CHARSET=utf8mb4 COMMENT='经规_滞销货架库存不足货架数'