CREATE TABLE `dm_en_third_user_balance_his` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `open_id` varchar(40) DEFAULT NULL COMMENT '第三方用户ID',
  `balance` decimal(10,2) DEFAULT NULL COMMENT '第三方余额',
  `channel` varchar(20) DEFAULT NULL COMMENT '接入渠道',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`),
  KEY `idx_open_id` (`open_id`),
  KEY `idx_channel` (`channel`)
) ENGINE=InnoDB AUTO_INCREMENT=36827363 DEFAULT CHARSET=utf8mb4 COMMENT='第三方余额历史表（每周日结存）'