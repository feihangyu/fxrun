CREATE TABLE `dm_op_shelf_price_grade` (
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区',
  `city_name` varchar(32) DEFAULT NULL COMMENT '城市',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `scene` varchar(32) DEFAULT NULL COMMENT '场景',
  `city_grade` varchar(32) DEFAULT NULL COMMENT '城市等级',
  `scene_grade` varchar(32) DEFAULT NULL COMMENT '场景等级',
  `is_regular_customer` varchar(10) DEFAULT NULL COMMENT '是否固定客户群',
  `payment_type` varchar(32) DEFAULT NULL COMMENT '费用类型',
  `payment_type_sum` int(10) DEFAULT NULL COMMENT '固定费用金额',
  `payment_type_percentage` int(10) DEFAULT NULL COMMENT '销售分成扣点',
  `mul_percent` decimal(18,2) DEFAULT '0.00' COMMENT '梯度分成综合扣点',
  `cost_grade` varchar(10) DEFAULT NULL COMMENT '合同费用等级',
  `multiple_grade` int(10) DEFAULT NULL COMMENT '综合价格等级',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='自贩机价格等级表-商品组'