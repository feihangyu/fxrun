CREATE TABLE `dm_op_shelf7_abnormal_product_sum` (
  `sdate` date NOT NULL COMMENT '统计日期',
  `business_name` varchar(32) NOT NULL COMMENT '地区',
  `abnormal_price` bigint(20) DEFAULT NULL COMMENT '异常价格数量',
  `abnormal_fill_2` bigint(20) DEFAULT NULL COMMENT '异常停补数量',
  `abnormal_fill_1` bigint(20) DEFAULT NULL COMMENT '异常开启补货数量',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`sdate`,`business_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='自贩机货架商品异常汇总'