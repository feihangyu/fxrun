CREATE TABLE `dm_lo_zone_daily_data` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date NOT NULL DEFAULT '0000-00-00' COMMENT '统计日',
  `business_area` varchar(50) DEFAULT NULL COMMENT '区域',
  `zone_code` varchar(100) DEFAULT NULL COMMENT '门店编码',
  `zone_name` varchar(100) DEFAULT NULL COMMENT '门店名称',
  `last_month_gmv` decimal(18,2) DEFAULT NULL COMMENT '上月GMV',
  `shelfs` int(30) DEFAULT NULL COMMENT '货架数量',
  `district` varchar(100) DEFAULT NULL COMMENT '覆盖行政区',
  `distance_avg` decimal(18,2) DEFAULT '0.00' COMMENT '平均货架距离',
  `shelf_pre_distance_avg` decimal(18,2) DEFAULT '0.00' COMMENT '货架到前置仓平均距离',
  `area` decimal(18,2) DEFAULT '0.00' COMMENT '面积',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `unique_key` (`sdate`,`business_area`,`zone_name`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=280324 DEFAULT CHARSET=utf8mb4 COMMENT='门店日信息统计表'