CREATE TABLE `dm_op_dim_product_area_normal` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `month_id` char(7) DEFAULT NULL COMMENT '月份',
  `product_id` int(11) DEFAULT NULL COMMENT '商品',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_type` varchar(100) DEFAULT NULL COMMENT '商品类型',
  `product_type_last2` varchar(100) DEFAULT NULL COMMENT '两月前商品类型',
  `normal_flag` tinyint(1) DEFAULT '0' COMMENT '连续两月为原有',
  `fill_model_flag` tinyint(1) DEFAULT '0' COMMENT '盒装',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `month_id` (`month_id`,`product_id`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=7551192 DEFAULT CHARSET=utf8mb4 COMMENT='地区商品清单_原有品'