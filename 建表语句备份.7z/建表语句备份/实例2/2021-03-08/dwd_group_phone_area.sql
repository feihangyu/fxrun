CREATE TABLE `dwd_group_phone_area` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `mobile_phone` varchar(100) DEFAULT NULL COMMENT '手机号',
  `business_area` varchar(20) DEFAULT NULL COMMENT '区域',
  PRIMARY KEY (`pid`),
  KEY `index_mobile_phone` (`mobile_phone`)
) ENGINE=InnoDB AUTO_INCREMENT=2730 DEFAULT CHARSET=utf8mb4 COMMENT='企业用户手机对应的地区'