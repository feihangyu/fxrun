CREATE TABLE `dm_sc_preware_kpi` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` datetime DEFAULT NULL COMMENT '统计日期(周/月最后一天)',
  `seq` tinyint(4) DEFAULT NULL COMMENT '序号',
  `kpi_type` varchar(50) DEFAULT NULL COMMENT 'KPI类型',
  `kpi` decimal(18,4) DEFAULT '0.0000' COMMENT 'KPI',
  `kpi_name` varchar(50) DEFAULT NULL COMMENT 'KPI名称',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=8022 DEFAULT CHARSET=utf8mb4 COMMENT='前置仓KPI'