CREATE TABLE `dm_op_area_high_stock` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `month_id` varchar(10) NOT NULL COMMENT '日期（每月1日截存）',
  `business_name` varchar(20) NOT NULL COMMENT '地区',
  `shelf_qty` int(8) DEFAULT NULL COMMENT '货架数',
  `bind_cnt` int(8) DEFAULT NULL COMMENT '关联货架数',
  `avg_sku_qty` decimal(10,2) DEFAULT NULL COMMENT '架均有库存SKU',
  `avg_stock_value` decimal(10,2) DEFAULT NULL COMMENT '架均库存金额',
  `total_stock_value` decimal(10,2) DEFAULT NULL COMMENT '总库存金额',
  `total_high_stock_value` decimal(10,2) DEFAULT NULL COMMENT '高库存金额',
  `high_stock_value_ratio` decimal(10,2) DEFAULT NULL COMMENT '高库存占比',
  `layout_high_stock_shelf_qty` int(4) DEFAULT NULL COMMENT '排面高库存货架数',
  `layout_low_stock_shelf_qty` int(4) DEFAULT NULL COMMENT '排面低库存货架数',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_month_id_area` (`month_id`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=20298 DEFAULT CHARSET=utf8mb4 COMMENT='货架高库存明细表'