CREATE TABLE `dwd_sf_shelf_product_status_log` (
  `log_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '日志id',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架id',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `operate_type` tinyint(2) DEFAULT '0' COMMENT '操作类型 字典：(1-补货状态修改)',
  `operate_enter` tinyint(2) DEFAULT '0' COMMENT '操作入口 【operate_type=1 字典：operateEnter(1-定时任务、2-店主选品【店主提交】、3-品类黑名单、4-商品详情、5-店主选品【后台审核】、6-批量导入、7-货架关联、8-货架解绑、9-智能柜列表)】',
  `operate_action` tinyint(2) DEFAULT '0' COMMENT '操作动作 【operate_type=1 字典：ShelfFillFlag(1-正常补货、2-停止补货)】',
  `operate_remark` varchar(500) DEFAULT '' COMMENT '备注',
  `change_Reason` tinyint(2) DEFAULT NULL COMMENT '变更原因 字典（正常补货：shelfProductStartFillStatus；停止补货：shelfProductStopFillStatus）',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人编号',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人编号',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `data_flag` tinyint(1) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  PRIMARY KEY (`log_id`),
  KEY `idx_shelf_product_id` (`shelf_id`,`product_id`),
  KEY `idx_add_time` (`add_time`)
) ENGINE=InnoDB AUTO_INCREMENT=4840437 DEFAULT CHARSET=utf8mb4 COMMENT='货架商品状态修改日志表'