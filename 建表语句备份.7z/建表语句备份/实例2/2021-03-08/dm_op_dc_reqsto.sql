CREATE TABLE `dm_op_dc_reqsto` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `business_name` varchar(100) DEFAULT NULL COMMENT '地区',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `supplier_id` bigint(20) NOT NULL COMMENT '供应商编号',
  `depot_code` varchar(30) DEFAULT NULL COMMENT '仓库编码',
  `qty_sto` int(11) DEFAULT NULL COMMENT '库存',
  `qty_req` decimal(18,6) DEFAULT NULL COMMENT '前30天日均销量',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`product_id`,`supplier_id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `product_id` (`product_id`),
  KEY `depot_code` (`depot_code`),
  KEY `idx_area_product_id` (`business_name`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2227563 DEFAULT CHARSET=utf8mb4 COMMENT='仓库满足'