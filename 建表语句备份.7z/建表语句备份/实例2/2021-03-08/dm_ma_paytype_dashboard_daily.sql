CREATE TABLE `dm_ma_paytype_dashboard_daily` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL,
  `business_name` varchar(20) NOT NULL DEFAULT 'other',
  `payment_type` varchar(20) NOT NULL DEFAULT '其他' COMMENT '支付渠道类型',
  `gmv` decimal(15,2) DEFAULT '0.00',
  `amount` decimal(15,2) DEFAULT '0.00',
  `after_pay_amount` decimal(15,2) DEFAULT '0.00',
  `discount_amount` decimal(15,2) DEFAULT '0.00',
  `coupon_amount` decimal(15,2) DEFAULT '0.00',
  `order_num` bigint(21) DEFAULT '0',
  `user_num` bigint(21) DEFAULT '0',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `sdate` (`sdate`,`business_name`,`payment_type`),
  KEY `idx_business_name` (`business_name`),
  KEY `idx_paytype` (`payment_type`)
) ENGINE=InnoDB AUTO_INCREMENT=2406990 DEFAULT CHARSET=utf8mb4 COMMENT='支付渠道维度日报看板'