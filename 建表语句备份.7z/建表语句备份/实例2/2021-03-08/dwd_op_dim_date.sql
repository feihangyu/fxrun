CREATE TABLE `dwd_op_dim_date` (
  `edate` date DEFAULT NULL COMMENT '结束日期',
  `sdate` date DEFAULT NULL COMMENT '开始日期',
  `version_id` varchar(100) NOT NULL DEFAULT '' COMMENT '版本号',
  PRIMARY KEY (`version_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='日期对应清单'