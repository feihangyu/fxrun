CREATE TABLE `dwd_sf_material_detail` (
  `material_detail_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '物资对象ID',
  `material_id` bigint(20) DEFAULT NULL COMMENT '物资类型id',
  `material_status` int(2) DEFAULT '0' COMMENT '物资状态(1:新增、2:撤架)',
  `material_address` varchar(200) DEFAULT NULL COMMENT '存放地址',
  `remark` varchar(500) DEFAULT NULL COMMENT '备注',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`material_detail_id`),
  KEY `IDX_materialDetail_materialId` (`material_id`)
) ENGINE=InnoDB AUTO_INCREMENT=132787 DEFAULT CHARSET=utf8mb4 COMMENT='物资对象表'