CREATE TABLE `dwd_sf_shelf_info_flag` (
  `shelf_info_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架ID',
  `continue_no_upgrade_new_days` int(11) DEFAULT '0' COMMENT '连续未上新品天数',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `business_characteristics_remark` varchar(200) DEFAULT NULL COMMENT '商业特性细分特性备注',
  `business_characteristics_segment` int(2) DEFAULT NULL COMMENT '商业特性细分特性',
  `belong_industry_segment` int(2) DEFAULT NULL COMMENT '公司行业细分行业',
  `belong_industry` int(2) DEFAULT NULL COMMENT '公司行业',
  `business_characteristics` int(2) DEFAULT NULL COMMENT '商业特性',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`shelf_info_id`),
  UNIQUE KEY `IDX_SHELF_ID` (`shelf_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=60075468 DEFAULT CHARSET=utf8mb4 COMMENT='货架信息标识'