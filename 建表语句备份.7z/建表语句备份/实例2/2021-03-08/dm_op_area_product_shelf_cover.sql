CREATE TABLE `dm_op_area_product_shelf_cover` (
  `sdate` datetime NOT NULL COMMENT '统计日期',
  `business_name` varchar(32) NOT NULL COMMENT '地区',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `product_type` varchar(32) DEFAULT NULL COMMENT '商品类型',
  `sale_level` varchar(32) DEFAULT NULL COMMENT '商品等级',
  `active_shelf` bigint(20) DEFAULT '0' COMMENT '地区激活货架数',
  `noclose_active_shelf` bigint(20) DEFAULT '0' COMMENT '地区激活非关闭货架数',
  `sto_shelf` bigint(20) DEFAULT '0' COMMENT '有库存货架数',
  `fill_shelf` bigint(20) DEFAULT '0' COMMENT '可补货货架数',
  `sto_noclose_shelf` bigint(20) DEFAULT '0' COMMENT '有库存非关闭货架数',
  `fill_noclose_shelf` bigint(20) DEFAULT '0' COMMENT '可补货非关闭货架数',
  `stock` bigint(20) DEFAULT '0' COMMENT '大仓库存',
  `pre_stock` bigint(20) DEFAULT '0' COMMENT '前置仓库存',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  `fst_shelf` int(11) DEFAULT '0' COMMENT '可补货或有库存货架数',
  `fst_noclose_shelf` int(11) DEFAULT '0' COMMENT '可补货或有库存非关闭货架数',
  PRIMARY KEY (`sdate`,`business_name`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区商品覆盖货架数据(不含智能设备)'