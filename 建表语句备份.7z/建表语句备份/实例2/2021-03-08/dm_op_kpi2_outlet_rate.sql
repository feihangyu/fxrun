CREATE TABLE `dm_op_kpi2_outlet_rate` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date DEFAULT '0000-00-00' COMMENT '日期',
  `version_id` varchar(100) DEFAULT '' COMMENT '版本号',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `cum_qty_sal` int(11) DEFAULT '0' COMMENT '累计销量',
  `cum_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '累计gmv',
  `cum_discount` decimal(18,2) DEFAULT '0.00' COMMENT '累计折扣金额',
  `cum_qty_fil` int(11) DEFAULT '0' COMMENT '累计补货量',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`business_name`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5492016 DEFAULT CHARSET=utf8mb4 COMMENT='淘汰品售罄率'