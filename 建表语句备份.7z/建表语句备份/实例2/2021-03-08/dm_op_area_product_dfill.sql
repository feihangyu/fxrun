CREATE TABLE `dm_op_area_product_dfill` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_id` bigint(20) DEFAULT '0' COMMENT '商品编号',
  `qty_fill` int(11) DEFAULT '0' COMMENT '补货数量',
  `val_fill` decimal(18,2) DEFAULT '0.00' COMMENT '补货金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`business_name`,`product_id`),
  KEY `idx_business_name_product_id` (`business_name`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2910630 DEFAULT CHARSET=utf8mb4 COMMENT='地区商品每日补货'