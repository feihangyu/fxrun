CREATE TABLE `dwd_ma_gmv_goal` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `smonth` date DEFAULT NULL COMMENT '月份',
  `gmv_goal` decimal(18,2) DEFAULT '0.00' COMMENT '销售目标',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COMMENT='市场月度gmv目标(手动插入市场目标值，伟铨维护)'