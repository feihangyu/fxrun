CREATE TABLE `dm_op_fill_area_product_stat` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL DEFAULT '0000-00-00' COMMENT '日期',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_id` bigint(20) DEFAULT '0' COMMENT '商品编号',
  `orders` int(11) DEFAULT '0' COMMENT '订单量',
  `orders_cum` int(11) DEFAULT '0' COMMENT '累计订单量',
  `actual_apply_num` int(11) DEFAULT '0' COMMENT '补货商品量',
  `actual_apply_num_cum` int(11) DEFAULT '0' COMMENT '累计补货商品量',
  `actual_apply_val` decimal(18,2) DEFAULT '0.00' COMMENT '补货金额',
  `actual_apply_val_cum` decimal(18,2) DEFAULT '0.00' COMMENT '累计补货金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`business_name`,`product_id`),
  KEY `idx_business_name_product_id` (`business_name`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5243687 DEFAULT CHARSET=utf8mb4 COMMENT='补货表每日地区商品统计'