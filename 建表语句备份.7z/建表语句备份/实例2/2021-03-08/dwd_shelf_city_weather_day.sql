CREATE TABLE `dwd_shelf_city_weather_day` (
  `city_name` varchar(32) NOT NULL COMMENT '城市名',
  `sdate` date NOT NULL COMMENT '日期',
  `sweek` varchar(16) DEFAULT NULL COMMENT '星期',
  `weather` varchar(32) DEFAULT NULL COMMENT '天气',
  `current_temperature` smallint(6) DEFAULT NULL COMMENT '当前气温（℃）',
  `temp_range` varchar(32) DEFAULT NULL COMMENT '气温范围',
  `high_temperature` smallint(6) DEFAULT NULL COMMENT '最高气温（℃）',
  `low_temperature` smallint(6) DEFAULT NULL COMMENT '最低气温（℃）',
  `wind_direction` varchar(32) DEFAULT NULL COMMENT '风向',
  `cdate_detail_info` varchar(64) DEFAULT NULL COMMENT '当前天气详细信息',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`city_name`,`sdate`),
  KEY `idx_sdate` (`sdate`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='城市天气信息表'