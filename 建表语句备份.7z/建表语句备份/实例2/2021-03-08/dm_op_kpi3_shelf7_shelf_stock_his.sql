CREATE TABLE `dm_op_kpi3_shelf7_shelf_stock_his` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架编号',
  `sto_qty` int(21) DEFAULT '0' COMMENT '库存数量',
  `psto_qty` int(21) DEFAULT '0' COMMENT '库存数量_正库存',
  `sto_val` decimal(18,2) DEFAULT '0.00' COMMENT '库存金额',
  `psto_val` decimal(18,2) DEFAULT '0.00' COMMENT '库存金额_正库存',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`shelf_id`),
  KEY `idx_shelf_id` (`shelf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2305340 DEFAULT CHARSET=utf8mb4 COMMENT='自贩机历史库存'