CREATE TABLE `dwd_sserp_t_bas_billtype_l` (
  `FPKID` varchar(36) NOT NULL DEFAULT '',
  `FBILLTYPEID` varchar(36) DEFAULT NULL,
  `FLOCALEID` int(11) DEFAULT NULL,
  `FNAME` varchar(80) DEFAULT NULL,
  `FDESCRIPTION` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`FPKID`),
  KEY `idx_billtype` (`FBILLTYPEID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4