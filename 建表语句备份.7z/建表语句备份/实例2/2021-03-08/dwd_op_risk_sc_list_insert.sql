CREATE TABLE `dwd_op_risk_sc_list_insert` (
  `id` int(8) NOT NULL AUTO_INCREMENT,
  `version_id` int(8) NOT NULL DEFAULT '0' COMMENT '档期01风控02采购',
  `shelf_id` int(8) NOT NULL COMMENT '货架id',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_version_id` (`version_id`) COMMENT '档期01风控02采购',
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=100 DEFAULT CHARSET=utf8mb4 COMMENT='风控疑似包盗损&采购集中清理货架清单(英南维护)'