CREATE TABLE `dm_op_product_area_shelftype_dfill` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `business_name` varchar(32) NOT NULL COMMENT '地区名称',
  `shelf_type` int(2) NOT NULL DEFAULT '1' COMMENT '货架类型',
  `supplier_type` int(2) DEFAULT '1' COMMENT '供应商类型',
  `fill_type` int(2) DEFAULT '1' COMMENT '补货类型',
  `qty_fill` int(11) DEFAULT '0' COMMENT '补货数量',
  `val_fill` decimal(18,2) DEFAULT '0.00' COMMENT '补货金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`product_id`,`business_name`,`shelf_type`,`supplier_type`,`fill_type`),
  KEY `idx_product_id_business_name` (`product_id`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=23975870 DEFAULT CHARSET=utf8mb4 COMMENT='地区商品类型每日补货'