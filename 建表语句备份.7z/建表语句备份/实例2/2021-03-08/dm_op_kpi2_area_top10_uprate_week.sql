CREATE TABLE `dm_op_kpi2_area_top10_uprate_week` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `week_end` date NOT NULL DEFAULT '0000-00-00' COMMENT '周最后一天',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `order_num` tinyint(4) DEFAULT '0' COMMENT '排序',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `product_id_lw` bigint(20) DEFAULT NULL COMMENT '上周商品编号',
  `gmv_lw` decimal(18,2) DEFAULT '0.00' COMMENT '上周gmv',
  `gmv_lwp` decimal(18,2) DEFAULT '0.00' COMMENT '上周top10本周gmv',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `week_end` (`week_end`,`business_name`,`order_num`)
) ENGINE=InnoDB AUTO_INCREMENT=108791 DEFAULT CHARSET=utf8mb4 COMMENT='同批足月货架地区top10单品gmv周提升率'