CREATE TABLE `dm_op_area_shelf_open_close_times` (
  `month_id` varchar(32) NOT NULL DEFAULT '' COMMENT '月份',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区',
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架id',
  `shelf_type` int(2) DEFAULT NULL COMMENT '货架类型',
  `last_close_time` datetime DEFAULT NULL COMMENT '最近一次关闭日期',
  `last_open_time` datetime DEFAULT NULL COMMENT '最近一次开启日期',
  `close_times` int(4) DEFAULT NULL COMMENT '关闭频次',
  `days` decimal(18,4) DEFAULT NULL COMMENT '关闭时长',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`month_id`,`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='区域月份关闭货架时长表'