CREATE TABLE `dm_op_stock_product` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `business_name` varchar(100) DEFAULT NULL COMMENT '地区',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品',
  `sto_qty` int(8) DEFAULT NULL COMMENT '库存数量',
  `sto_val` decimal(18,2) DEFAULT '0.00' COMMENT '库存金额',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT '日均gmv',
  `sto_qty_lm` int(8) DEFAULT NULL COMMENT '上月库存数量',
  `sto_val_lm` decimal(18,2) DEFAULT '0.00' COMMENT '上月库存金额',
  `gmv_lm` decimal(18,2) DEFAULT '0.00' COMMENT '上月gmv',
  `sto_val_budget` decimal(18,2) DEFAULT '0.00' COMMENT '库存金额预算',
  `gmv_budget` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv预算',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`business_name`,`product_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2899510 DEFAULT CHARSET=utf8mb4 COMMENT='地区商品库存周转'