CREATE TABLE `dm_op_kpi2_monitor` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `indicate_type` char(1) NOT NULL DEFAULT 'w' COMMENT '指标类型:周w,月m',
  `indicate_id` smallint(6) NOT NULL COMMENT '指标号',
  `indicate_name` varchar(48) DEFAULT NULL COMMENT '指标名称',
  `indicate_value` decimal(18,6) DEFAULT NULL COMMENT '指标值',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `sdate` (`sdate`,`indicate_type`,`indicate_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2049 DEFAULT CHARSET=utf8mb4 COMMENT='运营kpi2首页'