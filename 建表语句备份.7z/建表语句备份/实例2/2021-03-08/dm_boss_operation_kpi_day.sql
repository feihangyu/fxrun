CREATE TABLE `dm_boss_operation_kpi_day` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date DEFAULT NULL COMMENT '统计日期',
  `seq` int(4) DEFAULT NULL COMMENT '排序字段',
  `primary_index` varchar(32) DEFAULT NULL COMMENT '一级指标',
  `secondary_index` varchar(32) DEFAULT NULL COMMENT '二级指标',
  `result_rate` decimal(18,4) DEFAULT NULL COMMENT '指标结果',
  `comm` varchar(32) DEFAULT NULL COMMENT '备注',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=5793 DEFAULT CHARSET=utf8mb4 COMMENT='GMV各业务达成保障kpi指标'