CREATE TABLE `dwd_op_city_grade` (
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区',
  `city_name` varchar(32) DEFAULT NULL COMMENT '城市',
  `city_grade` varchar(32) DEFAULT NULL COMMENT '城市等级',
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COMMENT='城市等级表-商品组'