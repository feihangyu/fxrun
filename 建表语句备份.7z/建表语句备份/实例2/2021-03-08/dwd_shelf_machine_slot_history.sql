CREATE TABLE `dwd_shelf_machine_slot_history` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `shelf_id` int(11) DEFAULT NULL COMMENT '货架id',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `manufacturer_slot_code` varchar(30) DEFAULT NULL COMMENT '厂商系统货道编码',
  `slot_status` int(11) DEFAULT NULL COMMENT '货道状态（1：正常 2:故障 3:停用;4:缺货;）',
  `stock_num` int(11) DEFAULT NULL COMMENT '库存数量',
  `slot_capacity_limit` tinyint(3) DEFAULT NULL COMMENT '机器货道容量',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=128107211 DEFAULT CHARSET=utf8mb4 COMMENT='贩卖机货道库存近7天截存'