CREATE TABLE `dwd_pub_number` (
  `number` bigint(10) NOT NULL COMMENT '序号',
  PRIMARY KEY (`number`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='序号表'