CREATE TABLE `dm_op_users_day_stat` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `business_name` varchar(32) NOT NULL COMMENT '地区名称',
  `users_new` int(11) DEFAULT '0' COMMENT '当天新增用户数',
  `users_day` int(11) DEFAULT '0' COMMENT '当天用户数',
  `users_week` int(11) DEFAULT '0' COMMENT '周累计用户数',
  `users_month` int(11) DEFAULT '0' COMMENT '月累计用户数',
  `users_year` int(11) DEFAULT '0' COMMENT '年累计用户数',
  `users` int(11) DEFAULT '0' COMMENT '总累计用户数',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=105811 DEFAULT CHARSET=utf8mb4 COMMENT='每日用户数统计'