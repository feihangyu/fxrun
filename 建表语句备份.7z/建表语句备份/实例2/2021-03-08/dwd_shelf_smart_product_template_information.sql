CREATE TABLE `dwd_shelf_smart_product_template_information` (
  `template_id` bigint(20) NOT NULL COMMENT '模板id',
  `template_name` varchar(64) NOT NULL COMMENT '模板名称',
  `machine_type_id` tinyint(1) NOT NULL COMMENT '设备类型id',
  `third_party_template_id` varchar(32) DEFAULT NULL COMMENT '第三方模板id',
  `template_status` tinyint(1) DEFAULT NULL COMMENT '模板可用状态(1 可用 2 不可用 3 待训练 4 训练中）',
  `remark` varchar(512) DEFAULT NULL COMMENT '备注，模板不可用原因',
  `product_id` bigint(20) NOT NULL DEFAULT '-1' COMMENT '商品id(-1代表空值)',
  `sale_price` decimal(18,2) DEFAULT '0.00' COMMENT '实际销售价格',
  `standard_quantity` int(11) DEFAULT '0' COMMENT '标配数量',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `use_status` tinyint(1) DEFAULT NULL COMMENT '应用状态',
  `relation_remark` varchar(512) DEFAULT NULL COMMENT '智能柜商品模板与货架关联表备注',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`template_id`,`shelf_id`,`product_id`),
  KEY `idx_shelf_id` (`shelf_id`),
  KEY `idx_product_id` (`product_id`),
  KEY `idx_load_time` (`load_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='智能柜商品模板信息表'