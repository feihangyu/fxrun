CREATE TABLE `dm_op_su_s_stat` (
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `users` int(11) DEFAULT '0' COMMENT '用户数',
  `users_first` int(11) DEFAULT '0' COMMENT '首次用户数',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架用户统计_货架'