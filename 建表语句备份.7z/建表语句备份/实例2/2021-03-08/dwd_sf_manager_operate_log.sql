CREATE TABLE `dwd_sf_manager_operate_log` (
  `log_id` bigint(32) NOT NULL AUTO_INCREMENT COMMENT '记录编号',
  `manager_id` bigint(20) DEFAULT NULL COMMENT '管理员编号',
  `operate_type` tinyint(1) DEFAULT '1' COMMENT '变更类型(1:新增、2:审核、3:修改)(DICT)',
  `operate_sfcode` varchar(50) DEFAULT NULL COMMENT '操作人丰声号',
  `remark` varchar(200) DEFAULT NULL COMMENT '操作描述',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人编号',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人编号',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `data_flag` tinyint(1) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  PRIMARY KEY (`log_id`),
  KEY `IDX_manager_id` (`manager_id`) USING BTREE,
  KEY `IDX_operate_sfcode` (`operate_sfcode`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=27991 DEFAULT CHARSET=utf8mb4 COMMENT='管理员操作记录表'