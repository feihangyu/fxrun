CREATE TABLE `dwd_shelf_machine_slot_type` (
  `slot_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '货道id主键',
  `manufacturer_slot_code` varchar(30) DEFAULT NULL COMMENT '厂商系统货道编码',
  `machine_id` bigint(20) DEFAULT NULL COMMENT '贩卖机id',
  `shelf_id` int(11) DEFAULT NULL COMMENT '货架id',
  `slot_status` int(11) DEFAULT '1' COMMENT '货道状态（1：正常 2:故障 3:停用;4:缺货;）',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `stock_num` int(11) NOT NULL DEFAULT '0' COMMENT '库存数量',
  `slot_type_id` bigint(20) DEFAULT NULL COMMENT '货道类型id',
  `machine_type_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '机器类型id',
  `slot_capacity_limit` tinyint(3) DEFAULT '0' COMMENT '机器货道容量',
  `slot_col` int(11) DEFAULT NULL COMMENT '货道宽度',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`slot_id`),
  KEY `idx_machine_id` (`machine_id`) USING BTREE,
  KEY `idx_shelf_id` (`shelf_id`) USING BTREE,
  KEY `idx_machine_id_slot_no` (`machine_id`,`manufacturer_slot_code`),
  KEY `idx_shelf_id_slot_no` (`shelf_id`,`manufacturer_slot_code`)
) ENGINE=InnoDB AUTO_INCREMENT=356367 DEFAULT CHARSET=utf8mb4 COMMENT='贩卖机货道信息+货道类型表_dw'