CREATE TABLE `dm_lo_apply_shelf_mid` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `apply_type` int(2) DEFAULT NULL COMMENT '申请类型(1.非智能设备,2.智能设备)',
  `RECORD_ID` bigint(20) DEFAULT NULL COMMENT '申请编号',
  `shelf_id` bigint(20) DEFAULT NULL COMMENT '货架编号',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '创建时间',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  KEY `idx_shelf_id` (`shelf_id`),
  KEY `idx_RECORD_ID` (`RECORD_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=91085 DEFAULT CHARSET=utf8mb4 COMMENT='已创建货架商机明细(中间表)'