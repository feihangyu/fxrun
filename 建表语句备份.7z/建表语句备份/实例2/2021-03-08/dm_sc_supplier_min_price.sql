CREATE TABLE `dm_sc_supplier_min_price` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `region_area` varchar(20) DEFAULT NULL COMMENT '大区',
  `business_area` varchar(20) DEFAULT NULL COMMENT '区域',
  `supplier_name` varchar(50) DEFAULT NULL COMMENT '供应商名称',
  `short_name` varchar(30) DEFAULT NULL COMMENT '供应商缩写',
  `product_id` bigint(20) NOT NULL COMMENT '商品ID',
  `product_code2` varchar(50) DEFAULT NULL COMMENT 'FE码',
  `product_name` varchar(50) DEFAULT NULL COMMENT '商品名称',
  `purchase_price` decimal(10,4) NOT NULL COMMENT '采购单价(含税)',
  `F_BGJ_FBOXEDSTANDARDS` int(10) DEFAULT NULL COMMENT '箱规',
  `first_purchase` date NOT NULL COMMENT '第一次采购日期',
  `pur_times` int(10) NOT NULL COMMENT '采购次数',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_business_product` (`business_area`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8192 DEFAULT CHARSET=utf8mb4 COMMENT='采购地区商品最小采购价'