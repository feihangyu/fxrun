CREATE TABLE `dwd_shelf_product_risk_source_change` (
  `pid` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `risk_source` tinyint(2) DEFAULT '0' COMMENT '风险来源(数据字典：effectiveRiskSource；1，手工录入、2，商品上架、3，前置仓调入、4，店主盘点、5，发货时间、6，货架调入)0代表空值',
  `start_date` date DEFAULT NULL COMMENT '开始日期',
  `end_date` date DEFAULT NULL COMMENT '开始日期',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `idx_shelf_id_product_id` (`shelf_id`,`product_id`,`start_date`,`end_date`),
  KEY `idx_shelf_detail_id` (`product_id`),
  KEY `idx_stat_date` (`start_date`)
) ENGINE=InnoDB AUTO_INCREMENT=29084365 DEFAULT CHARSET=utf8mb4 COMMENT='风险来源日期拉链表'