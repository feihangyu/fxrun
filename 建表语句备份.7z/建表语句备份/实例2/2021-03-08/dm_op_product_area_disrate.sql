CREATE TABLE `dm_op_product_area_disrate` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `product_id` bigint(20) NOT NULL COMMENT '商品编号',
  `business_name` varchar(32) NOT NULL COMMENT '地区名称',
  `product_type` varchar(100) DEFAULT NULL COMMENT '商品类型',
  `out_date` date DEFAULT NULL COMMENT '淘汰日期',
  `stock_quantity` int(11) DEFAULT '0' COMMENT '库存量',
  `stock_val` decimal(18,2) DEFAULT '0.00' COMMENT '库存金额',
  `qty_sal` int(11) DEFAULT '0' COMMENT '近30天销量',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT '近30天gmv',
  `stock_days` int(11) DEFAULT '0' COMMENT '库存周转天数',
  `disrate` decimal(18,2) DEFAULT '1.00' COMMENT '建议折扣',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `product_id` (`product_id`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=2048 DEFAULT CHARSET=utf8mb4 COMMENT='淘汰品建议折扣'