CREATE TABLE `dwd_pub_dictionary` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `DICTIONARY_ID` int(11) DEFAULT NULL COMMENT '字典类型编号',
  `DICTIONARY_CODE` varchar(30) DEFAULT NULL COMMENT '字典类型编码',
  `DICTIONARY_NAME` varchar(50) DEFAULT NULL COMMENT '字典类型名称',
  `ITEM_VALUE` varchar(50) DEFAULT '1' COMMENT '字典明细值',
  `ITEM_NAME` varchar(500) DEFAULT NULL,
  `ITEM_SORT` int(11) DEFAULT '1' COMMENT '字典明细排序',
  `pub_code` varchar(50) DEFAULT NULL COMMENT '下级字典code',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_dwd_last_update_time` (`last_update_time`),
  KEY `idx_dwd_DICTIONARY_ID` (`DICTIONARY_ID`,`ITEM_VALUE`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=4718 DEFAULT CHARSET=utf8mb4 COMMENT='字典类型明细_dwd'