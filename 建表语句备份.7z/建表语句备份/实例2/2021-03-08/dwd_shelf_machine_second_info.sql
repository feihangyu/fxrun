CREATE TABLE `dwd_shelf_machine_second_info` (
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架id',
  `machine_id` bigint(20) DEFAULT NULL COMMENT '设备id',
  `product_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '商品id',
  `stock_num` int(11) NOT NULL DEFAULT '0' COMMENT '库存数量',
  `machine_second_name` varchar(32) DEFAULT NULL COMMENT '贩卖机设备名称',
  `second_type` tinyint(1) NOT NULL DEFAULT '1' COMMENT '副柜类型（1：真实副柜 2：虚拟副柜）',
  PRIMARY KEY (`shelf_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='设备副柜商品明细_dw'