CREATE TABLE `dm_ma_user_monthly` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT,
  `sdate` date NOT NULL COMMENT '月1号',
  `business_name` varchar(20) NOT NULL DEFAULT 'other',
  `user_num` bigint(20) DEFAULT '0' COMMENT '全口径用户数',
  `user_num_multiorder` bigint(20) DEFAULT '0' COMMENT '全口径复购用户数',
  `user_num_shelf` bigint(20) DEFAULT '0' COMMENT '货架用户数',
  `user_num_shelf_multiorder` bigint(20) DEFAULT '0',
  `user_num_shelf6` bigint(20) DEFAULT '0' COMMENT '智能柜用户数',
  `user_num_shelf6_multiorder` bigint(20) DEFAULT '0',
  `user_num_shelf7` bigint(20) DEFAULT '0' COMMENT '自动贩卖机用户数',
  `user_num_shelf7_multiorder` bigint(20) DEFAULT '0',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `sdate_cityname` (`sdate`,`business_name`),
  KEY `idx_area` (`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=21080 DEFAULT CHARSET=utf8mb4 COMMENT='市场月维度用户统计'