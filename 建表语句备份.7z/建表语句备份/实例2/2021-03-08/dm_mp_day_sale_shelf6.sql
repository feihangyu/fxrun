CREATE TABLE `dm_mp_day_sale_shelf6` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` date DEFAULT NULL,
  `GMV` decimal(10,2) DEFAULT NULL,
  `buy_qty` bigint(20) DEFAULT NULL,
  `AMOUNT` decimal(10,2) DEFAULT NULL,
  `user_qty` bigint(20) DEFAULT NULL,
  `order_qty` bigint(20) DEFAULT NULL,
  `DISCOUNT` decimal(10,2) DEFAULT NULL,
  `ACTIVATE_shelf_qty` bigint(20) DEFAULT NULL,
  `REVOKE_shelf_qty` bigint(20) DEFAULT NULL,
  `shelfs_status2` int(11) DEFAULT '0' COMMENT '当天激活状态货架数',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=374 DEFAULT CHARSET=utf8mb4