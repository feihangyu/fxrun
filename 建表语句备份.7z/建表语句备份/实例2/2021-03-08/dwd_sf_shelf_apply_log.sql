CREATE TABLE `dwd_sf_shelf_apply_log` (
  `LOG_ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录编号',
  `RECORD_ID` bigint(20) DEFAULT NULL COMMENT '货架申请编号',
  `FILL_FLAG` varchar(2) DEFAULT NULL COMMENT '操作事项(1 申请  2 地区审核  3 总部审核  4 创建能量站  5 重复申请)',
  `REMARK` varchar(2000) DEFAULT NULL,
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '添加时间',
  `CREATE_USER_ID` bigint(20) DEFAULT NULL COMMENT '添加人编号',
  `SF_CODE` varchar(50) DEFAULT NULL COMMENT '丰声号',
  `CREATE_USER_NAME` varchar(100) DEFAULT NULL COMMENT '添加人名称',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`LOG_ID`),
  KEY `IDX_shelf_apply_log_RECORDID` (`RECORD_ID`) USING BTREE,
  KEY `idx_sf_shelf_apply_log_create_user_id` (`CREATE_USER_ID`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=781576 DEFAULT CHARSET=utf8 COMMENT='货架申请操作记录'