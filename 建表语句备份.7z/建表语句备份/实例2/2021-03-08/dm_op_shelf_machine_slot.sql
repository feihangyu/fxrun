CREATE TABLE `dm_op_shelf_machine_slot` (
  `slot_id` bigint(20) NOT NULL COMMENT '货道id',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`slot_id`),
  KEY `shelf_id` (`shelf_id`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='贩卖机货道信息表'