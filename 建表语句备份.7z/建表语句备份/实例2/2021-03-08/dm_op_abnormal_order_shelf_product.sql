CREATE TABLE `dm_op_abnormal_order_shelf_product` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架编号',
  `product_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '商品编号',
  `orders` smallint(6) DEFAULT '0' COMMENT '订单数',
  `users` smallint(6) DEFAULT '0' COMMENT '用户数',
  `quantity` bigint(20) DEFAULT '0' COMMENT '购买数量',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `val_cost` decimal(18,2) DEFAULT '0.00' COMMENT '成本',
  `oi_discount_amount` decimal(18,2) DEFAULT '0.00' COMMENT '商品优惠金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`shelf_id`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=838 DEFAULT CHARSET=utf8mb4 COMMENT='订单异常监控_货架商品'