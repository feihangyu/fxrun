CREATE TABLE `dm_shelftype_fill_stat` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL DEFAULT '0000-00-00' COMMENT '日期',
  `shelf_type` tinyint(4) DEFAULT '1' COMMENT '货架类型',
  `fill_type` tinyint(4) DEFAULT '0' COMMENT '补货类型',
  `orders` int(11) DEFAULT '0' COMMENT '订单量',
  `actual_apply_num` int(11) DEFAULT '0' COMMENT '补货商品量',
  `actual_apply_val` decimal(18,2) DEFAULT '0.00' COMMENT '补货金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`shelf_type`,`fill_type`)
) ENGINE=InnoDB AUTO_INCREMENT=30950 DEFAULT CHARSET=utf8mb4 COMMENT='补货表每日统计'