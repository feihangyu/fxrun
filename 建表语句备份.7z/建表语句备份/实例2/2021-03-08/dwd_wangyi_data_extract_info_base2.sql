CREATE TABLE `dwd_wangyi_data_extract_info_base2` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `data_base` varchar(32) DEFAULT NULL COMMENT '实例',
  `extract_name` varchar(64) DEFAULT NULL COMMENT '抽取名',
  `update_person` varchar(32) DEFAULT NULL COMMENT '修改人',
  `extract_stime` datetime DEFAULT NULL COMMENT '抽取时间',
  `extract_rtime` decimal(4,1) DEFAULT NULL COMMENT '抽取时长',
  `source_table` varchar(128) DEFAULT NULL COMMENT '源表名',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=1721 DEFAULT CHARSET=utf8mb4 COMMENT='实例2网易有数抽取任务相关信息'