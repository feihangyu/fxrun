CREATE TABLE `sql_log_info` (
  `pid` int(4) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `sdate` date DEFAULT NULL COMMENT '执行日期',
  `task_name` varchar(1024) DEFAULT NULL COMMENT '存储过程名',
  `sql_str` varchar(32) DEFAULT NULL COMMENT 'sql位置',
  `stime` datetime DEFAULT NULL COMMENT '开始时间',
  `etime` datetime DEFAULT NULL COMMENT '结束时间',
  `run_time` decimal(8,1) DEFAULT NULL COMMENT '执行时间',
  `run_time_second` int(11) DEFAULT NULL COMMENT '执行耗时（秒)',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=169384 DEFAULT CHARSET=utf8mb4 COMMENT='存储过程执行日志信息表'