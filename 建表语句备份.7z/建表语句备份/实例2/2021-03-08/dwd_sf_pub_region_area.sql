CREATE TABLE `dwd_sf_pub_region_area` (
  `region_area_id` int(11) NOT NULL COMMENT '大区id',
  `region_area_code` varchar(10) NOT NULL COMMENT '大区编码',
  `name` varchar(48) NOT NULL DEFAULT '' COMMENT '大区名称',
  `data_flag` tinyint(2) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`region_area_id`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_region_area_id` (`region_area_id`),
  KEY `idx_region_area_id_data_flag` (`region_area_id`,`data_flag`),
  KEY `idx_data_flag_area_code` (`data_flag`,`region_area_id`,`region_area_code`,`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区大区'