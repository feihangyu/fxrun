CREATE TABLE `dm_ma_plc_kpi_daily` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `sdate` date NOT NULL COMMENT '日',
  `plc` varchar(10) NOT NULL COMMENT '商品生命周期',
  `gmv` decimal(14,2) NOT NULL DEFAULT '0.00',
  `amont` decimal(14,2) NOT NULL DEFAULT '0.00',
  `sale_num` int(11) NOT NULL DEFAULT '0',
  `stock_quantity` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`sdate`,`plc`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='每日生命周期销售'