CREATE TABLE `dm_ma_shelf_product_seckill_remove` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `activity_name` varchar(50) NOT NULL COMMENT '活动名称',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`),
  KEY `shelf_id` (`shelf_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='国庆秒杀活动排除昨日秒杀货架商品'