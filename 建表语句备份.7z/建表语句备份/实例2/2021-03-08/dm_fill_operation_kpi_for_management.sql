CREATE TABLE `dm_fill_operation_kpi_for_management` (
  `pid` bigint(20) unsigned NOT NULL AUTO_INCREMENT COMMENT '序号',
  `first_grade_index` varchar(100) DEFAULT NULL COMMENT '一级指标',
  `second_grade_index` varchar(100) DEFAULT NULL COMMENT '二级指标',
  `date_type` varchar(100) DEFAULT NULL COMMENT '指标日期类别,1.申请时间,2.补货时间',
  `action_date` date DEFAULT NULL COMMENT '指标日期',
  `result_data` decimal(5,3) DEFAULT NULL COMMENT '指标数值',
  PRIMARY KEY (`pid`),
  KEY `idx_action_date` (`action_date`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COMMENT='物流KPI统计表'