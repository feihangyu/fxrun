CREATE TABLE `dwd_sf_shelf_product_log` (
  `LOG_ID` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '日志编号',
  `DETAIL_ID` bigint(20) DEFAULT '0' COMMENT '货架商品包详情编号',
  `PRODUCT_ID` bigint(20) DEFAULT '0' COMMENT '商品编号',
  `SHELF_ID` bigint(20) DEFAULT '0' COMMENT '货架编号',
  `SHELF_FILL_FLAG` varchar(2) DEFAULT NULL COMMENT '事件',
  `CREATE_USER_ID` bigint(20) DEFAULT '0' COMMENT '添加人编号',
  `CREATE_USER_NAME` varchar(100) DEFAULT NULL COMMENT '添加人名称',
  `CREATE_TIME` datetime DEFAULT NULL COMMENT '添加时间',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`LOG_ID`),
  KEY `idx_sf_shelf_product_log_shelf_id_product_id` (`SHELF_ID`,`PRODUCT_ID`),
  KEY `idx_sf_shelf_product_log_product_id` (`PRODUCT_ID`),
  KEY `idx_sf_shelf_product_log_create_user_id` (`CREATE_USER_ID`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=152867 DEFAULT CHARSET=utf8 COMMENT='货架商品修改记录'