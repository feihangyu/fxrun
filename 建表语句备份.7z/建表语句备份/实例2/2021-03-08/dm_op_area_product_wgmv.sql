CREATE TABLE `dm_op_area_product_wgmv` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date DEFAULT NULL COMMENT '周末',
  `product_id` bigint(20) DEFAULT '0' COMMENT '商品编号',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `qty_sal` int(11) DEFAULT '0' COMMENT '销售数量',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `discount` decimal(18,2) DEFAULT '0.00' COMMENT '折扣金额',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`product_id`,`business_name`),
  KEY `idx_product_id_business_name` (`product_id`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1827988 DEFAULT CHARSET=utf8mb4 COMMENT='商品地区每周gmv'