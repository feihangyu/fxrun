CREATE TABLE `dm_op_np_satisfaction_result_month` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区',
  `zone_name` varchar(32) DEFAULT NULL COMMENT '片区',
  `at_aim_shelfs` bigint(20) DEFAULT NULL COMMENT '达标货架数',
  `at_aim_normal_shelfs` bigint(20) DEFAULT NULL COMMENT '达标正在运营货架数',
  `shelfs` bigint(20) DEFAULT NULL COMMENT '总货架数',
  `shelfs_normal` bigint(20) DEFAULT NULL COMMENT '正在运营总货架数',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '自增主键',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=168227 DEFAULT CHARSET=utf8mb4 COMMENT='货架上新满足率汇总-月(剔除货架类型4,5,7,9)'