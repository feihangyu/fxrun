CREATE TABLE `dwd_pub_shelf_first_order_info` (
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架编号',
  `shelf_type` int(2) DEFAULT '1' COMMENT '货架类型',
  `shelf_type_desc` varchar(500) DEFAULT NULL COMMENT '货架类型描述',
  `first_order_date` timestamp NULL DEFAULT '0000-00-00 00:00:00' COMMENT '首次下单日期',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架首次下单信息表(包含未对接系统数据，不管是否支付成功)供明才使用'