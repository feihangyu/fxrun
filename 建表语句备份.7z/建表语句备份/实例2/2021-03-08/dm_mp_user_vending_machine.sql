CREATE TABLE `dm_mp_user_vending_machine` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `curweek` bigint(20) DEFAULT NULL,
  `lastweek` bigint(20) DEFAULT NULL,
  `lastweek_all` int(11) DEFAULT '0' COMMENT '上周整周累计',
  `curmonth` bigint(20) DEFAULT NULL,
  `lastmonth` bigint(20) DEFAULT NULL,
  `curyear` bigint(20) DEFAULT NULL,
  `lastyear` bigint(20) DEFAULT NULL,
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=371 DEFAULT CHARSET=utf8mb4