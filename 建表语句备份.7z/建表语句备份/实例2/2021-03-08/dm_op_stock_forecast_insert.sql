CREATE TABLE `dm_op_stock_forecast_insert` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `month_id` char(7) NOT NULL COMMENT '月份',
  `BUSINESS_AREA` varchar(20) NOT NULL COMMENT '地区',
  `stock_amount` int(10) DEFAULT NULL COMMENT '库存金额',
  `GMV` int(10) DEFAULT NULL COMMENT 'GMV',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `month_id` (`month_id`,`BUSINESS_AREA`)
) ENGINE=InnoDB AUTO_INCREMENT=129 DEFAULT CHARSET=utf8mb4 COMMENT='库存红线_库存预算及GMV预算(英南维护)'