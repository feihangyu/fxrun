CREATE TABLE `dwd_lo_node_monitor_data_after_cleanout` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键',
  `update_time` date DEFAULT NULL COMMENT '更新日期',
  `action_type` int(5) DEFAULT NULL COMMENT '项目类别（1.盘点,2.补货）',
  `action_id` bigint(20) DEFAULT NULL COMMENT '项目ID(盘点=check_id,补货=order_id)',
  `action_time` datetime DEFAULT NULL COMMENT '项目发生时间（1.盘点时间,2.补货时间）',
  `duration` decimal(18,0) DEFAULT NULL COMMENT '停留时长',
  `lng` decimal(18,5) DEFAULT NULL COMMENT '经度',
  `lat` decimal(18,5) DEFAULT NULL COMMENT '维度',
  `data_flag` tinyint(2) NOT NULL DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_monitor_data_after_cleanout_action_id` (`action_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6390220 DEFAULT CHARSET=utf8mb4 COMMENT='清洗后的埋点明细结果表'