CREATE TABLE `dm_op_shelf_his` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `stat_date` char(7) NOT NULL COMMENT '日期',
  `REGION_AREA` varchar(10) NOT NULL COMMENT '大区',
  `BUSINESS_AREA` varchar(10) NOT NULL COMMENT '地区',
  `shelf_type` tinyint(2) DEFAULT NULL COMMENT '货架类型',
  `shelf_qty` int(8) DEFAULT NULL COMMENT '货架数量',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_stat_date_area_shelf_type` (`stat_date`,`shelf_type`,`BUSINESS_AREA`)
) ENGINE=InnoDB AUTO_INCREMENT=4682 DEFAULT CHARSET=utf8mb4 COMMENT='每月已激活货架数截存'