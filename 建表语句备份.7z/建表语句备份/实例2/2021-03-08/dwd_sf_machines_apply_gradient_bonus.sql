CREATE TABLE `dwd_sf_machines_apply_gradient_bonus` (
  `record_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '记录主键',
  `apply_record_id` bigint(20) DEFAULT NULL COMMENT '贩卖机申请编号',
  `sales_min` decimal(10,2) DEFAULT NULL COMMENT '梯度最小营业额值',
  `sales_max` decimal(10,2) DEFAULT NULL COMMENT '梯度最大营业额值',
  `bonus_percentage` int(4) DEFAULT NULL COMMENT '分成百分',
  `data_flag` tinyint(2) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加记录人员（申请人）',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`record_id`),
  KEY `IDX_APPLY_REDOCR_ID` (`apply_record_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1268 DEFAULT CHARSET=utf8mb4 COMMENT='贩卖机申请合同梯度分成明细'