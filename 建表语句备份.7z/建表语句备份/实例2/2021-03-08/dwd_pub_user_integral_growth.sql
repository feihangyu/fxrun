CREATE TABLE `dwd_pub_user_integral_growth` (
  `user_integral_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) DEFAULT NULL COMMENT '用户ID',
  `integral` bigint(20) DEFAULT '0' COMMENT '用户可用积分',
  `preexpiry_integral` bigint(20) DEFAULT '0' COMMENT '预过期积分',
  `member_level` tinyint(2) unsigned DEFAULT '1' COMMENT '会员等级',
  `level_promotion_time` datetime DEFAULT NULL COMMENT '等级提升时间',
  `growth_value` int(11) DEFAULT '0' COMMENT '成长值',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`user_integral_id`),
  UNIQUE KEY `uk_user_integral_growth_uid` (`user_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=9357731 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='用户积分成长值表'