CREATE TABLE `dm_en_user_product_label` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `user_id` bigint(20) unsigned NOT NULL COMMENT '用户ID',
  `product_spec_id` bigint(20) unsigned NOT NULL COMMENT '商品规格ID',
  `second_category_id` bigint(20) DEFAULT NULL COMMENT '二级分类ID',
  `new_lab` tinyint(2) NOT NULL DEFAULT '2' COMMENT '是否新品(1:是、2:否)',
  `buy_lab` tinyint(2) NOT NULL DEFAULT '2' COMMENT '是否购买(1:是、2:否)',
  `score` decimal(18,2) DEFAULT NULL COMMENT '得分',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品ID',
  PRIMARY KEY (`pid`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_product_id` (`product_spec_id`),
  KEY `idx_category_id` (`second_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2293726 DEFAULT CHARSET=utf8mb4 COMMENT='用户商品标签表_开发使用'