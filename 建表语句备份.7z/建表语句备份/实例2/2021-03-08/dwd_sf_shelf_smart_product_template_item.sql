CREATE TABLE `dwd_sf_shelf_smart_product_template_item` (
  `item_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '明细id',
  `template_id` bigint(20) DEFAULT NULL COMMENT '模板id',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `sale_price` decimal(18,2) DEFAULT '0.00' COMMENT '实际销售价格',
  `uncheck_price` decimal(18,2) DEFAULT NULL COMMENT '待审核售价',
  `check_status` int(11) DEFAULT NULL COMMENT '审核状态 1：待审核 2 拒绝 3 已失效 4 通过 ',
  `standard_quantity` int(11) DEFAULT '0' COMMENT '标配数量',
  `initial_product_recommendation` tinyint(2) DEFAULT '0' COMMENT '初始商品推荐 1-是、2-否',
  `data_flag` tinyint(1) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人编号',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人编号',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `idx__template_product` (`template_id`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=99919 DEFAULT CHARSET=utf8mb4 COMMENT='商品模板明细表'