CREATE TABLE `dm_op_product_area_shelftype_mgmv` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `month_id` char(7) DEFAULT NULL COMMENT '月份',
  `product_id` bigint(20) DEFAULT '0' COMMENT '商品编号',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `shelf_type` int(2) NOT NULL DEFAULT '1' COMMENT '货架类型',
  `qty_sal` int(11) DEFAULT '0' COMMENT '销售数量',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `discount` decimal(18,2) DEFAULT '0.00' COMMENT '折扣金额',
  `coupon` decimal(18,2) DEFAULT '0.00' COMMENT '优惠券金额',
  `third_discount` decimal(18,2) DEFAULT '0.00' COMMENT '第三方优惠金额',
  `discount_amount` decimal(18,2) DEFAULT '0.00' COMMENT '纯折扣金额',
  `foodcard_gmv` decimal(18,2) DEFAULT '0.00' COMMENT '餐卡gmv',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `month_id` (`month_id`,`product_id`,`business_name`,`shelf_type`),
  KEY `idx_product_id_business_name` (`product_id`,`business_name`)
) ENGINE=InnoDB AUTO_INCREMENT=6989823 DEFAULT CHARSET=utf8mb4 COMMENT='商品地区货架类型每月gmv'