CREATE TABLE `dm_sc_current_dynamic_purchase_price` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT 'pid',
  `sdate` date NOT NULL COMMENT '统计日期',
  `business_area` varchar(32) DEFAULT NULL COMMENT '区域',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品id',
  `product_code2` varchar(32) DEFAULT NULL COMMENT 'FE码',
  `product_name` varchar(100) DEFAULT NULL COMMENT '商品名称',
  `purchase_price` decimal(18,4) DEFAULT NULL COMMENT '采购价(含税)',
  `fprice` decimal(10,4) DEFAULT NULL COMMENT '采购价（不含税）',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  UNIQUE KEY `uqk_business_product` (`business_area`,`product_id`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=16384 DEFAULT CHARSET=utf8mb4 COMMENT='当日动态加权价'