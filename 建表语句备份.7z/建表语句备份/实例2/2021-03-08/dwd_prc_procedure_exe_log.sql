CREATE TABLE `dwd_prc_procedure_exe_log` (
  `pid` int(11) NOT NULL AUTO_INCREMENT COMMENT '主键id',
  `sdate` date DEFAULT NULL COMMENT '日期',
  `procedure_name` varchar(64) DEFAULT NULL COMMENT '存储过程名',
  `maintainer` varchar(32) DEFAULT NULL COMMENT '维护人员',
  `action_flag` varchar(16) DEFAULT NULL COMMENT '操作标识',
  `loginfo` varchar(1024) DEFAULT NULL COMMENT '操作日志',
  `action_datetime` datetime DEFAULT NULL COMMENT '操作具体时间',
  `mesg_is_send` varchar(16) DEFAULT NULL COMMENT '通知邮件是否发送',
  PRIMARY KEY (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=2372 DEFAULT CHARSET=utf8mb4 COMMENT='sh_process库存储过程操作日志信息'