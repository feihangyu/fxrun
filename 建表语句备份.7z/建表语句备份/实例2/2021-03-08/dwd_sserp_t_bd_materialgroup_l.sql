CREATE TABLE `dwd_sserp_t_bd_materialgroup_l` (
  `FPKID` int(11) NOT NULL,
  `FID` int(11) DEFAULT NULL,
  `FLOCALEID` int(11) DEFAULT NULL,
  `FNAME` varchar(200) DEFAULT NULL,
  `FDESCRIPTION` varchar(510) DEFAULT NULL,
  PRIMARY KEY (`FPKID`),
  KEY `idx_fid` (`FID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4