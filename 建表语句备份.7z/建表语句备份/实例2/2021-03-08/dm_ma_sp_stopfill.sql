CREATE TABLE `dm_ma_sp_stopfill` (
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `DETAIL_ID` bigint(20) NOT NULL COMMENT '货架商品详情编号',
  `SHELF_ID` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架编号',
  `PRODUCT_ID` bigint(20) NOT NULL DEFAULT '0' COMMENT '商品编号',
  `stop_date` date NOT NULL COMMENT '停补日期',
  `stop_flag` smallint(6) NOT NULL DEFAULT '0' COMMENT '停止补货原因(0:其他,1:无库存淘汰品,2:有库存0销滞销品,3:SKU过多末位淘汰品 )',
  `stop_status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '停补状态(0:停补中,1:停补失效)',
  `stop_date_list` varchar(200) DEFAULT NULL COMMENT '停补日期列表',
  PRIMARY KEY (`DETAIL_ID`),
  UNIQUE KEY `idx_sp` (`SHELF_ID`,`PRODUCT_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='确定停补货架商品'