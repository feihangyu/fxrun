CREATE TABLE `dm_op_shelf_offstock` (
  `id` int(8) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `month_id` varchar(8) NOT NULL COMMENT '月份',
  `SHELF_ID` bigint(10) NOT NULL COMMENT '货架ID',
  `shelf_name` varchar(50) DEFAULT NULL COMMENT '货架名称',
  `SHELF_CODE` varchar(10) DEFAULT NULL COMMENT '货架编码',
  `shelf_type` tinyint(2) DEFAULT NULL COMMENT '货架类型',
  `offstock_ct` bigint(20) DEFAULT NULL COMMENT '货架缺货记录数',
  `ct` bigint(20) DEFAULT NULL COMMENT '货架总记录数（爆畅平）',
  `offstock_slots` bigint(20) DEFAULT NULL COMMENT '缺货货道数',
  `slots` bigint(20) DEFAULT NULL COMMENT '总货道数',
  `offstock_rate` decimal(8,2) DEFAULT NULL COMMENT '总缺货率',
  `offstock_val` decimal(10,2) DEFAULT NULL COMMENT '缺货损失',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`id`),
  KEY `idx_last_update_time` (`last_update_time`),
  KEY `idx_month_id_shelf_id` (`month_id`,`SHELF_ID`)
) ENGINE=InnoDB AUTO_INCREMENT=17855422 DEFAULT CHARSET=utf8mb4 COMMENT='货架维度缺货率统计（所有货架类型当月汇总）'