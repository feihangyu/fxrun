CREATE TABLE `dm_op_product_area_sal_month_large` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `product_id` int(11) NOT NULL COMMENT '商品',
  `business_name` varchar(32) NOT NULL DEFAULT '' COMMENT '地区名称',
  `qty_large` int(11) DEFAULT NULL COMMENT '大单销量',
  `gmv_large` decimal(18,2) DEFAULT '0.00' COMMENT '大单gmv',
  `add_user` varchar(32) DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`month_id`,`product_id`,`business_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区商品月销售_大单'