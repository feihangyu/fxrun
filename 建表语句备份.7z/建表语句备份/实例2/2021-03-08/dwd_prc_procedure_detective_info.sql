CREATE TABLE `dwd_prc_procedure_detective_info` (
  `procedure_name` varchar(64) NOT NULL COMMENT '存储过程',
  `create_time` datetime NOT NULL DEFAULT '0000-00-00 00:00:00' COMMENT '创建时间',
  `update_time` datetime DEFAULT NULL COMMENT ' 最近一次修改时间',
  `delete_time` datetime DEFAULT NULL COMMENT '删除时间',
  `delete_flag` tinyint(4) NOT NULL DEFAULT '0' COMMENT '删除标识（0:未删除;1:已删除）',
  PRIMARY KEY (`procedure_name`,`create_time`,`delete_flag`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='sh_process库存储过程监控信息'