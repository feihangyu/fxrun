CREATE TABLE `dwd_sf_order_yht_item` (
  `item_id` bigint(32) NOT NULL AUTO_INCREMENT,
  `order_id` bigint(32) DEFAULT NULL COMMENT '订单外键',
  `goods_id` bigint(32) DEFAULT NULL COMMENT '商品id',
  `goods_name` varchar(50) DEFAULT NULL COMMENT '商品名称',
  `locationId` varchar(10) DEFAULT NULL COMMENT '货道号',
  `price` decimal(8,2) DEFAULT NULL COMMENT '商品价格',
  `product_type_id` varchar(30) DEFAULT NULL COMMENT '商品类型 ID',
  `product_type_name` varchar(50) DEFAULT NULL COMMENT '商品类型名称',
  `product_count` int(3) DEFAULT NULL COMMENT '商品数量',
  `deliver_status` tinyint(2) DEFAULT NULL COMMENT '''出货状态 1: 出货中 , 0 出货成功 ;2 ：出货失败 货道售空 ; 出货失败 4 出货失败 出货通知发送失败 5 出货失败，支付超时'',',
  `add_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `add_user_id` bigint(20) DEFAULT '0' COMMENT '添加人员id',
  `last_update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `last_update_user_id` bigint(20) DEFAULT '0' COMMENT '最后修改人员id',
  PRIMARY KEY (`item_id`),
  KEY `idx_order_id` (`order_id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3506014 DEFAULT CHARSET=utf8mb4 COMMENT='映翰通订单明细'