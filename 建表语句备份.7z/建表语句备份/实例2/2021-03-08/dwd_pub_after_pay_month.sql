CREATE TABLE `dwd_pub_after_pay_month` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `month_id` char(7) NOT NULL DEFAULT '0000-00' COMMENT '统计月份',
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架ID',
  `payment_fund` decimal(18,2) DEFAULT '0.00' COMMENT '对公补付款金额',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`pid`),
  KEY `IDX_shelf_month_id` (`month_id`,`shelf_id`),
  KEY `IDX_shelf_id` (`shelf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3855 DEFAULT CHARSET=utf8mb4 COMMENT='对公补款金额（汤云峰没用手工跑数）'