CREATE TABLE `dm_sc_warehouse_sku_shelf_cnt` (
  `pid` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '主键ID',
  `sdate` datetime DEFAULT NULL COMMENT '统计日期',
  `region_area` varchar(50) DEFAULT NULL COMMENT '大区',
  `business_area` varchar(50) DEFAULT NULL COMMENT '区域',
  `qzc_cnt` int(4) DEFAULT NULL COMMENT '前置仓数量',
  `shelf_cnt` int(4) DEFAULT NULL COMMENT '货架数量',
  `qzc_shelf_cnt` int(4) DEFAULT NULL COMMENT '前置仓覆盖货架数量',
  `coverage_rate` decimal(18,4) DEFAULT NULL COMMENT '前置仓覆盖货架覆盖率',
  `op_sku_cnt` int(3) DEFAULT NULL COMMENT '正常运营商品数量',
  `op_new_sku_cnt` int(3) DEFAULT NULL COMMENT '新品运营数量',
  `pub_time` datetime DEFAULT NULL COMMENT '发布时间',
  `add_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  `last_update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  PRIMARY KEY (`pid`),
  KEY `idx_sdate` (`sdate`),
  KEY `idx_last_update_time` (`last_update_time`)
) ENGINE=InnoDB AUTO_INCREMENT=39320 DEFAULT CHARSET=utf8mb4 COMMENT='区域货架数SKU数'