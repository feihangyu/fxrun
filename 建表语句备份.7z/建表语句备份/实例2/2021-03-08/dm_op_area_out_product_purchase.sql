CREATE TABLE `dm_op_area_out_product_purchase` (
  `sdate` datetime NOT NULL COMMENT '统计日期',
  `business_area` varchar(32) NOT NULL COMMENT '地区',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `product_type` varchar(32) DEFAULT NULL COMMENT '商品类型',
  `sale_level` varchar(32) DEFAULT NULL COMMENT '商品等级',
  `out_date` datetime DEFAULT NULL COMMENT '淘汰日期',
  `stock` bigint(20) DEFAULT '0' COMMENT '大仓库存',
  `pre_stock` bigint(20) DEFAULT '0' COMMENT '前置仓库存',
  `actual_instock_qty` bigint(20) DEFAULT '0' COMMENT '淘汰后采购入库数量',
  `onload_qty` bigint(20) DEFAULT '0' COMMENT '淘汰后采购在途数量',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`sdate`,`business_area`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='地区淘汰品采购监控'