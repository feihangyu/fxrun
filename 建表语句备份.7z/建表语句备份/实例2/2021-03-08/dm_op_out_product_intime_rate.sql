CREATE TABLE `dm_op_out_product_intime_rate` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `business_area` varchar(32) NOT NULL COMMENT '地区',
  `product_id` bigint(20) NOT NULL COMMENT '商品id',
  `kb_rate` decimal(18,6) DEFAULT '0.000000' COMMENT '可补货占比',
  `stock_days` bigint(20) DEFAULT '0' COMMENT '近8周仓库有货天数',
  `is_hard_sell` int(2) DEFAULT NULL COMMENT '是否连续8周难卖',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT '近8周gmv',
  `rank` int(10) DEFAULT NULL COMMENT '近8周gmv排名',
  `vs_version` varchar(50) DEFAULT NULL COMMENT '对比版本号',
  `product_type_last` varchar(32) DEFAULT NULL COMMENT '上月商品类型',
  `product_type_now` varchar(32) DEFAULT NULL COMMENT '本月商品类型',
  `is_last` int(2) DEFAULT NULL COMMENT '是否排名后1/10',
  `should_out` int(2) DEFAULT NULL COMMENT '是否应该淘汰',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`month_id`,`business_area`,`product_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='淘汰及时率(不含自贩机)'