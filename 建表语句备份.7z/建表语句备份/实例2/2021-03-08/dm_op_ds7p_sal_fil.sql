CREATE TABLE `dm_op_ds7p_sal_fil` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `sdate` date NOT NULL COMMENT '日期',
  `shelf_id` int(11) NOT NULL DEFAULT '0' COMMENT '货架',
  `product_id` int(11) NOT NULL DEFAULT '0' COMMENT '商品',
  `quantity_act` int(11) DEFAULT '0' COMMENT '销量',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `actual_sign_num_in` int(11) DEFAULT '0' COMMENT '签收数量',
  `actual_sign_num_out` int(11) DEFAULT '0' COMMENT '调出数量',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `sdate` (`sdate`,`shelf_id`,`product_id`),
  KEY `shelf_id` (`shelf_id`),
  KEY `product_id` (`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10084071 DEFAULT CHARSET=utf8mb4 COMMENT='自贩机每日进销明细'