CREATE TABLE `dwd_op_np_satisfaction_item_month` (
  `month_id` char(7) NOT NULL COMMENT '月份',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区',
  `zone_name` varchar(32) DEFAULT NULL COMMENT '片区',
  `shelf_id` bigint(20) NOT NULL COMMENT '货架id',
  `shelf_status` varchar(32) DEFAULT NULL COMMENT '货架状态',
  `revoke_status` varchar(32) DEFAULT NULL COMMENT '撤架状态',
  `grade` varchar(32) DEFAULT NULL COMMENT '上月货架等级',
  `new_sku` bigint(20) DEFAULT NULL COMMENT '近30天上新sku数',
  `in_aim` int(2) DEFAULT NULL COMMENT '是否达标(1:是,0:否)',
  `load_time` datetime DEFAULT NULL COMMENT '数据加载时间',
  PRIMARY KEY (`month_id`,`shelf_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='货架上新满足率明细-月(剔除货架类型4,5,7,9)'