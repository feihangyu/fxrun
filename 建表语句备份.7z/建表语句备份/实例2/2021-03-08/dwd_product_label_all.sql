CREATE TABLE `dwd_product_label_all` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `label_id` bigint(20) NOT NULL COMMENT '标签编号',
  `label_code` varchar(50) DEFAULT NULL COMMENT '标签编码',
  `label_name` varchar(50) DEFAULT NULL COMMENT '标签名称',
  `product_id` bigint(20) DEFAULT NULL COMMENT '产品编号',
  `parent_id` bigint(20) DEFAULT NULL COMMENT '上级标签编号',
  `parent_label_name` varchar(50) DEFAULT NULL COMMENT '上级标签名称',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`row_id`),
  KEY `idx_product__product_id` (`product_id`),
  KEY `idx_product_label_product_id` (`label_id`,`product_id`),
  KEY `idx_product_label_load_time` (`load_time`)
) ENGINE=InnoDB AUTO_INCREMENT=10654 DEFAULT CHARSET=utf8mb4 COMMENT='商品标签'