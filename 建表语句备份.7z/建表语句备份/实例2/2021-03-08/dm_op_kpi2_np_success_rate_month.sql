CREATE TABLE `dm_op_kpi2_np_success_rate_month` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `month_id` char(7) DEFAULT '' COMMENT '月份',
  `version_id` varchar(100) DEFAULT '' COMMENT '版本号',
  `business_name` varchar(32) DEFAULT NULL COMMENT '地区名称',
  `product_id` bigint(20) DEFAULT NULL COMMENT '商品编号',
  `replace_product_id` bigint(20) DEFAULT NULL COMMENT '替换商品编号',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `gmv_aim` decimal(18,2) DEFAULT '0.00' COMMENT '目标gmv',
  `add_user` varchar(32) NOT NULL DEFAULT '0' COMMENT '添加人员',
  `add_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `month_id` (`month_id`,`business_name`,`product_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29570 DEFAULT CHARSET=utf8mb4 COMMENT='新品成功率'