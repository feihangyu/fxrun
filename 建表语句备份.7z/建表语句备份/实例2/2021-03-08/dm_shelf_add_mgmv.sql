CREATE TABLE `dm_shelf_add_mgmv` (
  `row_id` bigint(20) NOT NULL AUTO_INCREMENT COMMENT '行号',
  `month_id` char(7) NOT NULL DEFAULT '' COMMENT '月份',
  `shelf_id` bigint(20) NOT NULL DEFAULT '0' COMMENT '货架编号',
  `gmv` decimal(18,2) DEFAULT '0.00' COMMENT 'gmv',
  `load_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '添加时间',
  PRIMARY KEY (`row_id`),
  UNIQUE KEY `month_id` (`month_id`,`shelf_id`),
  KEY `idx_shelf_id` (`shelf_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2038 DEFAULT CHARSET=utf8mb4 COMMENT='货架每月gmv(包含补货和自贩机,供英南替换家荣表使用)'