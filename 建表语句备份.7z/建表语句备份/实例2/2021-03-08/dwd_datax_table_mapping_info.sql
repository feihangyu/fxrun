CREATE TABLE `dwd_datax_table_mapping_info` (
  `datax_project_name` varchar(128) NOT NULL COMMENT '同步任务名',
  `table_name_one` varchar(128) NOT NULL COMMENT '同步源表表名',
  `table_name_two` varchar(128) NOT NULL COMMENT '同步目标表表名',
  `erp_frequency` varchar(32) DEFAULT NULL COMMENT '同步频率',
  `delete_flag` tinyint(4) DEFAULT '1' COMMENT '有效标识（1：有效，2：无效）',
  `remark` varchar(128) DEFAULT NULL COMMENT '备注',
  `load_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '数据加载时间',
  PRIMARY KEY (`datax_project_name`,`table_name_one`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='datax同步任务两个实例表映射关系信息'