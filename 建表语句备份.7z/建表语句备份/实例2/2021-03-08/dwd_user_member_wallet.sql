CREATE TABLE `dwd_user_member_wallet` (
  `WALLET_ID` bigint(20) NOT NULL COMMENT '钱包ID',
  `MEMBER_ID` bigint(20) NOT NULL COMMENT '会员ID',
  `BALANCE` decimal(18,2) DEFAULT '0.00' COMMENT '余额',
  `CREATE_DATE` datetime DEFAULT NULL COMMENT '创建时间',
  `LAST_UPDATE_TIME` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '最后修改时间',
  `DATA_FLAG` tinyint(4) DEFAULT '1' COMMENT '数据状态(1:正常、2:删除)',
  `pay_password` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '支付密码',
  `error_times` tinyint(1) DEFAULT '0' COMMENT '输错次数',
  `last_error_time` datetime DEFAULT NULL COMMENT '最近一次输错时间',
  `status` tinyint(1) DEFAULT '1' COMMENT '钱包状态(1 正常 2 冻结)',
  `sign` varchar(128) COLLATE utf8mb4_bin DEFAULT NULL COMMENT '签名',
  PRIMARY KEY (`WALLET_ID`),
  UNIQUE KEY `user_member_wallet_idx1` (`MEMBER_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin COMMENT='会员钱包'