import requests
import pandas as pd
import xlrd

def locatebyLatLng(lat, lng, pois=0):
    items = {'location': str(lat) + ',' + str(lng)}
	ak = ''
    res = requests.get('http://api.map.baidu.com/reverse_geocoding/v3/?ak='+ ak +'&output=json&coordtype=wgs84ll&', params=items)
    result = res.json()
    print(result)
    print('--------------------------------------------')
    result_1 = result['result']['formatted_address'] + ',' + result['result']['sematic_description']
    return result_1

# 获取Sheet数据
def get_shelf(sheet_i):
    sheet1 = wb.sheet_by_index(sheet_i-1)#通过索引获取表格
    dic_shelf = {}
    for i in range(0,sheet1.ncols):
        col = sheet1.col_values(i)
        key = col[0]
        dic_shelf[key] = col[1:len(col)]
    return dic_shelf

file = 'd:/user/01386340/desktop/结果表/门店经纬度(百度坐标系)3.xlsx'

wb = xlrd.open_workbook(filename=file)#打开文件
sheet1_name = wb.sheet_names()
print(sheet1_name)

df = pd.DataFrame.from_dict(get_shelf(1))
df['area_id'] = df['area_id'].apply(int)
print(df)
df['add'] = df.apply(lambda x: locatebyLatLng(float(x['lat']),float(x['lng'])), axis=1)
print(df)
df.to_excel(f'd:/user/01386340/desktop/结果表/门店经纬度地址3.xlsx',index=False)
print('已下载')