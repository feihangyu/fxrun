from urllib import request
import xlrd

file = 'd:/user/01386340/desktop/数据/中粮.xlsx'

wb = xlrd.open_workbook(filename=file)#打开文件
sheet1_name = wb.sheet_names()

# 获取Sheet数据
def get_shelf(sheet_i):
    sheet1 = wb.sheet_by_index(sheet_i-1)#通过索引获取表格
    dic_shelf = {}
    for i in range(0,sheet1.ncols):
        col = sheet1.col_values(i)
        key = col[0]
        dic_shelf[key] = col[1:len(col)]
    return dic_shelf

dic_data = get_shelf(1)

# 获取url列表
dict = {}
list_1 = dic_data['盘点ID']
list_2 = dic_data['货架ID']
# list_3 = dic_data['店主名称']
list_4 = dic_data['盘点数量']
list_5 = dic_data['盘点照片']
print(list_5)
for i in range(0,len(list_1)):
    name = str(list_2[i]) + '_' + str(list_4[i])
    urls_data = bytes(list_5[i], encoding='utf-8')
    urls = urls_data.decode().split(",")
    for index, url in enumerate(urls):
        dict[name + '_' + str(index)] = url
print(dict)

# 爬取图片
i = 0
for name, url in dict.items():
    try:
        request.urlretrieve(url, f'G:/坚果盘点照片/{name}.jpg')
        i += 1
        print(i)
    except:
        pass
    continue