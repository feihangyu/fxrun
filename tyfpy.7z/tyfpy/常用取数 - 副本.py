import pymysql
import pandas as pd
import numpy as np
import datetime
import time
import re
from numpy import *
from openpyxl import load_workbook

# 更新用户工号
def updata_user():
    user_dic = {}
    file = open('d:/user/01386340/desktop/python/user.txt')
    for line in file:
        user_dic[line.split('\t')[0]] = line.split('\t')[1].split('\n')[0]
    file.close()
    return user_dic

# 大仓出库金额
def sql_1():
    print('\n请输入统计补货类型：用（,）隔开 1:人工申请、2:系统触发、3:初始商品包订单、4:撤架转移订单、5:撤架负数订单、6:调货负数订单、7:调货调入订单、8:要货订单、9:前置仓调能量站订单、10:前置仓调前置仓订单、11:货架调前置仓调出单、12:货架调前置仓调入单、13:电商销售订单、14:换架订单')
    fill_type = input()
    print( '供应商类型(1: 非仓库、2: 仓库、9: 前置仓)')
    SUPPLIER_TYPE = input()
    print('订单状态(1:已申请、2:已发货、3:已签收、4:已上架、5:退货中、7:待调整、8:已退货、9:已取消)')
    ORDER_STATUS = input()
    print('请输入统计开始时间：（例如：201907）')
    start_day = input()
    print('请输入统计结束时间：（例如：201908）')
    end_day = input()
    sql = """SELECT				
  DATE_FORMAT(b.APPLY_TIME, '%%Y%%m') AS '月份',				
  e.business_area AS '地区',				
  COUNT(DISTINCT a.order_id) AS '订单数',				
  SUM(a.ACTUAL_SEND_NUM) AS '实际发货量',				
  SUM(a.ACTUAL_SEND_NUM * c.sale_price) AS '实际发货金额(销售价)',				
  SUM(				
    a.ACTUAL_SEND_NUM * f.PURCHASE_PRICE				
  ) AS '实际发货金额（采购价）',				
  SUM(a.ACTUAL_SIGN_NUM) AS '实际签收量',				
  SUM(a.ACTUAL_SIGN_NUM * c.sale_price) AS '实际签收金额(销售价)',				
  SUM(				
    a.ACTUAL_SIGN_NUM * f.PURCHASE_PRICE				
  ) AS '实际签收金额（采购价）'				
FROM				
  fe.sf_product_fill_order_item a				
  LEFT JOIN fe.sf_product_fill_order b				
    ON a.order_id = b.order_id				
  LEFT JOIN fe.sf_shelf_product_detail c				
    ON a.shelf_id = c.shelf_id				
    AND a.product_id = c.product_id				
  LEFT JOIN fe.sf_shelf d				
    ON a.shelf_id = d.shelf_id				
  LEFT JOIN fe.sf_supplier_product_detail f				
    ON a.supplier_id = f.supplier_id				
    AND a.product_id = f.product_id				
  LEFT JOIN fe.zs_city_business e				
    ON SUBSTRING_INDEX(				
      SUBSTRING_INDEX(d.AREA_ADDRESS, ',', 2),				
      ',',				
-1				
    ) = e.city_name				
WHERE a.data_flag = 1				
  AND b.fill_type IN (%s)	
  AND b.SUPPLIER_TYPE IN (%s)				
  AND b.ORDER_STATUS IN (%s)				
  AND DATE_FORMAT(b.APPLY_TIME, '%%Y%%m') BETWEEN %s				
  AND %s							
GROUP BY DATE_FORMAT(APPLY_TIME, '%%Y%%m'),				
  e.business_area;""" % (fill_type,SUPPLIER_TYPE,ORDER_STATUS,start_day,end_day)
    return sql

# 大仓发货补货明细
def sql_2():
    print( '统计口径(1: 申请时间、2: 上架时间)')
    a = ["`APPLY_TIME`","`FILL_TIME`"]
    b = input()
    b = int(b)-1
    sday_type = a[(b)]
    print( '请输入统计补货类型：用（,）隔开 1:人工申请、2:系统触发、3:初始商品包订单、4:撤架转移订单、5:撤架负数订单、6:调货负数订单、7:调货调入订单、8:要货订单、9:前置仓调能量站订单、10:前置仓调前置仓订单、11:货架调前置仓调出单、12:货架调前置仓调入单、13:电商销售订单、14:换架订单')
    fill_type = input()
    print('供应商类型(1: 非仓库、2: 仓库、9: 前置仓)')
    SUPPLIER_TYPE = input()
    print('订单状态(1:已申请、2:已发货、3:已签收、4:已上架、5:退货中、7:待调整、8:已退货、9:已取消)')
    ORDER_STATUS = input()
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
t0.*,
IFNULL(t3.grade,"-") AS '货架等级',
CASE
WHEN t2.`second_user_type` = 1 THEN '全职店主'
ELSE '兼职店主' END AS '店主类型'
FROM (SELECT
  b.shelf_id AS '货架ID',
  b.shelf_code AS '货架编码',
    CASE
    WHEN b.SHELF_TYPE = 1
    THEN '四层标准货架'
    WHEN b.SHELF_TYPE = 2
    THEN '冰箱'
    WHEN b.SHELF_TYPE = 3
    THEN '五层防鼠货架'
    WHEN b.SHELF_TYPE = 4
    THEN '虚拟货架'
    WHEN b.SHELF_TYPE = 5
    THEN '冰柜'
    WHEN b.SHELF_TYPE = 6
    THEN '智能货柜'
    WHEN b.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN b.SHELF_TYPE = 7
    THEN '自动贩卖机'
    WHEN b.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN b.SHELF_TYPE = 9
    THEN '前置仓'
    END AS '货架类型',
  a.order_id AS '补货订单ID',
  a.APPLY_TIME AS '申请时间',
  a.FILL_TIME AS '上架时间',
CASE
WHEN a.`ORDER_STATUS` = 1 THEN '已申请'
WHEN a.`ORDER_STATUS` = 2 THEN '已发货'
WHEN a.`ORDER_STATUS` = 3 THEN '已签收'
WHEN a.`ORDER_STATUS` = 4 THEN '已上架'
WHEN a.`ORDER_STATUS` = 5 THEN '退货中'
WHEN a.`ORDER_STATUS` = 7 THEN '待调整'
WHEN a.`ORDER_STATUS` = 8 THEN '已退货'
WHEN a.`ORDER_STATUS` = 9 THEN '已取消'
END AS '订单状态',
  a.FILL_TYPE AS '补货类型',
  a.WAY_BILL_NO AS '物流单号',
  d.`business_name` AS '地区',
  SUBSTRING_INDEX(
    SUBSTRING_INDEX(b.AREA_ADDRESS, ',', 2),
    ',',
    - 1
  ) AS '城市',
  c.BRANCH_NAME AS '分部',
  c.BRANCH_CODE AS '分部ID',
  c.REAL_NAME AS '维护人名称',
  b.manager_id AS '管理员ID',
  c.sf_code AS '管理员工号',
    CASE
WHEN a.SUPPLIER_TYPE = 1 THEN '非仓库'
WHEN a.SUPPLIER_TYPE = 2 THEN '仓库'
WHEN a.SUPPLIER_TYPE = 9 THEN '前置仓'
END AS '供应商',
  a.`PRODUCT_NUM` AS '商品数量',
  a.`TOTAL_PRICE` AS '商品金额'
FROM
  fe.sf_product_fill_order a,
  fe.sf_shelf b,
  fe.pub_shelf_manager c,
  feods.`fjr_city_business` d
WHERE a.`SHELF_ID`= b.`SHELF_ID`
  AND b.`MANAGER_ID`= c.`MANAGER_ID`
  AND b.`CITY` = d.`CITY`
  AND a.%s>= DATE(%s) AND a.%s< DATE(%s)
  AND a.ORDER_STATUS IN (%s)
  and a.SUPPLIER_TYPE in (%s)
  AND a.FILL_TYPE IN (%s)
  AND a.`DATA_FLAG`=1
  LIMIT 10000000000) t0
LEFT JOIN fe.`pub_shelf_manager` t2
       ON t0.`管理员ID` = t2.`MANAGER_ID`
LEFT JOIN feods.d_op_shelf_grade t3
       ON t0.`货架ID` = t3.shelf_id
      AND t3.month_id = DATE_FORMAT(NOW(),'%%Y-%%m');""" % (sday_type,start_day,sday_type,end_day,ORDER_STATUS,SUPPLIER_TYPE,fill_type)
    return sql

# 大仓到前置站/货架补货金额
def sql_3():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
  a.`SUPPLIER_TYPE` AS '供应商类别',
  e.BUSINESS_AREA AS '地区',
  a.SHELF_ID AS '收货货架ID',
  b.shelf_code AS '收货货架编码',
  b.shelf_name AS '收货货架名称',
  CASE
    WHEN b.SHELF_TYPE = 1
    THEN '四层标准货架'
    WHEN b.SHELF_TYPE = 2
    THEN '冰箱'
    WHEN b.SHELF_TYPE = 3
    THEN '五层防鼠货架'
    WHEN b.SHELF_TYPE = 4
    THEN '虚拟货架'
    WHEN b.shelf_type = 5
    THEN '冰柜'
    WHEN b.shelf_type = 6
    THEN '智能货柜'
    WHEN b.shelf_type = 8
    THEN '校园货架'
    WHEN b.shelf_type = 7
    THEN '自动贩卖机'
    WHEN b.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN b.SHELF_TYPE = 9
    THEN '前置仓'
  END AS '收货货架类型',
  b.manager_id AS '店主ID',
  c.REAL_NAME AS '店主姓名',
  c.SF_CODE AS '店主工号',
  a.FILL_TYPE AS '补货类型',
  a.`FILL_USER_ID` AS '上架人ID',
  a.`FILL_USER_NAME` AS '上架人姓名',
  d.`SF_CODE` AS '上架人工号',
  a.order_id AS '订单编号',
  a.TOTAL_PRICE AS '商品金额',
  SUBSTRING_INDEX(
    SUBSTRING_INDEX(b.AREA_ADDRESS, ',', 2),
    ',',
    - 1
  ) AS '城市',
  STR_TO_DATE(
    DATE_FORMAT(a.APPLY_TIME, '%%Y%%m%%d'),
    '%%Y%%m%%d'
  ) AS '申请时间',
  STR_TO_DATE(
    DATE_FORMAT(a.FILL_TIME, '%%Y%%m%%d'),
    '%%Y%%m%%d'
  ) AS '上架时间'
FROM
  fe.sf_product_fill_order a,
  fe.sf_shelf b,
  fe.pub_shelf_manager c,
  fe.`pub_shelf_manager` d,
  fe.zs_city_business e				
WHERE a.shelf_id = b.shelf_id
  AND b.`MANAGER_ID`= c.manager_id
  AND a.`FILL_USER_ID`= d.`MANAGER_ID` 
  AND a.`FILL_TIME`>= DATE(%s)
  AND a.`FILL_TIME`< DATE(%s)
  AND SUBSTRING_INDEX(SUBSTRING_INDEX(b.AREA_ADDRESS, ',', 2),',',-1) = e.CITY_NAME
  LIMIT 100000000;""" % (start_day,end_day)
    return sql

# 大仓发未上架订单明细
def sql_4():
    sql = """SELECT
t0.*,
IFNULL(t3.grade,"-") AS '货架等级',
CASE
WHEN t2.`second_user_type` = 1 THEN '全职店主'
ELSE '兼职店主' END AS '店主类型'
FROM (SELECT
  b.shelf_id AS '货架ID',
  b.shelf_code AS '货架编码',
    CASE
    WHEN b.SHELF_TYPE = 1
    THEN '四层标准货架'
    WHEN b.SHELF_TYPE = 2
    THEN '冰箱'
    WHEN b.SHELF_TYPE = 3
    THEN '五层防鼠货架'
    WHEN b.SHELF_TYPE = 4
    THEN '虚拟货架'
    WHEN b.SHELF_TYPE = 5
    THEN '冰柜'
    WHEN b.SHELF_TYPE = 6
    THEN '智能货柜'
    WHEN b.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN b.SHELF_TYPE = 7
    THEN '自动贩卖机'
    WHEN b.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN b.SHELF_TYPE = 9
    THEN '前置仓'
    END AS '货架类型',
  a.order_id AS '补货订单ID',
  a.APPLY_TIME AS '申请时间',
  a.FILL_TIME AS '上架时间',
CASE
WHEN a.`ORDER_STATUS` = 1 THEN '已申请'
WHEN a.`ORDER_STATUS` = 2 THEN '已发货'
WHEN a.`ORDER_STATUS` = 3 THEN '已签收'
WHEN a.`ORDER_STATUS` = 4 THEN '已上架'
WHEN a.`ORDER_STATUS` = 5 THEN '退货中'
WHEN a.`ORDER_STATUS` = 7 THEN '待调整'
WHEN a.`ORDER_STATUS` = 8 THEN '已退货'
WHEN a.`ORDER_STATUS` = 9 THEN '已取消'
END AS '订单状态',
  a.FILL_TYPE AS '补货类型',
  a.WAY_BILL_NO AS '物流单号',
  d.`business_name` AS '地区',
  SUBSTRING_INDEX(
    SUBSTRING_INDEX(b.AREA_ADDRESS, ',', 2),
    ',',
    - 1
  ) AS '城市',
  c.BRANCH_NAME AS '分部',
  c.BRANCH_CODE AS '分部ID',
  c.REAL_NAME AS '维护人名称',
  b.manager_id AS '管理员ID',
  c.sf_code AS '管理员工号',
    CASE
WHEN a.SUPPLIER_TYPE = 1 THEN '非仓库'
WHEN a.SUPPLIER_TYPE = 2 THEN '仓库'
WHEN a.SUPPLIER_TYPE = 9 THEN '前置仓'
END AS '供应商',
  a.`PRODUCT_NUM` AS '商品数量',
  a.`TOTAL_PRICE` AS '商品金额'
FROM
  fe.sf_product_fill_order a,
  fe.sf_shelf b,
  fe.pub_shelf_manager c,
  feods.`fjr_city_business` d
WHERE a.`SHELF_ID`= b.`SHELF_ID`
  AND b.`MANAGER_ID`= c.`MANAGER_ID`
  AND b.`CITY` = d.`CITY`
  AND a.`APPLY_TIME`>= DATE('20190301') AND a.`APPLY_TIME`< CURRENT_DATE()
  AND a.ORDER_STATUS IN (1, 2)
  AND a.FILL_TYPE IN (1, 2, 8, 9)
  AND a.`DATA_FLAG`=1
  LIMIT 10000000000) t0
LEFT JOIN fe.`pub_shelf_manager` t2
       ON t0.`管理员ID` = t2.`MANAGER_ID`
LEFT JOIN feods.d_op_shelf_grade t3
       ON t0.`货架ID` = t3.shelf_id
      AND t3.month_id = DATE_FORMAT(NOW(),'%Y-%m');"""
    return sql

# 最小补货单位
def sql_5():
    sql = """SELECT 
PRODUCT_CODE2 AS '商品编码',
PRODUCT_ID AS '商品ID',
PRODUCT_NAME AS '商品名',
FILL_MODEL AS '最小补货规格'
FROM fe.sf_product 
WHERE DATA_FLAG=1
AND SALE_STATUS=1;"""
    return sql

# 撤架数据明细（包含撤架及时率以及流向）
def sql_6():
    print('\n请输入统计货架类型：用（,）隔开（1:四层标准货架、2:冰箱、3:五层防鼠货架、4:虚拟货架、5:冰柜、6:智能货架、7:自动贩卖机、8:校园货架、9:前置仓）')
    shelf_type = input()
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
      c.`BUSINESS_AREA` AS '地区',
      a.`SHELF_ID` AS '货架ID',
      b.`SHELF_CODE` AS '货架编码',
      f.`material_name` AS '物资信息',
      b.`MANAGER_NAME` AS '管理员',
      b.`SHELF_TYPE` AS '货架类型',
      b.`ADDRESS` AS '地址',
      b.`SHELF_STATUS` AS '货架状态',
      a.`AUDIT_STATUS` AS '审核状态',
      t1.`task_no` AS '任务编码',
      t1.`task_status` AS '任务状态:1待地区分配;2:待管理人员分配;3:待执行;4:待回仓;5:已完成;6:已关闭',
      b.`revoke_trace` AS '货架流向',
      a.`ADD_TIME` AS '申请时间',
      a.`AUDIT_TIME` AS '审核时间',
      b.`REVOKE_TIME` AS '完成撤架时间',
      DATEDIFF(b.`REVOKE_TIME`,a.audit_time) AS '间隔时间',
      IF(b.`REVOKE_TIME` IS NOT NULL AND a.audit_time IS NOT NULL,IF(DATEDIFF(b.`REVOKE_TIME`,a.audit_time)<=15,'是','否'),NULL) AS '是否及时'
    FROM
     fe.`sf_shelf_revoke` a
    LEFT JOIN
      fe.`sf_shelf` b
    ON a.`SHELF_ID`=b.`SHELF_ID`
    LEFT JOIN
      fe.`zs_city_business` c
    ON SUBSTRING_INDEX(SUBSTRING_INDEX(b.`AREA_ADDRESS`,',',2),',',-1)=c.`CITY_NAME`
    LEFT JOIN fe.`sf_material_shelf_relation` d
    ON a.`SHELF_ID`= d.`shelf_id`
    LEFT JOIN fe.`sf_material_detail` e
    ON d.`material_detail_id`= e.`material_detail_id`
    LEFT JOIN fe.`sf_material` f
    ON e.`material_id`=f.`material_id`
    LEFT JOIN fe.sf_shelf_logistics_task_revoke t0
    ON a.REVOKE_ID = t0.revoke_id
    LEFT JOIN fe.sf_shelf_logistics_task t1
    ON t0.logistics_task_id = t1.logistics_task_id
    WHERE a.`DATA_FLAG`=1 AND b.`DATA_FLAG`=1
    AND b.`SHELF_TYPE` IN (%s)
    AND a.`ADD_TIME` IS NOT NULL
    AND a.`ADD_TIME` >= DATE(%s)
    AND a.`ADD_TIME` < DATE(%s)
    LIMIT 100000000;""" % (shelf_type,start_day,end_day)
    return sql

# 前置站盘点明细
def sql_7():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
  a.shelf_id AS '货架ID',
  t3.shelf_code AS '货架编码',
  t3.shelf_name AS '前置仓名称',
  t4.business_name AS '区域',
  t4.city_name AS '城市',
  t5.sf_code AS '管理员工号',
  t5.real_name AS '管理员名称',
  a.CHECK_ID AS '盘点ID',
  CASE WHEN b.check_type = 1 THEN '普通盘点'
       WHEN b.check_type = 2 THEN '过期盘点'
       WHEN b.check_type = 3 THEN '撤架盘点'
       WHEN b.check_type = 4 THEN '巡检盘点'
       WHEN b.check_type = 5 THEN '前置仓效期盘点'
  END AS '盘点类型',
  CASE WHEN a.AUDIT_STATUS = 1 THEN '待审核'
       WHEN a.AUDIT_STATUS = 2 THEN '已审核'
       WHEN a.AUDIT_STATUS = 3 THEN '-'
  END AS '审核状态',
  DATE_FORMAT(b.OPERATE_TIME, '%%Y%%m%%d') AS '盘点时间',
  SUM(STOCK_NUM * t7.purchase_price) AS '库存金额',
  SUM(CHECK_NUM * t7.purchase_price) AS '盘点金额',
  SUM(CASE WHEN b.check_type = 5 THEN total_error_num * t7.purchase_price ELSE ERROR_NUM * t7.purchase_price END) AS '差异金额',
  SUM(CASE WHEN a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN AUDIT_ERROR_NUM * t7.purchase_price 
           WHEN a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN AUDIT_ERROR_NUM * t7.purchase_price + t8.other_audit_error_num * t7.purchase_price END) AS '审核通过后差异金额',
  SUM(CASE WHEN ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN total_error_num * t7.purchase_price END) AS '货物破损金额',
  SUM(CASE WHEN ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN AUDIT_ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 1 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN AUDIT_ERROR_NUM * t7.purchase_price + t8.other_audit_error_num * t7.purchase_price END) AS '货物破损审核后异常金额',
  SUM(CASE WHEN ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN total_error_num * t7.purchase_price END) AS '商品过期金额',
  SUM(CASE WHEN ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN AUDIT_ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 2 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN AUDIT_ERROR_NUM * t7.purchase_price + t8.other_audit_error_num * t7.purchase_price END) AS '商品过期审核后异常金额',
  SUM(CASE WHEN ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN total_error_num * t7.purchase_price END) AS '盘点盗损金额',
  SUM(CASE WHEN ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN AUDIT_ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 3 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN AUDIT_ERROR_NUM * t7.purchase_price + t8.other_audit_error_num * t7.purchase_price END) AS '盘点盗损审核后异常金额',
  SUM(CASE WHEN ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN total_error_num * t7.purchase_price END) AS '商品质量金额',
  SUM(CASE WHEN ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN AUDIT_ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 4 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN AUDIT_ERROR_NUM * t7.purchase_price + t8.other_audit_error_num * t7.purchase_price END) AS '商品质量审核后异常金额',
  SUM(CASE WHEN ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN total_error_num * t7.purchase_price END) AS '其他差异金额',
  SUM(CASE WHEN ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type != 5 THEN AUDIT_ERROR_NUM * t7.purchase_price 
           WHEN ERROR_REASON = 5 AND a.AUDIT_STATUS = 2 AND b.check_type = 5 THEN AUDIT_ERROR_NUM * t7.purchase_price + t8.other_audit_error_num * t7.purchase_price END) AS '其他差异审核后异常金额'
FROM
  fe.sf_shelf_check_detail a
  LEFT JOIN fe.sf_shelf_check b
    ON a.check_id = b.check_id
  LEFT JOIN fe.sf_shelf t3
    ON b.shelf_id = t3.shelf_id
  LEFT JOIN feods.`fjr_city_business` t4
    ON t3.`CITY` = t4.`CITY`
  LEFT JOIN fe.pub_shelf_manager t5
    ON t3.manager_id = t5.manager_id
  LEFT JOIN fe.`sf_product` t6
    ON a.PRODUCT_ID = t6.PRODUCT_ID 
  LEFT JOIN (SELECT * FROM feods.`wt_monthly_manual_purchase_price` WHERE stat_month >= DATE(%s) GROUP BY business_area,product_code2) t7
    ON t4.business_name = t7.business_area
   AND t6.PRODUCT_CODE2 = t7.product_code2
  LEFT JOIN fe.sf_shelf_check_detail_extend t8
    ON a.DETAIL_ID = t8.detail_id
WHERE b.shelf_id IN
  (SELECT DISTINCT
    warehouse_id AS shelf_id
  FROM
    fe.sf_prewarehouse_dept_detail)
  AND b.operate_time >= DATE(%s)
  AND b.operate_time < DATE(%s)
GROUP BY a.shelf_id,
         a.CHECK_ID,
         DATE(b.OPERATE_TIME)
ORDER BY a.shelf_id,DATE(b.OPERATE_TIME);""" % (start_day,start_day,end_day)
    return sql

# 前置站关联货架明细
def sql_8():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
  t2.*,
  t1.shelf_id AS '货架ID',
  t3.fill_time AS '初始运营时间',
    CASE
    WHEN t4.SHELF_STATUS = 1
    THEN '待激活'
    WHEN t4.SHELF_STATUS = 2
    THEN '已激活'
    WHEN t4.SHELF_STATUS = 3
    THEN '已撤架'
    WHEN t4.SHELF_STATUS = 4
    THEN '已关闭'
    WHEN t4.SHELF_STATUS = 5
    THEN '已注销'
    WHEN t4.SHELF_STATUS = 9
    THEN '维护中'
    WHEN t4.SHELF_STATUS = 10
    THEN '已失效'
    WHEN t4.SHELF_STATUS = 11
    THEN '撤仓中(前置仓)'
  END AS '货架状态',
    CASE
    WHEN t4.SHELF_TYPE = 1
    THEN '四层标准货架'
    WHEN t4.SHELF_TYPE = 2
    THEN '冰箱'
    WHEN t4.SHELF_TYPE = 3
    THEN '五层防鼠货架'
    WHEN t4.SHELF_TYPE = 4
    THEN '虚拟货架'
    WHEN t4.SHELF_TYPE = 5
    THEN '冰柜'
    WHEN t4.SHELF_TYPE = 6
    THEN '智能货柜'
    WHEN t4.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN t4.SHELF_TYPE = 7
    THEN '自动贩卖机'
    WHEN t4.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN t4.SHELF_TYPE = 9
    THEN '前置仓'
  END AS '货架类型',
  t4.SHELF_CODE AS '货架编码',
  t4.SHELF_NAME AS '货架名称',
  t5.SF_CODE AS '店主工号',
  t5.REAL_NAME AS '店主姓名',
  CASE 
  WHEN t5.`second_user_type` = 1 THEN '全职店主'
  ELSE '兼职店主' END AS '店主类型',
  t6.SUPPLIER_NAME AS '供应商',
  t7.total_stock AS '总库存',
  t8.gmv AS '货架统计时间段GMV',
  t8.payment_money AS '货架统计时间段补付款'
FROM
  (SELECT
    d.BUSINESS_AREA AS '地区',
    d.city_name AS '城市',
    a.warehouse_id AS '前置站ID',
    c.shelf_name AS '前置站名称',
    -- CONCAT(c.area_address, ',', c.address) AS '前置站地址',
    c.shelf_code AS '前置站编码',
    CASE
    WHEN c.SHELF_STATUS = 1
    THEN '待激活'
    WHEN c.SHELF_STATUS = 2
    THEN '已激活'
    WHEN c.SHELF_STATUS = 3
    THEN '已撤架'
    WHEN c.SHELF_STATUS = 4
    THEN '已关闭'
    WHEN c.SHELF_STATUS = 5
    THEN '已注销'
    WHEN c.SHELF_STATUS = 9
    THEN '维护中'
    WHEN c.SHELF_STATUS = 10
    THEN '已失效'
    WHEN c.SHELF_STATUS = 11
    THEN '撤仓中(前置仓)'
  END AS '前置站状态',
    f.SF_CODE AS '前置站站长工号',
    f.mobile_phone AS '前置站站长电话',
    f.REAL_NAME AS '前置站站长姓名',
  CASE WHEN f.`second_user_type` = 1 THEN '全职店主'
    ELSE '兼职店主' END AS '站长类型',
    dep.DEPT_NAME AS '前置站分部',
    GROUP_CONCAT(b.DEPT_CODE) AS '绑定分部代码',
    CONCAT(f.branch_name,f.branch_code) AS '绑定分部名称'
  FROM
    fe.sf_prewarehouse_dept_detail a
    LEFT JOIN fe.sf_department b
      ON a.dept_id = b.DEPT_ID
    LEFT JOIN fe.sf_shelf c
      ON a.warehouse_id = c.shelf_id
    LEFT JOIN fe.zs_city_business d
      ON SUBSTRING_INDEX(
        SUBSTRING_INDEX(c.AREA_ADDRESS, ',', 2),
        ',',
        - 1
      ) = d.CITY_NAME
    LEFT JOIN fe.sf_department dep
      ON c.prewarehouse_dept_id = dep.DEPT_ID
    LEFT JOIN (SELECT manager_id,
    SF_CODE,
    CONCAT(
  SUBSTRING(mobile_phone, 1, 3),
  SUBSTRING(mobile_phone, 8, 1),
  IF(
    SUBSTRING(mobile_phone, 5, 1) = '0',
    '9',
    IF(
      SUBSTRING(mobile_phone, 5, 1) = '1',
      '5',
      IF(
        SUBSTRING(mobile_phone, 5, 1) = '2',
        '4',
        IF(
          SUBSTRING(mobile_phone, 5, 1) = '3',
          '0',
          IF(
            SUBSTRING(mobile_phone, 5, 1) = '4',
            '3',
            IF(
              SUBSTRING(mobile_phone, 5, 1) = '5',
              '8',
              IF(
                SUBSTRING(mobile_phone, 5, 1) = '6',
                '1',
                IF(
                  SUBSTRING(mobile_phone, 5, 1) = '7',
                  '7',
                  IF(
                    SUBSTRING(mobile_phone, 5, 1) = '8',
                    '2',
                    '6'
                  )
                )
              )
            )
          )
        )
      )
    )
  ),
  SUBSTRING(mobile_phone, 10, 1),
  SUBSTRING(mobile_phone, 7, 1),
  SUBSTRING(mobile_phone, 4, 1),
  IF(
    SUBSTRING(mobile_phone, 9, 1) = '0',
    '9',
    IF(
      SUBSTRING(mobile_phone, 9, 1) = '1',
      '5',
      IF(
        SUBSTRING(mobile_phone, 9, 1) = '2',
        '4',
        IF(
          SUBSTRING(mobile_phone, 9, 1) = '3',
          '0',
          IF(
            SUBSTRING(mobile_phone, 9, 1) = '4',
            '3',
            IF(
              SUBSTRING(mobile_phone, 9, 1) = '5',
              '8',
              IF(
                SUBSTRING(mobile_phone, 9, 1) = '6',
                '1',
                IF(
                  SUBSTRING(mobile_phone, 9, 1) = '7',
                  '7',
                  IF(
                    SUBSTRING(mobile_phone, 9, 1) = '8',
                    '2',
                    '6'
                  )
                )
              )
            )
          )
        )
      )
    )
  ),
  SUBSTRING(mobile_phone, 6, 1),
  SUBSTRING(mobile_phone, 11, 1)
) AS mobile_phone,
  REAL_NAME,
  branch_name,
  branch_code,
 second_user_type FROM fe.pub_shelf_manager) f
      ON c.manager_id = f.manager_id
  WHERE a.data_flag = 1
  GROUP BY d.BUSINESS_AREA,
    d.city_name,
    a.warehouse_id,
    c.shelf_name,
    c.shelf_code) t2
  LEFT JOIN fe.sf_prewarehouse_shelf_detail t1
    ON (
      t1.warehouse_id = t2.`前置站ID`
      AND t1.data_flag = 1
    )
  LEFT JOIN
    (SELECT
      shelf_id,
      MIN(FILL_TIME) AS fill_time
    FROM
      fe.sf_product_fill_order
    WHERE ORDER_STATUS IN (3, 4)
      AND DATA_FLAG = 1
    GROUP BY shelf_id) t3
    ON t1.warehouse_id = t3.shelf_id
  LEFT JOIN fe.sf_shelf t4
    ON t1.shelf_id = t4.shelf_id
  LEFT JOIN fe.pub_shelf_manager t5
    ON t4.manager_id = t5.manager_id
  LEFT JOIN
    (SELECT
      warehouse_id,
      a.supplier_id,
      SUPPLIER_NAME
    FROM
      fe.sf_prewarehouse_supplier_detail a
      LEFT JOIN fe.sf_supplier b
        ON a.SUPPLIER_ID = b.SUPPLIER_ID
    WHERE a.data_flag = 1) t6
    ON t2.`前置站ID` = t6.warehouse_id
  LEFT JOIN
    (SELECT
      s.warehouse_id,
      SUM(
        s.freeze_stock + s.available_stock
      ) AS total_stock
    FROM
      fe.sf_prewarehouse_stock_detail s
    WHERE s.`data_flag` = 1
    GROUP BY s.`warehouse_id`) t7
    ON t2.`前置站ID` = t7.`warehouse_id`
LEFT JOIN
  (SELECT
  shelf_id,
  SUM(gmv) AS 'gmv',
  SUM(payment_money) AS 'payment_money'
  FROM
    feods.`fjr_shelf_dgmv`
  WHERE	sdate >= DATE(%s)
    AND sdate < DATE(%s)
   GROUP BY 1) t8
  ON t1.shelf_id = t8.shelf_id;""" % (start_day,end_day)
    return sql

# 前置站库存及动销
def sql_9():
    sql = """SELECT
  *
FROM
  (SELECT
    t4.business_area AS '区域',
    t4.city_name AS '城市',
    t3.shelf_code AS '前置仓ID',
    t1.warehouse_id AS warehouse_id,
    t3.shelf_name AS '前置仓名称',
    t1.product_id AS '商品ID',
    t1.save_time_days AS '商品保质期',
    t6.product_code2 AS '商品FE码',
    CONCAT('"', t6.product_name, '"') AS '商品名称',
    t8.PURCHASE_PRICE AS '采购价',
    t5.sf_code AS '管理员工号',
    t5.real_name AS '管理员名称',
    t1.freeze_stock AS '冻结库存',
    t1.due_freeze_stock AS '应有冻结库存',
    t1.available_stock AS '可用库存',
    t1.total_stock AS '总库存',
    IFNULL(t9.昨日仓库入库量, 0) AS '昨日仓库入库量',
    IFNULL(t9.昨日非仓库入库量, 0) AS '昨日非仓库入库量',
    IFNULL(t2.昨日出库量, 0) AS '昨日出库量',
    IFNULL(t9.近30天仓库入库量, 0) '近30天仓库入库量',
    IFNULL(
      t9.近30天非仓库入库量,
0
    ) '近30天非仓库入库量',
    IFNULL(t2.近30天出库量, 0) '近30天出库量'
  FROM
    (SELECT
  a.warehouse_id,
  a.product_id,
  p.save_time_days,
  a.freeze_stock AS freeze_stock,
  b.due_freeze_stock,
  a.available_stock AS available_stock,
  a.freeze_stock + a.available_stock AS total_stock
FROM
  fe.sf_prewarehouse_stock_detail a
  LEFT JOIN
    (SELECT
      b.`SUPPLIER_ID`,
      c.`PRODUCT_ID`,
      SUM(c.`ACTUAL_APPLY_NUM`) AS due_freeze_stock
    FROM
      fe.sf_product_fill_order b
      LEFT JOIN fe.`sf_product_fill_order_item` c
        ON b.`ORDER_ID` = c.`ORDER_ID`
    WHERE b.`SUPPLIER_TYPE` = 9
      AND b.`ORDER_STATUS` = 1
      AND b.`FILL_TYPE` IN (1,2,8)
      AND b.`DATA_FLAG` = 1
      AND c.`DATA_FLAG` = 1
    GROUP BY b.`SUPPLIER_ID`,
      c.product_id) b 
    ON a.`warehouse_id` = b.supplier_id
    AND a.`product_id` = b.product_id
  LEFT JOIN fe.`sf_product` p
  ON a.product_id = p.product_id
  WHERE a.data_flag=1) t1
    LEFT JOIN
      (SELECT
        b.SUPPLIER_ID,
        a.PRODUCT_ID,
        IFNULL(SUM(ACTUAL_SEND_NUM), 0) AS '近30天出库量',
        IFNULL(
          SUM(
            CASE
              WHEN DATE_FORMAT(b.FILL_TIME, '%Y%m%d') = DATE_FORMAT(
                DATE_SUB(CURDATE(), INTERVAL 1 DAY),
                '%Y%m%d'
              )
              THEN ACTUAL_SEND_NUM
            END
          ),
0
        ) AS '昨日出库量'
      FROM
        fe.sf_product_fill_order_item a
        LEFT JOIN fe.sf_product_fill_order b
          ON a.order_id = b.order_id
      WHERE b.SUPPLIER_ID IN
        (SELECT DISTINCT
          warehouse_id
        FROM
          fe.sf_prewarehouse_stock_detail)
        AND b.fill_type IN (8, 9, 10, 1, 2)
        AND DATE_FORMAT(b.FILL_TIME, '%Y%m%d') >= DATE_FORMAT(
          DATE_SUB(CURDATE(), INTERVAL 30 DAY),
          '%Y%m%d'
        )
        AND b.order_status IN (2, 3, 4)
      GROUP BY b.SUPPLIER_ID,
        a.PRODUCT_ID) t2
      ON t1.warehouse_id = t2.SUPPLIER_ID
      AND t1.product_id = t2.product_id
    LEFT JOIN
      (SELECT
        b.SHELF_ID,
        a.PRODUCT_ID,
        IFNULL(
          SUM(
            CASE
              WHEN b.SUPPLIER_TYPE != 2
              THEN ACTUAL_SEND_NUM
            END
          ),
0
        ) AS '近30天非仓库入库量',
        IFNULL(
          SUM(
            CASE
              WHEN b.SUPPLIER_TYPE = 2
              THEN ACTUAL_SEND_NUM
            END
          ),
0
        ) AS '近30天仓库入库量',
        IFNULL(
          SUM(
            CASE
              WHEN DATE_FORMAT(b.FILL_TIME, '%Y%m%d') = DATE_FORMAT(
                DATE_SUB(CURDATE(), INTERVAL 1 DAY),
                '%Y%m%d'
              )
              AND b.SUPPLIER_TYPE != 2
              THEN ACTUAL_SEND_NUM
            END
          ),
0
        ) AS '昨日非仓库入库量',
        IFNULL(
          SUM(
            CASE
              WHEN DATE_FORMAT(b.FILL_TIME, '%Y%m%d') = DATE_FORMAT(
                DATE_SUB(CURDATE(), INTERVAL 1 DAY),
                '%Y%m%d'
              )
              AND b.SUPPLIER_TYPE = 2
              THEN ACTUAL_SEND_NUM
            END
          ),
0
        ) AS '昨日仓库入库量'
      FROM
        fe.sf_product_fill_order_item a
        LEFT JOIN fe.sf_product_fill_order b
          ON a.order_id = b.order_id
      WHERE b.SHELF_ID IN
        (SELECT DISTINCT
          warehouse_id
        FROM
          fe.sf_prewarehouse_stock_detail)
        AND b.fill_type IN (4, 12, 1, 2)
        AND DATE_FORMAT(b.FILL_TIME, '%Y%m%d') >= DATE_FORMAT(
          DATE_SUB(CURDATE(), INTERVAL 30 DAY),
          '%Y%m%d'
        )
        AND b.order_status IN (2, 3, 4)
      GROUP BY b.SHELF_ID,
        a.PRODUCT_ID) t9
      ON t1.warehouse_id = t9.SHELF_ID
      AND t1.product_id = t9.product_id
    LEFT JOIN fe.sf_shelf t3
      ON t1.warehouse_id = t3.shelf_id
    LEFT JOIN fe.zs_city_business t4
      ON SUBSTRING_INDEX(
        SUBSTRING_INDEX(t3.AREA_ADDRESS, ',', 2),
        ',',
-1
      ) = t4.city_name
    LEFT JOIN fe.pub_shelf_manager t5
      ON t3.manager_id = t5.manager_id
    LEFT JOIN fe.sf_product t6
      ON t1.product_id = t6.product_id
    LEFT JOIN fe.sf_prewarehouse_supplier_detail t7
      ON t1.warehouse_id = t7.warehouse_id
    LEFT JOIN fe.sf_supplier_product_detail t8
      ON t7.supplier_id = t8.SUPPLIER_ID
      AND t1.product_id = t8.product_id
  WHERE t7.data_flag = 1
    AND t8.data_flag = 1
    AND t6.data_flag = 1
    AND t5.data_flag = 1) rslt
WHERE (
    rslt.总库存 + rslt.昨日仓库入库量 + rslt.昨日非仓库入库量 + rslt.昨日出库量 + rslt.近30天仓库入库量 + rslt.近30天非仓库入库量 + rslt.近30天出库量
  ) > 0 LIMIT 1000000000000;"""
    return sql

# 前置站库存金额及出库金额
def sql_10():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT d1.*,d2.stock_price AS '出库金额'
FROM
(SELECT t1.warehouse_id AS '前置仓ID'
,t3.shelf_name AS '前置仓名称'
,t4.business_area AS '区域'
,t4.city_name AS '城市'
,t5.sf_code AS '管理员工号'
,t5.real_name AS '管理员名称'
,t1.freeze_stock AS '冻结库存'
,t1.available_stock AS '可用库存'
,t1.total_stock AS '总库存'
,t2.total_price AS '总补货金额'
,t2.PRODUCT_NUM AS '总商品数量'
,t2.days AS '有出库天数'
FROM 
(SELECT a.warehouse_id,SUM(a.freeze_stock) AS freeze_stock,SUM(a.available_stock) AS available_stock,SUM(a.freeze_stock+a.available_stock) AS total_stock
FROM sf_prewarehouse_stock_detail a
LEFT JOIN sf_shelf_product_detail b ON a.warehouse_id=b.shelf_id AND a.product_id=b.product_id
GROUP BY a.warehouse_id
) t1
LEFT JOIN 
(SELECT SUPPLIER_ID,SUM(total_price) AS total_price,SUM(PRODUCT_NUM) AS PRODUCT_NUM,COUNT(DISTINCT DATE_FORMAT(FILL_TIME,'%%Y%%m%%d')) AS days
FROM sf_product_fill_order
WHERE SUPPLIER_ID IN (SELECT DISTINCT warehouse_id FROM sf_prewarehouse_stock_detail)
AND fill_type IN (8,9)
AND DATE_FORMAT(FILL_TIME,'%%Y%%m%%d') BETWEEN %s AND %s
AND order_status IN (1,2,3,4)
GROUP BY SUPPLIER_ID
) t2 ON t1.warehouse_id=t2.SUPPLIER_ID
LEFT JOIN sf_shelf t3 ON t1.warehouse_id=t3.shelf_id
LEFT JOIN zs_city_business t4 ON SUBSTRING_INDEX(SUBSTRING_INDEX(t3.AREA_ADDRESS, ',', 2),',',-1)=t4.city_name
LEFT JOIN pub_shelf_manager t5 ON t3.manager_id=t5.manager_id
)d1
LEFT JOIN
(SELECT t1.warehouse_id,SUM(t1.available_price)+SUM(t1.freeze_price) AS stock_price
FROM
(SELECT a.warehouse_id,a.product_id,a.freeze_stock*d.PURCHASE_PRICE AS freeze_price,a.available_stock*d.PURCHASE_PRICE AS available_price
FROM sf_prewarehouse_stock_detail a
LEFT JOIN sf_prewarehouse_product_detail b ON a.warehouse_id=b.warehouse_id AND a.product_id=b.product_id
LEFT JOIN sf_prewarehouse_supplier_detail c ON a.warehouse_id=c.warehouse_id
LEFT JOIN sf_supplier_product_detail d ON c.supplier_id=d.SUPPLIER_ID AND a.product_id=d.PRODUCT_ID
GROUP BY a.warehouse_id,a.product_id
)t1
GROUP BY t1.warehouse_id
)d2 ON d1.前置仓ID=d2.warehouse_id;""" % (start_day,end_day)
    return sql

# 前置站提成(分拣明细)
def sql_11():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
IFNULL(f.SOURCE_SHELF_ID,f1.SHELF_ID) AS '供货货架ID'
,IFNULL(h.SF_CODE,h1.SF_CODE) AS '供货货架编码'
,IFNULL(h.REAL_NAME,h1.REAL_NAME) AS '供货店主姓名'
,IFNULL(g.SHELF_STATUS,g1.SHELF_STATUS) AS '供货货架类型',
  DATE_FORMAT(APPLY_TIME, '%%Y%%m%%d') AS '申请时间',
  DATE_FORMAT(FILL_TIME, '%%Y%%m%%d') AS '上架时间',
  a.SUPPLIER_TYPE AS '供应商类型(1:非仓库、2:仓库、9:前置仓)',
  a.ORDER_ID AS '补货订单编号',
  a.shelf_id AS '补货货架ID',
  b.SHELF_CODE AS '补货货架编码',
  b.SHELF_NAME AS '补货货架姓名',
  c.target_shelf_id AS '调货目标货架ID',
  a.ORDER_STATUS AS '订单状态(1:已申请、2:已发货、3:已签收、4:已上架、5:退货中、7:待调整、8:已退货、9:已取消)',
  d.business_area AS '地区',
  e.BRANCH_CODE AS '分部代码',
  e.BRANCH_NAME AS '分部名称',
  e.SF_CODE AS '店主工号',
  e.REAL_NAME AS '店主姓名',
  a.FILL_TYPE AS '补货类型(1:人工申请、2:系统触发、3:初始商品包订单、4:撤架转移订单、5:撤架负数订单、6:调货负数订单、7:调货调入订单、8:要货订单、9:前置仓调能量站订单、10:前置仓调前置仓订单、11:货架调前置仓调出单、12:货架调前置仓调入单、13:电商销售订单、14:换架订单)',
  a.PRODUCT_TYPE_NUM AS '商品种数',
  a.PRODUCT_NUM AS '商品总数',
  a.TOTAL_PRICE AS '商品金额'
FROM
  fe.sf_product_fill_order a
  LEFT JOIN fe.sf_shelf b
    ON a.shelf_id = b.shelf_id
  LEFT JOIN fe.sf_shelf_goods_transfer c
    ON a.order_id = c.source_order_id
  LEFT JOIN fe.zs_city_business d
    ON SUBSTRING_INDEX(
      SUBSTRING_INDEX(b.AREA_ADDRESS, ',', 2),
      ',',
      - 1
    ) = d.CITY_NAME
  LEFT JOIN fe.pub_shelf_manager e
    ON b.manager_id = e.manager_id
  LEFT JOIN fe.sf_shelf_goods_transfer f ON a.order_id = f.TARGET_ORDER_ID
LEFT JOIN fe.sf_shelf_revoke f1 ON a.order_id = f1.ORDER_ID
LEFT JOIN fe.sf_shelf g ON f.SOURCE_SHELF_ID=g.SHELF_ID
LEFT JOIN fe.pub_shelf_manager h ON g.MANAGER_ID=h.MANAGER_ID
LEFT JOIN fe.sf_shelf g1 ON f1.SHELF_ID=g1.SHELF_ID
LEFT JOIN fe.pub_shelf_manager h1 ON g1.MANAGER_ID=h1.MANAGER_ID
WHERE b.SHELF_NAME LIKE '%%前置%%'
  AND a.fill_type NOT IN (8, 9, 10)
  AND a.order_status =4
  AND DATE_FORMAT(FILL_TIME, '%%Y%%m%%d') BETWEEN %s AND %s
UNION ALL
SELECT
'','','','',
  DATE_FORMAT(APPLY_TIME, '%%Y%%m%%d'),
  DATE_FORMAT(FILL_TIME, '%%Y%%m%%d'),
  a.SUPPLIER_TYPE,
  a.ORDER_ID,
  a.SUPPLIER_ID,
  b.SHELF_CODE,
  b.SHELF_NAME,
  a.SHELF_ID,
  a.ORDER_STATUS,
  d.business_area,
  e.BRANCH_CODE,
  e.BRANCH_NAME,
  e.SF_CODE,
  e.REAL_NAME,
  a.FILL_TYPE,
  a.PRODUCT_TYPE_NUM,
  a.PRODUCT_NUM,
  a.TOTAL_PRICE
FROM
  fe.sf_product_fill_order a
  LEFT JOIN fe.sf_shelf b
    ON a.SUPPLIER_ID = b.shelf_id
  LEFT JOIN fe.zs_city_business d
    ON SUBSTRING_INDEX(
      SUBSTRING_INDEX(b.AREA_ADDRESS, ',', 2),
      ',',
      - 1
    ) = d.CITY_NAME
  LEFT JOIN fe.pub_shelf_manager e
    ON b.manager_id = e.manager_id
WHERE a.fill_type IN (8, 9, 10)
  AND a.order_status =4
  AND DATE_FORMAT(FILL_TIME, '%%Y%%m%%d') BETWEEN %s AND %s
UNION ALL
SELECT '','','','',
  DATE_FORMAT(APPLY_TIME, '%%Y%%m%%d'),
  DATE_FORMAT(FILL_TIME, '%%Y%%m%%d'),
  a.SUPPLIER_TYPE,
  a.ORDER_ID,
  a.SUPPLIER_ID,
  b.SHELF_CODE,
  b.SHELF_NAME,
  a.SHELF_ID,
  a.ORDER_STATUS,
  d.business_area,
  e.BRANCH_CODE,
  e.BRANCH_NAME,
  e.SF_CODE,
  e.REAL_NAME,
  a.FILL_TYPE,
  a.PRODUCT_TYPE_NUM,
  a.PRODUCT_NUM,
  a.TOTAL_PRICE
FROM
  fe.sf_product_fill_order a
  LEFT JOIN fe.sf_shelf b
    ON a.SUPPLIER_ID = b.shelf_id
  LEFT JOIN fe.zs_city_business d
    ON SUBSTRING_INDEX(
      SUBSTRING_INDEX(b.AREA_ADDRESS, ',', 2),
      ',',
      - 1
    ) = d.CITY_NAME
  LEFT JOIN fe.pub_shelf_manager e
    ON b.manager_id = e.manager_id
WHERE a.fill_type IN (1, 2)
  AND a.order_status = 4
  AND a.SUPPLIER_ID IN
  (SELECT DISTINCT
    warehouse_id
  FROM
    fe.sf_prewarehouse_shelf_detail)
  AND DATE_FORMAT(FILL_TIME, '%%Y%%m%%d') BETWEEN %s AND %s;""" % (start_day,end_day,start_day,end_day,start_day,end_day)
    return sql

# 前置站提成(上架明细)
def sql_12():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    print('\n请输入统计订单状态：用（,）隔开(1:待付款;2:已付款;3:已取消;4:已过期;5:支付失败;6:出货失败;7:出货成功;)')
    order_type = input()
    sql = """SELECT 
 d.BUSINESS_AREA AS '地区'
,b.BRANCH_CODE AS '分部编码'
,b.BRANCH_NAME AS '分部名称'
,a.SHELF_ID AS '货架ID'
,a.SHELF_CODE AS '货架编码'
,a.SHELF_NAME AS '货架名称'
,a.SHELF_TYPE AS '货架类型(1:四层标准货架、2:冰箱、3:五层防鼠货架、4:虚拟货架、5:冰柜、6:智能货架、7:自动贩卖机、8:校园货架、9:前置仓)'
,a.MANAGER_ID AS '店主ID'
,b.real_name AS '店主姓名'
,b.sf_code AS '店主工号'
,g.gmv
,CASE WHEN e.shelf_id IS NULL THEN '否' ELSE '是' END AS '是否前置仓覆盖货架'
,f.shelf_code AS '覆盖的前置仓条码'
FROM fe.sf_shelf a
LEFT JOIN fe.pub_shelf_manager b ON a.MANAGER_ID=b.manager_id
LEFT JOIN fe.zs_city_business d ON SUBSTRING_INDEX(SUBSTRING_INDEX(a.AREA_ADDRESS, ',', 2),',',-1)=d.CITY_NAME
LEFT JOIN (SELECT DISTINCT shelf_id,warehouse_id FROM fe.sf_prewarehouse_shelf_detail WHERE DATA_FLAG=1) e ON a.shelf_id=e.shelf_id
LEFT JOIN fe.sf_shelf f ON e.warehouse_id=f.shelf_id
LEFT JOIN 
(SELECT b.shelf_id,SUM(CASE WHEN ORDER_STATUS=2 THEN a.QUANTITY*a.SALE_PRICE ELSE a.quantity_shipped*a.SALE_PRICE END) AS gmv
FROM fe.sf_order_item a
LEFT JOIN fe.sf_order b ON a.order_id=b.order_id
WHERE order_date>=DATE(%s)
AND order_date<DATE(%s)
AND ORDER_STATUS IN (%s)
GROUP BY b.shelf_id
) g ON a.shelf_id=g.shelf_id
WHERE a.MANAGER_ID IN (SELECT DISTINCT b.manager_id 
FROM fe.sf_shelf a
LEFT JOIN fe.pub_shelf_manager b ON a.manager_id=b.manager_id
WHERE a.shelf_id IN (SELECT DISTINCT shelf_id FROM fe.sf_prewarehouse_shelf_detail WHERE DATA_FLAG=1) 
);""" % (start_day,end_day,order_type)
    return sql

# 串点覆盖货架
def sql_13():
    sql = """SELECT 
 CASE 
 WHEN t.carrier_type = 1 THEN '顺丰速运'
 WHEN t.carrier_type = 2 THEN '自提承运商' 
 END AS '承运商',
 CASE 
 WHEN t.service_type = 1 THEN '标准快递'
 WHEN t.service_type = 2 THEN '顺丰特惠'
 WHEN t.service_type = 3 THEN '电商特惠'
 WHEN t.service_type = 4 THEN '电商速配'
 WHEN t.service_type = 5 THEN '电商专配'
 WHEN t.service_type = 6 THEN '物流普运'
 WHEN t.service_type = 7 THEN '自提'
 WHEN t.service_type = 8 THEN '顺丰隔日'
 END AS '服务类型',
 t.month_balance_code AS '月结卡号',
 t.add_time AS '保存日期',
 f.BUSINESS_AREA AS '地区',
 t.SHELF_ID AS '货架ID',
 t.shelfCode AS '货架编码',
 t.preShelfCode AS '前置仓编码',
 t.AREA_ADDRESS AS '投放区域',
 t.REAL_NAME AS '维护人员',
 t.BRANCH_CODE AS '分部代码',
 t.BRANCH_NAME AS '分部名称' 
 FROM 
 (
  (
  SELECT i.config_info_id,i.carrier_type,i.service_type,i.month_balance_code,i.add_time,s.SHELF_ID,s.SHELF_CODE AS shelfCode,NULL AS preShelfCode,s.AREA_ADDRESS,m.REAL_NAME,m.BRANCH_CODE,m.BRANCH_NAME
  FROM fe.sf_carrier_config_info i 
  LEFT JOIN fe.sf_shelf s ON i.shelf_id = s.SHELF_ID
  LEFT JOIN fe.pub_shelf_manager m ON s.MANAGER_ID = m.MANAGER_ID
  WHERE s.SHELF_TYPE != 9 AND i.data_flag = 1
  )
  UNION ALL   
  (
  SELECT i.config_info_id,i.carrier_type,i.service_type,i.month_balance_code,i.add_time,NULL AS SHELF_ID,NULL AS shelfCode,s.SHELF_CODE AS preShelfCode,s.AREA_ADDRESS,m.REAL_NAME,
  t.DEPT_CODE AS BRANCH_CODE,t.DEPT_NAME AS BRANCH_NAME
  FROM fe.sf_carrier_config_info i
  LEFT JOIN fe.sf_shelf s ON i.shelf_id = s.SHELF_ID
  LEFT JOIN fe.pub_shelf_manager m ON s.MANAGER_ID = m.MANAGER_ID
  LEFT JOIN fe.sf_department t ON s.prewarehouse_dept_id = t.DEPT_ID
  WHERE s.SHELF_TYPE = 9 AND i.data_flag = 1
  )
 ) t
 LEFT JOIN fe.zs_city_business f
 ON SUBSTRING_INDEX( 
 SUBSTRING_INDEX(t.AREA_ADDRESS, ',', 2),',',-1) = f.CITY_NAME
 ORDER BY t.add_time DESC;"""
    return sql

# 串点线路
def sql_14():
    sql = """SELECT
f.line_code AS '线路编号',
f.line_code_full_name AS '线路编号全称',
f.line_name AS '线路姓名',
f.bussiness_area AS '地区',
f.line_status AS '线路状态(1:启用;2:禁用)',
s.dept_id AS '分部ID',
d.DEPT_CODE AS '分部编码',
d.DEPT_NAME AS '分部名称'
FROM fe.sf_logistics_supplier_line_config f
LEFT JOIN fe.sf_logistics_supplier_line_config_branch s
  ON f.line_config_id = s.line_config_id
LEFT JOIN fe.sf_department d
  ON s.dept_id = d.DEPT_ID WHERE f.data_flag = 1
AND s.data_flag = 1
ORDER BY f.add_time DESC;"""
    return sql

# 串点任务明细
def sql_15():
    sql = """"""
    return sql

# 货架盘点明细+审核明细（排面)
def sql_16():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    print('\n请输入统计货架类型：用（,）隔开（1:四层标准货架、2:冰箱、3:五层防鼠货架、4:虚拟货架、5:冰柜、6:智能货架、7:自动贩卖机、8:校园货架、9:前置仓）')
    shelf_type = input()
    print('\n请输入统计盘点类型：用（,）隔开(1:普通盘点、2:过期盘点、3:撤架盘点、4:巡检盘点、5:前置仓效期盘点、6:自贩机货道盘点、7:自贩机副柜盘点)')
    check_type = input()
    sql = """SELECT
  g.CITY_NAME AS '城市',
  g.business_name AS '地区',
  a.check_id AS '盘点ID',
  a.SHELF_ID AS '货架ID',
  b.SHELF_CODE AS '货架编码',
  b.shelf_type AS '货架类型(1:四层标准货架、2:冰箱、3:五层防鼠货架、4:虚拟货架、5:冰柜、6:智能货架、7:自动贩卖机、8:校园货架、9:前置仓)',
  a.OPERATE_TIME AS '盘点时间',
  c.REAL_NAME AS '盘点人姓名',
  c.`SF_CODE` AS '盘点人工号',
    CASE
    WHEN c.second_user_type = 1 THEN '全职店主'
    ELSE '兼职店主' END AS '盘点人类型',
  h.REAL_NAME AS '店主姓名',
  h.`SF_CODE` AS '店主工号',  
  h.BRANCH_CODE '点部编码',
  h.BRANCH_NAME '点部名称',
  d.ITEM_NAME AS '账号类型',
  f.`REAL_NAME` AS '审核人姓名',
  a.check_type AS '盘点类型(1:普通盘点、2:过期盘点、3:撤架盘点、4:巡检盘点)',
  e.`add_time` AS '审核时间',
  CASE WHEN e.`audit_status` = 1 THEN '已审核' ELSE '未审核' END AS '审核状态',
  e.`is_fake_check` AS '审核是否虚假盘点',
  e.`fake_check_reason` AS '判断虚假盘点原因',
  e.`is_error_check` AS '是否盘点失误',
  e.`error_check_reason` AS '有盘点失误判断原因',
  e.`has_wrong_faces` AS '是否有排面问题',
  e.`wrong_faces_reason` AS '有牌面问题判断原因',
  e.remark AS '审核备注'
FROM
  fe.sf_shelf_check a
  LEFT JOIN fe.sf_shelf b
    ON a.shelf_id = b.shelf_id
  LEFT JOIN fe.pub_shelf_manager c
    ON a.OPERATOR_ID = c.MANAGER_ID
  LEFT JOIN fe.pub_dictionary_item d
    ON (
      c.USER_TYPE = d.ITEM_VALUE
      AND d.DICTIONARY_ID = 17
    )
  LEFT JOIN fe.`sf_check_audit_record` e
    ON a.`CHECK_ID` = e.`check_id`
  LEFT JOIN fe.`pub_manager` f
    ON e.add_user_id = f.`MANAGER_ID`
  LEFT JOIN feods.`fjr_city_business` g
	ON b.CITY = g.CITY
  LEFT JOIN fe.pub_shelf_manager h
    ON b.MANAGER_ID = h.MANAGER_ID
WHERE a.OPERATE_TIME >= DATE(%s)
  AND a.`OPERATE_TIME` < DATE(%s)
  AND a.check_type IN (%s)
  AND b.shelf_type IN (%s)
LIMIT 10000000000;""" % (start_day,end_day,check_type,shelf_type)
    return sql

# 货架管理员
def sql_17():
    print('\n请输入统计货架类型：用（,）隔开（1:四层标准货架、2:冰箱、3:五层防鼠货架、4:虚拟货架、5:冰柜、6:智能货架、7:自动贩卖机、8:校园货架、9:前置仓）')
    shelf_type = input()
    print('请输入统计货架状态：用（,）隔开（1:待激活;2:已激活;3:已撤架;4:已关闭;5已注销;9维护中;10已失效）')
    SHELF_STATUS = input()
    sql = """SELECT
  fcb.business_name AS '地区',
  sfs.SHELF_ID AS '货架ID',
  sfs.SHELF_CODE AS '货架编码',
  CASE
    WHEN sfs.SHELF_TYPE = 1
    THEN '四层标准货架'
    WHEN sfs.SHELF_TYPE = 2
    THEN '冰箱'
    WHEN sfs.SHELF_TYPE = 3
    THEN '五层标准货架'
    WHEN sfs.SHELF_TYPE = 4
    THEN '虚拟货架'
    WHEN sfs.SHELF_TYPE = 5
    THEN '冰柜'
    WHEN sfs.SHELF_TYPE = 6
    THEN '智能货柜'
    WHEN sfs.SHELF_TYPE = 7
    THEN '自动贩卖机'
    WHEN sfs.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN sfs.SHELF_TYPE = 9
    THEN '前置仓'
  END AS '货架类型',
  CASE
    WHEN sfs.SHELF_STATUS = 1
    THEN '待激活'
    WHEN sfs.SHELF_STATUS = 2
    THEN '已激活'
    WHEN sfs.SHELF_STATUS = 3
    THEN '已撤架'
    WHEN sfs.SHELF_STATUS = 4
    THEN '已关闭'
    WHEN sfs.SHELF_STATUS = 5
    THEN '已注销'
    WHEN sfs.SHELF_STATUS = 9
    THEN '维护中'
    WHEN sfs.SHELF_STATUS = 10
    THEN '已失效'
  END AS '货架状态',
  sfs.ACTIVATE_TIME AS '激活时间',
  sfs.REVOKE_TIME AS '撤架时间',
  CASE
    WHEN sfs.EXPLOIT_TYPE = 1
    THEN '业务开发'
    WHEN sfs.EXPLOIT_TYPE = 2
    THEN '公司申请'
    WHEN sfs.EXPLOIT_TYPE = 3
    THEN '渠道开发'
    WHEN sfs.EXPLOIT_TYPE = 4
    THEN '丰e BD开发'
    WHEN sfs.EXPLOIT_TYPE = 5
    THEN '快递员开发'
    WHEN sfs.EXPLOIT_TYPE = 9
    THEN '其他'
  END AS 'BD类型',
  sfs.AREA_ADDRESS AS '省市区名称',
  pmbd.REAL_NAME AS 'BD姓名',
  pmbd.SF_CODE AS 'BD工号',
  pm.REAL_NAME AS '店主姓名',
  pm.SF_CODE AS '店主工号',
  CASE
    when pm.second_user_type = 1 then '全职店主'
    else '兼职店主' end as '店主类型',
  pm.BRANCH_CODE '点部编码',
  pm.BRANCH_NAME '点部名称',
  sfs.ADD_TIME AS '货架记录添加时间',
  stv.audit_status AS '撤架状态'
FROM
  fe_dwd.`dwd_shelf_base_day_all` sfs
  LEFT JOIN fe.pub_shelf_manager pm
    ON pm.MANAGER_ID = sfs.MANAGER_ID
    AND pm.data_flag=1
  LEFT JOIN fe.`pub_shelf_manager` pmbd
    ON sfs.BD_ID = pmbd.MANAGER_ID
    AND pm.data_flag=1
  LEFT JOIN fe.sf_company sfc
    ON sfc.COMPANY_ID = sfs.COMPANY_ID
    AND sfc.data_flag=1
  LEFT JOIN fe.sf_shelf_apply sfa
    ON sfs.shelf_id = sfa.SHELF_ID
    AND sfa.data_flag=1
 LEFT JOIN feods.fjr_city_business fcb
    on sfs.CITY = fcb.CITY
  LEFT JOIN 
  (SELECT
  t.`SHELF_ID`,
  t.`AUDIT_STATUS`
FROM fe.`sf_shelf_revoke` t 
WHERE t.`DATA_FLAG`=1
AND (t.`SHELF_ID`,t.`ADD_TIME`) IN
(SELECT
 m.`SHELF_ID`,
 MAX(m.`ADD_TIME`) add_time
FROM
fe.`sf_shelf_revoke` m
WHERE m.`DATA_FLAG`=1
GROUP BY m.`SHELF_ID`)) stv
    ON stv.shelf_id = sfs.shelf_id
WHERE sfs.DATA_FLAG = 1
   and sfs.SHELF_TYPE in (%s)
   and sfs.SHELF_STATUS in (%s);""" % (shelf_type,SHELF_STATUS)
    return sql

# 关联货架
def sql_18():
    sql = """SELECT
CASE 
WHEN a.SHELF_HANDLE_STATUS = 9 THEN '已关联'
WHEN a.SHELF_HANDLE_STATUS = 10 THEN '已解绑'
ELSE '关联中' END AS '关联状态',
a.RECORD_ID AS '关联编号',
a.MAIN_SHELF_ID AS '主货架ID',
a.MAIN_SHELF_CODE AS '主货架编码',
a.SECONDARY_SHELF_ID AS '次货架ID',
a.SECONDARY_SHELF_CODE AS '次货架编码',
a.ADD_TIME AS '数据添加时间',
a.UNBIND_TIME AS '解绑时间',
a.ADD_TIME AS '关联时间'
FROM fe.`sf_shelf_relation_record` a
WHERE a.`DATA_FLAG` = 1;"""
    return sql

# 货架变更
def sql_19():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    print('\n请输入统计订单状态：用（,）隔开(1:维护人员变更、2:公司信息变更、3:投放地址变更)')
    order_type = input()
    sql = """SELECT
a.`LOG_ID` AS '变更ID',
a.`SHELF_ID` AS '货架ID',
a.`SF_CODE` AS '原店主工号',
a.MANAGER_NAME AS '原店主名字',
a.`NEW_SF_CODE` AS '新店主工号',
a.`NEW_MANAGER_NAME` AS '新店主名字',
a.`UPDATE_TIME` AS '修改时间',
a.`UPDATE_USER_NAME` AS '修改人名字',
b.`REAL_NAME`,
c.`REAL_NAME`,
a.`REMARK` AS '备注'
FROM fe.sf_shelf_log a
LEFT JOIN fe.`pub_shelf_manager` b
       ON a.`UPDATE_USER_ID` = b.`MANAGER_ID`
LEFT JOIN fe.`pub_manager` c
       ON a.`UPDATE_USER_ID` = c.`MANAGER_ID`
WHERE a.`add_time` >= DATE(%s)
  AND a.`add_time` < DATE(%s)
  AND a.`SHELF_CHANGE_TYPE` IN (%s);""" % (start_day,end_day,order_type)
    return sql

# 货架运营数据
def sql_20():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
  t1.shelf_id AS '货架ID',
  t1.shelf_code AS '货架条码',
  t1.SHELF_STATUS AS '货架状态',
  t1.SHELF_TYPE AS '货架类型',
  t1.real_name AS '管理员名称',
  t1.sf_code AS '管理员工号',
  t1.WHETHER_CLOSE AS '货架是否关闭',
  t1.ACTIVATE_TIME AS '货架激活时间',
  t1.REVOKE_TIME AS '货架撤架时间',
  t2.check_qty AS '盘点次数',
  t3.fill_order_qty AS '补货次数',
  t4.GMV,
  t5.缺货商品数量,
  t5.缺货商品金额,
  t6.在架商品数,
  t6.在架商品金额,
  t6.在架SKU数,
  t1.City '城市',
  t1.BD工号,
  t1.BD_NAME AS 'BD姓名',
  t1.BRANCH_CODE '点部编码',
  t1.BRANCH_NAME '点部名称',
  t7.fill_order_qty_d AS '调货次数',
  t7.fill_order_qty_n AS '调入次数'
FROM
  (SELECT
    SUBSTRING_INDEX(
    SUBSTRING_INDEX(a.AREA_ADDRESS, ',', 2),
    ',',
    - 1
  ) AS 'City',
    a.shelf_id,
    a.shelf_code,
    a.SHELF_STATUS,
    a.SHELF_TYPE,
    b.real_name,
    b.sf_code,
    a.WHETHER_CLOSE,
    a.ACTIVATE_TIME,
    a.REVOKE_TIME,
    a.REVOKE_STATUS,
    cfs.SF_CODE AS 'BD工号',
    a.BD_NAME,
    b.BRANCH_CODE,
    b.BRANCH_NAME
  FROM
    sf_shelf a
    LEFT JOIN pub_shelf_manager b
      ON a.manager_id = b.manager_id
    LEFT JOIN pub_manager cfs
      ON a.BD_NAME = cfs.REAL_NAME
    LEFT JOIN sf_shelf_relation_record c
      ON a.shelf_id = c.MAIN_SHELF_ID
  WHERE a.SHELF_STATUS IN (2, 3, 4, 5, 9)
    AND a.DATA_FLAG = 1) t1
  LEFT JOIN
    (SELECT
      shelf_id,
      COUNT(DISTINCT check_id) AS check_qty
    FROM
      fe.sf_shelf_check t
    WHERE t.`OPERATE_TIME`>= DATE(%s) AND t.`OPERATE_TIME`< DATE(%s)
    GROUP BY shelf_id) t2
    ON t1.shelf_id = t2.shelf_id
  LEFT JOIN
    (SELECT
      shelf_id,
      COUNT(DISTINCT order_id) AS fill_order_qty
    FROM
      sf_product_fill_order a
    WHERE a.`FILL_TIME`>= DATE(%s) AND a.`FILL_TIME`< DATE(%s)
      AND order_status IN (3, 4)
      AND fill_type IN (1, 2, 7, 8, 9)
      AND ABS(a.PRODUCT_NUM) > 10
    GROUP BY shelf_id) t3
    ON t1.shelf_id = t3.shelf_id
  LEFT JOIN
    (SELECT
      b.shelf_id,
      SUM(a.QUANTITY * a.sale_price) AS GMV
    FROM
      sf_order_item a
      LEFT JOIN sf_order b
        ON a.order_id = b.order_id
    WHERE b.`ORDER_DATE`>= DATE(%s) AND b.`ORDER_DATE`< DATE(%s)
      AND ORDER_STATUS = 2
    GROUP BY b.shelf_id) t4
    ON t1.shelf_id = t4.shelf_id
  LEFT JOIN
    (SELECT
      a.SHELF_ID,
      SUM(SUGGEST_FILL_NUM) AS '缺货商品数量',
      SUM(
        SUGGEST_FILL_NUM * PURCHASE_PRICE
      ) AS '缺货商品金额'
    FROM
      sf_product_fill_requirement a
    GROUP BY a.SHELF_ID) t5
    ON t1.shelf_id = t5.shelf_id
  LEFT JOIN
    (SELECT
      shelf_id,
      SUM(STOCK_QUANTITY) AS '在架商品数',
      SUM(STOCK_QUANTITY * SALE_PRICE) AS '在架商品金额',
      COUNT(STOCK_QUANTITY) AS '在架SKU数'
    FROM
      sf_shelf_product_detail
    WHERE STOCK_QUANTITY > 0
    GROUP BY shelf_id) t6
    ON t1.shelf_id = t6.shelf_id
  LEFT JOIN
    (SELECT
      shelf_id,
      COUNT(DISTINCT IF(a.`FILL_TYPE` IN (6,11),a.order_id,NULL)) AS fill_order_qty_d,
      COUNT(DISTINCT IF(a.`FILL_TYPE`=7,a.`ORDER_ID`,NULL)) AS fill_order_qty_n
    FROM
      sf_product_fill_order a
    WHERE a.`FILL_TIME`>= DATE(%s) AND a.`FILL_TIME`< DATE(%s)
      AND order_status IN (3, 4)
      AND fill_type IN (6,7,11)
      AND ABS(a.PRODUCT_NUM) > 10
    GROUP BY shelf_id) t7
    ON t1.shelf_id = t7.shelf_id LIMIT 1000000000;""" % (start_day,end_day,start_day,end_day,start_day,end_day,start_day,end_day)
    return sql

# 货架每日库存
def sql_21():
    print('请输入统计月份：（例如：2019-07）')
    smonth = input()
    sql = """SELECT
  c.business_area AS '地区',
  a.shelf_id AS '货架ID',
  b.shelf_type AS '货架类型',
  b.shelf_status AS '货架状态',
  b.ACTIVATE_TIME AS '激活时间',
  e.REAL_NAME AS '店主姓名',
  e.SF_CODE AS '店主工号',
  SUM(DAY1_QUANTITY) AS DAY1_QUANTITY,
  SUM(DAY2_QUANTITY) AS DAY2_QUANTITY,
  SUM(DAY3_QUANTITY) AS DAY3_QUANTITY,
  SUM(DAY4_QUANTITY) AS DAY4_QUANTITY,
  SUM(DAY5_QUANTITY) AS DAY5_QUANTITY,
  SUM(DAY6_QUANTITY) AS DAY6_QUANTITY,
  SUM(DAY7_QUANTITY) AS DAY7_QUANTITY,
  SUM(DAY8_QUANTITY) AS DAY8_QUANTITY,
  SUM(DAY9_QUANTITY) AS DAY9_QUANTITY,
  SUM(DAY10_QUANTITY) AS DAY10_QUANTITY,
  SUM(DAY11_QUANTITY) AS DAY11_QUANTITY,
  SUM(DAY12_QUANTITY) AS DAY12_QUANTITY,
  SUM(DAY13_QUANTITY) AS DAY13_QUANTITY,
  SUM(DAY14_QUANTITY) AS DAY14_QUANTITY,
  SUM(DAY15_QUANTITY) AS DAY15_QUANTITY,
  SUM(DAY16_QUANTITY) AS DAY16_QUANTITY,
  SUM(DAY17_QUANTITY) AS DAY17_QUANTITY,
  SUM(DAY18_QUANTITY) AS DAY18_QUANTITY,
  SUM(DAY19_QUANTITY) AS DAY19_QUANTITY,
  SUM(DAY20_QUANTITY) AS DAY20_QUANTITY,
  SUM(DAY21_QUANTITY) AS DAY21_QUANTITY,
  SUM(DAY22_QUANTITY) AS DAY22_QUANTITY,
  SUM(DAY23_QUANTITY) AS DAY23_QUANTITY,
  SUM(DAY24_QUANTITY) AS DAY24_QUANTITY,
  SUM(DAY25_QUANTITY) AS DAY25_QUANTITY,
  SUM(DAY26_QUANTITY) AS DAY26_QUANTITY,
  SUM(DAY27_QUANTITY) AS DAY27_QUANTITY,
  SUM(DAY28_QUANTITY) AS DAY28_QUANTITY,
  SUM(DAY29_QUANTITY) AS DAY29_QUANTITY,
  SUM(DAY30_QUANTITY) AS DAY30_QUANTITY,
  SUM(DAY31_QUANTITY) AS DAY31_QUANTITY,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY1_QUANTITY > 0
      THEN product_id
    END
  ) DAY1_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY2_QUANTITY > 0
      THEN product_id
    END
  ) DAY2_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY3_QUANTITY > 0
      THEN product_id
    END
  ) DAY3_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY4_QUANTITY > 0
      THEN product_id
    END
  ) DAY4_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY5_QUANTITY > 0
      THEN product_id
    END
  ) DAY5_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY6_QUANTITY > 0
      THEN product_id
    END
  ) DAY6_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY7_QUANTITY > 0
      THEN product_id
    END
  ) DAY7_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY8_QUANTITY > 0
      THEN product_id
    END
  ) DAY8_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY9_QUANTITY > 0
      THEN product_id
    END
  ) DAY9_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY10_QUANTITY > 0
      THEN product_id
    END
  ) DAY10_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY11_QUANTITY > 0
      THEN product_id
    END
  ) DAY11_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY12_QUANTITY > 0
      THEN product_id
    END
  ) DAY12_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY13_QUANTITY > 0
      THEN product_id
    END
  ) DAY13_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY14_QUANTITY > 0
      THEN product_id
    END
  ) DAY14_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY15_QUANTITY > 0
      THEN product_id
    END
  ) DAY15_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY16_QUANTITY > 0
      THEN product_id
    END
  ) DAY16_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY17_QUANTITY > 0
      THEN product_id
    END
  ) DAY17_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY18_QUANTITY > 0
      THEN product_id
    END
  ) DAY18_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY19_QUANTITY > 0
      THEN product_id
    END
  ) DAY19_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY20_QUANTITY > 0
      THEN product_id
    END
  ) DAY20_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY21_QUANTITY > 0
      THEN product_id
    END
  ) DAY21_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY22_QUANTITY > 0
      THEN product_id
    END
  ) DAY22_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY23_QUANTITY > 0
      THEN product_id
    END
  ) DAY23_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY24_QUANTITY > 0
      THEN product_id
    END
  ) DAY24_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY25_QUANTITY > 0
      THEN product_id
    END
  ) DAY25_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY26_QUANTITY > 0
      THEN product_id
    END
  ) DAY26_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY27_QUANTITY > 0
      THEN product_id
    END
  ) DAY27_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY28_QUANTITY > 0
      THEN product_id
    END
  ) DAY28_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY29_QUANTITY > 0
      THEN product_id
    END
  ) DAY29_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY30_QUANTITY > 0
      THEN product_id
    END
  ) DAY30_sku_qty,
  COUNT(
    DISTINCT
    CASE
      WHEN DAY31_QUANTITY > 0
      THEN product_id
    END
  ) DAY31_sku_qty
FROM
  fe.sf_shelf_product_stock_detail a
  JOIN fe.sf_shelf b
    ON a.shelf_id = b.shelf_id
  JOIN fe.zs_city_business c
    ON SUBSTRING_INDEX(
      SUBSTRING_INDEX(b.AREA_ADDRESS, ',', 2),
      ',',
      - 1
    ) = c.city_name
  LEFT JOIN
    (SELECT
      t.MAIN_SHELF_ID AS shelf_id,
      MAX(t.PACKAGE_MODEL) AS PACKAGE_MODEL,
      MAX(t.ADD_TIME) AS ADD_TIME,
      MONTH(MAX(t.ADD_TIME)) AS smonth,
      DAY(MAX(t.ADD_TIME)) AS sday
    FROM
      fe.sf_shelf_relation_record t
    WHERE t.SHELF_HANDLE_STATUS = 9
    GROUP BY t.MAIN_SHELF_ID) d
    ON a.shelf_id = d.shelf_id
	 LEFT JOIN fe.pub_shelf_manager e
		ON b.MANAGER_ID = e.MANAGER_ID
WHERE a.STAT_DATE = '%s'
  AND c.business_area IS NOT NULL
GROUP BY c.business_area,a.shelf_id
LIMIT 1000000000;""" % (smonth)
    return sql

# 店主信息（包含电话）
def sql_22():
    sql = """SELECT
  sm.REAL_NAME AS '申请人姓名',
  sm.SF_CODE AS '顺丰工号',
  sm.second_user_type as '兼全职（1为全职，其余为兼职）',
  MOBILE_PHONE,
	CONCAT(SUBSTRING(sm.MOBILE_PHONE,1,3),
             SUBSTRING(sm.MOBILE_PHONE,8,1),
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='0','9',
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='1','5',
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='2','4',
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='3','0',
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='4','3',
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='5','8',
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='6','1',
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='7','7',
                 IF(SUBSTRING(sm.MOBILE_PHONE,5,1)='8','2','6'))))))))),
            SUBSTRING(sm.MOBILE_PHONE,10,1),
  SUBSTRING(sm.MOBILE_PHONE,7,1),
             SUBSTRING(sm.MOBILE_PHONE,4,1),
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='0','9',
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='1','5',
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='2','4',
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='3','0',
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='4','3',
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='5','8',
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='6','1',
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='7','7',
                 IF(SUBSTRING(sm.MOBILE_PHONE,9,1)='8','2','6'))))))))),
            SUBSTRING(sm.MOBILE_PHONE,6,1),
  SUBSTRING(sm.MOBILE_PHONE,11,1)) AS '申请人电话'
FROM fe.pub_shelf_manager sm LIMIT 10000000000000;"""
    return sql

# 新店主考试
def sql_23():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
	m.SF_CODE AS '顺丰工号',
	m.REAL_NAME AS '店主姓名',
  COUNT(r.score) AS '查询到分数次数',
	MAX(r.score) AS '最高分数'
FROM
	fe.pub_shelf_manager m
LEFT JOIN fe.pub_user_wechat w ON m.WECHAT_ID = w.WECHAT_ID
LEFT JOIN fe.sf_exam_result r ON w.OPENID = open_id
AND r.data_flag = 1
WHERE m.user_type = 2
  AND m.data_flag = 1
  AND m.add_time >= DATE(%s)
  AND m.add_time < DATE(%s)
GROUP BY m.MANAGER_ID""" % (start_day,end_day)
    return sql

# 普通盘点/月末盘点(货架维度)
def sql_24():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """
    -- 普通盘点、撤架盘点
SELECT
    t3.business_name AS '地区',
    t3.CITY_NAME AS '城市',
    t1.shelf_id AS '货架ID',
    t1.shelf_code AS '货架编码',
    t1.shelf_name AS '货架名称',
  CASE
    WHEN t1.SHELF_TYPE = 1
    THEN '四层标准货架'
    WHEN t1.SHELF_TYPE = 2
    THEN '冰箱'
    WHEN t1.SHELF_TYPE = 3
    THEN '五层防鼠货架'
    WHEN t1.SHELF_TYPE = 4
    THEN '虚拟货架'
    WHEN t1.SHELF_TYPE = 5
    THEN '冰柜'
    WHEN t1.SHELF_TYPE = 6
    THEN '智能货柜'
    WHEN t1.SHELF_TYPE = 7
    THEN '自动贩卖机'
    WHEN t1.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN t1.SHELF_TYPE = 9
    THEN '前置仓'
  END AS '货架类型',
    t2.min_OPERATE_TIME AS '第一条盘点时间',
    t2.max_OPERATE_TIME AS '最后盘点时间',
    CASE
      WHEN t2.shelf_id
      THEN '已盘点'
      ELSE '未盘点'
    END AS '普通盘点',
    CASE
      WHEN (DAY(t2.max_OPERATE_TIME) BETWEEN 15 AND 31) AND t2.shelf_id IS NOT NULL AND t1.second_user_type = 1 THEN '已盘点'
      WHEN (DAY(t2.max_OPERATE_TIME) BETWEEN 20 AND 31) AND t2.shelf_id IS NOT NULL AND t1.second_user_type IN (0,2) THEN '已盘点'
      ELSE '未盘点'
    END AS '月末盘点',
    '无' AS '自贩机未盘点原因',
    t1.manager_id AS '店主ID',
    t1.real_name AS '店主姓名',
    t1.SF_CODE AS '店主工号',
    t1.BRANCH_CODE '分部编码',
    t1.BRANCH_NAME '分部名称',
    CASE
	  WHEN t1.second_user_type = 1 
	  THEN '全职店主'
	  ELSE '兼职店主'
	  END AS '店主类型'
  FROM
    (
    SELECT
      a.CITY,
      a.shelf_id,
      a.shelf_code,
      a.shelf_name,
      a.manager_id,
      a.SHELF_TYPE,
      b.real_name,
      b.BRANCH_CODE,
      b.BRANCH_NAME,
      b.SF_CODE,
      b.second_user_type
    FROM
      fe.sf_shelf a,
      fe.pub_shelf_manager b
    WHERE a.manager_id = b.manager_id
      AND a.data_flag = 1 AND b.data_flag = 1
      AND a.shelf_status = 2
      AND a.revoke_status NOT IN (6,7,9)
      AND a.SHELF_CODE <> ''
      AND a.SHELF_TYPE IN (1,2,3,5,6,8)
      AND a.shelf_id NOT IN (83290,67236,73560,73561,81538,81539,81540,85516,87318,87319,87726,87728,4183,4622,32116,32117,65748,87321,79057,79069,79643,84365,84631,89090,90026,90285,90573,91464,91509,91514,91665,92214,92481,92492,92495,92502,92530)) t1
    LEFT JOIN
      (SELECT
        b.shelf_id,
        MAX(b.OPERATE_TIME) AS max_OPERATE_TIME,
        MIN(b.OPERATE_TIME) AS min_OPERATE_TIME
      FROM
        fe.sf_shelf_check b
      WHERE b.data_flag = 1
        AND b.check_type IN (1,3)
        AND b.operate_time >= DATE(%s)
        AND b.operate_time < DATE(%s)
      GROUP BY b.shelf_id) t2  
      ON t1.shelf_id = t2.shelf_id
    LEFT JOIN feods.`fjr_city_business` t3
    ON t1.CITY = t3.CITY
UNION ALL
-- 自贩机盘点(含货道、副柜盘点)
  SELECT
    t3.business_name AS '地区',
    t3.CITY_NAME AS '城市',
    t1.shelf_id AS '货架ID',
    t1.shelf_code AS '货架编码',
    t1.shelf_name AS '货架名称',
  CASE
    WHEN t1.SHELF_TYPE = 1
    THEN '四层标准货架'
    WHEN t1.SHELF_TYPE = 2
    THEN '冰箱'
    WHEN t1.SHELF_TYPE = 3
    THEN '五层防鼠货架'
    WHEN t1.SHELF_TYPE = 4
    THEN '虚拟货架'
    WHEN t1.SHELF_TYPE = 5
    THEN '冰柜'
    WHEN t1.SHELF_TYPE = 6
    THEN '智能货柜'
    WHEN t1.SHELF_TYPE = 7
    THEN '自动贩卖机'
    WHEN t1.SHELF_TYPE = 8
    THEN '校园货架'
    WHEN t1.SHELF_TYPE = 9
    THEN '前置仓'
  END AS '货架类型',
    t2.min_OPERATE_TIME AS '第一条盘点时间',
    t2.max_OPERATE_TIME AS '最后盘点时间',
    CASE
      WHEN t2.shelf_id
      THEN '已盘点'
      ELSE '未盘点'
    END AS '普通盘点',
    CASE
      WHEN (DAY(t2.hd_max_OPERATE_TIME) BETWEEN 15 AND 31) AND (DAY(t2.fg_max_OPERATE_TIME) BETWEEN 15 AND 31) AND t1.second_user_type = 1 THEN '已盘点'
      WHEN (DAY(t2.hd_max_OPERATE_TIME) BETWEEN 20 AND 31) AND (DAY(t2.fg_max_OPERATE_TIME) BETWEEN 20 AND 31) AND t1.second_user_type IN (0,2) THEN '已盘点'
      ELSE '未盘点'
    END AS '月末盘点',
    CASE
      WHEN (DAY(t2.hd_max_OPERATE_TIME) BETWEEN 15 AND 31) AND (DAY(t2.fg_max_OPERATE_TIME) BETWEEN 15 AND 31) AND t1.second_user_type = 1 THEN '已盘点'
      WHEN (DAY(t2.hd_max_OPERATE_TIME) BETWEEN 20 AND 31) AND (DAY(t2.fg_max_OPERATE_TIME) BETWEEN 20 AND 31) AND t1.second_user_type IN (0,2) THEN '已盘点'
      WHEN (DAY(t2.hd_max_OPERATE_TIME) BETWEEN 15 AND 31) AND (IFNULL(DAY(t2.fg_max_OPERATE_TIME),0) < 15 ) AND t1.second_user_type = 1  THEN '副柜未盘点'
      WHEN (DAY(t2.hd_max_OPERATE_TIME) BETWEEN 20 AND 31) AND (IFNULL(DAY(t2.fg_max_OPERATE_TIME),0) < 20 ) AND t1.second_user_type IN (0,2) THEN '副柜未盘点'
      WHEN (IFNULL(DAY(t2.hd_max_OPERATE_TIME),0) < 15) AND (DAY(t2.fg_max_OPERATE_TIME) BETWEEN 15 AND 31) AND t1.second_user_type = 1 THEN '货道未盘点'
      WHEN (IFNULL(DAY(t2.hd_max_OPERATE_TIME),0) < 20) AND (DAY(t2.fg_max_OPERATE_TIME) BETWEEN 20 AND 31) AND t1.second_user_type IN (0,2) THEN '货道未盘点'
      ELSE '货道副柜均未盘点'
    END '自贩机未盘点原因',
    t1.manager_id AS '店主ID',
    t1.real_name AS '店主姓名',
    t1.SF_CODE AS '店主工号',
    t1.BRANCH_CODE '分部编码',
    t1.BRANCH_NAME '分部名称',
    CASE
	  WHEN t1.second_user_type = 1 
	  THEN '全职店主'
	  ELSE '兼职店主'
	  END AS '店主类型'
  FROM
    (
    SELECT
      a.CITY,
      a.shelf_id,
      a.shelf_code,
      a.shelf_name,
      a.manager_id,
      a.SHELF_TYPE,
      b.real_name,
      b.BRANCH_CODE,
      b.BRANCH_NAME,
      b.SF_CODE,
      b.second_user_type
    FROM
      fe.sf_shelf a,
      fe.pub_shelf_manager b
    WHERE a.manager_id = b.manager_id
      AND a.data_flag = 1 AND b.data_flag = 1
      AND a.shelf_status = 2
      AND a.revoke_status NOT IN (6,7,9)
      AND a.SHELF_CODE <> ''
      AND a.SHELF_TYPE = 7
      AND a.shelf_id NOT IN (83290,67236,73560,73561,81538,81539,81540,85516,87318,87319,87726,87728,4183,4622,32116,32117,65748,87321,79057,79069,79643,84365,84631,89090,90026,90285,90573,91464,91509,91514,91665,92214,92481,92492,92495,92502,92530)) t1
    LEFT JOIN
      (SELECT
        b.shelf_id,
        MAX(CASE WHEN b.check_type = 6 THEN b.OPERATE_TIME END) AS hd_max_OPERATE_TIME,
        MAX(CASE WHEN b.check_type = 7 THEN b.OPERATE_TIME END) AS fg_max_OPERATE_TIME,
        MAX(b.OPERATE_TIME) AS max_OPERATE_TIME,
        MIN(b.OPERATE_TIME) AS min_OPERATE_TIME
      FROM
        fe.sf_shelf_check b
      WHERE b.data_flag = 1
        AND b.check_type IN (1,3,6,7)
        AND b.operate_time >= DATE(%s)
        AND b.operate_time < DATE(%s)
      GROUP BY b.shelf_id) t2  
      ON t1.shelf_id = t2.shelf_id
    LEFT JOIN feods.`fjr_city_business` t3
    ON t1.CITY = t3.CITY;""" % (start_day,end_day,start_day,end_day)
    return sql

# 自动贩卖机、智能柜安装
def sql_25():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
  t3.business_name AS '地区',
  DATE_FORMAT(t0.operation_time, '%%Y%%m') AS '统计月份',
  t0.`machine_apply_record_id` AS '自贩机申请编号',
  t0.shelf_id AS '货架ID',
  t4.manufacturer_name AS '厂家名称',
  t0.operation_time AS '审核通过时间',
  CASE
    WHEN t2.shelf_type = 6
    THEN '智能货架'
    WHEN t2.shelf_type = 7
    THEN '自动贩卖机'
  END AS '货架类型',
  CASE
    WHEN t2.SHELF_STATUS = 1
    THEN '待激活'
    WHEN t2.SHELF_STATUS = 2
    THEN '已激活'
    WHEN t2.SHELF_STATUS = 3
    THEN '已撤架'
    WHEN t2.SHELF_STATUS = 4
    THEN '已关闭'
    WHEN t2.SHELF_STATUS = 5
    THEN '已注销'
    WHEN t2.SHELF_STATUS = 9
    THEN '维护中'
    WHEN t2.SHELF_STATUS = 10
    THEN '已失效'
  END AS '货架状态',
  IFNULL(
    t1.任务编码,
    '未生成安装任务'
  ) AS '任务编码',
  t1.任务状态,
  t1.执行结果,
  t1.任务添加时间,
  t1.任务开始时间,
  t1.任务完结时间,
  DATEDIFF(
    t1.任务完结时间,
    t0.operation_time
  ) AS '审核结束到完结天数',
    DATEDIFF(
    t1.任务添加时间,
    t0.operation_time
  ) AS '审核结束到创建任务天数',
  t1.任务创建到完结天数,
  t1.任务开始到完结天数
FROM
  (SELECT
    a.`machine_apply_record_id`,
    SUBSTRING_INDEX(
      SUBSTRING_INDEX(
        a.`operation_detail`,
        ',',
        b.`number`
      ),
      'ID',
      - 1
    ) AS 'shelf_id',
    a.`operation_time`
  FROM
    fe.`sf_machines_apply_operation` a
    JOIN feods.`fjr_number` b
      ON b.number > 0
      AND b.number <= (
        LENGTH(a.`operation_detail`) - LENGTH(
          REPLACE(a.`operation_detail`, ',', '')
        )
      )
  WHERE a.`operation_item` = '创建货架'
  AND a.operation_time >= DATE(%s)
  AND a.operation_time < DATE(%s)) t0
  LEFT JOIN
    (SELECT
      a.`task_no` AS '任务编码',
      b.shelf_id AS '货架ID',
      CASE
        WHEN c.shelf_type = 6
        THEN '智能货架'
        WHEN c.shelf_type = 7
        THEN '自动贩卖机'
      END AS '货架类型',
      CASE
        WHEN c.SHELF_STATUS = 1
        THEN '待激活'
        WHEN c.SHELF_STATUS = 2
        THEN '已激活'
        WHEN c.SHELF_STATUS = 3
        THEN '已撤架'
        WHEN c.SHELF_STATUS = 4
        THEN '已关闭'
        WHEN c.SHELF_STATUS = 5
        THEN '已注销'
        WHEN c.SHELF_STATUS = 9
        THEN '维护中'
        WHEN c.SHELF_STATUS = 10
        THEN '已失效'
      END AS '货架状态',
      CASE
        WHEN a.task_status = 1
        THEN '待地区分配'
        WHEN a.task_status = 2
        THEN '待管理人员分配'
        WHEN a.task_status = 3
        THEN '待执行'
        WHEN a.task_status = 4
        THEN '待回仓'
        WHEN a.task_status = 5
        THEN '已完成'
        WHEN a.task_status = 6
        THEN '已关闭'
      END AS '任务状态',
      CASE
        WHEN a.error_reason = 0
        THEN '待执行'
        WHEN a.error_reason = 1
        THEN '执行成功'
        WHEN a.error_reason = 2
        THEN '人数低于50人'
        WHEN a.error_reason = 3
        THEN '安装位置不合规'
        WHEN a.error_reason = 4
        THEN '客户拒绝安装'
        WHEN a.error_reason = 5
        THEN '公司地址不存在'
        WHEN a.error_reason = 6
        THEN '更改安装时间'
        WHEN a.error_reason = 7
        THEN '客户已下班'
      END AS '执行结果',
      a.add_time AS '任务添加时间',
      a.`execute_start_time` AS '任务开始时间',
      a.`execute_finish_time` AS '任务完结时间',
      DATEDIFF(
        a.`execute_finish_time`,
        a.`execute_start_time`
      ) AS '任务开始到完结天数',
      DATEDIFF(
        a.`execute_finish_time`,
        a.add_time
      ) AS '任务创建到完结天数'
    FROM
      fe.sf_shelf_logistics_task a
      INNER JOIN fe.sf_shelf_logistics_task_install b
        ON a.logistics_task_id = b.`logistics_task_id`
      LEFT JOIN fe.`sf_shelf` c
        ON b.`shelf_id` = c.`SHELF_ID`
    WHERE a.`data_flag` = 1
      AND a.task_type = 1
      AND c.shelf_type IN (6, 7)) t1
    ON t0.shelf_id = t1.货架ID
  LEFT JOIN fe.sf_shelf t2
    ON t0.shelf_id = t2.SHELF_ID
  LEFT JOIN feods.fjr_city_business t3
    ON t2.CITY = t3.CITY
  LEFT JOIN fe.sf_shelf_machine t4
    ON t0.shelf_id = t4.shelf_id;""" % (start_day,end_day)
    return sql

# 上架后GMV下降的明细
def sql_26():
    sql = """SELECT
  sub.business_area,
  CASE
    WHEN sub.supplier_type = 2
    THEN '仓库'
    WHEN sub.supplier_type = 9
    THEN '前置仓'
  END AS supplier_type,
  sub.fill_date,
  sub.ORDER_ID as '补货订单ID',
  sub.shelf_id,
  sub.shelf_type,
  pm.sf_code,
  sub.fill_user_name,
  SUM(
    IF(
      od.work_day_seq >= sub.before_workday_seq
      AND od.work_day_seq < sub.fill_date_seq,
      od.sale_price * od.quantity,
      0
    )
  ) AS before_workday_gmv,
  SUM(
    IF(
      od.work_day_seq > sub.fill_date_seq
      AND od.work_day_seq <= sub.after_workday_seq,
      od.sale_price * od.quantity,
      0
    )
  ) AS after_workday_gmv
  ,
  IF(SUM(
    IF(
      od.work_day_seq >= sub.before_workday_seq
      AND od.work_day_seq < sub.fill_date_seq,
      od.sale_price * od.quantity,
      0
    )
  ) = 0,
      IF( SUM(
    IF(
      od.work_day_seq > sub.fill_date_seq
      AND od.work_day_seq <= sub.after_workday_seq,
      od.sale_price * od.quantity,
      0
    )
  ) = 0, 0, 1),
  SUM(
    IF(
      od.work_day_seq > sub.fill_date_seq
      AND od.work_day_seq <= sub.after_workday_seq,
      od.sale_price * od.quantity,
      0
    )
  ) / SUM(
    IF(
      od.work_day_seq >= sub.before_workday_seq
      AND od.work_day_seq < sub.fill_date_seq,
      od.sale_price * od.quantity,
      0
    )
  ) - 1) AS A
FROM
  (SELECT
    DATE(a.fill_time) AS fill_date,
    c.business_area,
    a.ORDER_ID,
    a.shelf_id,
    d.shelf_type,
    a.supplier_type,
    a.fill_user_id,
    a.fill_user_name,
    b.work_day_seq AS fill_date_seq,
    b.work_day_seq - 2 AS before_workday_seq,
    b.work_day_seq + 2 AS after_workday_seq
  FROM
    fe.sf_product_fill_order a,
    fe.`sf_shelf` d,
    fe.`zs_city_business` c,
    feods.fjr_work_days b
  WHERE a.ORDER_STATUS IN (2, 3, 4)
    AND a.fill_type IN (1, 2, 8, 9, 10)
    AND d.shelf_type IN (1,2,3,5)
    AND a.supplier_type IN (2, 9)
    AND a.FILL_TIME >= DATE_ADD(CURDATE(),INTERVAL -DAY(CURDATE())+1 DAY)
    AND a.fill_time < CURDATE()
    AND DATE(a.fill_time) = b.sdate
    AND a.shelf_id = d.shelf_id
    AND SUBSTRING_INDEX(SUBSTRING_INDEX(d.area_address,',',2),',',-1)=c.city_name
    AND b.if_work_day = 1) sub  --   货架补货时间以及前后两个工作日的序列维表
    INNER JOIN
   (SELECT
    o.shelf_id,
    o.sale_price,
    o.quantity,
    w.sdate,
    w.work_day_seq
  FROM
    feods.sf_order_item_temp o,
    feods.fjr_work_days w
  WHERE w.sdate = DATE(o.order_date)
    AND w.if_work_day = 1
    AND w.sdate >= DATE_ADD(CURDATE(),INTERVAL -DAY(CURDATE())+1 DAY)
    AND w.sdate < CURDATE()) od   -- 货架订单时间相应序列以及销售订单数据
 ON sub.shelf_id = od.shelf_id
 LEFT JOIN fe.`pub_shelf_manager` pm
 ON pm.manager_id = sub.fill_user_id
GROUP BY
  CASE
    WHEN sub.supplier_type = 2
    THEN '仓库'
    WHEN sub.supplier_type = 9
    THEN '前置仓'
  END,
  sub.fill_date,
  sub.shelf_id
  HAVING A < 0;"""
    return sql

# 临期提报
def sql_27():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
  e.BUSINESS_AREA AS '区域',
  e.CITY_NAME AS '城市',
  b.OPERATE_TIME AS '盘点时间',
  b.check_type AS '盘点类型(1:普通盘点、2:过期盘点、3:撤架盘点、4:巡检盘点)',
  a.SHELF_ID AS '货架编号',	
  a.SHELF_CODE AS '货架编码',
  f.SF_CODE AS '店主工号',
  f.REAL_NAME AS '店主姓名',
  f.BRANCH_NAME AS '网点名称',
  f.BRANCH_CODE AS '网点代码',
  a.PRODUCT_ID AS '商品编号',
  c.product_code2 AS '商品FE编码',				
  a.ERROR_REASON AS '异常原因(1:货物破损、2:商品过期)(DICT)',
  a.ERROR_NUM AS '异常数量',
  a.AUDIT_ERROR_NUM AS '审核后异常数量',	
  a.production_date AS '最近生产日期',
  a.AUDIT_STATUS AS '审核状态(1:待审核、2:已审核、3:-)(DICT)',
  a.REMARK AS '审核结果（2-已通过，3-不通过）',
  a.AUDIT_TYPE AS '审核不通过说明1',
  a.ATTRIBUTE2 AS '审核不通过说明2',
  a.AUDIT_REMARK AS '审核备注',
  a.ATTRIBUTE1 AS '过期风险审核不通过原因:1、商品名称不符  2、填写生产日期与商品日期不一致',
  a.sale_price AS '销售价',
  h.ITEM_NAME AS '账号类型',
  g.SF_CODE AS '盘点人工号',
  g.REAL_NAME AS '盘点人名称'
FROM
  fe.sf_shelf_check_detail a
  LEFT JOIN fe.sf_shelf_check b
    ON a.check_id = b.check_id
  LEFT JOIN fe.sf_product c
    ON a.product_id = c.product_id
  LEFT JOIN fe.sf_shelf d
    ON a.SHELF_ID = d.SHELF_ID
	LEFT JOIN fe.pub_shelf_manager g
		ON b.`OPERATOR_ID` = g.MANAGER_ID
  LEFT JOIN fe.zs_city_business e			
    ON SUBSTRING_INDEX(
      SUBSTRING_INDEX(d.AREA_ADDRESS, ',', 2),
      ',',
      - 1
    ) = e.CITY_NAME
  LEFT JOIN fe.pub_shelf_manager f
    ON d.manager_id = f.manager_id
  LEFT JOIN fe.pub_dictionary_item h
    ON (
      g.USER_TYPE = h.ITEM_VALUE
      AND h.DICTIONARY_ID = 17
    )
WHERE b.`OPERATE_TIME`>= DATE(%s) AND b.`OPERATE_TIME`< DATE(%s)
  AND (
    ERROR_REASON = 2
    OR production_date IS NOT NULL
  )
LIMIT 10000000000000;""" % (start_day,end_day)
    return sql

# 店主结算信息
def sql_28():
    sql = """SELECT a.`MANAGER_ID`,a.`SF_CODE`,a.`REAL_NAME`,a.`sf_card_no`,a.`ID_NO`,a.`CARD_NO`,a.`BANK_NAME`,a.`AREA_ADDRESS`,a.`CARD_NAME`
FROM fe.`pub_shelf_manager` a
WHERE a.`DATA_FLAG` = 1;"""
    return sql

# 门店统计数据
def sql_29():
    print('请输入统计开始时间：（例如：20190701）')
    start_day = input()
    print('请输入统计结束时间：（例如：20190801）')
    end_day = input()
    sql = """SELECT
  a.`business_name` AS '地区',
  a.`zone_code` AS '门店代码',
  a.`zone_name` AS '门店名称',
  a.`shelf_id` AS '货架ID',
  a.`SHELF_CODE` AS '货架编码',
  a.SHELF_STATUS_desc AS '货架状态',
  CASE 
    WHEN a.shelf_type_desc = '虚拟货架' AND a.shelf_tag = 1 THEN '未对接自贩机'
    WHEN a.shelf_type_desc = '虚拟货架' AND a.shelf_tag = 2 THEN '未对接智能柜'
    WHEN a.type_name='澳柯玛60' THEN '未对接自贩机'
    ELSE a.shelf_type_desc END AS '货架类型',
  DATE(a.`ACTIVATE_TIME`) AS '激活日期',
  DATE(a.`REVOKE_TIME`) AS '撤架日期',
  CASE WHEN a.`ACTIVATE_TIME` >= %s and a.`ACTIVATE_TIME` < %s THEN 1 ELSE 0 END AS '是否本期新开',
  CASE WHEN a.`REVOKE_TIME` >= %s and a.`REVOKE_TIME` < %s THEN 1 ELSE 0 END AS '是否本期撤架',
  a.`SF_CODE` AS '店主工号',
  a.`REAL_NAME` AS '店主名称',
  a.`manager_type` AS '店主类型',
  f.SHELF_ID AS '前置仓ID ',
  f.SHELF_CODE AS '前置仓编码',
  f.SHELF_NAME AS '前置仓名称',
  c.GMV,
  c.AMOUNT AS '实收'
FROM fe_dwd.`dwd_shelf_base_day_all` a
LEFT JOIN 
      (SELECT
  a.`shelf_id`,
  SUM(IFNULL(a.`gmv`, 0) + IFNULL(a.`refunding_GMV`, 0) - IFNULL(a.`before_refund_GMV`, 0) + IFNULL(a.`AFTER_PAYMENT_MONEY`, 0)) GMV,
  SUM(IFNULL(a.`pay_amount`, 0) - IFNULL(a.`refund_finish_amount`, 0) - IFNULL(a.`before_refund_amount`, 0) + IFNULL(a.`AFTER_PAYMENT_MONEY`, 0)) AMOUNT
FROM
  fe_dwd.`dwd_shelf_day_his` a
WHERE a.`sdate` >= %s and a.`sdate` < %s
GROUP BY a.`shelf_id`) c    -- 销售数据
      ON a.shelf_id = c.shelf_id
LEFT JOIN fe.`sf_prewarehouse_shelf_detail` e
  ON a.`shelf_id` = e.`shelf_id`
  AND e.data_flag = 1
LEFT JOIN fe.`sf_shelf` f
  ON e.warehouse_id = f.`SHELF_ID`
  AND f.DATA_FLAG = 1 
WHERE a.`DATA_FLAG` = 1
  AND (a.`REVOKE_TIME` > %s OR a.`REVOKE_TIME` IS NULL)
  AND a.SHELF_TYPE < 9;""" % (start_day,end_day,start_day,end_day,start_day,end_day,start_day)
    return sql


user_dic = updata_user()
user_id = input('请输入工号：')
if user_id in user_dic.keys():
    print('\n',user_dic[user_id],",你好！\n")
else:
    print("\n非运作组工号，欢迎下次使用")
    time.sleep(5)
    exit()

# 创建数据库连接
try:
    db = pymysql.Connect(
        host='gz-cdb-2huk27sw.sql.tencentcdb.com',
        port=63298,
        user='',
        password='',
        db='fe',
        charset='utf8mb4')
except:
    print('\n数据库连接失败，10s后重试')
    time.sleep(10)

# 需要执行的sql语句
print('1、大仓\n2、前置站以及串点\n3、店主\n4、其它\n请输入要取数模块序号：')
get_iteam_1 = input()
get_iteam = {'1':['0、大仓出库金额','1、补货订单明细','2、大仓到前置站货架补货金额','3、大仓未上架订单明细','4、最小补货单位','5、撤架数据明细（包含撤架及时率以及流向）'],
             '2':['0、前置站盘点明细','1、前置站关联货架明细','2、前置站库存及动销','3、前置站库存金额及出库金额','4、前置站提成(分拣明细)',
                  '5、前置站提成(上架明细)','6、串点覆盖货架','7、串点线路','8、串点任务明细','9、门店统计信息'],
             '3':['0、货架盘点明细+审核明细（排面）','1、货架管理员','2、关联货架','3、货架变更','4、货架运营数据','5、货架每日库存','6、店主信息（包含电话）',
                  '7、新店主考试','8、普通盘点月末盘点(货架维度)','9、临期提报'],
             '4':['0、自动贩卖机、智能柜安装','1、上架后GMV下降的明细','2、店主结算信息']}
print('\n',get_iteam[get_iteam_1])
print('请输入要取的数据表序号：')
get_iteam_2 = int(input())
sql_name = get_iteam[get_iteam_1][get_iteam_2]
# print(sql_name)
sql_dic = {'0、大仓出库金额':'sql_1()','1、补货订单明细':'sql_2()','3、大仓未上架订单明细':'sql_4()','2、大仓到前置站货架补货金额':'sql_3()','4、最小补货单位':'sql_5()','5、撤架数据明细（包含撤架及时率以及流向）':'sql_6()',
           '0、前置站盘点明细':'sql_7()','1、前置站关联货架明细':'sql_8()','2、前置站库存及动销':'sql_9()','3、前置站库存金额及出库金额':'sql_10()','4、前置站提成(分拣明细)':'sql_11()',
           '5、前置站提成(上架明细)':'sql_12()','6、串点覆盖货架':'sql_13()','7、串点线路':'sql_14()','8、串点任务明细':'sql_15()',
           '0、货架盘点明细+审核明细（排面）':'sql_16()','1、货架管理员':'sql_17()','2、关联货架':'sql_18()','3、货架变更':'sql_19()','4、货架运营数据':'sql_20()','5、货架每日库存':'sql_21()','6、店主信息（包含电话）':'sql_22()',
           '7、新店主考试':'sql_23()','8、普通盘点月末盘点(货架维度)':'sql_24()','0、自动贩卖机、智能柜安装':'sql_25()',
           '1、上架后GMV下降的明细':'sql_26()','9、临期提报':'sql_27()','2、店主结算信息':'sql_28()','9、门店统计信息':'sql_29()'}


print('\n输入成功，正在访问数据库..')
# 创建游标
cursor = db.cursor()
# 执行sql语句,返回受影响的行数
num = cursor.execute(eval(sql_dic[sql_name]))
print('数据一共 ：',num,'条')
# 获取结果集
result = cursor.fetchall()
col = cursor.description
# print(result)
# 关闭连接
cursor.close()
db.close()


print('数据下载中')
title = []
for i in col:
    title.append(i[0])
result = np.array(result)
data = pd.DataFrame(columns = title,data = result)
data.head()
name = str(user_dic[user_id])+ '-' + str(re.sub("[A-Za-z0-9\!\%\[\]\,\。\、]", "", sql_name)) + str(datetime.date.today())
try:
    data[['补货订单ID']] = data[['补货订单ID']].astype(str)
except:
    print('无补货订单ID')
    try:
        data.to_excel(f'd:/user/01386340/desktop/python取数结果/{name}.xlsx', index=False, encoding='utf_8_sig')
        print('写入excel')
        print('\n下载完成 ！')
    except:
        data.to_csv(f'd:/user/01386340/desktop/python取数结果/{name}.csv',mode='w',index=False,encoding='utf_8_sig')
        print('写入csv')
        print('\n下载完成 ！')
else:
    try:
        data.to_excel(f'd:/user/01386340/desktop/python取数结果/{name}.xlsx', index=False, encoding='utf_8_sig')
        print('写入excel')
        print('\n下载完成 ！')
    except:
        data.to_csv(f'd:/user/01386340/desktop/python取数结果/{name}.csv',mode='w',index=False,encoding='utf_8_sig')
        print('写入csv')
        print('\n下载完成 ！')
time.sleep(5)