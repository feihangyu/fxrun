import requests
from bs4 import BeautifulSoup
import re
import pymysql
import random
import time
import pandas as pd

link = 'https://f.qianzhan.com/yuanqu/diqu/'
head = ['Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:6.0) Gecko/20100101 Firefox/6.0',
            'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/534.50 (KHTML, like Gecko) Version/5.1 Safari/534.50',
            'Opera/9.80 (Windows NT 6.1; U; zh-cn) Presto/2.9.168 Version/11.50',
            'Mozilla/5.0 (Windows; U; Windows NT 6.1; ) AppleWebKit/534.12 (KHTML, like Gecko) Maxthon/3.0 Safari/534.12']
header = random.choice(head)
headers = {
    "User-Agent": header,
}

# 分省列表，一个数字代表一个省
area_list = [44,32,33,37,31,42,35,41,34,13,11,51,21,43,12,36,61,50,14,45,52,15,22,23,53,62,65,64,63,46,54]
data = []

for i in area_list:
    url = link + str(i) + "/"       # 组合各个省网址
    r = requests.get(url, headers=headers)      #get请求
    text = BeautifulSoup(r.content, 'lxml')     #BeautifulSoup解析网址
    pat_page = '<a href="/yuanqu/diqu/.*?/?pg=(.*?)">.*?</a>'       #匹配改省最大页面数
    page = re.compile(pat_page).findall(str(text))              #匹配改省最大页面数
    list_page = []
    for j in page:          #匹配改省最大页面数
        j = int(j)
        list_page.append(j)
    page_max = max(list_page)
    for j in range(1, page_max + 1):
        line = url + '?pg=' + str(j)        #组合网址到各个页面
        r_line = requests.get(line, headers=headers)        #get请求网址
        text_line = BeautifulSoup(r_line.content, 'lxml')
        pat = '<tr>\n<td>(.*?)</td>\n<td class="text-l"><a class="blue" href="(.*?)" target="_blank">(.*?)</a></td>\n<td>(.*?)</td>\n<td>(.*?)</td>\n<td>(.*?)</td>\n<td class="text-l">(.*?)</td>\n<td>(.*?)</td>\n<td>(.*?)</td>'
        list_line = re.compile(pat).findall(str(text_line))
        print(list_line, "第" + str(j) + "页" , "共" + str(page_max) + "页")        #打印提示，可删除。
        for li in list_line:
            xuhao = li[0]       #序号
            name = li[2]        #园区名称
            province = li[3]    #园区所在省
            city = li[4]        #园区所在市
            district = li[5]    #园区所在县
            address = li[6]     #园区地址
            area = li[7]        #园区面积
            num = li[8]         #园区入驻企业个数
            iternet = "https://f.qianzhan.com" + li[1]      #园区网址
            list = [xuhao, name, province, city, district, address, area, num, iternet]
            data.append(list)
            print(list)  # 打印详情

reslt = pd.DataFrame(data=data)
try:
    reslt.to_excel(f'd:/user/01386340/desktop/python取数结果/11111111111.xlsx', index=False, encoding='utf_8_sig')
    print('\n写入excel')
    print('下载完成 ！')
except:
    reslt.to_csv(f'd:/user/01386340/desktop/python取数结果/111111111111.csv',mode='w',index=False,encoding='utf_8_sig')
    print('\n写入csv')
    print('下载完成 ！')