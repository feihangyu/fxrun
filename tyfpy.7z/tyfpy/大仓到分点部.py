import pandas as pd
import requests
import json
import xlrd

def get_dis_tm(origin, destination):
    url = 'https://restapi.amap.com/v3/direction/driving?'
    key = ''  # api，key值
    origin = "{},{}".format(origin[0], origin[1])
    destination = "{},{}".format(destination[0], destination[1])
    link = '{}origin={}&destination={}&key={}'.format(url, origin ,destination , key)
    response = requests.get(link)
    dis, tm = 999999, 999999
    if response.status_code == 200:
        results = response.json()
        if results['status'] == '1':
            dis = int(results['route']['paths'][0]['distance'])
            tm = int(results['route']['paths'][0]['duration'])
        else:
            print(link)
    return dis


file = 'd:/user/01386340/desktop/数据/分点部经纬度.xlsx'

wb = xlrd.open_workbook(filename=file)#打开文件
sheet1_name = wb.sheet_names()
print(sheet1_name)

# 获取Sheet数据
def get_shelf(sheet_i):
    sheet1 = wb.sheet_by_index(sheet_i-1)#通过索引获取表格
    dic_shelf = {}
    for i in range(0,sheet1.ncols):
        col = sheet1.col_values(i)
        key = col[0]
        dic_shelf[key] = col[1:len(col)]
    return dic_shelf


a = get_shelf(1)
b = get_shelf(2)
print(a)
print(b)
dic_1 = {}  # 分部字典，分部：【地区，经度，纬度】
dic_2 = {}  # 大仓字典，地区：【经度，纬度】
dic_3 = {}  # 分部到大仓距离，分部：【距离】
data_0 = a['地区']
data_1 = a['名称']
data_2 = a['经度']
data_3 = a['纬度']
data_4 = b['地区']
data_5 = b['经度']
data_6 = b['纬度']
data_7 = []

for i in range(0, len(data_0)):
    data_8 = []
    data_8.append(data_0[i])
    data_8.append(data_2[i])
    data_8.append(data_3[i])
    dic_1[data_1[i]] = data_8
for i in range(0, len(data_4)):
    data_8 = []
    data_8.append(data_5[i])
    data_8.append(data_6[i])
    dic_2[data_4[i]] = data_8
print(dic_1)
print(dic_2)
keys = list(dic_1.keys())
print(keys)

for i in range(0, len(keys)):
    data_8 = []
    c = keys[i]
    d = dic_1[c]
    data_8.append(d[1])
    data_8.append(d[2])
    dic_3[c] = get_dis_tm(data_8,dic_2[d[0]])

print(dic_3)
data = pd.DataFrame.from_dict(dic_3, orient='index',columns=['行驶距离'])
data =data.reset_index().rename(columns = {'index':'分点部'})
print(data)
data.to_excel(f'd:/user/01386340/desktop/结果表/大仓分点部行驶距离.xlsx',index=False)