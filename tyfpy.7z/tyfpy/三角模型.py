import xlrd
import pandas as pd

file = '三角模型.xlsx'

wb = xlrd.open_workbook(filename=file)#打开文件
sheet1_name = wb.sheet_names()
# print(sheet1_name)

# 获取分表数据
def get_shelf(sheet_i):
    sheet1 = wb.sheet_by_index(sheet_i-1)#通过索引获取表格
    dic_shelf = {}
    for i in range(0,sheet1.ncols):
        col = sheet1.col_values(i)
        key = col[0]
        dic_shelf[key] = col[1:len(col)]
    return dic_shelf

data = get_shelf(1)
print(data.keys())
# 次日上架率 临期提报规范率	盘点率	补货上架规范率	虚假盘点率	盘点失误率	排面失误率

# 去空格
def remove(test):
    while '' in test:
        test.remove('')

arr_1 = data['次日上架率']
arr_2 = data['临期提报规范率']
arr_3 = data['盘点率']
arr_4 = data['补货上架规范率']
arr_5 = data['虚假盘点率']
arr_6 = data['盘点失误率']
arr_7 = data['排面失误率']

remove(arr_1)
remove(arr_2)
remove(arr_3)
remove(arr_4)
remove(arr_5)
remove(arr_6)
remove(arr_7)

def quickSort(list, start, end):
    if start>end:
        return
    i, j = start, end
    flag = list[start]
    while True:
        while j>i and list[j] >= flag:
            j = j - 1
        while i< j and list[i] <= flag:
            i += 1
        if i < j:
            list[i], list[j] = list[j], list[i]
        elif i == j:
            list[start], list[i] = list[i], list[start]
            break
    quickSort(list,start, i-1)
    quickSort(list, i+1, end)

quickSort(arr_1, 0, (len(arr_1)-1))
quickSort(arr_2, 0, (len(arr_2)-1))
quickSort(arr_3, 0, (len(arr_3)-1))
quickSort(arr_4, 0, (len(arr_4)-1))
quickSort(arr_5, 0, (len(arr_5)-1))
quickSort(arr_6, 0, (len(arr_6)-1))
quickSort(arr_7, 0, (len(arr_7)-1))

def five_point(list):
    list_1 = []
    len_list_1 = round(len(list) * (1 / 9))
    len_list_2 = round(len(list) * (1 / 3))
    len_list_3 = round(len(list) * (2 / 3))
    len_list_4 = round(len(list) * (8 / 9))
    list_1.append(list[(len_list_1 - 1)])
    list_1.append(list[(len_list_2 - 1)])
    list_1.append(list[(len_list_3 - 1)])
    list_1.append(list[(len_list_4 - 1)])
    print(list_1)

five_point(arr_1)
five_point(arr_2)
five_point(arr_3)
five_point(arr_4)
five_point(arr_5)
five_point(arr_6)
five_point(arr_7)