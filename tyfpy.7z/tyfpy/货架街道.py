# -*- coding:utf-8 -*-

import xlrd
import requests
import pandas as pd
import numpy as np
import time
import sys

file = 'd:/user/01386340/desktop/数据/佛山1111.xlsx'

wb = xlrd.open_workbook(filename=file)#打开文件
sheet1_name = wb.sheet_names()
print(sheet1_name)

# 获取Sheet数据
def get_shelf(sheet_i):
    sheet1 = wb.sheet_by_index(sheet_i-1)#通过索引获取表格
    dic_shelf = {}
    for i in range(0,sheet1.ncols):
        col = sheet1.col_values(i)
        key = col[0]
        dic_shelf[key] = col[1:len(col)]
    return dic_shelf

def search_location(address):
    params = {'address': address,
              'city': '佛山',
              'key': 'b35e4a04ffd3b6065ac32254d29bbb99'}
    base_url = 'http://restapi.amap.com/v3/geocode/geo'
    response = requests.get(url=base_url, params=params)
    json_data = response.json()
    if json_data['status'] == '1' and len(json_data['geocodes']) > 0:
        return json_data['geocodes'][0]['location'] if json_data['geocodes'][0]['location'] else 'errorlocation', json_data
    return 'errorlocation', json_data

def search_address_detail(location):
    params = {'location': location,
              'key': 'b35e4a04ffd3b6065ac32254d29bbb99'}
    base_url = 'http://restapi.amap.com/v3/geocode/regeo'
    response = requests.get(url=base_url, params=params)
    json_data = response.json()
    if json_data['status'] == '1':
        if json_data['regeocode']['addressComponent']['township']:
            return json_data['regeocode']['addressComponent']['township'], json_data
    return 'errorSearchAddress', json_data


a = pd.DataFrame(get_shelf(1))
a[['货架ID']] = a[['货架ID']].astype(int)
b = a[['货架ID','货架经度','货架纬度']]
np.set_printoptions(suppress=True)
data = []
i = 1
for indexs in b.index:
    data_2 = []
    data_1 = b.loc[indexs].values[0:3]
    str_data = [str(data_1[1]),',',str(data_1[2])]
    location_str = ''.join(str_data)
    print(location_str)
    township_str, search_address_json = search_address_detail(location=location_str)
    data_2.append(data_1[0])
    data_2.append(township_str)
    data.append(data_2)
    i = i+1
    print(i)
print(data)

data = pd.DataFrame(data,columns=['货架ID','街道'])
data.to_excel('d:/user/01386340/desktop/结果表/佛山1111.xlsx',index=False)