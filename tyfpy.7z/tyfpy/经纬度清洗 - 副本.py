# -*- coding: utf-8 -*-
import math
import pandas as pd
import numpy as np
import datetime
import time
import re
import pymysql
from numpy import *
from sqlalchemy import create_engine


# 地球数据
x_pi = math.pi * 3000.0 / 180.0
a = 6378245.0  # 长半轴
ee = 0.00669342162296594323  # 偏心率平方

def transformlat(lng, lat):
    ret = -100.0 + 2.0 * lng + 3.0 * lat + 0.2 * lat * lat + \
        0.1 * lng * lat + 0.2 * math.sqrt(math.fabs(lng))
    ret += (20.0 * math.sin(6.0 * lng * math.pi) + 20.0 *
            math.sin(2.0 * lng * math.pi)) * 2.0 / 3.0
    ret += (20.0 * math.sin(lat * math.pi) + 40.0 *
            math.sin(lat / 3.0 * math.pi)) * 2.0 / 3.0
    ret += (160.0 * math.sin(lat / 12.0 * math.pi) + 320 *
            math.sin(lat * math.pi / 30.0)) * 2.0 / 3.0
    return ret

def transformlng(lng, lat):
    ret = 300.0 + lng + 2.0 * lat + 0.1 * lng * lng + \
        0.1 * lng * lat + 0.1 * math.sqrt(math.fabs(lng))
    ret += (20.0 * math.sin(6.0 * lng * pi) + 20.0 *
            math.sin(2.0 * lng * math.pi)) * 2.0 / 3.0
    ret += (20.0 * math.sin(lng * math.pi) + 40.0 *
            math.sin(lng / 3.0 * math.pi)) * 2.0 / 3.0
    ret += (150.0 * math.sin(lng / 12.0 * pi) + 300.0 *
            math.sin(lng / 30.0 * math.pi)) * 2.0 / 3.0
    return ret

# 百度坐标系经纬度数据并转换为火星坐标
def bd09_to_gcj02(lng, lat):
    x = lng - 0.0065
    y = lat - 0.006
    z = math.sqrt(x * x + y * y) - 0.00002 * math.sin(y * x_pi)
    theta = math.atan2(y, x) - 0.000003 * math.cos(x * x_pi)
    gg_lng = z * math.cos(theta)
    gg_lat = z * math.sin(theta)
    return [gg_lng, gg_lat]

# 火星坐标系经纬度数据并转换为WGS84坐标
def gcj02_to_wgs84(lng, lat):
    dlat = transformlat(lng - 105.0, lat - 35.0)
    dlng = transformlng(lng - 105.0, lat - 35.0)
    radlat = lat / 180.0 * math.pi
    magic = math.sin(radlat)
    magic = 1 - ee * magic * magic
    sqrtmagic = math.sqrt(magic)
    dlat = (dlat * 180.0) / ((a * (1 - ee)) / (magic * sqrtmagic) * math.pi)
    dlng = (dlng * 180.0) / (a / sqrtmagic * math.cos(radlat) * math.pi)
    mglat = lat + dlat
    mglng = lng + dlng
    return [lng * 2 - mglng, lat * 2 - mglat]

# 百度坐标系经纬度数据并转换为WGS84坐标
def bd09_to_wgs84(lng, lat):
    lng, lat = bd09_to_gcj02(lng, lat)
    return gcj02_to_wgs84(lng, lat)

def wgs84_to_gcj02(lng, lat):
    """
    WGS84转GCJ02(火星坐标系)
    :param lng:WGS84坐标系的经度
    :param lat:WGS84坐标系的纬度
    :return:
    """
    dlat = transformlat(lng - 105.0, lat - 35.0)
    dlng = transformlng(lng - 105.0, lat - 35.0)
    radlat = lat / 180.0 * math.pi
    magic = math.sin(radlat)
    magic = 1 - ee * magic * magic
    sqrtmagic = math.sqrt(magic)
    dlat = (dlat * 180.0) / ((a * (1 - ee)) / (magic * sqrtmagic) * math.pi)
    dlng = (dlng * 180.0) / (a / sqrtmagic * math.cos(radlat) * math.pi)
    mglat = lat + dlat
    mglng = lng + dlng
    return [mglng, mglat]

def gcj02_to_bd09(lng, lat):
    """
    火星坐标系(GCJ-02)转百度坐标系(BD-09)
    谷歌、高德——>百度
    :param lng:火星坐标经度
    :param lat:火星坐标纬度
    :return:
    """
    z = math.sqrt(lng * lng + lat * lat) + 0.00002 * math.sin(lat * x_pi)
    theta = math.atan2(lat, lng) + 0.000003 * math.cos(lng * x_pi)
    bd_lng = z * math.cos(theta) + 0.0065
    bd_lat = z * math.sin(theta) + 0.006
    return [bd_lng, bd_lat]

# wgs84转bd
def wgs84_to_bd09(lng, lat):
    lng, lat = wgs84_to_gcj02(lng, lat)
    return gcj02_to_bd09(lng, lat)

# 执行sql
def get_sql(sql_n):
    # 创建游标
    cursor = db.cursor()
    # 执行sql语句,返回受影响的行数
    db.ping(reconnect=True)
    num = cursor.execute(sql_n)
    print('数据一共 ：',num,'条')
    # 获取结果集
    result = cursor.fetchall()
    col = cursor.description
    # print(result)
    # 关闭连接
    cursor.close()
    db.close()
    return result,col

# 补货盘点埋点货架经纬度（百度坐标系） -- 10.15后更改坐标系后数据
sql_1 = """
SELECT a.`action_type`,b.`SHELF_ID`,a.`lng`,a.`lat`
    FROM feods.`D_LO_node_monitor_data_after_cleanout` a
  JOIN fe.`sf_shelf_check` b
    ON a.`action_id` = b.`CHECK_ID` AND a.`action_type` = 1 AND a.`data_flag` = 1 AND a.`lng` IS NOT NULL AND b.`DATA_FLAG` = 1
    AND a.update_time >= DATE('20201015')
UNION ALL
SELECT a.`action_type`,b.`SHELF_ID`,a.`lng`,a.`lat`
     FROM feods.`D_LO_node_monitor_data_after_cleanout` a
  JOIN fe.`sf_product_fill_order` b
    ON a.`action_id` = b.`ORDER_ID` AND a.`action_type` = 2 AND a.`data_flag` = 1 AND a.`lng` IS NOT NULL AND b.`DATA_FLAG` = 1
    AND a.update_time >= DATE('20201015')"""

# 货架申请货架经纬度（wgs84）
sql_2 = """
SELECT '3' AS 'action_type',a.`SHELF_ID`,b.`LONGITUDE` as `lng`,b.`LATITUDE` as `lat`
    FROM fe.`sf_shelf_apply` a
  JOIN fe.`sf_shelf_apply_record` b
    ON a.`RECORD_ID` = b.`RECORD_ID` AND a.`DATA_FLAG` =1 AND b.`DATA_FLAG` = 1 AND b.`LATITUDE` IS NOT NULL AND a.`SHELF_ID` > 0"""

# 货架安装货架经纬度（wgs84）
sql_3 = """
SELECT '4' AS 'action_type',a.`shelf_id` as `SHELF_ID`,a.`longitude` as `lng`,a.`latitude` as `lat`
    FROM fe.`sf_shelf_logistics_task_install` a
WHERE a.`data_flag` = 1 AND a.`latitude` IS NOT NULL
ORDER BY 2"""

# 补货盘点埋点货架经纬度（wgs84） -- 10.15后更改坐标系前数据
sql_4 = """
SELECT a.`action_type`,b.`SHELF_ID`,a.`lng`,a.`lat`
    FROM feods.`D_LO_node_monitor_data_after_cleanout` a
  JOIN fe.`sf_shelf_check` b
    ON a.`action_id` = b.`CHECK_ID` AND a.`action_type` = 1 AND a.`data_flag` = 1 AND a.`lng` IS NOT NULL AND b.`DATA_FLAG` = 1
    AND a.update_time < DATE('20201015')
UNION ALL
SELECT a.`action_type`,b.`SHELF_ID`,a.`lng`,a.`lat`
     FROM feods.`D_LO_node_monitor_data_after_cleanout` a
  JOIN fe.`sf_product_fill_order` b
    ON a.`action_id` = b.`ORDER_ID` AND a.`action_type` = 2 AND a.`data_flag` = 1 AND a.`lng` IS NOT NULL AND b.`DATA_FLAG` = 1
    AND a.update_time < DATE('20201015')"""

# 创建数据库连接
try:
    db = pymysql.Connect(
        host='gz-cdb-2huk27sw.sql.tencentcdb.com',
        port=63298,
        user='',
        password='',
        db='fe',
        charset='utf8mb4')
except Exception as e:
    print(e)

def get_sql(sql_n):
    # 创建游标
    cursor = db.cursor()
    # 执行sql语句,返回受影响的行数
    db.ping(reconnect=True)
    num = cursor.execute(sql_n)
    print('数据一共 ：',num,'条')
    # 获取结果集
    result = cursor.fetchall()
    col = cursor.description
    # print(result)
    # 关闭连接
    cursor.close()
    db.close()
    return result,col

def get_DataFrame(result, col):
    title = []
    for i in col:
        title.append(i[0])
    result = np.array(result)
    data = pd.DataFrame(columns=title, data=result)
    return data

# 执行sql,获取经纬度数据
Fill_check_result_2,Fill_check_col_2 = get_sql(sql_1)
Shelf_apply_result,Shelf_apply_col = get_sql(sql_2)
Shelf_install_result,Shelf_install_col = get_sql(sql_3)
Fill_check_result_1,Fill_check_col_1 = get_sql(sql_4)
print('***************************  1')

# 结果转换DataFrame
data_bd09_Fill_check = get_DataFrame(Fill_check_result_2,Fill_check_col_2)
data_wgs84_Shelf_apply = get_DataFrame(Shelf_apply_result,Shelf_apply_col)
data_wgs84_Shelf_install = get_DataFrame(Shelf_install_result,Shelf_install_col)
data_wgs84_Fill_check = get_DataFrame(Fill_check_result_1,Fill_check_col_1)
print('***************************  2')

# 所有坐标系转换为wgs84
data_bd09_Fill_check['lng_1'] = data_bd09_Fill_check.apply(lambda x: bd09_to_wgs84(float(x['lng']),float(x['lat']))[0], axis=1)
data_bd09_Fill_check['lat_1'] = data_bd09_Fill_check.apply(lambda x: bd09_to_wgs84(float(x['lng']),float(x['lat']))[1], axis=1)
data_bd09_Fill_check[['lng','lat']] = data_bd09_Fill_check[['lng_1','lat_1']]
data_wgs84_Fill_check_1 = data_bd09_Fill_check[['SHELF_ID','action_type','lng','lat']]
data_wgs84_Shelf_apply = data_wgs84_Shelf_apply[['SHELF_ID','action_type','lng','lat']]
data_wgs84_Shelf_install = data_wgs84_Shelf_install[['SHELF_ID','action_type','lng','lat']]
data_wgs84_Fill_check_2 = data_wgs84_Fill_check[['SHELF_ID','action_type','lng','lat']]
print('***************************  3')

# 合并DataFrame
'''
SHELF_ID int COMMENT 货架ID
action_type int COMMENT 获取途径（1：补货，2：盘点，3：货架申请，4：货架安装）
lng float COMMENT 货架经度(WGS84坐标)
lat float COMMENT 货架纬度(WGS84坐标)
'''

data_wgs84_Shelf = pd.concat([data_wgs84_Fill_check_1,data_wgs84_Shelf_apply,data_wgs84_Shelf_install,data_wgs84_Fill_check_2],axis=0,ignore_index=True)
print(data_wgs84_Shelf)

# 清洗数据
data_wgs84_Shelf[['lng']] = data_wgs84_Shelf[['lng']].astype(float)
data_wgs84_Shelf[['lat']] = data_wgs84_Shelf[['lat']].astype(float)
data_wgs84_Shelf[['SHELF_ID']] = data_wgs84_Shelf[['SHELF_ID']].astype(int)
print(data_wgs84_Shelf.dtypes)
data_mean = data_wgs84_Shelf.groupby(by=['SHELF_ID'])['lng','lat'].mean().fillna(value=0)
data_std = data_wgs84_Shelf.groupby(by=['SHELF_ID'])['lng','lat'].std().fillna(value=0)
print(data_std)
print(data_mean)
print('*******************')

data = pd.merge(data_mean,data_std,how='outer',on=['SHELF_ID'])
print(data)
data['MAX_lng'] = data.apply(lambda x: float(x['lng_x'])+float(x['lng_y']), axis=1)
data['Min_lng'] = data.apply(lambda x: float(x['lng_x'])-float(x['lng_y']), axis=1)
data['MAX_lat'] = data.apply(lambda x: float(x['lat_x'])+float(x['lat_y']), axis=1)
data['Min_lat'] = data.apply(lambda x: float(x['lat_x'])-float(x['lat_y']), axis=1)
data = pd.merge(data_wgs84_Shelf,data,how='outer',on=['SHELF_ID'])
print(data)

a_1 = data[data['lng'] < data['Min_lng']][['SHELF_ID','lng','lat']]
a_2 = data[data['lng'] > data['MAX_lng']][['SHELF_ID','lng','lat']]
a_3 = data[data['lat'] < data['Min_lat']][['SHELF_ID','lng','lat']]
a_4 = data[data['lat'] > data['MAX_lat']][['SHELF_ID','lng','lat']]

data_insert = data[(data['lng'] >= data['Min_lng'])&(data['lng'] <= data['MAX_lng'])&(data['lat'] >= data['Min_lat'])&(data['lat'] <= data['MAX_lat'])][['SHELF_ID','lng','lat']]

data_outlier = pd.concat([a_1,a_2,a_3,a_4]).round({'lng': 5, 'lat': 5})
print(data_outlier)

data_insert = data_insert.groupby(by=['SHELF_ID'])['lng','lat'].mean().fillna(value=0).round({'lng': 5, 'lat': 5})
data_insert = data_insert.reset_index()
data_insert.rename(columns={'SHELF_ID':'shelf_id'},inplace=True)
data_insert['lng_bd'] = data_insert.apply(lambda x: wgs84_to_bd09(float(x['lng']),float(x['lat']))[0], axis=1)
data_insert['lat_bd'] = data_insert.apply(lambda x: wgs84_to_bd09(float(x['lng']),float(x['lat']))[1], axis=1)
data_insert['lng_bd'] = round(data_insert['lng_bd'],5)
data_insert['lat_bd'] = round(data_insert['lat_bd'],5)
print(data_insert)


engine = create_engine('mysql+pymysql://tangyunfeng:Mes87I&*uak7@gz-cdb-2huk27sw.sql.tencentcdb.com:63298/fe_dwd?charset=utf8')
sql_update = "UPDATE fe_dwd.dwd_lo_shelf_longitude_latitude SET data_flag=2;"
sql_delete = "DELETE FROM fe_dwd.dwd_lo_shelf_longitude_latitude WHERE data_flag = 2;"
try:
    engine.execute(sql_update)
    pd.io.sql.to_sql(data_insert, 'dwd_lo_shelf_longitude_latitude', con=engine, index=False, schema='fe_dwd',if_exists='append')
    print("Write to MySQL successfully!")
    engine.execute(sql_delete)
except Exception as e:
    print(e)
