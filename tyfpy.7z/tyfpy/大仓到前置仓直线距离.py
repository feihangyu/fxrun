from math import radians, cos, sin, asin, sqrt
import numpy as np
import xlrd
import pandas as pd
import xlsxwriter

file = 'd:/user/01386340/desktop/数据/大仓点位.xlsx'

wb = xlrd.open_workbook(filename=file)#打开文件
sheet1_name = wb.sheet_names()
print(sheet1_name)

# 获取Sheet数据
def get_shelf(sheet_i):
    sheet1 = wb.sheet_by_index(sheet_i-1)#通过索引获取表格
    dic_shelf = {}
    for i in range(0,sheet1.ncols):
        col = sheet1.col_values(i)
        key = col[0]
        dic_shelf[key] = col[1:len(col)]
    return dic_shelf

def get_fdb(sheet_i):
    sheet1 = wb.sheet_by_index(sheet_i-1)#通过索引获取表格
    dic_shelf = {}
    for i in range(0,b):
        col = sheet1.col_values(i)
        key = col[0]
        dic_shelf[key] = col[1:len(col)]
    return dic_shelf

# 经纬度距离
def haversine(lon1, lat1, lon2, lat2): # 经度1，纬度1，经度2，纬度2
    # 将十进制度数转化为弧度
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 6371.393 # 地球平均半径，单位为KM
    return c * r * 1000

a = get_shelf(1)
a = pd.DataFrame(a)
a_1 = a['大仓经度']
a_2 = a['前置站经度']
a_3 = a['大仓纬度']
a_4 = a['前置站纬度']
a_5 = []
a_6 = []
for i in range(0,a.shape[0]):
    a_6.append(float(haversine(a_1[i],a_3[i],a_2[i],a_4[i])))
    if a_1[i] >= a_2[i]:
        if a_3[i] >= a_4[i]:
            a_5.append('东北')
        else:
            a_5.append('东南')
    else:
        if a_3[i] >= a_4[i]:
            a_5.append('西北')
        else:
            a_5.append('西南')
a['direction'] = a_5
a['distance'] = a_6
print(a)

a.to_excel('d:/user/01386340/desktop/结果表/大仓点位.xlsx',index=False)