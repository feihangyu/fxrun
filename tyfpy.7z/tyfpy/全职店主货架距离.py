from math import radians, cos, sin, asin, sqrt
import numpy as np
import xlrd
import pandas as pd
import xlsxwriter

file = 'd:/user/01386340/desktop/数据/全网_1.xlsx'

wb = xlrd.open_workbook(filename=file)#打开文件
sheet1_name = wb.sheet_names()
print(sheet1_name)

# 获取Sheet数据
def get_shelf(sheet_i):
    sheet1 = wb.sheet_by_index(sheet_i-1)#通过索引获取表格
    dic_shelf = {}
    for i in range(0,sheet1.ncols):
        col = sheet1.col_values(i)
        key = col[0]
        dic_shelf[key] = col[1:len(col)]
    return dic_shelf

# 经纬度距离
def haversine(lon1, lat1, lon2, lat2): # 经度1，纬度1，经度2，纬度2
    # 将十进制度数转化为弧度
    lon1, lat1, lon2, lat2 = map(radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = sin(dlat/2)**2 + cos(lat1) * cos(lat2) * sin(dlon/2)**2
    c = 2 * asin(sqrt(a))
    r = 6371.393 # 地球平均半径，单位为KM
    return c * r * 1000

for k in range(7,8):
    a = get_shelf(k)
    print(a)
    dic_1 = {} #行政区字典，{行政区：【货架ID，经度，纬度】}
    data_0 = a['货架ID']
    data_1 = a['分部代码']
    data_2 = a['分部经度']
    data_3 = a['分部纬度']
    data_4 = a['货架经度']
    data_5 = a['货架纬度']
    data_7 = []
    data_8 = []
    data_10 = []

    for i in range(0,len(data_0)):
        data_6 = []
        data_6.append(data_0[i])
        data_6.append(data_4[i])
        data_6.append(data_5[i])
        data_7.append(data_6)
    data_all_1 = pd.DataFrame(data_7,columns=['货架ID','货架经度','货架纬度'])
    data_all_1[['货架ID']] = data_all_1[['货架ID']].astype(int)

    for i in range(0,len(data_1)):
        data_6 = []
        data_6.append(data_1[i])
        data_6.append(data_2[i])
        data_6.append(data_3[i])
        data_8.append(data_6)
    data_all_2 = pd.DataFrame(data_8,columns=['分部代码','分部经度','分部纬度'])

    data_all_1 = data_all_1.drop_duplicates()
    data_all_2 = data_all_2.drop_duplicates()
    data_all_1 = data_all_1.reset_index(drop=True)
    data_all_2 = data_all_2.reset_index(drop=True)
    data_all_2.drop([len(data_all_2)-1],inplace=True)
    print(data_all_1)
    print(data_all_2)

    g = 0
    for i in range(0,data_all_1.shape[0]):
        data_all_1_list = list(data_all_1.loc[i])
        for j in range(0,data_all_2.shape[0]):
            print(i,j,g,k)
            data_9 = []
            data_all_2_list = list(data_all_2.loc[j])
            data_9.append(data_all_1_list[0])
            data_9.append(data_all_2_list[0])
            if data_all_1_list[1] >= data_all_2_list[1]:
                if data_all_1_list[2] >= data_all_2_list[2]:
                    data_9.append('东北')
                else:
                    data_9.append('东南')
            else:
                if data_all_1_list[2] >= data_all_2_list[2]:
                    data_9.append('西北')
                else:
                    data_9.append('西南')
            data_9.append(haversine(data_all_1_list[1],data_all_1_list[2],data_all_2_list[1],data_all_2_list[2]))
            if data_9[3] <= 4000:
                g = g+1
                data_10.append(data_9)
            else:
                continue

    data_all = pd.DataFrame(data_10,columns=['货架ID','分部代码','方向','距离'])
    data_all = data_all.loc[(data_all['距离']<4000)]
    print(data_all)
    name = str(k)
    data_all.to_excel(f'd:/user/01386340/desktop/结果表/{name}.xlsx',index=False)