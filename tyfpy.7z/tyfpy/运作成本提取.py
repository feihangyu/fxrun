import os
import xlrd
import test_wy
import pandas as pd
from numpy import *
import numpy as np

month_name = input("请输入文件夹名称： ")

xpath=f"{month_name}"
xtype="xlsx"
typedata = []
name = []
raw_data=[]
file_path=[]
def collect_xls(list_collect,type1):
    #取得列表中所有的type文件
    for each_element in list_collect:
        if isinstance(each_element,list):
            collect_xls(each_element,type1)
        elif each_element.endswith(type1):
              typedata.insert(0,each_element)
    return typedata
#读取所有文件夹中的xls文件
def read_xls(path,type2):
    #遍历路径文件夹
    print(os.walk(path))
    for file in os.walk(path):
        print(file)
        for each_list in file[2]:
            file_path=file[0]+"/"+each_list
            name.insert(0,file_path)
        all_xls = collect_xls(name, type2)
    #遍历所有type文件路径并读取数据
    for evey_name in all_xls:
        sheet_data=test_wy.excel_table_byname(evey_name,11,25,'Sheet0')
        raw_data.insert(0, sheet_data)
        print(evey_name,'Sheet0',":Data has been done.")
    return raw_data

a = read_xls(xpath,xtype)
b = ['运单号码','对方地区','计费重量','产品类型','应付金额','订单id','商品金额','补货类型','前置站ID']
b_1 = ['运单号码','城市','计费重量','产品类型','应付金额','订单ID','商品金额','补货类型','前置站ID']
c = mat(zeros((0, 9)))
for i in a:
    for j in i:
        data_a = []
        try:
            data_a.append(j[b[0]])
            data_a.append(j[b[1]])
            data_a.append(j[b[2]])
            data_a.append(j[b[3]])
            data_a.append(j[b[4]])
            try:
                data_a.append(j[b[5]])
            except:
                data_a.append(j['订单号'])
            data_a.append(j[b[6]])
            data_a.append(j[b[7]])
            try:
                data_a.append(j[b[8]])
            except:
                try:
                    data_a.append(j['前置站'])
                except:
                    data_a.append('')
            data_a = np.array(data_a)
            data_at = data_a.T
            c = np.row_stack((c, data_at))
        except: print('error name :',j)
        # print(c)

name_return = month_name
df = pd.DataFrame(np.array(c))
df.to_excel(f'{name_return}.xlsx',index=False,header=b_1)