# -*- coding: utf-8 -*-
import math
import pandas as pd
import numpy as np
import datetime
from sshtunnel import SSHTunnelForwarder
import pymysql
from sqlalchemy import create_engine


class TransformLatLng():  # 经纬度坐标系切换
    # 地球数据
    x_pi = math.pi * 3000.0 / 180.0
    a = 6378245.0  # 长半轴
    ee = 0.00669342162296594323  # 偏心率平方

    def __init__(self, lng, lat):
        self.lng = lng
        self.lat = lat

    # 维度调整
    def transformlat(self):
        ret = -100.0 + 2.0 * self.lng + 3.0 * self.lat + 0.2 * self.lat * self.lat + \
              0.1 * self.lng * self.lat + 0.2 * math.sqrt(math.fabs(self.lng))
        ret += (20.0 * math.sin(6.0 * self.lng * math.pi) + 20.0 *
                math.sin(2.0 * self.lng * math.pi)) * 2.0 / 3.0
        ret += (20.0 * math.sin(self.lat * math.pi) + 40.0 *
                math.sin(self.lat / 3.0 * math.pi)) * 2.0 / 3.0
        ret += (160.0 * math.sin(self.lat / 12.0 * math.pi) + 320 *
                math.sin(self.lat * math.pi / 30.0)) * 2.0 / 3.0
        return ret

    # 经度调整
    def transformlng(self):
        ret = 300.0 + self.lng + 2.0 * self.lat + 0.1 * self.lng * self.lng + \
              0.1 * self.lng * self.lat + 0.1 * math.sqrt(math.fabs(self.lng))
        ret += (20.0 * math.sin(6.0 * self.lng * math.pi) + 20.0 *
                math.sin(2.0 * self.lng * math.pi)) * 2.0 / 3.0
        ret += (20.0 * math.sin(self.lng * math.pi) + 40.0 *
                math.sin(self.lng / 3.0 * math.pi)) * 2.0 / 3.0
        ret += (150.0 * math.sin(self.lng / 12.0 * math.pi) + 300.0 *
                math.sin(self.lng / 30.0 * math.pi)) * 2.0 / 3.0
        return ret

    # 火星坐标系经纬度数据并转换为WGS84坐标
    def gcj02_to_wgs84(self):
        dlat = TransformLatLng.transformlat(self)
        dlng = TransformLatLng.transformlng(self)
        radlat = self.lat / 180.0 * math.pi
        magic = math.sin(radlat)
        magic = 1 - TransformLatLng.ee * magic * magic
        sqrtmagic = math.sqrt(magic)
        dlat = (dlat * 180.0) / ((TransformLatLng.a * (1 - TransformLatLng.ee)) / (magic * sqrtmagic) * math.pi)
        dlng = (dlng * 180.0) / (TransformLatLng.a / sqrtmagic * math.cos(radlat) * math.pi)
        mglat = self.lat + dlat
        mglng = self.lng + dlng
        return [self.lng * 2 - mglng, self.lat * 2 - mglat]

class RunsqltoDataFrame():  # 运行sql并把结果转换为DataFrame
    def __init__(self, sql, db):
        self.sql = sql
        self.db = db
    def get_sql(self):  # 执行sql
        # 创建游标
        cursor = self.db.cursor()
        # 执行sql语句,返回受影响的行数
        self.db.ping(reconnect=True)
        num = cursor.execute(self.sql)
        print('数据一共 ：', num, '条')
        # 获取结果集
        result = cursor.fetchmany(num)
        col = cursor.description
        # print(result)
        # 关闭连接
        cursor.close()
        self.db.close()
        title = []
        for i in col:
            title.append(i[0])
        result = np.array(result)
        data = pd.DataFrame(columns=title, data=result)
        return data

def haversine(lon1, lat1, lon2, lat2):  # 经度1，纬度1，经度2，纬度2  求直线距离
    # 将十进制度数转化为弧度
    lon1, lat1, lon2, lat2 = map(math.radians, [lon1, lat1, lon2, lat2])
    dlon = lon2 - lon1
    dlat = lat2 - lat1
    a = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlon / 2) ** 2
    c = 2 * math.asin(math.sqrt(a))
    r = 6371.393  # 地球平均半径，单位为KM
    return c * r * 1000

def update_month_fill_type(month_fill_type, distance):  # 判断距离在 100米外增加疑似虚假原因 3
    if month_fill_type == '4':
        if distance <= 100:
            return 4
        else:
            return 3
    else:
        if distance <= 100:
            return month_fill_type
        else:
            return '%s,%s' % (month_fill_type, '3')


if __name__ == '__main__':
    '''
    # SSH跳转机连接信息
    ssh_address = '122.51.112.49' # 指定ssh登录的跳转机的address
    ssh_port = '26534'
    ssh_username =   # 跳转机的用户
    ssh_password =   # 跳转机的密码
    remote_bind_address = 'gz-cdb-2huk27sw.sql.tencentcdb.com'
    remote_bind_port = '63298'

    # 连接跳板机
    try:
        server = SSHTunnelForwarder(
            ssh_address_or_host=(ssh_address,int(ssh_port)),  # 指定ssh登录的跳转机的address
            ssh_username=ssh_username,  # 跳转机的用户
            ssh_password=ssh_password,  # 跳转机的密码
            remote_bind_address=(remote_bind_address,int(remote_bind_port))
        )
        server.start()
        print('连接跳板机成功')
    except Exception as e:
        print(e, '异常发生时间%s' % datetime.datetime.now())
    '''

    # 数据库连接信息
    host = 'gz-cdb-2huk27sw.sql.tencentcdb.com'  # "127.0.0.1" 跳板机连接
    port = 63298 # server.local_bind_port 跳板机连接
    user = ''
    password = ''
    db_name = 'fe'
    charset = 'utf8mb4'

    try:
        conn = pymysql.Connect(
            host=host,
            port=port,
            user=user,
            password=password,
            db=db_name,
            charset=charset)
        print('连接数据库成功%s' % datetime.datetime.now())
    except Exception as e:
        print(e, '异常发生时间%s' % datetime.datetime.now())

    # 自动获取日期做前一日增量更新
    start_day = (datetime.date.today() + datetime.timedelta(days=-1)).strftime('%Y%m%d')
    end_day = datetime.date.today().strftime('%Y%m%d')

    # '疑似原因(1:上架时间异常,2:上架后GMV下降,3:定位埋点异常,4:月度普查)'
    sql_1 = """
    SELECT
        DATE_FORMAT(a.`FILL_TIME`, '%%Y%%m%%d') AS stat_date,
        a.ORDER_ID,
        a.`FILL_TYPE`, 
        a.`FILL_TIME` fill_time,
        c.business_name business_area,
        a.shelf_id,
        c.`PROVINCE`,
        c.`CITY`,
        c.`DISTRICT`,
        c.shelf_type,
        a.`FILL_USER_ID`,
        b.`REAL_NAME` FILL_USER_NAME,
        b.`SF_CODE`,
        CASE
        WHEN DATE_FORMAT(a.FILL_TIME, '%%H') IN ('22','23','00','01','02','03','04','05','06','07') AND t0.shelf_id IS NULL THEN '1'
        WHEN DATE_FORMAT(a.FILL_TIME, '%%H') NOT IN ('22','23','00','01','02','03','04','05','06','07') AND t0.shelf_id THEN '2'
        WHEN DATE_FORMAT(a.FILL_TIME, '%%H') IN ('22','23','00','01','02','03','04','05','06','07') AND t0.shelf_id THEN '1,2'
        ELSE '4' END month_fill_type
      FROM
        fe.sf_product_fill_order a
       LEFT JOIN fe.`pub_shelf_manager` b
              ON a.`FILL_USER_ID` = b.`MANAGER_ID`
              AND b.`DATA_FLAG` = 1
       LEFT JOIN fe_dwd.`dwd_shelf_base_day_all` c
              ON a.shelf_id = c.shelf_id
              AND c.`DATA_FLAG` = 1
       LEFT JOIN 
       (SELECT
      sub.fill_date,
      sub.shelf_id,
      sub.shelf_type,
      IF(SUM(
        IF(
          od.work_day_seq >= sub.before_workday_seq
          AND od.work_day_seq < sub.fill_date_seq,
          od.sale_price * od.quantity,
          0
        )
      ) = 0,
          IF( SUM(
        IF(
          od.work_day_seq > sub.fill_date_seq
          AND od.work_day_seq <= sub.after_workday_seq,
          od.sale_price * od.quantity,
          0
        )
      ) = 0, 0, 1),
      SUM(
        IF(
          od.work_day_seq > sub.fill_date_seq
          AND od.work_day_seq <= sub.after_workday_seq,
          od.sale_price * od.quantity,
          0
        )
      ) / SUM(
        IF(
          od.work_day_seq >= sub.before_workday_seq
          AND od.work_day_seq < sub.fill_date_seq,
          od.sale_price * od.quantity,
          0
        )
      ) - 1) AS A
    FROM
      (SELECT
        DATE(a.fill_time) AS fill_date,
        c.business_area,
        a.ORDER_ID,
        a.shelf_id,
        a.fill_user_id,
        d.shelf_type,
        a.supplier_type,
        b.work_day_seq AS fill_date_seq,
        b.work_day_seq - 2 AS before_workday_seq,
        b.work_day_seq + 2 AS after_workday_seq
      FROM
        fe.sf_product_fill_order a,
        fe.`sf_shelf` d,
        fe.`zs_city_business` c,
        feods.fjr_work_days b
      WHERE a.ORDER_STATUS IN (2, 3, 4)
        AND a.fill_type IN (1, 2, 8, 9, 10)
        AND d.shelf_type IN (1,2,3,5)
        AND a.supplier_type IN (2, 9)
        AND a.FILL_TIME >= DATE_ADD(CURDATE(),INTERVAL -DAY(CURDATE())+1 DAY)
        AND a.fill_time < CURDATE()
        AND DATE(a.fill_time) = b.sdate
        AND a.shelf_id = d.shelf_id
        AND SUBSTRING_INDEX(SUBSTRING_INDEX(d.area_address,',',2),',',-1)=c.city_name
        AND b.if_work_day = 1) sub  --   货架补货时间以及前后两个工作日的序列维表
        INNER JOIN
       (SELECT
        o.shelf_id,
        o.sale_price,
        o.quantity,
        w.sdate,
        w.work_day_seq
      FROM
        feods.sf_order_item_temp o,
        feods.fjr_work_days w
      WHERE w.sdate = DATE(o.order_date)
        AND w.if_work_day = 1
        AND w.sdate >= DATE_ADD(CURDATE(),INTERVAL -DAY(CURDATE())+1 DAY)
        AND w.sdate < CURDATE()) od   -- 货架订单时间相应序列以及销售订单数据
     ON sub.shelf_id = od.shelf_id
     LEFT JOIN fe.`pub_shelf_manager` pm
     ON pm.manager_id = sub.fill_user_id
    GROUP BY
      sub.fill_date,sub.shelf_id
      HAVING A < -0.4) t0
    ON DATE(a.`FILL_TIME`) = t0.fill_date
    AND a.shelf_id = t0.shelf_id
      WHERE a.ORDER_STATUS IN (2, 3, 4)
        AND a.fill_type IN (1, 2, 7, 8, 9)
        AND c.shelf_type IN (1,2,3,5,6,7)
        AND a.FILL_TIME >= DATE(%s)
        AND a.FILL_TIME < DATE(%s)
        AND a.`DATA_FLAG` = 1
    order by a.`FILL_TIME`;""" % (start_day, end_day)

    # 埋点数据对应货架经纬度
    sql_2 = """SELECT c.`action_id` ORDER_ID,a.`shelf_id`,c.`lng`,c.`lat`,a.`lng` lng_1,a.`lat` lat_1
    FROM fe_dwd.`dwd_shelf_base_day_all` a
    JOIN fe.`sf_product_fill_order` b
    ON a.`shelf_id` = b.`SHELF_ID`
    AND a.`DATA_FLAG` = 1 AND b.`DATA_FLAG` = 1
    AND b.ORDER_STATUS IN (2, 3, 4)
    AND b.fill_type IN (1, 2, 7, 8, 9)
    AND a.shelf_type IN (1,2,3,5,6,7)
    AND b.FILL_TIME >= DATE(%s)
    AND b.FILL_TIME < DATE(%s)
    JOIN feods.`D_LO_node_monitor_data_after_cleanout` c
    ON b.`ORDER_ID` = c.`action_id`
    AND c.`data_flag` = 1
    AND c.action_type = 2
    AND c.action_time >= DATE(%s)
    AND c.action_time < DATE(%s);""" % (start_day, end_day, start_day, end_day)

    # 执行sql,获取数据
    try:
        data_Fill = RunsqltoDataFrame(sql_1,conn).get_sql()
    except Exception as e:
        print(e, 'sql1 异常发生时间%s' % datetime.datetime.now())
    try:
        data_Shelf = RunsqltoDataFrame(sql_2,conn).get_sql()
        print(data_Shelf)
    except Exception as e:
        print(e, 'sql2 异常发生时间%s' % datetime.datetime.now())
    print('*************************** 执行sql转为DataFrame-时间为%s' % datetime.datetime.now())

    # 所有坐标系转换为wgs84
    try:
        data_Shelf['lng_2'] = data_Shelf.apply(
            lambda x: TransformLatLng(float(x['lng']), float(x['lat'])).gcj02_to_wgs84()[0], axis=1)
        data_Shelf['lat_2'] = data_Shelf.apply(
            lambda x: TransformLatLng(float(x['lng']), float(x['lat'])).gcj02_to_wgs84()[1], axis=1)
        data_Shelf[['lng', 'lat']] = data_Shelf[['lng_2', 'lat_2']]
        data_Shelf = data_Shelf[['ORDER_ID', 'lng', 'lat', 'lng_1', 'lat_1']]
        data_Shelf[['lng', 'lat', 'lng_1', 'lat_1']] = data_Shelf[['lng', 'lat', 'lng_1', 'lat_1']].astype(float)
    except Exception as e:
        print(e, '坐标转换异常发生时间%s' % datetime.datetime.now())
    print('*************************** DataFrame坐标转换-时间为%s' % datetime.datetime.now())

    # 坐标求距离，打疑似虚假标签
    data = pd.merge(data_Fill, data_Shelf, how='outer', on=['ORDER_ID'])
    data = data.fillna(0)
    data.rename(columns={'ORDER_ID': 'order_id'}, inplace=True)
    data['month_fill_type_1'] = data.apply( lambda x: haversine(float(x['lng']), float(x['lat']),
                                          float(x['lng_1']), float(x['lat_1'])), axis=1)
    data['month_fill_type'] = data.apply(lambda x: update_month_fill_type(x['month_fill_type'],
                                        x['month_fill_type_1']),axis=1)
    data = data[
        ['stat_date', 'order_id', 'FILL_TYPE', 'fill_time', 'business_area', 'PROVINCE', 'CITY', 'DISTRICT', 'shelf_id',
         'shelf_type', 'FILL_USER_ID', 'FILL_USER_NAME', 'SF_CODE', 'month_fill_type']]
    data[['stat_date']] = data[['stat_date']].astype(int)

    print(data)



    # # 增量写入数据库,删除更新时间段历史数据，插入数据并把虚拟货架、自贩机、校园、前置仓设置为不审核
    # engine = create_engine(
    #     'mysql+pymysql://{}:{}@{}:{}/{}?charset=utf8'.format(user, password, '127.0.0.1', port, db_name))
    # sql_3 = "DELETE FROM fe_dm.`dm_lo_fill_for_month_label` WHERE fill_time >= DATE('%s') and fill_time < DATE('%s');" % (start_day, end_day)
    # engine.execute(sql_3)
    # pd.io.sql.to_sql(data, 'dm_lo_fill_for_month_label', con=engine, index=False, schema='fe_dm', if_exists='append')
    # sql_4 = "UPDATE fe_dm.dm_lo_fill_for_month_label SET if_audit=2 where shelf_type in (4,8,9)"
    # engine.execute(sql_4)
    # print('*************************** Write to MySQL successfully!时间为%s' % datetime.datetime.now())