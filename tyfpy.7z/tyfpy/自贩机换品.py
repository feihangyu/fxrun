# -*- coding: utf-8 -*-
import xlrd
import math
import pandas as pd
import numpy as np
import datetime
import pymysql



class RunsqltoDataFrame():  # 运行sql并把结果转换为DataFrame
    def __init__(self, sql, db):
        self.sql = sql
        self.db = db
    def get_sql(self):  # 执行sql
        # 创建游标
        cursor = self.db.cursor()
        # 执行sql语句,返回受影响的行数
        self.db.ping(reconnect=True)
        num = cursor.execute(self.sql)
        print('数据一共 ：', num, '条')
        # 获取结果集
        result = cursor.fetchmany(num)
        col = cursor.description
        # print(result)
        # 关闭连接
        cursor.close()
        self.db.close()
        title = []
        for i in col:
            title.append(i[0])
        result = np.array(result)
        data = pd.DataFrame(columns=title, data=result)
        return data

    # 获取Sheet数据
    def get_sheet(wb,sheet_i):
        sheet1 = wb.sheet_by_index(sheet_i - 1)  # 通过索引获取表格
        dic_shelf = {}
        for i in range(0, sheet1.ncols):
            col = sheet1.col_values(i)
            key = col[0]
            dic_shelf[key] = col[1:len(col)]
        return dic_shelf

if __name__ == '__main__':

    # 数据库连接信息
    host = '111.230.187.245'  # "127.0.0.1" 跳板机连接
    port = 63298 # server.local_bind_port 跳板机连接
    user = ''
    password = ''
    db_name = 'fe'
    charset = 'utf8mb4'

    try:
        conn = pymysql.Connect(
            host=host,
            port=port,
            user=user,
            password=password,
            db=db_name,
            charset=charset)
        print('连接数据库成功%s' % datetime.datetime.now())
    except Exception as e:
        print(e, '异常发生时间%s' % datetime.datetime.now())

    # 自动获取日期做前一日增量更新
    stday = datetime.date.today().strftime('%Y%m%d')

    # 获取贩卖机商品汰换表
    sql_1 = """SELECT
                  a.`business_name`,
                  a.`shelf_id`,
                  a.`gmv`,
                  a.`change_type`,
                  a.`slot_id`,
                  a.`manufacturer_slot_code`,
                  a.`slot_type_id`,
                  a.`product_id`,
                  a.`stock_num`,
                  a.`SALE_PRICE`,
                  a.`shelf_sku`,
                  a.`change_product_id_slot`,
                  a.`SALES_FLAG`,
                  a.`change_product_slot_price`,
                  a.`DAY_AVG_SALE_NUM`,
                  a.`change_product_id_second`,
                  a.`second_stock_num`,
                  a.`change_second_slots`,
                  a.`change_second_sku`,
                  a.`change_product_id_area`,
                  a.`change_area_avg_sale`,
                  a.`change_area_slots`,
                  a.`change_area_sku`,
                  a.`slots`,
                  a.`perfect_slots`
                FROM dwd_shelf_machine_slot_product_change a
                WHERE a.data_flag = 1 AND a.sdate = DATE('%s') AND a.business_name IS NOT NULL
                ;""" % (stday)


    # 执行sql,获取数据
    try:
        data_product_change = RunsqltoDataFrame(sql_1,conn).get_sql()
        print('*************************** 执行sql_1转为DataFrame-时间为%s' % datetime.datetime.now())

    except Exception as e:
        print(e, 'sql_1异常发生时间%s' % datetime.datetime.now())

    print(data_product_change)



    def choose_change_type(id_1,id_2,id_3,slots,perfect_slots):
        if id_1 > 0:
            if slots <= perfect_slots:
                return [id_1, '1']
            elif id_2 > 0:
                return [id_2, '2']
            elif id_3 > 0:
                return [id_3, '3']
        elif id_2 > 0:
                return [id_2, '2']
        elif id_3 > 0:
            return [id_3, '3']
        else:
            return ['0', '4']

    data_product_change = data_product_change.fillna(0)
    data_product_change['shelf_id'] = data_product_change['shelf_id'].apply(int)
    data_product_change['shelf_sku'] = data_product_change['shelf_sku'].apply(int)
    shelf_id_list = data_product_change['shelf_id'].drop_duplicates().values.tolist()
    print(shelf_id_list)

    # 抽取每个货架可替换方案
    for i in shelf_id_list:
        print(i)
        data_shelf = data_product_change[data_product_change['shelf_id'] == i]
        shelf_sku = data_shelf['shelf_sku'].drop_duplicates().values[0]
        slot_id_list = data_shelf['slot_id'].drop_duplicates().values.tolist()

        # 判断货架SKU数并进行不同方案优先级排序 （参数:23）
        if shelf_sku > 23:
            data_shelf.sort_values(
                ['stock_num', 'slot_id', 'slots', 'DAY_AVG_SALE_NUM', 'second_stock_num', 'change_area_avg_sale'],
                ascending=(True, True, True, False, True, False))
            print(data_shelf)

            # 抽取每个货道逐个配置
            for j in slot_id_list:
                data_slot = data_shelf[data_shelf['slot_id'] == j]
                data_slot['slot_change_type'] = data_slot.apply(
                    lambda x: choose_change_type(int(x['change_product_id_slot']), int(x['change_product_id_second']),
                                                 int(x['change_product_id_area']), int(x['slots']),
                                                 int(x['perfect_slots']))[1], axis=1)
                data_slot['slot_change_id'] = data_slot.apply(
                    lambda x: choose_change_type(int(x['change_product_id_slot']), int(x['change_product_id_second']),
                                                 int(x['change_product_id_area']), int(x['slots']),
                                                 int(x['perfect_slots']))[0], axis=1)
                data_slot.sort_values(['slot_change_type'], ascending=True)
                print(data_slot)
        else:
            data_shelf.sort_values(
                ['stock_num', 'slot_id', 'second_stock_num', 'change_area_avg_sale', 'slots', 'DAY_AVG_SALE_NUM'],
                ascending=(True, True, True, False, True, False))
            print(data_shelf)

    # file = 'd:/user/01386340/desktop/数据/自贩机换品.xlsx'
    #
    # wb = xlrd.open_workbook(filename=file)  # 打开文件
    # sheet1_name = wb.sheet_names()
    # print(sheet1_name)
    #
    # df = pd.DataFrame.from_dict(get_sheet(wb,1))
    # df = df.fillna(0)
    # df['shelf_id'] = df['shelf_id'].apply(int)
    # df['shelf_sku'] = df['shelf_sku'].apply(int)
    # shelf_id_list = df['shelf_id'].drop_duplicates().values.tolist()
    # print(shelf_id_list)
    #
    # # 抽取每个货架可替换方案
    # for i in shelf_id_list:
    #     print(i)
    #     data_shelf = df[df['shelf_id'] == i]
    #     shelf_sku = data_shelf['shelf_sku'].drop_duplicates().values[0]
    #     slot_id_list = data_shelf['slot_id'].drop_duplicates().values.tolist()
    #
    #     # 判断货架SKU数并进行不同方案优先级排序 （参数:23种）
    #     if shelf_sku > 23:
    #         data_shelf.sort_values(
    #             ['stock_num', 'slot_id', 'slots', 'DAY_AVG_SALE_NUM', 'second_stock_num', 'change_area_avg_sale'],
    #             ascending=(True, True, True, False, True, False))
    #         print(data_shelf)
    #
    #         # 抽取每个货道逐个配置
    #         for j in slot_id_list:
    #             data_slot = data_shelf[data_shelf['slot_id'] == j]
    #             data_slot['slot_change_type'] = data_slot.apply(
    #                 lambda x: choose_change_type(int(x['change_product_id_slot']), int(x['change_product_id_second']),
    #                                              int(x['change_product_id_area']), int(x['slots']),
    #                                              int(x['perfect_slots']))[1], axis=1)
    #             data_slot['slot_change_id'] = data_slot.apply(
    #                 lambda x: choose_change_type(int(x['change_product_id_slot']), int(x['change_product_id_second']),
    #                                              int(x['change_product_id_area']), int(x['slots']),
    #                                              int(x['perfect_slots']))[0], axis=1)
    #             data_slot.sort_values(['slot_change_type'], ascending=True)
    #             print(data_slot)
    #     else:
    #         data_shelf.sort_values(
    #             ['stock_num', 'slot_id', 'second_stock_num', 'change_area_avg_sale', 'slots', 'DAY_AVG_SALE_NUM'],
    #             ascending=(True, True, True, False, True, False))
    #         print(data_shelf)